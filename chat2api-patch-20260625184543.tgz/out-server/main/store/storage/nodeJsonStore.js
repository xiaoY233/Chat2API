"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const fs = require("fs");
const path = require("path");
class NodeJsonStore {
  constructor(options) {
    fs.mkdirSync(options.cwd, { recursive: true });
    this.filePath = path.join(options.cwd, `${options.name}.json`);
    this.data = { ...options.defaults };
    if (fs.existsSync(this.filePath)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(this.filePath, "utf8"));
        this.data = { ...this.data, ...parsed };
      } catch {
        fs.renameSync(this.filePath, path.join(options.cwd, `${options.name}.corrupted.${Date.now()}.json`));
        this.persist();
      }
    } else {
      this.persist();
    }
  }
  get(key) {
    return this.data[key];
  }
  set(key, value) {
    this.data = {
      ...this.data,
      [key]: value
    };
    this.persist();
  }
  delete(key) {
    const next = { ...this.data };
    delete next[key];
    this.data = next;
    this.persist();
  }
  clear() {
    this.data = {};
    this.persist();
  }
  persist() {
    fs.writeFileSync(this.filePath, `${JSON.stringify(this.data, null, 2)}
`, "utf8");
  }
}
exports.NodeJsonStore = NodeJsonStore;
