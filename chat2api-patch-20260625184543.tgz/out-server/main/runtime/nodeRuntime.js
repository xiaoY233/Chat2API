"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const crypto = require("crypto");
const fs = require("fs");
const os = require("os");
const path = require("path");
const ENCRYPTION_PREFIX = "c2a:v1:";
function getEncryptionKey() {
  const secret = process.env.CHAT2API_STORAGE_ENCRYPTION_KEY;
  if (!secret) {
    return null;
  }
  return crypto.createHash("sha256").update(secret).digest();
}
const nodeRuntime = {
  kind: "node",
  getDataDir() {
    if (process.env.CHAT2API_DATA_DIR) {
      return path.resolve(process.env.CHAT2API_DATA_DIR);
    }
    if (process.env.NODE_ENV === "production") {
      return "/data";
    }
    return path.join(os.homedir(), ".chat2api");
  },
  isEncryptionAvailable() {
    return getEncryptionKey() !== null;
  },
  encryptString(value) {
    const key = getEncryptionKey();
    if (!key) {
      return value;
    }
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
    const encrypted = Buffer.concat([cipher.update(value, "utf8"), cipher.final()]);
    const tag = cipher.getAuthTag();
    return `${ENCRYPTION_PREFIX}${Buffer.concat([iv, tag, encrypted]).toString("base64")}`;
  },
  decryptString(value) {
    const key = getEncryptionKey();
    if (!key || !value.startsWith(ENCRYPTION_PREFIX)) {
      return value;
    }
    const payload = Buffer.from(value.slice(ENCRYPTION_PREFIX.length), "base64");
    const iv = payload.subarray(0, 12);
    const tag = payload.subarray(12, 28);
    const encrypted = payload.subarray(28);
    const decipher = crypto.createDecipheriv("aes-256-gcm", key, iv);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(encrypted), decipher.final()]).toString("utf8");
  },
  getResourcePath(fileName) {
    const candidates = [
      path.resolve(process.cwd(), fileName),
      path.resolve(process.cwd(), "resources", fileName),
      path.resolve(__dirname, "..", "..", "..", fileName)
    ];
    return candidates.find((candidate) => fs.existsSync(candidate)) || candidates[0];
  },
  async openExternal(url) {
    console.log(`[Runtime] Open this URL manually: ${url}`);
  },
  notify() {
  }
};
exports.nodeRuntime = nodeRuntime;
