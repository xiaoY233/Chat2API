"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
const server_bootstrapConfig = require("./bootstrapConfig.js");
const main_runtime_nodeRuntime = require("../main/runtime/nodeRuntime.js");
const Koa = require("koa");
const Router = require("@koa/router");
const bodyParser = require("koa-bodyparser");
const stream = require("stream");
const axios = require("axios");
const fs = require("fs");
const crypto$1 = require("crypto");
const eventsourceParser = require("eventsource-parser");
const FormData = require("form-data");
const mime = require("mime-types");
const path = require("path");
const zlib = require("zlib");
const ZstdCodec = require("zstd-codec");
const OSS = require("ali-oss");
const http2 = require("http2");
const http = require("http");
require("os");
require("node:fs");
require("node:path");
require("../main/store/storage/nodeJsonStore.js");
function _interopNamespaceDefault(e) {
  const n = Object.create(null, { [Symbol.toStringTag]: { value: "Module" } });
  if (e) {
    for (const k in e) {
      if (k !== "default") {
        const d = Object.getOwnPropertyDescriptor(e, k);
        Object.defineProperty(n, k, d.get ? d : {
          enumerable: true,
          get: () => e[k]
        });
      }
    }
  }
  n.default = e;
  return Object.freeze(n);
}
const ZstdCodec__namespace = /* @__PURE__ */ _interopNamespaceDefault(ZstdCodec);
class LoadBalancer {
  constructor() {
    this.roundRobinIndex = /* @__PURE__ */ new Map();
    this.failedAccounts = /* @__PURE__ */ new Map();
  }
  static {
    this.FAIL_THRESHOLD = 1;
  }
  static {
    this.RECOVERY_TIME = 6e4;
  }
  // 1 minute
  /**
   * Mark account as failed
   */
  markAccountFailed(accountId) {
    const current = this.failedAccounts.get(accountId) || { count: 0 };
    this.failedAccounts.set(accountId, {
      count: current.count + 1,
      lastFailTime: Date.now()
    });
  }
  /**
   * Clear account failure status
   */
  clearAccountFailure(accountId) {
    this.failedAccounts.delete(accountId);
  }
  /**
   * Check if account is in failure state
   */
  isAccountInFailure(accountId) {
    const failure = this.failedAccounts.get(accountId);
    if (!failure) return false;
    if (Date.now() - failure.lastFailTime > LoadBalancer.RECOVERY_TIME) {
      this.failedAccounts.delete(accountId);
      return false;
    }
    return failure.count >= LoadBalancer.FAIL_THRESHOLD;
  }
  /**
   * Select account
   * @param model Requested model
   * @param strategy Load balance strategy
   * @param preferredProviderId Preferred provider ID
   * @param preferredAccountId Preferred account ID
   */
  selectAccount(model, strategy = "round-robin", preferredProviderId, preferredAccountId) {
    let candidates = this.getAvailableAccounts(model, preferredProviderId, true);
    if (candidates.length === 0) {
      candidates = this.getAvailableAccounts(model, preferredProviderId, false);
    }
    if (candidates.length === 0) {
      return null;
    }
    if (preferredAccountId) {
      const preferred = candidates.find((c) => c.account.id === preferredAccountId);
      if (preferred && !this.isAccountInFailure(preferredAccountId)) {
        return preferred;
      }
    }
    if (strategy === "fill-first") {
      return this.selectFillFirst(candidates);
    }
    if (strategy === "failover") {
      return this.selectFailover(candidates);
    }
    return this.selectRoundRobin(candidates);
  }
  /**
   * Get available accounts list
   */
  getAvailableAccounts(model, preferredProviderId, excludeFailed = false) {
    const providers = server_bootstrapConfig.storeManager.getProviders().filter((p) => p.enabled);
    const candidates = [];
    for (const provider of providers) {
      if (preferredProviderId && provider.id !== preferredProviderId) {
        continue;
      }
      if (!this.providerSupportsModel(provider, model)) {
        continue;
      }
      const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(provider.id, true).filter((account) => this.isAccountAvailable(account)).filter((account) => !excludeFailed || !this.isAccountInFailure(account.id));
      console.log(`[LoadBalancer] Provider ${provider.name} (${provider.id}) has ${accounts.length} available accounts`);
      for (const account of accounts) {
        console.log(`[LoadBalancer] Account ${account.name} (${account.id}) selected as candidate`);
        candidates.push({
          account,
          provider,
          actualModel: this.mapModel(model, provider)
        });
      }
    }
    return candidates;
  }
  /**
   * Check if provider supports model
   */
  providerSupportsModel(provider, model) {
    const effectiveModels = server_bootstrapConfig.storeManager.getEffectiveModels(provider.id);
    if (effectiveModels.length === 0) {
      return true;
    }
    const normalizedModel = this.normalizeModelForProviderMatch(model).toLowerCase();
    const supported = effectiveModels.some((m) => {
      const normalizedSupported = m.displayName.toLowerCase();
      if (normalizedSupported.endsWith("*")) {
        return normalizedModel.startsWith(normalizedSupported.slice(0, -1));
      }
      return normalizedSupported === normalizedModel;
    });
    if (supported) {
      return true;
    }
    const config = server_bootstrapConfig.storeManager.getConfig();
    const globalMapping = config.modelMappings[model];
    if (globalMapping) {
      if (globalMapping.preferredProviderId) {
        if (globalMapping.preferredProviderId === provider.id) {
          console.log(`[LoadBalancer] Model "${model}" matched preferred provider ${provider.name}`);
          return true;
        }
        return false;
      }
      const actualModel = globalMapping.actualModel;
      const normalizedActualModel = this.normalizeModelForProviderMatch(actualModel).toLowerCase();
      const actualSupported = effectiveModels.some((m) => {
        const normalizedSupported = m.displayName.toLowerCase();
        if (normalizedSupported.endsWith("*")) {
          return normalizedActualModel.startsWith(normalizedSupported.slice(0, -1));
        }
        return normalizedSupported === normalizedActualModel;
      });
      if (actualSupported) {
        console.log(`[LoadBalancer] Model "${model}" (actualModel: "${actualModel}") supported by ${provider.name}`);
        return true;
      }
    }
    console.log(`[LoadBalancer] Provider ${provider.name} does not support model ${model}`);
    return false;
  }
  normalizeModelForProviderMatch(model) {
    return model.replace(/-(thinking|fast)$/i, "");
  }
  /**
   * Check if account is available
   */
  isAccountAvailable(account) {
    if (account.status !== "active") {
      return false;
    }
    if (account.dailyLimit && account.todayUsed && account.todayUsed >= account.dailyLimit) {
      return false;
    }
    return true;
  }
  /**
   * Map model name
   */
  mapModel(model, provider) {
    console.log(`[LoadBalancer] mapModel called with model="${model}", provider="${provider.name}"`);
    const effectiveModels = server_bootstrapConfig.storeManager.getEffectiveModels(provider.id);
    const normalizedModel = this.normalizeModelForProviderMatch(model).toLowerCase();
    const effectiveModel = effectiveModels.find(
      (m) => m.displayName.toLowerCase() === normalizedModel
    );
    if (effectiveModel) {
      console.log(`[LoadBalancer] Model mapped from "${model}" to "${effectiveModel.actualModelId}" via effective models`);
      return effectiveModel.actualModelId;
    }
    const config = server_bootstrapConfig.storeManager.getConfig();
    const mapping = config.modelMappings[model];
    if (mapping && (!mapping.preferredProviderId || mapping.preferredProviderId === provider.id)) {
      const actualModel = mapping.actualModel;
      console.log(`[LoadBalancer] Model mapped from "${model}" to "${actualModel}" via global mapping`);
      const actualEffectiveModel = effectiveModels.find(
        (m) => m.displayName.toLowerCase() === actualModel.toLowerCase()
      );
      if (actualEffectiveModel) {
        console.log(`[LoadBalancer] Model further mapped from "${actualModel}" to "${actualEffectiveModel.actualModelId}" via effective models`);
        return actualEffectiveModel.actualModelId;
      }
      return actualModel;
    }
    console.log(`[LoadBalancer] No mapping found, returning original model "${model}"`);
    return model;
  }
  /**
   * Round Robin strategy
   */
  selectRoundRobin(candidates) {
    const providerIds = [...new Set(candidates.map((c) => c.provider.id))];
    const key = providerIds.join(",");
    const currentIndex = this.roundRobinIndex.get(key) || 0;
    const selected = candidates[currentIndex % candidates.length];
    this.roundRobinIndex.set(key, (currentIndex + 1) % candidates.length);
    return selected;
  }
  /**
   * Fill First strategy
   * Use current account preferentially until limit is reached
   */
  selectFillFirst(candidates) {
    return candidates.reduce((best, current) => {
      const bestUsed = best.account.todayUsed || 0;
      const currentUsed = current.account.todayUsed || 0;
      if (currentUsed < bestUsed) {
        return current;
      }
      if (currentUsed === bestUsed) {
        const bestLastUsed = best.account.lastUsed || 0;
        const currentLastUsed = current.account.lastUsed || 0;
        if (currentLastUsed < bestLastUsed) {
          return current;
        }
      }
      return best;
    });
  }
  /**
   * Failover strategy
   * Select account with least failures, preferring healthy accounts
   */
  selectFailover(candidates) {
    const healthyCandidates = candidates.filter((c) => !this.isAccountInFailure(c.account.id));
    if (healthyCandidates.length > 0) {
      return this.selectRoundRobin(healthyCandidates);
    }
    const sortedCandidates = candidates.sort((a, b) => {
      const failureA = this.failedAccounts.get(a.account.id);
      const failureB = this.failedAccounts.get(b.account.id);
      const countA = failureA ? failureA.count : 0;
      const countB = failureB ? failureB.count : 0;
      if (countA !== countB) {
        return countA - countB;
      }
      const timeA = failureA ? failureA.lastFailTime : 0;
      const timeB = failureB ? failureB.lastFailTime : 0;
      return timeA - timeB;
    });
    return sortedCandidates[0];
  }
  /**
   * Reset Round Robin index
   */
  resetRoundRobinIndex() {
    this.roundRobinIndex.clear();
  }
  /**
   * Get available account count
   */
  getAvailableAccountCount(model, providerId) {
    return this.getAvailableAccounts(model, providerId).length;
  }
  /**
   * Get all available models
   */
  getAvailableModels() {
    const providers = server_bootstrapConfig.storeManager.getProviders().filter((p) => p.enabled);
    const models = /* @__PURE__ */ new Set();
    for (const provider of providers) {
      const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(provider.id).filter((account) => this.isAccountAvailable(account));
      if (accounts.length > 0) {
        const effectiveModels = server_bootstrapConfig.storeManager.getEffectiveModels(provider.id);
        effectiveModels.forEach((m) => models.add(m.displayName));
      }
    }
    return [...models];
  }
}
const loadBalancer = new LoadBalancer();
class ProxyStatusManager {
  constructor() {
    this.statistics = {
      totalRequests: 0,
      successRequests: 0,
      failedRequests: 0,
      avgLatency: 0,
      requestsPerMinute: 0,
      activeConnections: 0,
      modelUsage: {},
      providerUsage: {},
      accountUsage: {}
    };
    this.config = {
      port: 8080,
      host: "0.0.0.0",
      timeout: 12e4,
      retryCount: 3,
      retryDelay: 5e3,
      maxConnections: 100,
      enableCors: true,
      corsOrigin: "*"
    };
    this.startTime = null;
    this.isRunning = false;
    this.requestTimestamps = [];
    this.latencySum = 0;
  }
  /**
   * Get statistics
   */
  getStatistics() {
    this.cleanupOldTimestamps();
    this.statistics.requestsPerMinute = this.requestTimestamps.length;
    this.statistics.avgLatency = this.statistics.totalRequests > 0 ? this.latencySum / this.statistics.totalRequests : 0;
    return { ...this.statistics };
  }
  /**
   * Get configuration
   */
  getConfig() {
    return { ...this.config };
  }
  /**
   * Update configuration
   */
  updateConfig(config) {
    this.config = { ...this.config, ...config };
  }
  /**
   * Get running status
   */
  getRunningStatus() {
    return {
      isRunning: this.isRunning,
      startTime: this.startTime,
      uptime: this.startTime ? Date.now() - this.startTime : 0
    };
  }
  /**
   * Start proxy
   */
  start() {
    this.isRunning = true;
    this.startTime = Date.now();
  }
  /**
   * Stop proxy
   */
  stop() {
    this.isRunning = false;
    this.startTime = null;
    this.statistics.activeConnections = 0;
  }
  /**
   * Record request start
   */
  recordRequestStart(model, providerId, accountId) {
    this.statistics.totalRequests++;
    this.statistics.activeConnections++;
    this.requestTimestamps.push(Date.now());
    this.statistics.modelUsage[model] = (this.statistics.modelUsage[model] || 0) + 1;
    if (providerId) {
      this.statistics.providerUsage[providerId] = (this.statistics.providerUsage[providerId] || 0) + 1;
    }
    if (accountId) {
      this.statistics.accountUsage[accountId] = (this.statistics.accountUsage[accountId] || 0) + 1;
    }
    this.cleanupOldTimestamps();
  }
  /**
   * Record request success
   */
  recordRequestSuccess(latency) {
    this.statistics.successRequests++;
    this.statistics.activeConnections = Math.max(0, this.statistics.activeConnections - 1);
    this.latencySum += latency;
  }
  /**
   * Record request failure
   */
  recordRequestFailure(latency) {
    this.statistics.failedRequests++;
    this.statistics.activeConnections = Math.max(0, this.statistics.activeConnections - 1);
    this.latencySum += latency;
  }
  /**
   * Clean up expired timestamps (older than 1 minute)
   */
  cleanupOldTimestamps() {
    const oneMinuteAgo = Date.now() - 6e4;
    this.requestTimestamps = this.requestTimestamps.filter((ts) => ts > oneMinuteAgo);
  }
  /**
   * Reset statistics
   */
  resetStatistics() {
    this.statistics = {
      totalRequests: 0,
      successRequests: 0,
      failedRequests: 0,
      avgLatency: 0,
      requestsPerMinute: 0,
      activeConnections: 0,
      modelUsage: {},
      providerUsage: {},
      accountUsage: {}
    };
    this.requestTimestamps = [];
    this.latencySum = 0;
  }
  /**
   * Get port
   */
  getPort() {
    return this.config.port;
  }
  /**
   * Set port
   */
  setPort(port) {
    this.config.port = port;
  }
  /**
   * Get host
   */
  getHost() {
    return this.config.host;
  }
  /**
   * Set host
   */
  setHost(host) {
    this.config.host = host;
  }
}
const proxyStatusManager = new ProxyStatusManager();
class DeepSeekHash {
  constructor() {
    this.offset = 0;
    this.cachedUint8Memory = null;
    this.cachedTextEncoder = new TextEncoder();
  }
  encodeString(text, allocate, reallocate) {
    if (!reallocate) {
      const encoded = this.cachedTextEncoder.encode(text);
      const ptr2 = allocate(encoded.length, 1) >>> 0;
      const memory2 = this.getCachedUint8Memory();
      memory2.subarray(ptr2, ptr2 + encoded.length).set(encoded);
      this.offset = encoded.length;
      return ptr2;
    }
    const strLength = text.length;
    let ptr = allocate(strLength, 1) >>> 0;
    const memory = this.getCachedUint8Memory();
    let asciiLength = 0;
    for (; asciiLength < strLength; asciiLength++) {
      const charCode = text.charCodeAt(asciiLength);
      if (charCode > 127) break;
      memory[ptr + asciiLength] = charCode;
    }
    if (asciiLength !== strLength) {
      if (asciiLength > 0) {
        text = text.slice(asciiLength);
      }
      ptr = reallocate(ptr, strLength, asciiLength + text.length * 3, 1) >>> 0;
      const result = this.cachedTextEncoder.encodeInto(
        text,
        this.getCachedUint8Memory().subarray(ptr + asciiLength, ptr + asciiLength + text.length * 3)
      );
      asciiLength += result.written;
      ptr = reallocate(ptr, asciiLength + text.length * 3, asciiLength, 1) >>> 0;
    }
    this.offset = asciiLength;
    return ptr;
  }
  getCachedUint8Memory() {
    if (this.cachedUint8Memory === null || this.cachedUint8Memory.byteLength === 0) {
      this.cachedUint8Memory = new Uint8Array(this.wasmInstance.memory.buffer);
    }
    return this.cachedUint8Memory;
  }
  calculateHash(algorithm, challenge, salt, difficulty, expireAt) {
    if (algorithm !== "DeepSeekHashV1") {
      throw new Error("Unsupported algorithm: " + algorithm);
    }
    const prefix = `${salt}_${expireAt}_`;
    try {
      const retptr = this.wasmInstance.__wbindgen_add_to_stack_pointer(-16);
      const ptr0 = this.encodeString(
        challenge,
        this.wasmInstance.__wbindgen_export_0,
        this.wasmInstance.__wbindgen_export_1
      );
      const len0 = this.offset;
      const ptr1 = this.encodeString(
        prefix,
        this.wasmInstance.__wbindgen_export_0,
        this.wasmInstance.__wbindgen_export_1
      );
      const len1 = this.offset;
      this.wasmInstance.wasm_solve(retptr, ptr0, len0, ptr1, len1, difficulty);
      const dataView = new DataView(this.wasmInstance.memory.buffer);
      const status = dataView.getInt32(retptr + 0, true);
      const value = dataView.getFloat64(retptr + 8, true);
      if (status === 0)
        return void 0;
      return value;
    } finally {
      this.wasmInstance.__wbindgen_add_to_stack_pointer(16);
    }
  }
  async init(wasmPath) {
    const imports = { wbg: {} };
    const wasmBuffer = await fs.promises.readFile(wasmPath);
    const { instance } = await WebAssembly.instantiate(wasmBuffer, imports);
    this.wasmInstance = instance.exports;
    return this.wasmInstance;
  }
}
let deepSeekHashInstance = null;
async function getDeepSeekHash() {
  if (!deepSeekHashInstance) {
    deepSeekHashInstance = new DeepSeekHash();
    const wasmPath = server_bootstrapConfig.getRuntime().getResourcePath("sha3_wasm_bg.7b9ca65ddd.wasm");
    console.log("[DeepSeekHash] WASM path:", wasmPath);
    console.log("[DeepSeekHash] File exists:", fs.existsSync(wasmPath));
    try {
      await deepSeekHashInstance.init(wasmPath);
      console.log("[DeepSeekHash] WASM initialized successfully");
    } catch (error) {
      console.error("[DeepSeekHash] WASM initialization failed:", error);
      throw error;
    }
  }
  return deepSeekHashInstance;
}
function resolveDeepSeekChatOptions(request, _prompt = "") {
  const modelLower = request.model.toLowerCase();
  const isProModel = modelLower.includes("deepseek-v4-pro") || modelLower.includes("expert");
  const isSearchAlias = modelLower.includes("search");
  const isThinkingAlias = modelLower.includes("think") || modelLower.includes("r1") || modelLower.includes("reasoner");
  return {
    modelType: isProModel ? "expert" : "default",
    searchEnabled: Boolean(request.web_search) || isSearchAlias,
    thinkingEnabled: Boolean(request.reasoning_effort) || isThinkingAlias
  };
}
function resolveKimiScenario(model) {
  return model.toLowerCase().includes("k2.6") ? "SCENARIO_K2D6" : "SCENARIO_K2D5";
}
function createKimiChatPayload(options) {
  const scenario = resolveKimiScenario(options.model);
  return {
    scenario,
    chat_id: "",
    tools: options.enableWebSearch ? [{ type: "TOOL_TYPE_SEARCH", search: {} }] : [],
    message: {
      parent_id: "",
      role: "user",
      blocks: [{
        message_id: "",
        text: { content: options.content }
      }],
      scenario
    },
    options: {
      thinking: options.enableThinking
    }
  };
}
function encodeKimiGrpcFrame(payload) {
  const jsonBuffer = Buffer.from(JSON.stringify(payload), "utf8");
  const frameBuffer = Buffer.alloc(5 + jsonBuffer.length);
  frameBuffer.writeUInt8(0, 0);
  frameBuffer.writeUInt32BE(jsonBuffer.length, 1);
  jsonBuffer.copy(frameBuffer, 5);
  return frameBuffer;
}
function detectMarkers(buffer, markers) {
  let earliest = -1;
  for (const marker of markers) {
    const index = buffer.indexOf(marker);
    if (index !== -1 && (earliest === -1 || index < earliest)) {
      earliest = index;
    }
  }
  if (earliest !== -1) {
    return { matched: true, partial: false, markerStart: earliest };
  }
  for (let index = 0; index < buffer.length; index += 1) {
    const suffix = buffer.slice(index);
    if (markers.some((marker) => marker.startsWith(suffix))) {
      return { matched: false, partial: true, markerStart: index };
    }
  }
  return { matched: false, partial: false };
}
function stripFencedCodeBlocks(content) {
  return content.replace(/```[\s\S]*?```/g, "");
}
function toolNames(tools) {
  return new Set(tools.map((tool) => tool.name));
}
function createParseResult(input) {
  return {
    content: input.content,
    toolCalls: input.toolCalls,
    protocol: input.protocol,
    rawMatches: input.rawMatches,
    malformedReason: input.malformedReason,
    invalidToolNames: input.invalidToolNames ?? []
  };
}
function buildToolCall(id, index, name, args, rawText) {
  return {
    id,
    index,
    type: "function",
    function: {
      name,
      arguments: normalizeArguments(args)
    },
    ...rawText ? { rawText } : {}
  };
}
function normalizeArguments(args) {
  if (typeof args === "string") {
    const trimmed = args.trim();
    if (!trimmed) return "{}";
    try {
      return JSON.stringify(JSON.parse(trimmed));
    } catch {
      return trimmed;
    }
  }
  return JSON.stringify(args ?? {});
}
function parseJsonValue(value) {
  const trimmed = unwrapCdata(value).trim();
  if (!trimmed) return "";
  try {
    return JSON.parse(trimmed);
  } catch {
    return decodeXml(trimmed);
  }
}
function unwrapCdata(value) {
  const cdata = value.match(/^\s*<!\[CDATA\[([\s\S]*?)\]\]>\s*$/);
  return cdata ? cdata[1] : value;
}
function decodeXml(value) {
  return value.replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
}
function escapeXmlAttribute(value) {
  return value.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function addParameter(target, name, value) {
  const existing = target[name];
  if (existing === void 0) {
    target[name] = value;
  } else if (Array.isArray(existing)) {
    target[name] = [...existing, value];
  } else {
    target[name] = [existing, value];
  }
}
function renderToolList(tools) {
  return tools.map((tool) => {
    const parameters = JSON.stringify(tool.parameters ?? {});
    return `Tool \`${tool.name}\`: ${tool.description || "No description"}. Arguments JSON schema: ${parameters}`;
  }).join("\n");
}
function genericToolResultBlock(result) {
  return `[TOOL_RESULT for ${result.toolCallId}] ${result.content}`;
}
const CHAT2API_START = "<|CHAT2API|tool_calls>";
const CHAT2API_END = "</|CHAT2API|tool_calls>";
const XML_START = "<tool_calls>";
const managedXmlProtocol = {
  id: "managed_xml",
  renderPrompt(tools) {
    return `## Available Tools
You can invoke the following developer tools. Tool names are case-sensitive.
Use only the exact tool names listed below. Do not rename, camelCase, translate, shorten, or invent tool names.

${renderToolList(tools)}

When calling tools, respond with only this Chat2API XML block:

<|CHAT2API|tool_calls><|CHAT2API|invoke name="exact_tool_name"><|CHAT2API|parameter name="argument"><![CDATA[value]]></|CHAT2API|parameter></|CHAT2API|invoke></|CHAT2API|tool_calls>

Tool results will be provided as Chat2API XML result blocks:

<|CHAT2API|tool_result tool_call_id="call_id"><![CDATA[result]]></|CHAT2API|tool_result>`;
  },
  detectStart(buffer) {
    return detectMarkers(buffer, [CHAT2API_START, XML_START]);
  },
  parse(content, context) {
    const parseable = stripFencedCodeBlocks(content);
    const allowedNames = toolNames(context.tools);
    const rawMatches = [];
    const invalidToolNames = [];
    const toolCalls = [];
    parseBlocks(parseable, {
      blockPattern: /<\|CHAT2API\|tool_calls>([\s\S]*?)<\/\|CHAT2API\|tool_calls>/g,
      invokePattern: /<\|CHAT2API\|invoke\s+name="([^"]+)"\s*>([\s\S]*?)<\/\|CHAT2API\|invoke>/g,
      parameterPattern: /<\|CHAT2API\|parameter\s+name="([^"]+)"\s*>([\s\S]*?)<\/\|CHAT2API\|parameter>/g,
      rawMatches,
      invalidToolNames,
      allowedNames,
      toolCalls
    });
    parseBlocks(parseable, {
      blockPattern: /<tool_calls>([\s\S]*?)<\/tool_calls>/g,
      invokePattern: /<invoke\s+name="([^"]+)"\s*>([\s\S]*?)<\/invoke>/g,
      parameterPattern: /<parameter\s+name="([^"]+)"\s*>([\s\S]*?)<\/parameter>/g,
      rawMatches,
      invalidToolNames,
      allowedNames,
      toolCalls
    });
    if (toolCalls.length === 0) {
      return createParseResult({
        content,
        toolCalls,
        protocol: rawMatches.length > 0 ? "managed_xml" : "unknown",
        rawMatches,
        invalidToolNames
      });
    }
    const cleanContent = rawMatches.reduce((acc, raw) => acc.replace(raw, ""), parseable).trim();
    return createParseResult({
      content: cleanContent,
      toolCalls,
      protocol: "managed_xml",
      rawMatches,
      invalidToolNames
    });
  },
  formatAssistantToolCalls(calls) {
    const invokes = calls.map((call) => {
      const args = safeParseObject(call.arguments);
      const params = Object.entries(args).map(([name, value]) => {
        const text = typeof value === "string" ? value : JSON.stringify(value);
        return `<|CHAT2API|parameter name="${escapeXmlAttribute(name)}"><![CDATA[${text}]]></|CHAT2API|parameter>`;
      }).join("");
      return `<|CHAT2API|invoke name="${escapeXmlAttribute(call.name)}">${params}</|CHAT2API|invoke>`;
    });
    return `${CHAT2API_START}${invokes.join("")}${CHAT2API_END}`;
  },
  formatToolResult(result) {
    return `<|CHAT2API|tool_result tool_call_id="${escapeXmlAttribute(result.toolCallId)}"><![CDATA[${result.content}]]></|CHAT2API|tool_result>`;
  }
};
function parseBlocks(content, options) {
  let blockMatch;
  while ((blockMatch = options.blockPattern.exec(content)) !== null) {
    options.rawMatches.push(blockMatch[0]);
    let invokeMatch;
    while ((invokeMatch = options.invokePattern.exec(blockMatch[1])) !== null) {
      const name = invokeMatch[1].trim();
      if (!options.allowedNames.has(name)) {
        options.invalidToolNames.push(name);
        continue;
      }
      const args = {};
      let parameterMatch;
      options.parameterPattern.lastIndex = 0;
      while ((parameterMatch = options.parameterPattern.exec(invokeMatch[2])) !== null) {
        addParameter(args, parameterMatch[1].trim(), parseJsonValue(parameterMatch[2]));
      }
      options.toolCalls.push(
        buildToolCall(`call_${options.toolCalls.length}`, options.toolCalls.length, name, JSON.stringify(args), invokeMatch[0])
      );
    }
  }
}
function safeParseObject(value) {
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
  } catch {
    return {};
  }
}
const chat2ApiXmlHistoryProfile = {
  managedSupport: true,
  supportsNativeTools: false,
  preferredManagedProtocol: "managed_xml",
  formatAssistantToolCalls(calls) {
    return managedXmlProtocol.formatAssistantToolCalls(calls);
  },
  formatToolResult(result) {
    return managedXmlProtocol.formatToolResult(result);
  }
};
const profiles = {
  deepseek: {
    providerId: "deepseek",
    ...chat2ApiXmlHistoryProfile
  },
  kimi: {
    providerId: "kimi",
    ...chat2ApiXmlHistoryProfile
  },
  glm: {
    providerId: "glm",
    ...chat2ApiXmlHistoryProfile
  },
  qwen: {
    providerId: "qwen",
    ...chat2ApiXmlHistoryProfile
  }
};
function getProviderToolProfile(providerId) {
  return profiles[providerId] ?? {
    providerId,
    ...chat2ApiXmlHistoryProfile
  };
}
const DEEPSEEK_API_BASE$1 = "https://chat.deepseek.com/api";
const FAKE_HEADERS$a = {
  Accept: "*/*",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
  Origin: "https://chat.deepseek.com",
  Referer: "https://chat.deepseek.com/",
  "Sec-Ch-Ua": '"Not/A)Brand";v="99", "Chromium";v="148"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
  "X-App-Version": "2.0.0",
  "X-Client-Locale": "zh_CN",
  "X-Client-Platform": "web",
  "x-Client-Timezone-Offset": "28800",
  "X-Client-Version": "2.0.0"
};
const tokenCache$1 = /* @__PURE__ */ new Map();
const sessionCache$1 = /* @__PURE__ */ new Map();
function generateRandomString(length, charset = "alphanumeric") {
  const sets = {
    numeric: "0123456789",
    alphabetic: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
    alphanumeric: "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
    hex: "0123456789abcdef"
  };
  const chars = sets[charset] || sets.alphanumeric;
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
function uuid$8() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
function generateCookie() {
  const timestamp = Date.now();
  return `intercom-HWWAFSESTIME=${timestamp}; HWWAFSESID=${generateRandomString(18, "hex")}; Hm_lvt_${uuid$8()}=${Math.floor(timestamp / 1e3)},${Math.floor(timestamp / 1e3)},${Math.floor(timestamp / 1e3)}; Hm_lpvt_${uuid$8()}=${Math.floor(timestamp / 1e3)}; _frid=${uuid$8()}; _fr_ssid=${uuid$8()}; _fr_pvid=${uuid$8()}`;
}
function unixTimestamp$3() {
  return Math.floor(Date.now() / 1e3);
}
let DeepSeekAdapter$1 = class DeepSeekAdapter {
  constructor(provider, account) {
    this.provider = provider;
    this.account = account;
    console.log("[DeepSeek] Account credentials:", JSON.stringify(account.credentials, null, 2));
    this.token = account.credentials.token || account.credentials.apiKey || account.credentials.refreshToken || "";
    console.log("[DeepSeek] Using token:", this.token.substring(0, 20) + "...");
  }
  async acquireToken() {
    if (!this.token) {
      throw new Error("DeepSeek Token not configured, please add Token in account settings");
    }
    const cached = tokenCache$1.get(this.token);
    if (cached && cached.expiresAt > unixTimestamp$3()) {
      return cached.accessToken;
    }
    console.log("[DeepSeek] Acquiring token...");
    const result = await axios.get(`${DEEPSEEK_API_BASE$1}/v0/users/current`, {
      headers: {
        Authorization: `Bearer ${this.token}`,
        ...FAKE_HEADERS$a
      },
      timeout: 15e3,
      validateStatus: () => true
    });
    console.log("[DeepSeek] Token response status:", result.status);
    if (result.status === 401 || result.status === 403) {
      throw new Error(`Token invalid or expired, please get a new Token`);
    }
    if (result.status !== 200) {
      throw new Error(`Failed to acquire token: HTTP ${result.status}`);
    }
    const bizData = result.data?.data?.biz_data || result.data?.biz_data;
    if (!bizData?.token) {
      const errorMsg = result.data?.msg || result.data?.data?.biz_msg || "Unknown error";
      console.log("[DeepSeek] Token response data:", JSON.stringify(result.data, null, 2));
      throw new Error(`Failed to acquire token: ${errorMsg}`);
    }
    const accessToken = bizData.token;
    tokenCache$1.set(this.token, {
      accessToken,
      refreshToken: this.token,
      expiresAt: unixTimestamp$3() + 3600
    });
    console.log("[DeepSeek] Token acquired successfully");
    return accessToken;
  }
  async createSession() {
    const cacheKey = this.account.id;
    const cached = sessionCache$1.get(cacheKey);
    if (cached && Date.now() - cached.createdAt < 3e5) {
      return cached.sessionId;
    }
    const token = await this.acquireToken();
    const result = await axios.post(
      `${DEEPSEEK_API_BASE$1}/v0/chat_session/create`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
          ...FAKE_HEADERS$a,
          Cookie: generateCookie()
        },
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    console.log("[DeepSeek] Create session response:", JSON.stringify(result.data, null, 2));
    const bizData = result.data?.data?.biz_data || result.data?.biz_data;
    if (result.status !== 200 || !bizData?.chat_session?.id) {
      throw new Error(`Failed to create session: ${result.data?.msg || result.data?.data?.biz_msg || result.status}`);
    }
    const sessionId = bizData?.chat_session?.id;
    sessionCache$1.set(cacheKey, { sessionId, createdAt: Date.now() });
    return sessionId;
  }
  async deleteSession(sessionId) {
    try {
      const token = await this.acquireToken();
      const result = await axios.post(
        `${DEEPSEEK_API_BASE$1}/v0/chat_session/delete`,
        { chat_session_id: sessionId },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            ...FAKE_HEADERS$a
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      console.log("[DeepSeek] Delete session response:", JSON.stringify(result.data, null, 2));
      const success = result.status === 200 && result.data?.code === 0;
      if (success) {
        const cacheKey = this.account.id;
        sessionCache$1.delete(cacheKey);
        console.log("[DeepSeek] Session deleted:", sessionId);
      }
      return success;
    } catch (error) {
      console.error("[DeepSeek] Failed to delete session:", error);
      return false;
    }
  }
  async getChallenge(targetPath) {
    const token = await this.acquireToken();
    const result = await axios.post(
      `${DEEPSEEK_API_BASE$1}/v0/chat/create_pow_challenge`,
      { target_path: targetPath },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          ...FAKE_HEADERS$a
        },
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    const bizData = result.data?.data?.biz_data || result.data?.biz_data;
    if (result.status !== 200 || !bizData?.challenge) {
      throw new Error(`Failed to get challenge: ${result.data?.msg || result.data?.data?.biz_msg || result.status}`);
    }
    return bizData.challenge;
  }
  async calculateChallengeAnswer(challenge) {
    const { algorithm, challenge: challengeStr, salt, difficulty, expire_at, signature } = challenge;
    if (algorithm !== "DeepSeekHashV1") {
      throw new Error(`Unsupported algorithm: ${algorithm}`);
    }
    console.log("[DeepSeek] Challenge parameters:", { difficulty });
    const deepSeekHash = await getDeepSeekHash();
    const answer = deepSeekHash.calculateHash(algorithm, challengeStr, salt, difficulty, expire_at);
    if (answer === void 0) {
      throw new Error("Challenge calculation failed");
    }
    console.log("[DeepSeek] Challenge answer found:", answer);
    return Buffer.from(JSON.stringify({
      algorithm,
      challenge: challengeStr,
      salt,
      answer,
      signature,
      target_path: "/api/v0/chat/completion"
    })).toString("base64");
  }
  messagesToPrompt(messages, isMultiTurn = false) {
    const toolProfile = getProviderToolProfile("deepseek");
    const processedMessages = messages.map((message) => {
      let text;
      if (message.role === "assistant" && message.tool_calls && message.tool_calls.length > 0) {
        text = toolProfile.formatAssistantToolCalls(message.tool_calls.map((tc) => ({
          id: tc.id,
          name: tc.function.name,
          arguments: tc.function.arguments
        })));
      } else if (message.role === "tool" && message.tool_call_id) {
        text = toolProfile.formatToolResult({
          toolCallId: message.tool_call_id,
          content: String(message.content || "")
        });
      } else if (Array.isArray(message.content)) {
        const texts = message.content.filter((item) => item.type === "text").map((item) => item.text);
        text = texts.join("\n");
      } else {
        text = String(message.content || "");
      }
      return { role: message.role, text };
    });
    if (processedMessages.length === 0) return "";
    if (isMultiTurn) {
      let lastUserIdx = -1;
      for (let i = processedMessages.length - 1; i >= 0; i--) {
        if (processedMessages[i].role === "user") {
          lastUserIdx = i;
          break;
        }
      }
      if (lastUserIdx !== -1) {
        const lastUserMsg = processedMessages[lastUserIdx];
        let text = lastUserMsg.text;
        for (let i = lastUserIdx + 1; i < processedMessages.length; i++) {
          if (processedMessages[i].role === "tool") {
            text += `

${processedMessages[i].text}`;
          }
        }
        return `<｜User｜>${text}`;
      }
    }
    const mergedBlocks = [];
    let currentBlock = { ...processedMessages[0] };
    for (let i = 1; i < processedMessages.length; i++) {
      const msg = processedMessages[i];
      if (msg.role === currentBlock.role) {
        currentBlock.text += `

${msg.text}`;
      } else {
        mergedBlocks.push(currentBlock);
        currentBlock = { ...msg };
      }
    }
    mergedBlocks.push(currentBlock);
    return mergedBlocks.map((block, index) => {
      if (block.role === "assistant") {
        return `<｜Assistant｜>${block.text}<｜end of sentence｜>`;
      }
      if (block.role === "user" || block.role === "system") {
        return index > 0 ? `<｜User｜>${block.text}` : block.text;
      }
      if (block.role === "tool") {
        return `<｜User｜>${block.text}`;
      }
      return block.text;
    }).join("").replace(/!\[.+\]\(.+\)/g, "");
  }
  async chatCompletion(request) {
    const token = await this.acquireToken();
    const sessionId = await this.createSession();
    console.log("[DeepSeek] Created new session:", sessionId);
    const challenge = await this.getChallenge("/api/v0/chat/completion");
    const challengeAnswer = await this.calculateChallengeAnswer(challenge);
    const messages = [...request.messages];
    let prompt = this.messagesToPrompt(messages, false);
    const { modelType, searchEnabled, thinkingEnabled } = resolveDeepSeekChatOptions(request, prompt);
    if (request.web_search || request.model.toLowerCase().includes("search")) {
      console.log("[DeepSeek] Web search enabled");
    }
    if (request.reasoning_effort || thinkingEnabled) {
      console.log("[DeepSeek] Reasoning mode enabled, effort:", request.reasoning_effort);
    }
    const response = await axios.post(
      `${DEEPSEEK_API_BASE$1}/v0/chat/completion`,
      {
        chat_session_id: sessionId,
        parent_message_id: null,
        prompt,
        model_type: modelType,
        ref_file_ids: [],
        search_enabled: searchEnabled,
        thinking_enabled: thinkingEnabled,
        preempt: false
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          ...FAKE_HEADERS$a,
          Referer: `https://chat.deepseek.com/a/chat/s/${sessionId}`,
          Cookie: generateCookie(),
          "X-Ds-Pow-Response": challengeAnswer
        },
        timeout: 12e4,
        validateStatus: () => true,
        responseType: "stream"
      }
    );
    return { response, sessionId };
  }
  async deleteAllChats() {
    try {
      const token = await this.acquireToken();
      const result = await axios.post(
        `${DEEPSEEK_API_BASE$1}/v0/chat_session/delete_all`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
            ...FAKE_HEADERS$a
          },
          timeout: 3e4,
          validateStatus: () => true
        }
      );
      console.log("[DeepSeek] Delete all chats response:", JSON.stringify(result.data, null, 2));
      const success = result.status === 200 && result.data?.code === 0;
      if (success) {
        sessionCache$1.clear();
        console.log("[DeepSeek] All chats deleted");
      }
      return success;
    } catch (error) {
      console.error("[DeepSeek] Failed to delete all chats:", error);
      return false;
    }
  }
  static isDeepSeekProvider(provider) {
    return provider.id === "deepseek" || provider.apiEndpoint.includes("deepseek.com");
  }
  /**
   * Clear session cache for a specific account
   * This should be called when a session is deleted externally (e.g., from web)
   */
  static clearSessionCache(accountId) {
    sessionCache$1.delete(accountId);
    console.log("[DeepSeek] Cleared session cache for account:", accountId);
  }
};
function parseToolCallsFromText(text, modelType = "default") {
  console.log("[ToolParser] parseToolCallsFromText called, modelType:", modelType, "text length:", text?.length || 0);
  if (!text) {
    return { content: "", toolCalls: [] };
  }
  const toolCalls = [];
  let cleanContent = text;
  const hasFunctionCalls = text.includes("[function_calls]") || text.includes("function_calls]") || /\[call[:=]/.test(text);
  console.log("[ToolParser] hasFunctionCalls:", hasFunctionCalls);
  if (!hasFunctionCalls) {
    return { content: text, toolCalls: [] };
  }
  let processedText = text;
  const missingBracketRegex = /(^|[^\/\[])(function_calls\])/g;
  if (!processedText.includes("[function_calls]") && missingBracketRegex.test(processedText)) {
    processedText = processedText.replace(/(^|[^\/\[])(function_calls\])/g, "$1[$2");
    console.log("[ToolParser] Prepended opening bracket, processedText:", processedText.substring(0, 100));
  }
  const blockRegex = /\[function_calls\]([\s\S]*?)(?:\[\/function_calls\]|$)/g;
  let blockMatch;
  while ((blockMatch = blockRegex.exec(processedText)) !== null) {
    const blockContent = blockMatch[1];
    console.log("[ToolParser] blockContent:", blockContent?.substring(0, 200));
    if (modelType === "kimi" || modelType === "glm" || modelType === "minimax" || modelType === "zai") {
      const callRegex = modelType === "minimax" ? /\[(?:call\s*[:=]\s*([a-zA-Z0-9_:-]+)|invoke\s+name\s*=\s*"([a-zA-Z0-9_:-]+)")\]([\s\S]*?)\[\/call\]/g : /\[call\s*[:=]?\s*([a-zA-Z0-9_:-]+)\]([\s\S]*?)\[\/call\]/g;
      let match;
      while ((match = callRegex.exec(blockContent)) !== null) {
        const functionName = match[1] || match[2];
        let argumentsStr = "";
        if (modelType === "minimax") {
          argumentsStr = (match[3] || "").trim();
        } else {
          argumentsStr = (match[2] || "").trim();
        }
        if (argumentsStr.startsWith("```") && argumentsStr.endsWith("```")) {
          argumentsStr = argumentsStr.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
        }
        const parsed = tryParseJSON$1(argumentsStr);
        if (parsed) {
          toolCalls.push({
            index: toolCalls.length,
            id: `call_${Date.now()}_${toolCalls.length}`,
            type: "function",
            function: { name: functionName, arguments: JSON.stringify(parsed) },
            rawText: match[0]
          });
        }
      }
    } else {
      const callStartRegex = /\[call[:=]?([a-zA-Z0-9_:-]+)\]/g;
      let callStartMatch;
      while ((callStartMatch = callStartRegex.exec(blockContent)) !== null) {
        const functionName = callStartMatch[1];
        const argsStartIndex = callStartMatch.index + callStartMatch[0].length;
        const remainingText = blockContent.substring(argsStartIndex);
        let argumentsStr = extractBalancedJson$1(remainingText);
        let jsonEndIndex = -1;
        let parsed = null;
        if (argumentsStr) {
          const startIdx = remainingText.indexOf("{");
          jsonEndIndex = startIdx + argumentsStr.length;
          let cleanArgsStr = argumentsStr.trim();
          if (cleanArgsStr.startsWith("```") && cleanArgsStr.endsWith("```")) {
            cleanArgsStr = cleanArgsStr.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
          }
          parsed = tryParseJSON$1(cleanArgsStr);
        }
        if (!parsed) {
          parsed = tryRegexFallback$1(remainingText);
          if (parsed) {
            const endCallIdx = remainingText.indexOf("[/call]");
            jsonEndIndex = endCallIdx !== -1 ? endCallIdx : remainingText.length;
          }
        }
        if (parsed) {
          let rawTextEndIndex = argsStartIndex + jsonEndIndex;
          const afterJson = blockContent.substring(rawTextEndIndex);
          const closeTagMatch = afterJson.match(/^\s*\[\/call\]/);
          if (closeTagMatch) rawTextEndIndex += closeTagMatch[0].length;
          toolCalls.push({
            index: toolCalls.length,
            id: `call_${Date.now()}_${toolCalls.length}`,
            type: "function",
            function: { name: functionName, arguments: JSON.stringify(parsed) },
            rawText: blockContent.substring(callStartMatch.index, rawTextEndIndex)
          });
          callStartRegex.lastIndex = rawTextEndIndex;
        }
      }
    }
    for (const tc of toolCalls) {
      if (tc.rawText) {
        cleanContent = cleanContent.replace(tc.rawText, "");
      }
    }
    if (blockContent.includes("[/function_calls]")) {
      const emptyBlockRegex = /\[function_calls\]\s*\[\/function_calls\]/g;
      cleanContent = cleanContent.replace(emptyBlockRegex, "");
    }
  }
  return {
    content: cleanContent.trim(),
    toolCalls
  };
}
function extractBalancedJson$1(str) {
  const startIdx = str.indexOf("{");
  if (startIdx === -1) return null;
  let depth = 0;
  let inString = false;
  let isEscaped = false;
  for (let i = startIdx; i < str.length; i++) {
    const char = str[i];
    if (char === "\\" && !isEscaped) {
      isEscaped = true;
      continue;
    }
    if (char === '"' && !isEscaped) {
      inString = !inString;
    } else if (!inString) {
      if (char === "{") {
        depth++;
      } else if (char === "}") {
        depth--;
        if (depth === 0) {
          return str.substring(startIdx, i + 1);
        }
      }
    }
    isEscaped = false;
  }
  return null;
}
function tryParseJSON$1(str) {
  if (!str) return null;
  try {
    return JSON.parse(str);
  } catch (e) {
  }
  try {
    let inString = false;
    let isEscaped = false;
    let fixedStr = "";
    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      if (char === "\\" && !isEscaped) {
        isEscaped = true;
        fixedStr += char;
      } else if (char === '"' && !isEscaped) {
        inString = !inString;
        fixedStr += char;
      } else if (inString && (char === "\n" || char === "\r" || char === "	")) {
        if (char === "\n") fixedStr += "\\n";
        else if (char === "\r") fixedStr += "\\r";
        else if (char === "	") fixedStr += "\\t";
      } else {
        isEscaped = false;
        fixedStr += char;
      }
    }
    return JSON.parse(fixedStr);
  } catch (e) {
  }
  try {
    let inString = false;
    let isEscaped = false;
    let compactStr = "";
    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      if (char === "\\" && !isEscaped) {
        isEscaped = true;
        compactStr += char;
      } else if (char === '"' && !isEscaped) {
        inString = !inString;
        compactStr += char;
      } else if (!inString && (char === "\n" || char === "\r" || char === "	")) {
        continue;
      } else {
        isEscaped = false;
        compactStr += char;
      }
    }
    return JSON.parse(compactStr);
  } catch (e) {
  }
  try {
    const fixedStr = str.replace(/([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:/g, '$1"$2":');
    let inString = false;
    let isEscaped = false;
    let compactStr = "";
    for (let i = 0; i < fixedStr.length; i++) {
      const char = fixedStr[i];
      if (char === "\\" && !isEscaped) {
        isEscaped = true;
        compactStr += char;
      } else if (char === '"' && !isEscaped) {
        inString = !inString;
        compactStr += char;
      } else if (!inString && (char === "\n" || char === "\r")) {
        continue;
      } else {
        isEscaped = false;
        compactStr += char;
      }
    }
    return JSON.parse(compactStr);
  } catch (e) {
  }
  try {
    const doubleQuotedStr = str.replace(/'/g, '"');
    return JSON.parse(doubleQuotedStr);
  } catch (e) {
  }
  return null;
}
function tryRegexFallback$1(str) {
  try {
    if (str.includes('"filePath"') && str.includes('"content"')) {
      const filePathMatch = str.match(/"filePath"\s*:\s*"([^"]+)"/);
      if (filePathMatch) {
        const contentStart = str.indexOf('"content"');
        if (contentStart !== -1) {
          const valueStart = str.indexOf('"', contentStart + 9) + 1;
          let valueEnd = -1;
          const endMatch = str.match(/"\s*\}\s*(?:\[\/call\])?\s*$/);
          if (endMatch) {
            valueEnd = endMatch.index;
          } else {
            return null;
          }
          if (valueStart !== 0 && valueEnd > valueStart) {
            const contentValue = str.substring(valueStart, valueEnd);
            return {
              filePath: filePathMatch[1],
              content: contentValue.replace(/\\n/g, "\n").replace(/\\"/g, '"')
            };
          }
        }
      }
    }
    if (str.includes('"filePath"') && str.includes('"old_str"') && str.includes('"new_str"')) {
      const filePathMatch = str.match(/"filePath"\s*:\s*"([^"]+)"/);
      if (filePathMatch) {
        const oldStrStart = str.indexOf('"old_str"');
        const newStrStart = str.indexOf('"new_str"');
        if (oldStrStart !== -1 && newStrStart !== -1) {
          const oldStrValueStart = str.indexOf('"', oldStrStart + 9) + 1;
          const oldStrValueEnd = str.lastIndexOf('"', newStrStart - 1);
          const newStrValueStart = str.indexOf('"', newStrStart + 9) + 1;
          let newStrValueEnd = -1;
          const endMatch = str.match(/"\s*\}\s*(?:\[\/call\])?\s*$/);
          if (endMatch) {
            newStrValueEnd = endMatch.index;
          } else {
            return null;
          }
          if (oldStrValueStart !== 0 && oldStrValueEnd > oldStrValueStart && newStrValueStart !== 0 && newStrValueEnd > newStrValueStart) {
            const oldStrValue = str.substring(oldStrValueStart, oldStrValueEnd);
            const newStrValue = str.substring(newStrValueStart, newStrValueEnd);
            return {
              filePath: filePathMatch[1],
              old_str: oldStrValue.replace(/\\n/g, "\n").replace(/\\"/g, '"'),
              new_str: newStrValue.replace(/\\n/g, "\n").replace(/\\"/g, '"')
            };
          }
        }
      }
    }
  } catch (e) {
  }
  return null;
}
const START_MARKER = "[function_calls]";
const END_MARKER = "[/function_calls]";
const managedBracketProtocol = {
  id: "managed_bracket",
  renderPrompt(tools) {
    return `## Available Tools
You can invoke the following developer tools. Tool names are case-sensitive.

${renderToolList(tools)}

When calling tools, respond with only this block:

[function_calls]
[call:exact_tool_name]{"argument":"value"}[/call]
[/function_calls]`;
  },
  detectStart(buffer) {
    return detectMarkers(buffer, [START_MARKER]);
  },
  parse(content, context) {
    const parseable = stripFencedCodeBlocks(content);
    const allowedNames = toolNames(context.tools);
    const rawMatches = [];
    const invalidToolNames = [];
    const toolCalls = [];
    const blockPattern = /\[function_calls\]([\s\S]*?)\[\/function_calls\]/g;
    let blockMatch;
    while ((blockMatch = blockPattern.exec(parseable)) !== null) {
      rawMatches.push(blockMatch[0]);
      const callPattern = /\[call:([^\]]+)\]([\s\S]*?)\[\/call\]/g;
      let callMatch;
      while ((callMatch = callPattern.exec(blockMatch[1])) !== null) {
        const name = callMatch[1].trim();
        if (!allowedNames.has(name)) {
          invalidToolNames.push(name);
          continue;
        }
        toolCalls.push(buildToolCall(`call_${toolCalls.length}`, toolCalls.length, name, callMatch[2], callMatch[0]));
      }
    }
    if (toolCalls.length === 0) {
      return createParseResult({
        content,
        toolCalls,
        protocol: rawMatches.length > 0 ? "managed_bracket" : "unknown",
        rawMatches,
        invalidToolNames
      });
    }
    const cleanContent = rawMatches.reduce((acc, raw) => acc.replace(raw, ""), parseable).trim();
    return createParseResult({
      content: cleanContent,
      toolCalls,
      protocol: "managed_bracket",
      rawMatches,
      invalidToolNames
    });
  },
  formatAssistantToolCalls(calls) {
    const body = calls.map((call) => `[call:${call.name}]${call.arguments}[/call]`).join("\n");
    return `${START_MARKER}
${body}
${END_MARKER}`;
  },
  formatToolResult(result) {
    return genericToolResultBlock(result);
  }
};
const anthropicToolUseProtocol = {
  id: "anthropic_tool_use",
  renderPrompt(tools) {
    return `## Available Tools
${renderToolList(tools)}

Use Anthropic-style tool invocation only when this protocol is enabled.`;
  },
  detectStart(buffer) {
    return detectMarkers(buffer, ["<antml:function_calls>"]);
  },
  parse(content, context) {
    const parseable = stripFencedCodeBlocks(content);
    const allowedNames = toolNames(context.tools);
    const rawMatches = [];
    const invalidToolNames = [];
    const toolCalls = [];
    const blockPattern = /<antml:function_calls>([\s\S]*?)<\/antml:function_calls>/g;
    let blockMatch;
    while ((blockMatch = blockPattern.exec(parseable)) !== null) {
      rawMatches.push(blockMatch[0]);
      const invokePattern = /<antml:invoke\s+name="([^"]+)"\s*>([\s\S]*?)<\/antml:invoke>/g;
      let invokeMatch;
      while ((invokeMatch = invokePattern.exec(blockMatch[1])) !== null) {
        const name = invokeMatch[1].trim();
        if (!allowedNames.has(name)) {
          invalidToolNames.push(name);
          continue;
        }
        const parameters = invokeMatch[2].match(/<antml:parameters>([\s\S]*?)<\/antml:parameters>/);
        toolCalls.push(
          buildToolCall(
            `call_${toolCalls.length}`,
            toolCalls.length,
            name,
            parameters ? parameters[1] : "{}",
            invokeMatch[0]
          )
        );
      }
    }
    if (toolCalls.length === 0) {
      return createParseResult({
        content,
        toolCalls,
        protocol: rawMatches.length > 0 ? "anthropic_tool_use" : "unknown",
        rawMatches,
        invalidToolNames
      });
    }
    return createParseResult({
      content: rawMatches.reduce((acc, raw) => acc.replace(raw, ""), parseable).trim(),
      toolCalls,
      protocol: "anthropic_tool_use",
      rawMatches,
      invalidToolNames
    });
  },
  formatAssistantToolCalls(calls) {
    const body = calls.map((call) => `<antml:invoke name="${call.name}"><antml:parameters>${call.arguments}</antml:parameters></antml:invoke>`).join("");
    return `<antml:function_calls>${body}</antml:function_calls>`;
  },
  formatToolResult(result) {
    return genericToolResultBlock(result);
  }
};
const codexResponsesProtocol = {
  id: "codex_responses",
  renderPrompt(tools) {
    return `## Available Tools
${renderToolList(tools)}

When Codex Responses compatibility is enabled, emit response items with type "function_call".`;
  },
  detectStart(buffer) {
    return detectMarkers(buffer, ['"type":"function_call"', '"type": "function_call"', '{"type"']);
  },
  parse(content, context) {
    const parseable = stripFencedCodeBlocks(content).trim();
    const allowedNames = toolNames(context.tools);
    const rawMatches = [];
    const invalidToolNames = [];
    const toolCalls = [];
    let parsed;
    try {
      parsed = JSON.parse(parseable);
    } catch {
      return createParseResult({
        content,
        toolCalls,
        protocol: "unknown",
        rawMatches,
        malformedReason: "codex_responses_json_parse_failed"
      });
    }
    const items = extractResponseItems(parsed);
    for (const item of items) {
      if (!item || typeof item !== "object") continue;
      const record = item;
      if (record.type !== "function_call") continue;
      const name = typeof record.name === "string" ? record.name : "";
      if (!allowedNames.has(name)) {
        if (name) invalidToolNames.push(name);
        continue;
      }
      const id = typeof record.call_id === "string" ? record.call_id : typeof record.id === "string" ? record.id : `call_${toolCalls.length}`;
      toolCalls.push(buildToolCall(id, toolCalls.length, name, normalizeArguments(record.arguments), parseable));
    }
    if (toolCalls.length > 0) rawMatches.push(parseable);
    return createParseResult({
      content: toolCalls.length > 0 ? "" : content,
      toolCalls,
      protocol: toolCalls.length > 0 || invalidToolNames.length > 0 ? "codex_responses" : "unknown",
      rawMatches,
      invalidToolNames
    });
  },
  formatAssistantToolCalls(calls) {
    return JSON.stringify(
      calls.map((call) => ({
        type: "function_call",
        call_id: call.id,
        name: call.name,
        arguments: call.arguments
      }))
    );
  },
  formatToolResult(result) {
    return genericToolResultBlock(result);
  }
};
function extractResponseItems(value) {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== "object") return [];
  const record = value;
  if (record.type === "function_call") return [record];
  if (Array.isArray(record.output)) return record.output;
  if (Array.isArray(record.items)) return record.items;
  return [];
}
const protocols = {
  openai_chat: managedBracketProtocol,
  managed_bracket: managedBracketProtocol,
  managed_xml: managedXmlProtocol,
  anthropic_tool_use: anthropicToolUseProtocol,
  codex_responses: codexResponsesProtocol
};
function getToolProtocol(id) {
  return protocols[id];
}
class ToolStreamParser {
  constructor(plan) {
    this.buffer = "";
    this.isBufferingToolCall = false;
    this.emittedToolCall = false;
    this.nextToolCallIndex = 0;
    this.plan = plan;
  }
  push(content, baseChunk, includeRole = false) {
    if (!content || !this.plan.shouldParseResponse) return [];
    this.buffer += content;
    const chunks = [];
    if (!this.isBufferingToolCall) {
      const markerStart = findMarkerStart(this.buffer, this.plan);
      if (markerStart.matched) {
        if (markerStart.index > 0) {
          chunks.push(createContentChunk(baseChunk, this.buffer.slice(0, markerStart.index), includeRole));
        }
        this.buffer = this.buffer.slice(markerStart.index);
        this.isBufferingToolCall = true;
      } else if (markerStart.partial) {
        if (markerStart.index > 0) {
          chunks.push(createContentChunk(baseChunk, this.buffer.slice(0, markerStart.index), includeRole));
          this.buffer = this.buffer.slice(markerStart.index);
        }
        this.isBufferingToolCall = true;
        return chunks;
      } else {
        chunks.push(createContentChunk(baseChunk, this.buffer, includeRole));
        this.buffer = "";
        return chunks;
      }
    }
    const parsed = parseBufferedToolCall(this.buffer, this.plan);
    if (parsed.toolCalls.length > 0) {
      for (const toolCall of parsed.toolCalls) {
        const indexedToolCall = {
          ...toolCall,
          index: this.nextToolCallIndex,
          id: toolCall.id || `call_${this.nextToolCallIndex}`
        };
        this.nextToolCallIndex += 1;
        chunks.push(createToolCallChunk(baseChunk, indexedToolCall, includeRole && !this.emittedToolCall));
      }
      this.emittedToolCall = true;
      this.isBufferingToolCall = false;
      this.buffer = "";
      return chunks;
    }
    if (parsed.invalidToolNames.length > 0 || parsed.rawMatches.length > 0) {
      this.isBufferingToolCall = false;
      this.buffer = "";
    }
    return chunks;
  }
  flush(baseChunk) {
    if (!this.buffer) return [];
    const parsed = parseBufferedToolCall(this.buffer, this.plan);
    if (parsed.toolCalls.length > 0) {
      const chunks = parsed.toolCalls.map((toolCall) => {
        const indexedToolCall = {
          ...toolCall,
          index: this.nextToolCallIndex,
          id: toolCall.id || `call_${this.nextToolCallIndex}`
        };
        this.nextToolCallIndex += 1;
        this.emittedToolCall = true;
        return createToolCallChunk(baseChunk, indexedToolCall, false);
      });
      this.buffer = "";
      this.isBufferingToolCall = false;
      return chunks;
    }
    const shouldReleaseText = !this.emittedToolCall;
    const text = this.buffer;
    this.buffer = "";
    this.isBufferingToolCall = false;
    return shouldReleaseText ? [createContentChunk(baseChunk, text, false)] : [];
  }
  hasEmittedToolCall() {
    return this.emittedToolCall;
  }
  isBuffering() {
    return this.isBufferingToolCall;
  }
}
function parseBufferedToolCall(buffer, plan) {
  const selected = getToolProtocol(plan.protocol);
  return selected.parse(buffer, { tools: plan.tools, protocol: plan.protocol });
}
function findMarkerStart(buffer, plan) {
  const protocol = getToolProtocol(plan.protocol);
  const ranges = fencedRanges(buffer);
  let partialIndex = -1;
  for (let index = 0; index < buffer.length; index += 1) {
    if (isInsideRange(index, ranges)) continue;
    const suffix = buffer.slice(index);
    const detection = protocol.detectStart(suffix);
    if (detection.matched && detection.markerStart === 0) {
      return { matched: true, partial: false, index };
    }
    if (detection.partial && detection.markerStart === 0 && partialIndex === -1) {
      partialIndex = index;
    }
  }
  return partialIndex === -1 ? { matched: false, partial: false, index: -1 } : { matched: false, partial: true, index: partialIndex };
}
function fencedRanges(content) {
  const ranges = [];
  const pattern = /```[\s\S]*?```/g;
  let match;
  while ((match = pattern.exec(content)) !== null) {
    ranges.push({ start: match.index, end: match.index + match[0].length });
  }
  return ranges;
}
function isInsideRange(index, ranges) {
  return ranges.some((range) => index >= range.start && index < range.end);
}
function createContentChunk(baseChunk, content, includeRole) {
  return {
    ...baseChunk,
    choices: [{
      index: 0,
      delta: {
        ...includeRole ? { role: "assistant" } : {},
        content
      },
      finish_reason: null
    }]
  };
}
function createToolCallChunk(baseChunk, toolCall, includeRole) {
  const { rawText, ...openAiToolCall } = toolCall;
  return {
    ...baseChunk,
    choices: [{
      index: 0,
      delta: {
        ...includeRole ? { role: "assistant" } : {},
        tool_calls: [openAiToolCall]
      },
      finish_reason: null
    }]
  };
}
const SEARCH_CONTROL_MARKER_PATTERN = /^(SEARCH|WEB_SEARCH|SEARCHING)(?:\s+|$)/i;
function stripSearchControlMarker(content, enabled) {
  return enabled ? content.replace(SEARCH_CONTROL_MARKER_PATTERN, "") : content;
}
function createBaseChunk$1(id, model, created) {
  return {
    id,
    model,
    object: "chat.completion.chunk",
    created
  };
}
class DeepSeekStreamHandler {
  constructor(model, sessionId, onEnd, webSearchEnabled = false, reasoningEffort, toolCallingPlan, semanticModel) {
    this.isFirstChunk = true;
    this.messageId = "";
    this.currentPath = "";
    this.searchResults = [];
    this.thinkingStarted = false;
    this.accumulatedTokenUsage = 2;
    this.isDone = false;
    this.model = model;
    this.semanticModel = (semanticModel || model).toLowerCase();
    this.sessionId = sessionId;
    this.created = Math.floor(Date.now() / 1e3);
    this.onEnd = onEnd;
    this.toolCallingPlan = toolCallingPlan;
    this.toolStreamParser = toolCallingPlan?.shouldParseResponse ? new ToolStreamParser(toolCallingPlan) : void 0;
    this.webSearchEnabled = webSearchEnabled;
    this.reasoningEffort = reasoningEffort;
  }
  getLastMessageId() {
    return this.messageId;
  }
  isThinkingModel() {
    return this.semanticModel.includes("think") || this.semanticModel.includes("r1") || this.semanticModel.includes("reasoner") || !!this.reasoningEffort;
  }
  isFoldModel(isThinkingModel) {
    return (this.semanticModel.includes("fold") || this.semanticModel.includes("search") || this.webSearchEnabled) && !isThinkingModel;
  }
  isSilentModel() {
    return this.semanticModel.includes("silent");
  }
  isSearchSilentModel() {
    return this.semanticModel.includes("search-silent");
  }
  shouldStripSearchControlMarker() {
    return this.webSearchEnabled || this.semanticModel.includes("search");
  }
  static normalizeSearchResult(result) {
    if (!result || typeof result !== "object") return null;
    const url = result.url;
    const title = result.title;
    if (typeof url !== "string" || typeof title !== "string") return null;
    const citeIndex = typeof result.cite_index === "number" ? result.cite_index : typeof result.citeIndex === "number" ? result.citeIndex : void 0;
    const normalized = {
      ...result
    };
    delete normalized.cite_index;
    delete normalized.citeIndex;
    if (typeof citeIndex === "number" && Number.isFinite(citeIndex)) {
      normalized.cite_index = citeIndex;
    }
    return normalized;
  }
  static mergeSearchResultsInto(target, results) {
    for (const result of results) {
      const normalized = DeepSeekStreamHandler.normalizeSearchResult(result);
      if (!normalized) continue;
      const existingIndex = target.findIndex((item) => item.url === normalized.url);
      if (existingIndex >= 0) {
        target[existingIndex] = {
          ...target[existingIndex],
          ...normalized
        };
      } else {
        target.push(normalized);
      }
    }
  }
  static applySearchResultBatch(target, operations) {
    for (const op of operations) {
      const match = op?.p?.match(/^(\d+)\/cite_index$/);
      if (!match) continue;
      const index = parseInt(match[1], 10);
      if (target[index] && typeof op.v === "number" && Number.isFinite(op.v)) {
        target[index].cite_index = op.v;
      }
    }
  }
  static formatSearchCitations(results) {
    const seenUrls = /* @__PURE__ */ new Set();
    return results.filter((r) => Number.isFinite(r.cite_index) && typeof r.url === "string" && typeof r.title === "string").filter((r) => {
      if (seenUrls.has(r.url)) return false;
      seenUrls.add(r.url);
      return true;
    }).sort((a, b) => a.cite_index - b.cite_index).map((r) => `[${r.cite_index}]: [${r.title}](${r.url})`).join("\n");
  }
  parseSSE(data) {
    try {
      return JSON.parse(data);
    } catch {
      return null;
    }
  }
  createChunk(delta, finishReason) {
    return `data: ${JSON.stringify({
      id: `${this.sessionId}@${this.messageId}`,
      model: this.model,
      object: "chat.completion.chunk",
      choices: [{
        index: 0,
        delta,
        finish_reason: finishReason || null
      }],
      created: this.created
    })}

`;
  }
  async handleStream(stream$1) {
    const transStream = new stream.PassThrough();
    const isThinkingModel = this.isThinkingModel();
    const isSilentModel = this.isSilentModel();
    const isFoldModel = this.isFoldModel(isThinkingModel);
    const isSearchSilentModel = this.isSearchSilentModel();
    let buffer = "";
    stream$1.on("data", (chunk) => {
      buffer += chunk.toString();
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.trim() || !line.startsWith("data:")) continue;
        const data = line.slice(5).trim();
        if (data === "[DONE]") {
          this.handleDone(transStream, isFoldModel, isSearchSilentModel);
          return;
        }
        const parsed = this.parseSSE(data);
        if (!parsed) continue;
        this.processChunk(parsed, transStream, isThinkingModel, isSilentModel, isFoldModel, isSearchSilentModel);
      }
    });
    stream$1.on("end", () => {
      this.handleDone(transStream, isFoldModel, isSearchSilentModel);
    });
    stream$1.on("error", (err) => {
      transStream.emit("error", err);
    });
    return transStream;
  }
  processChunk(chunk, transStream, isThinkingModel, isSilentModel, isFoldModel, isSearchSilentModel) {
    if (chunk.response_message_id && !this.messageId) {
      this.messageId = chunk.response_message_id;
    }
    this.currentPath;
    if (chunk.v && typeof chunk.v === "object" && chunk.v.response) {
      const isThinkingNow = chunk.v.response.thinking_enabled;
      this.currentPath = isThinkingNow ? "thinking" : "content";
      const fragments = chunk.v.response.fragments;
      if (Array.isArray(fragments) && fragments.length > 0) {
        for (const fragment of fragments) {
          if (Array.isArray(fragment.results)) {
            DeepSeekStreamHandler.mergeSearchResultsInto(this.searchResults, fragment.results);
          }
          if (fragment.content) {
            const fragmentType = fragment.type;
            const fragmentContent = fragment.content;
            if (fragmentType === "THINK") {
              this.sendContent(fragmentContent, "thinking", transStream, isSilentModel, isFoldModel, isSearchSilentModel);
            } else if (fragmentType === "ANSWER" || fragmentType === "RESPONSE") {
              this.sendContent(fragmentContent, "content", transStream, isSilentModel, isFoldModel, isSearchSilentModel);
            }
          }
        }
      }
    } else if (chunk.p === "response/fragments") {
      if (Array.isArray(chunk.v)) {
        for (const fragment of chunk.v) {
          if (fragment.content) {
            const fragmentType = fragment.type;
            const fragmentContent = fragment.content;
            if (fragmentType === "THINK") {
              this.currentPath = "thinking";
              this.sendContent(fragmentContent, "thinking", transStream, isSilentModel, isFoldModel, isSearchSilentModel);
            } else if (fragmentType === "ANSWER" || fragmentType === "RESPONSE") {
              this.currentPath = "content";
              this.sendContent(fragmentContent, "content", transStream, isSilentModel, isFoldModel, isSearchSilentModel);
            }
          }
        }
      }
    } else if (chunk.p === "response" && Array.isArray(chunk.v)) {
      const hasThinking = chunk.v.some(
        (e) => e.p === "response" && e.v && typeof e.v === "object" && e.v.thinking_enabled === true
      );
      if (hasThinking) {
        this.currentPath = "thinking";
      }
    }
    if (chunk.p === "response/search_status") return;
    if (chunk.p === "response" && Array.isArray(chunk.v)) {
      chunk.v.forEach((e) => {
        if (e.p === "accumulated_token_usage" && typeof e.v === "number") {
          this.accumulatedTokenUsage = e.v;
        }
      });
    }
    if ((chunk.p === "response/search_results" || /^response\/fragments\/-?\d+\/results$/.test(chunk.p || "")) && Array.isArray(chunk.v)) {
      if (chunk.o !== "BATCH") {
        DeepSeekStreamHandler.mergeSearchResultsInto(this.searchResults, chunk.v);
      } else {
        DeepSeekStreamHandler.applySearchResultBatch(this.searchResults, chunk.v);
      }
      return;
    }
    let content = "";
    if (typeof chunk.v === "string") {
      content = chunk.v;
    } else if (Array.isArray(chunk.v)) {
      content = chunk.v.map((e) => {
        if (Array.isArray(e.v)) {
          return e.v.map((v) => v.content).join("");
        }
        return "";
      }).join("");
    }
    if (!content) return;
    let effectivePath = this.currentPath;
    if (!effectivePath && isThinkingModel) {
      effectivePath = "thinking";
    }
    this.sendContent(content, effectivePath, transStream, isSilentModel, isFoldModel, isSearchSilentModel);
  }
  sendContent(content, path2, transStream, isSilentModel, isFoldModel, isSearchSilentModel) {
    const cleanedValue = content.replace(/FINISHED/g, "");
    const filteredForSearch = stripSearchControlMarker(cleanedValue, this.shouldStripSearchControlMarker());
    const processedContent = isSearchSilentModel ? filteredForSearch.replace(/\[citation:(\d+)\]/g, "") : filteredForSearch.replace(/\[citation:(\d+)\]/g, "[$1]");
    if ((path2 === "content" || path2 === "") && this.toolStreamParser) {
      const baseChunk = createBaseChunk$1(`${this.sessionId}@${this.messageId}`, this.model, this.created);
      const chunks = this.toolStreamParser.push(processedContent, baseChunk, this.isFirstChunk);
      for (const chunk of chunks) {
        transStream.write(`data: ${JSON.stringify(chunk)}

`);
        this.isFirstChunk = false;
      }
      if (this.toolStreamParser.isBuffering() || this.toolStreamParser.hasEmittedToolCall()) {
        return;
      }
      if (chunks.length > 0) {
        return;
      }
    }
    const delta = {};
    let shouldSendDelta = true;
    if (this.isFirstChunk) {
      delta.role = "assistant";
    }
    if (path2 === "thinking") {
      if (isSilentModel) return;
      if (isFoldModel) {
        if (!this.thinkingStarted) {
          this.thinkingStarted = true;
          delta.content = `<details><summary>Thinking Process</summary><pre>${processedContent}`;
        } else {
          delta.content = processedContent;
        }
      } else {
        if (processedContent) {
          delta.reasoning_content = processedContent;
        } else {
          shouldSendDelta = false;
        }
      }
    } else if (path2 === "content") {
      if (isFoldModel && this.thinkingStarted) {
        delta.content = `</pre></details>${processedContent}`;
        this.thinkingStarted = false;
      } else {
        delta.content = processedContent;
      }
    } else {
      delta.content = processedContent;
    }
    if (shouldSendDelta && (delta.content !== void 0 || delta.reasoning_content !== void 0)) {
      transStream.write(this.createChunk(delta));
      this.isFirstChunk = false;
    }
  }
  handleDone(transStream, isFoldModel, isSearchSilentModel) {
    if (this.isDone) return;
    this.isDone = true;
    const baseChunk = createBaseChunk$1(`${this.sessionId}@${this.messageId}`, this.model, this.created);
    const flushChunks = this.toolStreamParser?.flush(baseChunk) ?? [];
    for (const outChunk of flushChunks) {
      transStream.write(`data: ${JSON.stringify(outChunk)}

`);
    }
    if (isFoldModel && this.thinkingStarted) {
      transStream.write(this.createChunk({ content: "</pre></details>" }));
    }
    if (this.searchResults.length > 0 && !isSearchSilentModel) {
      const citations = DeepSeekStreamHandler.formatSearchCitations(this.searchResults);
      if (citations) {
        transStream.write(this.createChunk({ content: `

${citations}` }));
      }
    }
    const finishReason = this.toolStreamParser?.hasEmittedToolCall() ? "tool_calls" : "stop";
    transStream.write(this.createChunk({}, finishReason));
    transStream.write("data: [DONE]\n\n");
    transStream.end();
    this.onEnd?.();
  }
  async handleNonStream(stream2) {
    let accumulatedContent = "";
    let accumulatedThinkingContent = "";
    let messageId = "";
    let currentPath = "";
    let accumulatedTokenUsage = 2;
    const searchResults = [];
    const isThinkingModel = this.isThinkingModel();
    const isFoldModel = this.isFoldModel(isThinkingModel);
    const isSearchSilentModel = this.isSearchSilentModel();
    const shouldStripSearchControlMarker = this.shouldStripSearchControlMarker();
    return new Promise((resolve, reject) => {
      let buffer = "";
      stream2.on("data", (chunk) => {
        buffer += chunk.toString();
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (!line.trim() || !line.startsWith("data:")) continue;
          const data = line.slice(5).trim();
          if (data === "[DONE]") return;
          try {
            const parsed = JSON.parse(data);
            if (parsed.response_message_id && !messageId) {
              messageId = parsed.response_message_id;
              this.messageId = parsed.response_message_id;
            }
            if (parsed.v && typeof parsed.v === "object" && parsed.v.response) {
              const isThinkingNow = parsed.v.response.thinking_enabled;
              if (isThinkingNow !== void 0) {
                currentPath = isThinkingNow ? "thinking" : "content";
              }
              const fragments = parsed.v.response.fragments;
              if (Array.isArray(fragments) && fragments.length > 0) {
                for (const fragment of fragments) {
                  if (Array.isArray(fragment.results)) {
                    DeepSeekStreamHandler.mergeSearchResultsInto(searchResults, fragment.results);
                  }
                  if (fragment.content) {
                    let cleanedFragment = fragment.content.replace(/FINISHED/g, "");
                    cleanedFragment = stripSearchControlMarker(cleanedFragment, shouldStripSearchControlMarker);
                    if (fragment.type === "THINK") {
                      accumulatedThinkingContent += cleanedFragment;
                    } else if (fragment.type === "ANSWER" || fragment.type === "RESPONSE") {
                      accumulatedContent += cleanedFragment;
                    }
                  }
                }
              }
            } else if (parsed.p === "response/fragments") {
              if (Array.isArray(parsed.v)) {
                for (const fragment of parsed.v) {
                  if (fragment.content) {
                    let cleanedFragment = fragment.content.replace(/FINISHED/g, "");
                    cleanedFragment = stripSearchControlMarker(cleanedFragment, shouldStripSearchControlMarker);
                    if (fragment.type === "THINK") {
                      currentPath = "thinking";
                      accumulatedThinkingContent += cleanedFragment;
                    } else if (fragment.type === "ANSWER" || fragment.type === "RESPONSE") {
                      currentPath = "content";
                      accumulatedContent += cleanedFragment;
                    }
                  }
                }
              }
            } else if (parsed.p === "response" && Array.isArray(parsed.v)) {
              const hasThinking = parsed.v.some(
                (e) => e.p === "response" && e.v && typeof e.v === "object" && e.v.thinking_enabled === true
              );
              if (hasThinking) {
                currentPath = "thinking";
              }
            }
            if ((parsed.p === "response/search_results" || /^response\/fragments\/-?\d+\/results$/.test(parsed.p || "")) && Array.isArray(parsed.v)) {
              if (parsed.o !== "BATCH") {
                DeepSeekStreamHandler.mergeSearchResultsInto(searchResults, parsed.v);
              } else {
                DeepSeekStreamHandler.applySearchResultBatch(searchResults, parsed.v);
              }
              continue;
            }
            if (!currentPath && isThinkingModel) {
              currentPath = "thinking";
            }
            if (!currentPath && isFoldModel) {
              currentPath = "content";
            }
            if (typeof parsed.v === "object" && Array.isArray(parsed.v)) {
              parsed.v.forEach((e) => {
                if (e.accumulated_token_usage && typeof e.v === "number") {
                  accumulatedTokenUsage = e.v;
                }
                if (Array.isArray(e.v)) {
                  let cleanedValue = e.v.map((v) => v.content).join("").replace(/FINISHED/g, "");
                  cleanedValue = stripSearchControlMarker(cleanedValue, shouldStripSearchControlMarker);
                  if (currentPath === "thinking") {
                    accumulatedThinkingContent += cleanedValue;
                  } else if (currentPath === "content") {
                    accumulatedContent += cleanedValue;
                  }
                }
              });
            }
            if (typeof parsed.v === "string") {
              let cleanedValue = parsed.v.replace(/FINISHED/g, "");
              cleanedValue = stripSearchControlMarker(cleanedValue, shouldStripSearchControlMarker);
              if (currentPath === "thinking") {
                accumulatedThinkingContent += cleanedValue;
              } else if (currentPath === "content") {
                accumulatedContent += cleanedValue;
              }
            }
          } catch {
          }
        }
      });
      stream2.on("end", () => {
        const { content: cleanContent, toolCalls } = this.toolCallingPlan?.shouldParseResponse ? { content: accumulatedContent, toolCalls: [] } : parseToolCallsFromText(accumulatedContent);
        const citations = isSearchSilentModel ? "" : DeepSeekStreamHandler.formatSearchCitations(searchResults);
        const trimmedContent = cleanContent.trim();
        const contentWithCitations = citations ? trimmedContent ? `${trimmedContent}

${citations}` : citations : trimmedContent;
        const message = {
          role: "assistant",
          reasoning_content: accumulatedThinkingContent.trim() || void 0,
          content: toolCalls.length > 0 ? null : contentWithCitations
        };
        if (toolCalls.length > 0) {
          message.tool_calls = toolCalls;
        }
        if (isThinkingModel || accumulatedThinkingContent) {
          console.log("[DeepSeek] Non-stream thinking model:", this.model);
          console.log("[DeepSeek] Accumulated thinking content length:", accumulatedThinkingContent.length);
          console.log("[DeepSeek] Accumulated content length:", accumulatedContent.length);
        }
        resolve({
          id: `${this.sessionId}@${messageId}`,
          model: this.model,
          object: "chat.completion",
          choices: [{
            index: 0,
            message,
            finish_reason: toolCalls.length > 0 ? "tool_calls" : "stop"
          }],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: accumulatedTokenUsage },
          created: this.created
        });
      });
      stream2.on("error", reject);
    });
  }
}
const CLIENT_SIGNATURES = {
  cline: {
    id: "cline",
    name: "Cline",
    detectPatterns: [
      "TOOL USE",
      "When using tools, follow this format",
      "function_calls block",
      "## Tool Use",
      "When invoking a tool"
    ],
    toolCallFormat: "xml",
    injectsPrompt: true,
    promptSectionMarkers: {
      start: "TOOL USE",
      end: "USER'S CURRENT REQUEST"
    }
  },
  rooCode: {
    id: "rooCode",
    name: "RooCode",
    detectPatterns: [
      "## Tool Use Guidelines",
      "TOOL USE",
      "You are Roo",
      "## Tool Use",
      "When invoking a tool"
    ],
    toolCallFormat: "xml",
    injectsPrompt: true
  },
  claudeCode: {
    id: "claudeCode",
    name: "Claude Code",
    detectPatterns: [
      "interactive CLI tool",
      "Claude Code",
      "You are an interactive CLI tool",
      "claude-code"
    ],
    toolCallFormat: "anthropic",
    injectsPrompt: true
  },
  cherryStudio: {
    id: "cherryStudio",
    name: "Cherry Studio",
    detectPatterns: [
      "In this environment you have access to a set of tools",
      "## Tool Use Available Tools",
      "<tool_use>",
      "<tool_use_result>"
    ],
    toolCallFormat: "xml",
    injectsPrompt: true,
    promptSectionMarkers: {
      start: "In this environment you have access to a set of tools",
      end: "# User Instructions"
    }
  },
  kilocode: {
    id: "kilocode",
    name: "Kilocode",
    detectPatterns: [
      "You are Kilo",
      "Kilo, the best coding agent",
      "## Tools",
      "Tool definitions:"
    ],
    toolCallFormat: "native",
    injectsPrompt: true
  },
  codexCli: {
    id: "codexCli",
    name: "Codex CLI",
    detectPatterns: [
      "Codex CLI",
      "terminal-based coding assistant",
      "open source project led by OpenAI",
      "apply_patch"
    ],
    toolCallFormat: "native",
    injectsPrompt: true
  },
  vscodeAgent: {
    id: "vscodeAgent",
    name: "VSCode Agent",
    detectPatterns: [
      "GitHub Copilot",
      "AI programming assistant",
      "VS Code Agent"
    ],
    toolCallFormat: "native",
    injectsPrompt: true
  },
  unknown: {
    id: "unknown",
    name: "Unknown",
    detectPatterns: [],
    toolCallFormat: "bracket",
    injectsPrompt: false
  }
};
const GENERAL_TOOL_SIGNATURES = [
  "## Available Tools",
  "## Tool Call Protocol",
  "[function_calls]",
  "TOOL_WRAP_HINT",
  "You can invoke the following developer tools",
  "Tool Call Formatting",
  "TOOL USE",
  "## Tool Use",
  "## Tools"
];
function hasGeneralToolPromptSignature(content) {
  return GENERAL_TOOL_SIGNATURES.some((sig) => content.includes(sig));
}
({
  clients: Object.fromEntries(
    Object.entries(CLIENT_SIGNATURES).map(([key, value]) => [
      key,
      value.detectPatterns
    ])
  )
});
function hasToolPromptInjected(messages) {
  for (const msg of messages) {
    if (msg.role === "system" || msg.role === "user") {
      const content = typeof msg.content === "string" ? msg.content : "";
      if (hasGeneralToolPromptSignature(content)) {
        console.log("[Tools] Detected existing tool prompt injection, skipping");
        return true;
      }
    }
  }
  return false;
}
function toolsToSystemPrompt(tools, simple = false) {
  if (!tools || tools.length === 0) {
    return "";
  }
  const toolDefinitions = tools.map((tool) => {
    const params = tool.function.parameters ? JSON.stringify(tool.function.parameters) : "{}";
    return `Tool \`${tool.function.name}\`: ${tool.function.description || "No description"}. Arguments JSON schema: ${params}`;
  }).join("\n");
  if (simple) {
    return `## Available Tools
You can invoke the following developer tools. Call a tool only when it is required and follow the JSON schema exactly when providing arguments.

${toolDefinitions}

## Tool Call Protocol
When you decide to call a tool, you MUST respond with NOTHING except a single [function_calls] block exactly like the template below:

[function_calls]
[call:exact_tool_name_from_list]{"argument": "value"}[/call]
[/function_calls]

CRITICAL RULES:
1. EVERY tool call MUST start with [call:exact_tool_name] and end with [/call]
2. You MUST use the EXACT tool name as defined in the Available Tools list
3. The content between [call:...] and [/call] MUST be a raw JSON object on ONE LINE - NO LINE BREAKS inside the JSON
4. Do NOT wrap JSON in \`\`\`json blocks
5. Do NOT output any other text, explanation, or reasoning before or after the [function_calls] block
6. If you need to call multiple tools, put them all inside the same [function_calls] block, each with its own [call:...]...[/call] wrapper
7. JSON arguments MUST be compact, all on one line, NO pretty printing, NO newlines
8. If you are writing code or regular expressions, you MUST properly escape all backslashes and quotes inside the JSON string.`;
  }
  const caseSensitivityWarning = `
CRITICAL: Tool names are CASE-SENSITIVE. You MUST use the exact tool name as defined below, including any prefixes like 'default_api:'.
`;
  return `## Available Tools
You can invoke the following developer tools. Call a tool only when it is required and follow the JSON schema exactly when providing arguments.
${caseSensitivityWarning}

${toolDefinitions}

## Tool Call Protocol
When you decide to call a tool, you MUST respond with NOTHING except a single [function_calls] block exactly like the template below:

[function_calls]
[call:exact_tool_name_from_list]{"argument": "value"}[/call]
[/function_calls]

CRITICAL RULES:
1. EVERY tool call MUST start with [call:exact_tool_name] and end with [/call]
2. You MUST use the EXACT tool name as defined in the Available Tools list (e.g., if the tool is named \`default_api:read_file\`, you MUST use \`[call:default_api:read_file]\`, NOT \`[call:read_file]\`).
3. The content between [call:...] and [/call] MUST be a raw JSON object on ONE LINE - NO LINE BREAKS inside the JSON
4. Do NOT wrap JSON in \`\`\`json blocks
5. Do NOT output any other text, explanation, or reasoning before or after the [function_calls] block
6. If you need to call multiple tools, put them all inside the same [function_calls] block, each with its own [call:...]...[/call] wrapper
7. JSON arguments MUST be compact, all on one line, NO pretty printing, NO newlines
8. If you are writing code or regular expressions, you MUST properly escape all backslashes and quotes inside the JSON string.

EXAMPLE with multiple tools - NOTE THE JSON IS ALL ON ONE LINE:
[function_calls]
[call:default_api:read_file]{"filePath":"/path/to/file"}[/call]
[call:default_api:list_dir]{"target_directory":"/path/to/dir"}[/call]
[call:default_api:search_content]{"pattern":"example","directory":"/path/to/dir"}[/call]
[/function_calls]

When you receive a tool result, it will be in the format:
[TOOL_RESULT for call_id] result_content
`;
}
const TOOL_WRAP_HINT = `

IMPORTANT: If you need to use a tool, you MUST wrap the tool call inside a [function_calls] block exactly like:
[function_calls]
[call:exact_tool_name]{"argument":"value"}[/call]
[/function_calls]

CRITICAL - MUST FOLLOW:
- Start with [call:exact_tool_name] (MUST include prefixes like default_api: if present in the tool name)
- Then the JSON arguments ALL ON ONE LINE - NO NEWLINES
- Example: [call:default_api:read_file]{"filePath":"/path/to/file"}[/call]
- Then CLOSE with [/call]
- Respond with NOTHING else if you are calling a tool`;
function parseToolCalls$1(content) {
  if (!content) {
    return { content: "", toolCalls: [], format: "unknown", rawMatches: [] };
  }
  const format = detectToolCallFormat(content);
  console.log("[ToolParser] Detected format:", format);
  let result;
  switch (format) {
    case "bracket":
      result = parseBracketFormat(content);
      break;
    case "xml":
      result = parseXmlFormat(content);
      break;
    case "anthropic":
      result = parseAnthropicFormat(content);
      break;
    case "json":
      result = parseJsonFormat(content);
      break;
    default:
      return { content, toolCalls: [], format: "unknown", rawMatches: [] };
  }
  return { ...result, format };
}
function detectToolCallFormat(content) {
  if (content.includes("[function_calls]") || /\[call[:=]/.test(content)) {
    return "bracket";
  }
  if (content.includes("<tool_use>")) {
    return "xml";
  }
  if (content.includes("<antml:function_calls>") || content.includes("antml:function_calls")) {
    return "anthropic";
  }
  if (/content"\s*:\s*\[/i.test(content) || /"function"\s*:\s*\{/i.test(content)) {
    return "json";
  }
  return "bracket";
}
function parseBracketFormat(content) {
  const toolCalls = [];
  const rawMatches = [];
  let cleanContent = content;
  let processedText = content;
  const missingBracketRegex = /(^|[^\/\[])(function_calls\])/g;
  if (!processedText.includes("[function_calls]") && missingBracketRegex.test(processedText)) {
    processedText = processedText.replace(/(^|[^\/\[])(function_calls\])/g, "$1[$2");
  }
  const blockRegex = /\[function_calls\]([\s\S]*?)(?:\[\/function_calls\]|$)/g;
  let blockMatch;
  while ((blockMatch = blockRegex.exec(processedText)) !== null) {
    const blockContent = blockMatch[1];
    const callStartRegex = /\[call[:=]?([a-zA-Z0-9_:-]+)\]/g;
    let callStartMatch;
    while ((callStartMatch = callStartRegex.exec(blockContent)) !== null) {
      const functionName = callStartMatch[1];
      const argsStartIndex = callStartMatch.index + callStartMatch[0].length;
      const remainingText = blockContent.substring(argsStartIndex);
      let argumentsStr = extractBalancedJson(remainingText);
      let parsed = null;
      if (argumentsStr) {
        let cleanArgsStr = argumentsStr.trim();
        if (cleanArgsStr.startsWith("```") && cleanArgsStr.endsWith("```")) {
          cleanArgsStr = cleanArgsStr.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
        }
        parsed = tryParseJSON(cleanArgsStr);
      }
      if (!parsed) {
        parsed = tryRegexFallback(remainingText);
      }
      if (parsed) {
        let rawTextEndIndex = argsStartIndex + (argumentsStr?.length || 0);
        const afterJson = blockContent.substring(rawTextEndIndex);
        const closeTagMatch = afterJson.match(/^\s*\[\/call\]/);
        if (closeTagMatch) rawTextEndIndex += closeTagMatch[0].length;
        const rawText = blockContent.substring(callStartMatch.index, rawTextEndIndex);
        rawMatches.push(rawText);
        toolCalls.push({
          index: toolCalls.length,
          id: `call_${Date.now()}_${toolCalls.length}`,
          type: "function",
          function: { name: functionName, arguments: JSON.stringify(parsed) }
        });
        callStartRegex.lastIndex = rawTextEndIndex;
      }
    }
  }
  for (const raw of rawMatches) {
    cleanContent = cleanContent.replace(raw, "");
  }
  const emptyBlockRegex = /\[function_calls\]\s*\[\/function_calls\]/g;
  cleanContent = cleanContent.replace(emptyBlockRegex, "");
  return { content: cleanContent.trim(), toolCalls, rawMatches };
}
function parseXmlFormat(content) {
  const toolCalls = [];
  const rawMatches = [];
  let cleanContent = content;
  const toolUseRegex = /<tool_use>\s*<name>([^<]+)<\/name>\s*<arguments>([\s\S]*?)<\/arguments>\s*<\/tool_use>/g;
  let match;
  let index = 0;
  while ((match = toolUseRegex.exec(content)) !== null) {
    const rawText = match[0];
    const name = match[1].trim();
    let argsStr = match[2].trim();
    if (argsStr.startsWith("```")) {
      argsStr = argsStr.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "");
    }
    const parsed = tryParseJSON(argsStr);
    if (parsed) {
      rawMatches.push(rawText);
      toolCalls.push({
        index: index++,
        id: `call_${Date.now()}_${index}`,
        type: "function",
        function: {
          name,
          arguments: JSON.stringify(parsed)
        }
      });
    }
  }
  for (const raw of rawMatches) {
    cleanContent = cleanContent.replace(raw, "");
  }
  return { content: cleanContent.trim(), toolCalls, rawMatches };
}
function parseAnthropicFormat(content) {
  const toolCalls = [];
  const rawMatches = [];
  let cleanContent = content;
  const blockRegex = /<antml:function_calls>\s*([\s\S]*?)\s*<\/antml:function_calls>/g;
  let blockMatch;
  while ((blockMatch = blockRegex.exec(content)) !== null) {
    const blockContent = blockMatch[1];
    rawMatches.push(blockMatch[0]);
    const invokeRegex = /<antml:invoke name="([^"]+)">\s*<antml:parameters>([\s\S]*?)<\/antml:parameters>\s*<\/antml:invoke>/g;
    let invokeMatch;
    let index = 0;
    while ((invokeMatch = invokeRegex.exec(blockContent)) !== null) {
      const name = invokeMatch[1];
      const argsStr = invokeMatch[2].trim();
      const parsed = tryParseJSON(argsStr);
      if (parsed) {
        toolCalls.push({
          index: index++,
          id: `call_${Date.now()}_${index}`,
          type: "function",
          function: {
            name,
            arguments: JSON.stringify(parsed)
          }
        });
      }
    }
  }
  for (const raw of rawMatches) {
    cleanContent = cleanContent.replace(raw, "");
  }
  return { content: cleanContent.trim(), toolCalls, rawMatches };
}
function parseJsonFormat(content) {
  const toolCalls = [];
  const rawMatches = [];
  try {
    const parsed = JSON.parse(content);
    if (parsed.tool_calls && Array.isArray(parsed.tool_calls)) {
      for (let i = 0; i < parsed.tool_calls.length; i++) {
        const tc = parsed.tool_calls[i];
        if (tc.function) {
          toolCalls.push({
            index: i,
            id: tc.id || `call_${Date.now()}_${i}`,
            type: "function",
            function: {
              name: tc.function.name,
              arguments: typeof tc.function.arguments === "string" ? tc.function.arguments : JSON.stringify(tc.function.arguments)
            }
          });
        }
      }
      rawMatches.push(content);
      return { content: "", toolCalls, rawMatches };
    }
  } catch {
  }
  const toolCallsRegex = /"tool_calls"\s*:\s*\[([\s\S]*?)\]/g;
  let match;
  while ((match = toolCallsRegex.exec(content)) !== null) {
    const toolCallsStr = `[${match[1]}]`;
    try {
      const calls = JSON.parse(toolCallsStr);
      for (let i = 0; i < calls.length; i++) {
        const tc = calls[i];
        if (tc.function) {
          toolCalls.push({
            index: i,
            id: tc.id || `call_${Date.now()}_${i}`,
            type: "function",
            function: {
              name: tc.function.name,
              arguments: typeof tc.function.arguments === "string" ? tc.function.arguments : JSON.stringify(tc.function.arguments)
            }
          });
        }
      }
      rawMatches.push(match[0]);
    } catch {
    }
  }
  let cleanContent = content;
  for (const raw of rawMatches) {
    cleanContent = cleanContent.replace(raw, "");
  }
  return { content: cleanContent.trim(), toolCalls, rawMatches };
}
function extractBalancedJson(str) {
  const startIdx = str.indexOf("{");
  if (startIdx === -1) return null;
  let depth = 0;
  let inString = false;
  let isEscaped = false;
  for (let i = startIdx; i < str.length; i++) {
    const char = str[i];
    if (char === "\\" && !isEscaped) {
      isEscaped = true;
      continue;
    }
    if (char === '"' && !isEscaped) {
      inString = !inString;
    } else if (!inString) {
      if (char === "{") {
        depth++;
      } else if (char === "}") {
        depth--;
        if (depth === 0) {
          return str.substring(startIdx, i + 1);
        }
      }
    }
    isEscaped = false;
  }
  return null;
}
function tryParseJSON(str) {
  if (!str) return null;
  try {
    return JSON.parse(str);
  } catch {
  }
  try {
    let inString = false;
    let isEscaped = false;
    let fixedStr = "";
    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      if (char === "\\" && !isEscaped) {
        isEscaped = true;
        fixedStr += char;
      } else if (char === '"' && !isEscaped) {
        inString = !inString;
        fixedStr += char;
      } else if (inString && (char === "\n" || char === "\r" || char === "	")) {
        if (char === "\n") fixedStr += "\\n";
        else if (char === "\r") fixedStr += "\\r";
        else if (char === "	") fixedStr += "\\t";
      } else {
        isEscaped = false;
        fixedStr += char;
      }
    }
    return JSON.parse(fixedStr);
  } catch {
  }
  try {
    let inString = false;
    let isEscaped = false;
    let compactStr = "";
    for (let i = 0; i < str.length; i++) {
      const char = str[i];
      if (char === "\\" && !isEscaped) {
        isEscaped = true;
        compactStr += char;
      } else if (char === '"' && !isEscaped) {
        inString = !inString;
        compactStr += char;
      } else if (!inString && (char === "\n" || char === "\r" || char === "	")) {
        continue;
      } else {
        isEscaped = false;
        compactStr += char;
      }
    }
    return JSON.parse(compactStr);
  } catch {
  }
  try {
    const fixedStr = str.replace(/([{,]\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*:/g, '$1"$2":');
    let inString = false;
    let isEscaped = false;
    let compactStr = "";
    for (let i = 0; i < fixedStr.length; i++) {
      const char = fixedStr[i];
      if (char === "\\" && !isEscaped) {
        isEscaped = true;
        compactStr += char;
      } else if (char === '"' && !isEscaped) {
        inString = !inString;
        compactStr += char;
      } else if (!inString && (char === "\n" || char === "\r")) {
        continue;
      } else {
        isEscaped = false;
        compactStr += char;
      }
    }
    return JSON.parse(compactStr);
  } catch {
  }
  try {
    const doubleQuotedStr = str.replace(/'/g, '"');
    return JSON.parse(doubleQuotedStr);
  } catch {
  }
  return null;
}
function tryRegexFallback(str) {
  try {
    if (str.includes('"filePath"') && str.includes('"content"')) {
      const filePathMatch = str.match(/"filePath"\s*:\s*"([^"]+)"/);
      if (filePathMatch) {
        const contentStart = str.indexOf('"content"');
        if (contentStart !== -1) {
          const valueStart = str.indexOf('"', contentStart + 9) + 1;
          let valueEnd = -1;
          const endMatch = str.match(/"\s*\}\s*(?:\[\/call\])?\s*$/);
          if (endMatch) {
            valueEnd = endMatch.index;
          } else {
            return null;
          }
          if (valueStart !== 0 && valueEnd > valueStart) {
            const contentValue = str.substring(valueStart, valueEnd);
            return {
              filePath: filePathMatch[1],
              content: contentValue.replace(/\\n/g, "\n").replace(/\\"/g, '"')
            };
          }
        }
      }
    }
    if (str.includes('"filePath"') && str.includes('"old_str"') && str.includes('"new_str"')) {
      const filePathMatch = str.match(/"filePath"\s*:\s*"([^"]+)"/);
      if (filePathMatch) {
        const oldStrStart = str.indexOf('"old_str"');
        const newStrStart = str.indexOf('"new_str"');
        if (oldStrStart !== -1 && newStrStart !== -1) {
          const oldStrValueStart = str.indexOf('"', oldStrStart + 9) + 1;
          const oldStrValueEnd = str.lastIndexOf('"', newStrStart - 1);
          const newStrValueStart = str.indexOf('"', newStrStart + 9) + 1;
          let newStrValueEnd = -1;
          const endMatch = str.match(/"\s*\}\s*(?:\[\/call\])?\s*$/);
          if (endMatch) {
            newStrValueEnd = endMatch.index;
          } else {
            return null;
          }
          if (oldStrValueStart !== 0 && oldStrValueEnd > oldStrValueStart && newStrValueStart !== 0 && newStrValueEnd > newStrValueStart) {
            const oldStrValue = str.substring(oldStrValueStart, oldStrValueEnd);
            const newStrValue = str.substring(newStrValueStart, newStrValueEnd);
            return {
              filePath: filePathMatch[1],
              old_str: oldStrValue.replace(/\\n/g, "\n").replace(/\\"/g, '"'),
              new_str: newStrValue.replace(/\\n/g, "\n").replace(/\\"/g, '"')
            };
          }
        }
      }
    }
  } catch {
  }
  return null;
}
function createStreamState() {
  return {
    contentBuffer: "",
    isBufferingToolCall: false,
    toolCallIndex: 0,
    hasEmittedToolCall: false
  };
}
function createToolCallState() {
  return createStreamState();
}
function processStreamContent(content, state, baseChunk, isFirstChunk, modelType = "default") {
  const result = [];
  const marker = "[function_calls]";
  if (!content) {
    return { chunks: result, shouldFlush: false };
  }
  state.contentBuffer += content;
  if (!state.isBufferingToolCall) {
    const markerIdx = state.contentBuffer.indexOf("[function_calls]");
    if (markerIdx !== -1) {
      state.isBufferingToolCall = true;
      if (markerIdx > 0) {
        const textBefore = state.contentBuffer.substring(0, markerIdx);
        if (!state.hasEmittedToolCall) {
          result.push({
            ...baseChunk,
            choices: [{
              index: 0,
              delta: {
                ...isFirstChunk ? { role: "assistant" } : {},
                content: textBefore
              },
              finish_reason: null
            }]
          });
        }
        state.contentBuffer = state.contentBuffer.substring(markerIdx);
      }
    } else {
      let foundPartial = false;
      for (let i = 0; i < state.contentBuffer.length; i++) {
        if (state.contentBuffer[i] === "[") {
          const potentialMarker = state.contentBuffer.substring(i);
          if (marker.startsWith(potentialMarker)) {
            state.isBufferingToolCall = true;
            foundPartial = true;
            if (i > 0) {
              const textBefore = state.contentBuffer.substring(0, i);
              if (!state.hasEmittedToolCall) {
                result.push({
                  ...baseChunk,
                  choices: [{
                    index: 0,
                    delta: {
                      ...isFirstChunk ? { role: "assistant" } : {},
                      content: textBefore
                    },
                    finish_reason: null
                  }]
                });
              }
              state.contentBuffer = potentialMarker;
            }
            break;
          }
        }
      }
      if (foundPartial) {
        return { chunks: result, shouldFlush: false };
      }
    }
  }
  if (state.isBufferingToolCall) {
    const hasFullMarker = state.contentBuffer.includes(marker);
    const isPrefix = marker.startsWith(state.contentBuffer);
    if (!hasFullMarker && !isPrefix) {
      state.isBufferingToolCall = false;
      if (state.contentBuffer && !state.hasEmittedToolCall) {
        result.push({
          ...baseChunk,
          choices: [{
            index: 0,
            delta: {
              ...isFirstChunk ? { role: "assistant" } : {},
              content: state.contentBuffer
            },
            finish_reason: null
          }]
        });
      }
      state.contentBuffer = "";
      return { chunks: result, shouldFlush: true };
    }
    const { content: cleanContent, toolCalls } = parseToolCallsFromText(state.contentBuffer, modelType);
    if (toolCalls.length > 0) {
      for (const tc of toolCalls) {
        tc.index = state.toolCallIndex++;
        const rawText = tc.rawText;
        delete tc.rawText;
        const toolCallData = {
          ...baseChunk,
          choices: [{
            index: 0,
            delta: {
              role: isFirstChunk ? "assistant" : void 0,
              tool_calls: [tc]
            },
            finish_reason: null
          }]
        };
        result.push(toolCallData);
        if (rawText) {
          state.contentBuffer = state.contentBuffer.replace(rawText, "");
        }
      }
      state.hasEmittedToolCall = true;
      if (state.contentBuffer.includes("[/function_calls]")) {
        state.isBufferingToolCall = false;
        state.contentBuffer = state.contentBuffer.replace(/\[\/?function_calls\]/g, "").trim();
      } else {
        state.isBufferingToolCall = state.contentBuffer.includes("[function_calls]");
      }
      if (!state.isBufferingToolCall) {
        state.contentBuffer = "";
      }
      return { chunks: result, shouldFlush: true };
    } else {
      if (state.contentBuffer.length > 5e5) {
        state.isBufferingToolCall = false;
        if (!state.hasEmittedToolCall) {
          result.push({
            ...baseChunk,
            choices: [{
              index: 0,
              delta: {
                ...isFirstChunk ? { role: "assistant" } : {},
                content: state.contentBuffer
              },
              finish_reason: null
            }]
          });
        }
        state.contentBuffer = "";
        return { chunks: result, shouldFlush: true };
      }
      return { chunks: result, shouldFlush: false };
    }
  }
  if (state.contentBuffer) {
    if (!state.hasEmittedToolCall) {
      result.push({
        ...baseChunk,
        choices: [{
          index: 0,
          delta: {
            ...isFirstChunk ? { role: "assistant" } : {},
            content: state.contentBuffer
          },
          finish_reason: null
        }]
      });
    }
    state.contentBuffer = "";
  }
  return { chunks: result, shouldFlush: true };
}
function flushToolCallBuffer(state, baseChunk, modelType = "default") {
  const result = [];
  if (!state.contentBuffer) {
    return result;
  }
  const { content: cleanContent, toolCalls } = parseToolCallsFromText(state.contentBuffer, modelType);
  if (toolCalls.length > 0) {
    for (const tc of toolCalls) {
      tc.index = state.toolCallIndex++;
      delete tc.rawText;
      result.push({
        ...baseChunk,
        choices: [{
          index: 0,
          delta: { tool_calls: [tc] },
          finish_reason: null
        }]
      });
    }
    state.hasEmittedToolCall = true;
    if (cleanContent && cleanContent.trim()) {
      result.push({
        ...baseChunk,
        choices: [{
          index: 0,
          delta: { content: cleanContent },
          finish_reason: null
        }]
      });
    }
  } else {
    if (state.contentBuffer && !state.hasEmittedToolCall) {
      result.push({
        ...baseChunk,
        choices: [{
          index: 0,
          delta: { content: state.contentBuffer },
          finish_reason: null
        }]
      });
    } else if (state.contentBuffer && state.hasEmittedToolCall) {
      console.warn("[StreamToolHandler] Discarding remaining buffer because tool calls were emitted:", state.contentBuffer.substring(0, 200) + "...");
    }
  }
  state.contentBuffer = "";
  return result;
}
function createBaseChunk(id, model, created) {
  return {
    id,
    model,
    object: "chat.completion.chunk",
    created
  };
}
const GLM_API_BASE$1 = "https://chatglm.cn/chatglm";
const DEFAULT_ASSISTANT_ID = "65940acff94777010aa6b796";
const SIGN_SECRET$1 = "8a1317a7468aa3ad86e997d08f3f31cb";
const ACCESS_TOKEN_EXPIRES = 3600;
const FILE_MAX_SIZE = 100 * 1024 * 1024;
const FAKE_HEADERS$9 = {
  Accept: "text/event-stream",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
  "App-Name": "chatglm",
  "Cache-Control": "no-cache",
  "Content-Type": "application/json",
  Origin: "https://chatglm.cn",
  Pragma: "no-cache",
  Priority: "u=1, i",
  "Sec-Ch-Ua": '"Microsoft Edge";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"Windows"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "X-App-Fr": "browser_extension",
  "X-App-Platform": "pc",
  "X-App-Version": "0.0.1",
  "X-Device-Brand": "",
  "X-Device-Model": "",
  "X-Lang": "zh",
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"
};
const tokenCache = /* @__PURE__ */ new Map();
function uuid$7() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
function md5$2(str) {
  return crypto$1.createHash("md5").update(str).digest("hex");
}
function generateSign() {
  const e = Date.now();
  const A = e.toString();
  const t = A.length;
  const o = A.split("").map((c) => Number(c));
  const i = o.reduce((acc, val) => acc + val, 0) - o[t - 2];
  const a = i % 10;
  const timestamp = A.substring(0, t - 2) + a + A.substring(t - 1, t);
  const nonce = uuid$7();
  const sign = md5$2(`${timestamp}-${nonce}-${SIGN_SECRET$1}`);
  return { timestamp, nonce, sign };
}
let GLMAdapter$1 = class GLMAdapter {
  constructor(provider, account) {
    this.provider = provider;
    this.account = account;
  }
  getRefreshToken() {
    const credentials = this.account.credentials;
    return credentials.refresh_token || credentials.token || "";
  }
  async acquireToken() {
    const refreshToken = this.getRefreshToken();
    const cached = tokenCache.get(refreshToken);
    if (cached && Date.now() < cached.expiresAt) {
      return cached.accessToken;
    }
    console.log("[GLM] Refreshing Token...");
    const sign = generateSign();
    const response = await axios.post(
      `${GLM_API_BASE$1}/user-api/user/refresh`,
      {},
      {
        headers: {
          Authorization: `Bearer ${refreshToken}`,
          ...FAKE_HEADERS$9,
          "X-Device-Id": uuid$7(),
          "X-Nonce": sign.nonce,
          "X-Request-Id": uuid$7(),
          "X-Sign": sign.sign,
          "X-Timestamp": sign.timestamp
        },
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    console.log("[GLM] Token response:", JSON.stringify(response.data, null, 2));
    const { code, status, message } = response.data || {};
    const isSuccess = code === 0 || status === 0;
    if (response.status !== 200 || !isSuccess) {
      const errorMsg = message || `HTTP ${response.status}`;
      throw new Error(`Token refresh failed: ${errorMsg}`);
    }
    const { access_token, refresh_token } = response.data.result;
    const tokenInfo = {
      accessToken: access_token,
      refreshToken: refresh_token,
      expiresAt: Date.now() + ACCESS_TOKEN_EXPIRES * 1e3
    };
    tokenCache.set(refreshToken, tokenInfo);
    if (refresh_token !== refreshToken) {
      console.log("[GLM] Token updated, saving new token");
      const decryptedCredentials = {
        refresh_token
      };
      await server_bootstrapConfig.storeManager.updateAccount(this.account.id, {
        credentials: decryptedCredentials
      });
    }
    console.log("[GLM] Token refresh successful");
    return access_token;
  }
  /**
   * Check if URL is base64 data
   */
  isBase64Data(url) {
    return url.startsWith("data:");
  }
  /**
   * Extract MIME type from base64 data URL
   */
  extractBase64Format(url) {
    const match = url.match(/^data:([^;]+);/);
    return match ? match[1] : "application/octet-stream";
  }
  /**
   * Remove base64 data header
   */
  removeBase64Header(url) {
    return url.replace(/^data:[^;]+;base64,/, "");
  }
  /**
   * Upload file to GLM
   */
  async uploadFile(fileUrl) {
    console.log("[GLM] Uploading file:", fileUrl.substring(0, 50) + "...");
    let filename;
    let fileData;
    let mimeType;
    if (this.isBase64Data(fileUrl)) {
      mimeType = this.extractBase64Format(fileUrl);
      const ext = mime.extension(mimeType) || "bin";
      filename = `${uuid$7()}.${ext}`;
      fileData = Buffer.from(this.removeBase64Header(fileUrl), "base64");
    } else {
      filename = path.basename(fileUrl.split("?")[0]);
      const response2 = await axios.get(fileUrl, {
        responseType: "arraybuffer",
        maxContentLength: FILE_MAX_SIZE,
        timeout: 6e4
      });
      fileData = Buffer.from(response2.data);
      mimeType = response2.headers["content-type"] || mime.lookup(filename) || "application/octet-stream";
    }
    const formData = new FormData();
    formData.append("file", fileData, {
      filename,
      contentType: mimeType
    });
    const token = await this.acquireToken();
    const response = await axios.post(
      `${GLM_API_BASE$1}/backend-api/assistant/file_upload`,
      formData,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          Referer: "https://chatglm.cn/",
          ...FAKE_HEADERS$9,
          ...formData.getHeaders()
        },
        maxBodyLength: FILE_MAX_SIZE,
        timeout: 6e4,
        validateStatus: () => true
      }
    );
    if (response.status !== 200 || !response.data?.result) {
      throw new Error(`File upload failed: HTTP ${response.status}`);
    }
    console.log("[GLM] File uploaded successfully:", response.data.result.source_id);
    return response.data.result;
  }
  /**
   * Extract file URLs from message content
   */
  extractFileUrls(messages) {
    const fileUrls = [];
    const imageUrls = [];
    for (const msg of messages) {
      if (Array.isArray(msg.content)) {
        for (const part of msg.content) {
          if (part.type === "image_url" && part.image_url?.url) {
            imageUrls.push(part.image_url.url);
          } else if (part.type === "file" && part.file_url?.url) {
            fileUrls.push(part.file_url.url);
          }
        }
      }
    }
    return { fileUrls, imageUrls };
  }
  messagesToPrompt(messages, refs = [], toolsPrompt, isMultiTurn = false) {
    const toolProfile = getProviderToolProfile("glm");
    const imageRefs = refs.filter((ref) => ref.width !== void 0 || ref.height !== void 0 || ref.image_url);
    const fileRefs = refs.filter((ref) => !ref.width && !ref.height && !ref.image_url);
    const content = [];
    if (fileRefs.length > 0) {
      content.push({
        type: "file",
        file: fileRefs.map((ref) => ({
          source_id: ref.source_id,
          file_url: ref.file_url
        }))
      });
    }
    for (const imageRef of imageRefs) {
      content.push({
        type: "image_url",
        image_url: {
          url: imageRef.image_url || imageRef.source_id
        }
      });
    }
    const processedMessages = messages.map((msg) => {
      if (msg.role === "assistant" && msg.tool_calls && msg.tool_calls.length > 0) {
        return {
          ...msg,
          content: toolProfile.formatAssistantToolCalls(msg.tool_calls.map((tc) => ({
            id: tc.id,
            name: tc.function.name,
            arguments: tc.function.arguments
          })))
        };
      }
      if (msg.role === "tool" && msg.tool_call_id) {
        return {
          ...msg,
          role: "user",
          content: toolProfile.formatToolResult({
            toolCallId: msg.tool_call_id,
            content: String(msg.content || "")
          })
        };
      }
      return msg;
    });
    if (isMultiTurn) {
      let lastUserIdx = -1;
      for (let i = processedMessages.length - 1; i >= 0; i--) {
        if (processedMessages[i].role === "user") {
          lastUserIdx = i;
          break;
        }
      }
      if (lastUserIdx !== -1) {
        const lastUserMsg = processedMessages[lastUserIdx];
        let textContent2 = "";
        if (typeof lastUserMsg.content === "string") {
          textContent2 = lastUserMsg.content;
        } else if (Array.isArray(lastUserMsg.content)) {
          textContent2 = lastUserMsg.content.filter((c) => c.type === "text").map((c) => c.text).join("");
        }
        for (let i = lastUserIdx + 1; i < processedMessages.length; i++) {
          if (processedMessages[i].role === "user") {
            const toolText = typeof processedMessages[i].content === "string" ? processedMessages[i].content : "";
            textContent2 += "\n" + toolText;
          }
        }
        if (toolsPrompt) {
          textContent2 = textContent2.trim() + "\n\n" + toolsPrompt;
        }
        content.push({ type: "text", text: textContent2 });
        return [{ role: "user", content }];
      }
    }
    if (processedMessages.length < 2) {
      let textContent2 = processedMessages.reduce((acc, msg) => {
        if (typeof msg.content === "string") {
          return acc + msg.content + "\n";
        } else if (Array.isArray(msg.content)) {
          const textParts = msg.content.filter((c) => c.type === "text").map((c) => c.text);
          return acc + textParts.join("") + "\n";
        }
        return acc;
      }, "");
      if (toolsPrompt) {
        textContent2 = textContent2.trim() + "\n\n" + toolsPrompt;
      }
      content.push({ type: "text", text: textContent2 });
      return [{ role: "user", content }];
    }
    let textContent = processedMessages.reduce((acc, msg) => {
      const role = msg.role.replace("system", "System").replace("assistant", "Assistant").replace("user", "User").replace("tool", "User");
      if (typeof msg.content === "string") {
        return acc + `${role}: ${msg.content}

`;
      } else if (Array.isArray(msg.content)) {
        const text = msg.content.filter((c) => c.type === "text").map((c) => c.text).join("");
        return acc + `${role}: ${text}

`;
      }
      return acc;
    }, "");
    if (toolsPrompt) {
      textContent = textContent.trim() + "\n\n" + toolsPrompt;
    }
    content.push({ type: "text", text: textContent + "Assistant: " });
    return [{ role: "user", content }];
  }
  async chatCompletion(request) {
    const token = await this.acquireToken();
    const sign = generateSign();
    const messages = [...request.messages];
    const toolPromptExists = hasToolPromptInjected(messages);
    let toolsPrompt = "";
    if (request.tools && request.tools.length > 0 && !toolPromptExists) {
      const glmStrictHint = `

GLM STRICT RULES:
- If user asks to create/modify code or files, you MUST call tools instead of replying with plain text.
- You MUST output ONLY one [function_calls] block when calling tools.
- Use exact tool names from list, case-sensitive, do not rename.`;
      toolsPrompt = toolsToSystemPrompt(request.tools) + glmStrictHint;
      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].role === "user") {
          const currentContent = messages[i].content;
          if (typeof currentContent === "string") {
            messages[i] = { ...messages[i], content: currentContent + TOOL_WRAP_HINT };
          } else if (Array.isArray(currentContent)) {
            messages[i] = {
              ...messages[i],
              content: [...currentContent, { type: "text", text: TOOL_WRAP_HINT }]
            };
          }
          break;
        }
      }
    }
    const { fileUrls, imageUrls } = this.extractFileUrls(messages);
    const refs = [];
    for (const fileUrl of fileUrls) {
      try {
        const result = await this.uploadFile(fileUrl);
        refs.push({
          source_id: result.source_id,
          file_url: result.file_url || fileUrl
        });
      } catch (error) {
        console.error("[GLM] Failed to upload file:", error);
      }
    }
    for (const imageUrl of imageUrls) {
      try {
        const result = await this.uploadFile(imageUrl);
        refs.push({
          source_id: result.source_id,
          image_url: result.file_url || imageUrl,
          width: 0,
          height: 0
        });
      } catch (error) {
        console.error("[GLM] Failed to upload image:", error);
      }
    }
    const preparedMessages = this.messagesToPrompt(messages, refs, toolsPrompt, false);
    let assistantId = DEFAULT_ASSISTANT_ID;
    let chatMode = "";
    let isNetworking = false;
    if (request.reasoning_effort) {
      chatMode = "zero";
      console.log("[GLM] Using reasoning mode, effort:", request.reasoning_effort);
    }
    if (request.web_search) {
      isNetworking = true;
      console.log("[GLM] Web search enabled");
    }
    if (request.deep_research) {
      chatMode = "deep_research";
      console.log("[GLM] Using deep research mode");
    }
    const modelForDetection = request.originalModel || request.model;
    const modelLower = modelForDetection.toLowerCase();
    if (!chatMode && (modelLower.includes("think") || modelLower.includes("zero"))) {
      chatMode = "zero";
      console.log("[GLM] Using reasoning mode (from model name)");
    }
    if (!chatMode && modelLower.includes("deepresearch")) {
      chatMode = "deep_research";
      console.log("[GLM] Using deep research mode (from model name)");
    }
    if (/^[a-z0-9]{24,}$/.test(request.model)) {
      assistantId = request.model;
    }
    console.log("[GLM] Sending chat request...");
    const response = await axios.post(
      `${GLM_API_BASE$1}/backend-api/assistant/stream`,
      {
        assistant_id: assistantId,
        conversation_id: "",
        project_id: "",
        chat_type: "user_chat",
        messages: preparedMessages,
        meta_data: {
          channel: "",
          chat_mode: chatMode || void 0,
          draft_id: "",
          if_plus_model: true,
          input_question_type: "xxxx",
          is_networking: isNetworking,
          is_test: false,
          platform: "pc",
          quote_log_id: "",
          cogview: {
            rm_label_watermark: false
          }
        }
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
          ...FAKE_HEADERS$9,
          "X-Device-Id": uuid$7(),
          "X-Request-Id": uuid$7(),
          "X-Sign": sign.sign,
          "X-Timestamp": sign.timestamp,
          "X-Nonce": sign.nonce
        },
        timeout: 12e4,
        validateStatus: () => true,
        responseType: "stream"
      }
    );
    return { response, conversationId: "" };
  }
  async deleteConversation(conversationId) {
    try {
      const token = await this.acquireToken();
      const sign = generateSign();
      await axios.post(
        `${GLM_API_BASE$1}/backend-api/assistant/conversation/delete`,
        {
          assistant_id: DEFAULT_ASSISTANT_ID,
          conversation_id: conversationId
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Referer: "https://chatglm.cn/main/alltoolsdetail",
            "X-Device-Id": uuid$7(),
            "X-Request-Id": uuid$7(),
            "X-Sign": sign.sign,
            "X-Timestamp": sign.timestamp,
            "X-Nonce": sign.nonce,
            ...FAKE_HEADERS$9
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      console.log("[GLM] Conversation deleted:", conversationId);
      return true;
    } catch (error) {
      console.error("[GLM] Failed to delete conversation:", error);
      return false;
    }
  }
  async deleteAllChats() {
    try {
      const token = await this.acquireToken();
      const allConversationIds = [];
      let page = 1;
      let hasMore = true;
      while (hasMore) {
        const sign2 = generateSign();
        const listResponse = await axios.post(
          `${GLM_API_BASE$1}/mainchat-api/conversation/recent_list`,
          { page, page_size: 100 },
          {
            headers: {
              Authorization: `Bearer ${token}`,
              Referer: "https://chatglm.cn/main/alltoolsdetail",
              "X-Device-Id": uuid$7(),
              "X-Request-Id": uuid$7(),
              "X-Sign": sign2.sign,
              "X-Timestamp": sign2.timestamp,
              "X-Nonce": sign2.nonce,
              ...FAKE_HEADERS$9
            },
            timeout: 3e4,
            validateStatus: () => true
          }
        );
        console.log("[GLM] Get conversation list page", page, "response:", JSON.stringify(listResponse.data, null, 2));
        const { status, result } = listResponse.data || {};
        if (listResponse.status !== 200 || status !== 0) {
          console.error("[GLM] Failed to get conversation list");
          return false;
        }
        const conversationList = result?.conversation_list || [];
        for (const c of conversationList) {
          allConversationIds.push(c.conversation_id);
        }
        hasMore = result?.has_more || false;
        page++;
        if (conversationList.length === 0) {
          break;
        }
      }
      if (allConversationIds.length === 0) {
        console.log("[GLM] No conversations to delete");
        return true;
      }
      console.log("[GLM] Found", allConversationIds.length, "conversations to delete");
      const sign = generateSign();
      const deleteResponse = await axios.post(
        `${GLM_API_BASE$1}/mainchat-api/conversation/bulk_delete`,
        { conversation_ids: allConversationIds },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Referer: "https://chatglm.cn/main/alltoolsdetail",
            "X-Device-Id": uuid$7(),
            "X-Request-Id": uuid$7(),
            "X-Sign": sign.sign,
            "X-Timestamp": sign.timestamp,
            "X-Nonce": sign.nonce,
            ...FAKE_HEADERS$9
          },
          timeout: 6e4,
          validateStatus: () => true
        }
      );
      console.log("[GLM] Bulk delete response:", JSON.stringify(deleteResponse.data, null, 2));
      const deleteResult = deleteResponse.data || {};
      const success = deleteResponse.status === 200 && deleteResult.status === 0;
      if (success) {
        console.log("[GLM] All chats deleted");
      }
      return success;
    } catch (error) {
      console.error("[GLM] Failed to delete all chats:", error);
      return false;
    }
  }
  static isGLMProvider(provider) {
    return provider.id === "glm" || provider.apiEndpoint.includes("chatglm.cn");
  }
};
class GLMStreamHandler {
  constructor(model, onEnd, initialConversationId, toolCallingPlan) {
    this.conversationId = "";
    this.model = model;
    this.created = Math.floor(Date.now() / 1e3);
    this.onEnd = onEnd;
    this.toolCallingPlan = toolCallingPlan;
    this.toolStreamParser = toolCallingPlan?.shouldParseResponse ? new ToolStreamParser(toolCallingPlan) : void 0;
    if (initialConversationId) {
      this.conversationId = initialConversationId;
    }
  }
  async handleStream(stream$1) {
    const transStream = new stream.PassThrough();
    const cachedParts = [];
    let sentContent = "";
    let sentReasoning = "";
    let sentRole = false;
    transStream.write(
      `data: ${JSON.stringify({
        id: "",
        model: this.model,
        object: "chat.completion.chunk",
        choices: [{ index: 0, delta: { role: "assistant", content: "" }, finish_reason: null }],
        created: this.created
      })}

`
    );
    const parser = eventsourceParser.createParser({
      onEvent: (event) => {
        try {
          const result = JSON.parse(event.data);
          if (!this.conversationId && result.conversation_id) {
            this.conversationId = result.conversation_id;
          }
          if (result.status !== "finish" && result.status !== "intervene") {
            if (result.parts) {
              result.parts.forEach((part) => {
                const index = cachedParts.findIndex((p) => p.logic_id === part.logic_id);
                if (index !== -1) {
                  cachedParts[index] = part;
                } else {
                  cachedParts.push(part);
                }
              });
            }
            const searchMap = /* @__PURE__ */ new Map();
            cachedParts.forEach((part) => {
              if (!part.content || !Array.isArray(part.content)) return;
              const { meta_data } = part;
              part.content.forEach((item) => {
                if (item.type === "tool_result" && meta_data?.tool_result_extra?.search_results) {
                  meta_data.tool_result_extra.search_results.forEach((res) => {
                    if (res.match_key) {
                      searchMap.set(res.match_key, res);
                    }
                  });
                }
              });
            });
            const keyToIdMap = /* @__PURE__ */ new Map();
            let counter = 1;
            let fullText = "";
            let fullReasoning = "";
            cachedParts.forEach((part) => {
              const { content, meta_data } = part;
              if (!Array.isArray(content)) return;
              let partText = "";
              let partReasoning = "";
              content.forEach((value) => {
                const { type, text, think, image, code, content: innerContent } = value;
                if (type === "text") {
                  let txt = text;
                  if (searchMap.size > 0) {
                    txt = txt.replace(/【?(turn\d+[a-zA-Z]+\d+)】?/g, (match, key) => {
                      const searchInfo = searchMap.get(key);
                      if (!searchInfo) return match;
                      if (!keyToIdMap.has(key)) {
                        keyToIdMap.set(key, counter++);
                      }
                      return ` [${keyToIdMap.get(key)}](${searchInfo.url})`;
                    });
                  }
                  partText += txt;
                } else if (type === "think") {
                  partReasoning += think;
                } else if (type === "image" && Array.isArray(image) && part.status === "finish") {
                  const imageText = image.reduce((imgs, v) => {
                    return imgs + (/^(http|https):\/\//.test(v.image_url) ? `![image](${v.image_url})` : "");
                  }, "") + "\n";
                  partText += imageText;
                } else if (type === "code") {
                  partText += "```python\n" + code + (part.status === "finish" ? "\n```\n" : "");
                } else if (type === "execution_output" && typeof innerContent === "string" && part.status === "finish") {
                  partText += innerContent + "\n";
                }
              });
              if (partText) fullText += (fullText.length > 0 ? "\n" : "") + partText;
              if (partReasoning) fullReasoning += (fullReasoning.length > 0 ? "\n" : "") + partReasoning;
            });
            const reasoningChunk = fullReasoning.substring(sentReasoning.length);
            if (reasoningChunk) {
              sentReasoning += reasoningChunk;
              transStream.write(
                `data: ${JSON.stringify({
                  id: this.conversationId,
                  model: this.model,
                  object: "chat.completion.chunk",
                  choices: [{ index: 0, delta: { reasoning_content: reasoningChunk }, finish_reason: null }],
                  created: this.created
                })}

`
              );
            }
            const chunk = fullText.substring(sentContent.length);
            if (chunk) {
              sentContent += chunk;
            }
            const baseChunk = createBaseChunk(this.conversationId, this.model, this.created);
            const outputChunks = this.toolStreamParser?.push(chunk, baseChunk, !sentRole) ?? (chunk ? [{
              ...baseChunk,
              choices: [{ index: 0, delta: { ...!sentRole ? { role: "assistant" } : {}, content: chunk }, finish_reason: null }]
            }] : []);
            for (const outChunk of outputChunks) {
              transStream.write(`data: ${JSON.stringify(outChunk)}

`);
            }
            if (outputChunks.length > 0) sentRole = true;
          } else {
            const baseChunk = createBaseChunk(this.conversationId, this.model, this.created);
            const flushChunks = this.toolStreamParser?.flush(baseChunk) ?? [];
            for (const outChunk of flushChunks) {
              transStream.write(`data: ${JSON.stringify(outChunk)}

`);
            }
            const finishReason = this.toolStreamParser?.hasEmittedToolCall() ? "tool_calls" : "stop";
            transStream.write(
              `data: ${JSON.stringify({
                id: this.conversationId,
                model: this.model,
                object: "chat.completion.chunk",
                choices: [
                  {
                    index: 0,
                    delta: result.status === "intervene" && result.last_error?.intervene_text ? { content: "\n\n" + result.last_error.intervene_text } : {},
                    finish_reason: finishReason
                  }
                ],
                usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
                created: this.created
              })}

`
            );
            transStream.end("data: [DONE]\n\n");
            this.onEnd?.();
          }
        } catch (err) {
          console.error("[GLM] Stream parse error:", err);
        }
      }
    });
    const decoder = new TextDecoder("utf-8");
    stream$1.on("data", (buffer) => parser.feed(decoder.decode(buffer, { stream: true })));
    stream$1.once("error", (err) => {
      console.error("[GLM] Stream error:", err.message);
      const baseChunk = createBaseChunk(this.conversationId, this.model, this.created);
      const flushChunks = this.toolStreamParser?.flush(baseChunk) ?? [];
      for (const outChunk of flushChunks) {
        transStream.write(`data: ${JSON.stringify(outChunk)}

`);
      }
      const finishReason = this.toolStreamParser?.hasEmittedToolCall() ? "tool_calls" : "stop";
      transStream.write(
        `data: ${JSON.stringify({
          id: this.conversationId,
          model: this.model,
          object: "chat.completion.chunk",
          choices: [{ index: 0, delta: {}, finish_reason: finishReason }],
          created: this.created
        })}

`
      );
      transStream.end("data: [DONE]\n\n");
      this.onEnd?.();
    });
    stream$1.once("close", () => {
      console.log("[GLM] Stream closed");
      if (!transStream.closed) {
        const baseChunk = createBaseChunk(this.conversationId, this.model, this.created);
        const flushChunks = this.toolStreamParser?.flush(baseChunk) ?? [];
        for (const outChunk of flushChunks) {
          transStream.write(`data: ${JSON.stringify(outChunk)}

`);
        }
        const finishReason = this.toolStreamParser?.hasEmittedToolCall() ? "tool_calls" : "stop";
        transStream.write(
          `data: ${JSON.stringify({
            id: this.conversationId,
            model: this.model,
            object: "chat.completion.chunk",
            choices: [{ index: 0, delta: {}, finish_reason: finishReason }],
            created: this.created
          })}

`
        );
        transStream.end("data: [DONE]\n\n");
        this.onEnd?.();
      }
    });
    return transStream;
  }
  async handleNonStream(stream2) {
    return new Promise((resolve, reject) => {
      const cachedParts = [];
      const parser = eventsourceParser.createParser({
        onEvent: (event) => {
          try {
            const result = JSON.parse(event.data);
            if (!this.conversationId && result.conversation_id) {
              this.conversationId = result.conversation_id;
            }
            if (result.status !== "finish") {
              if (result.parts) {
                result.parts.forEach((part) => {
                  const index = cachedParts.findIndex((p) => p.logic_id === part.logic_id);
                  if (index !== -1) {
                    cachedParts[index] = part;
                  } else {
                    cachedParts.push(part);
                  }
                });
              }
            } else {
              const searchMap = /* @__PURE__ */ new Map();
              cachedParts.forEach((part) => {
                if (!part.content || !Array.isArray(part.content)) return;
                const { meta_data } = part;
                part.content.forEach((item) => {
                  if (item.type === "tool_result" && meta_data?.tool_result_extra?.search_results) {
                    meta_data.tool_result_extra.search_results.forEach((res) => {
                      if (res.match_key) {
                        searchMap.set(res.match_key, res);
                      }
                    });
                  }
                });
              });
              const keyToIdMap = /* @__PURE__ */ new Map();
              let counter = 1;
              let fullText = "";
              let fullReasoning = "";
              cachedParts.forEach((part) => {
                const { content, meta_data } = part;
                if (!Array.isArray(content)) return;
                let partText = "";
                let partReasoning = "";
                content.forEach((value) => {
                  const { type, text, think, image, code, content: innerContent } = value;
                  if (type === "text") {
                    let txt = text;
                    if (searchMap.size > 0) {
                      txt = txt.replace(/【?(turn\d+[a-zA-Z]+\d+)】?/g, (match, key) => {
                        const searchInfo = searchMap.get(key);
                        if (!searchInfo) return match;
                        if (!keyToIdMap.has(key)) {
                          keyToIdMap.set(key, counter++);
                        }
                        return ` [${keyToIdMap.get(key)}](${searchInfo.url})`;
                      });
                    }
                    partText += txt;
                  } else if (type === "think") {
                    partReasoning += think;
                  } else if (type === "image" && Array.isArray(image) && part.status === "finish") {
                    const imageText = image.reduce((imgs, v) => {
                      return imgs + (/^(http|https):\/\//.test(v.image_url) ? `![image](${v.image_url})` : "");
                    }, "") + "\n";
                    partText += imageText;
                  } else if (type === "code") {
                    partText += "```python\n" + code + "\n```\n";
                  } else if (type === "execution_output" && typeof innerContent === "string" && part.status === "finish") {
                    partText += innerContent + "\n";
                  }
                });
                if (partText) fullText += (fullText.length > 0 ? "\n" : "") + partText;
                if (partReasoning) fullReasoning += (fullReasoning.length > 0 ? "\n" : "") + partReasoning;
              });
              const { content: cleanContent, toolCalls } = this.toolCallingPlan?.shouldParseResponse ? { content: fullText, toolCalls: [] } : parseToolCallsFromText(fullText, "glm");
              resolve({
                id: this.conversationId,
                model: this.model,
                object: "chat.completion",
                choices: [
                  {
                    index: 0,
                    message: {
                      role: "assistant",
                      content: toolCalls.length > 0 ? null : cleanContent.trim(),
                      reasoning_content: fullReasoning || null,
                      ...toolCalls.length > 0 ? { tool_calls: toolCalls } : {}
                    },
                    finish_reason: toolCalls.length > 0 ? "tool_calls" : "stop"
                  }
                ],
                usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
                created: Math.floor(Date.now() / 1e3)
              });
            }
          } catch (err) {
            reject(err);
          }
        }
      });
      stream2.on("data", (buffer) => parser.feed(buffer.toString()));
      stream2.once("error", reject);
      stream2.once("close", () => {
        resolve({
          id: this.conversationId,
          model: this.model,
          object: "chat.completion",
          choices: [
            {
              index: 0,
              message: { role: "assistant", content: "", reasoning_content: null },
              finish_reason: "stop"
            }
          ],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
          created: Math.floor(Date.now() / 1e3)
        });
      });
    });
  }
  getConversationId() {
    return this.conversationId;
  }
}
const KIMI_API_BASE$1 = "https://www.kimi.com";
const FAKE_HEADERS$8 = {
  Accept: "*/*",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
  "Cache-Control": "no-cache",
  Pragma: "no-cache",
  Origin: KIMI_API_BASE$1,
  "Sec-Ch-Ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"Windows"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
  Priority: "u=1, i"
};
const accessTokenMap = /* @__PURE__ */ new Map();
function unixTimestamp$2() {
  return Math.floor(Date.now() / 1e3);
}
function detectTokenType(token) {
  if (token.startsWith("eyJ") && token.split(".").length === 3) {
    try {
      const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64").toString());
      if (payload.app_id === "kimi" && payload.typ === "access") {
        return "jwt";
      }
    } catch (e) {
    }
  }
  return "refresh";
}
function extractUserIdFromJWT(token) {
  try {
    const payload = JSON.parse(Buffer.from(token.split(".")[1], "base64").toString());
    return payload.sub;
  } catch (e) {
    return void 0;
  }
}
function checkResult$1(result, refreshToken) {
  if (result.status === 401) {
    accessTokenMap.delete(refreshToken);
    throw new Error("Token invalid or expired");
  }
  if (!result.data) {
    return null;
  }
  const { error_type, message } = result.data;
  if (typeof error_type !== "string") {
    return result.data;
  }
  if (error_type === "auth.token.invalid") {
    accessTokenMap.delete(refreshToken);
  }
  throw new Error(`Kimi API error: ${message || error_type}`);
}
let KimiAdapter$1 = class KimiAdapter {
  constructor(provider, account) {
    this.provider = provider;
    this.account = account;
    this.token = account.credentials.token || account.credentials.refreshToken || "";
  }
  async acquireToken() {
    if (!this.token) {
      throw new Error("Kimi Token not configured");
    }
    let result = accessTokenMap.get(this.token);
    if (result && result.refreshTime > unixTimestamp$2()) {
      console.log("[Kimi] Using cached token");
      return { accessToken: result.accessToken, userId: result.userId };
    }
    const tokenType = detectTokenType(this.token);
    console.log("[Kimi] Token type:", tokenType);
    if (tokenType === "jwt") {
      const userId = extractUserIdFromJWT(this.token) || "";
      accessTokenMap.set(this.token, {
        accessToken: this.token,
        refreshToken: this.token,
        userId,
        refreshTime: unixTimestamp$2() + 300
      });
      console.log("[Kimi] Using JWT token, userId:", userId);
      return { accessToken: this.token, userId };
    }
    console.log("[Kimi] Non-JWT token detected, attempting direct use...");
    accessTokenMap.set(this.token, {
      accessToken: this.token,
      refreshToken: this.token,
      userId: "",
      refreshTime: unixTimestamp$2() + 300
    });
    return { accessToken: this.token, userId: "" };
  }
  messagesPrepare(messages, toolsPrompt, isMultiTurn = false) {
    const toolProfile = getProviderToolProfile("kimi");
    const processedMessages = messages.map((msg) => {
      if (msg.role === "assistant" && msg.tool_calls && msg.tool_calls.length > 0) {
        return {
          ...msg,
          content: toolProfile.formatAssistantToolCalls(msg.tool_calls.map((tc) => ({
            id: tc.id,
            name: tc.function.name,
            arguments: tc.function.arguments
          })))
        };
      }
      if (msg.role === "tool" && msg.tool_call_id) {
        return {
          ...msg,
          role: "user",
          content: toolProfile.formatToolResult({
            toolCallId: msg.tool_call_id,
            content: String(msg.content || "")
          })
        };
      }
      return msg;
    });
    let systemContent = "";
    const otherMessages = processedMessages.filter((msg) => {
      if (msg.role === "system") {
        const text = typeof msg.content === "string" ? msg.content : "";
        systemContent = text;
        return false;
      }
      return true;
    });
    let content = "";
    if (systemContent) {
      content = `system:${systemContent}
`;
    }
    if (isMultiTurn) {
      let lastUserIdx = -1;
      for (let i = otherMessages.length - 1; i >= 0; i--) {
        if (otherMessages[i].role === "user") {
          lastUserIdx = i;
          break;
        }
      }
      if (lastUserIdx !== -1) {
        const lastUserMsg = otherMessages[lastUserIdx];
        const text = typeof lastUserMsg.content === "string" ? lastUserMsg.content : "";
        content += `user:${this.wrapUrlsToTags(text)}
`;
        for (let i = lastUserIdx + 1; i < otherMessages.length; i++) {
          if (otherMessages[i].role === "user") {
            const toolText = typeof otherMessages[i].content === "string" ? otherMessages[i].content : "";
            content += `user:${toolText}
`;
          }
        }
        if (toolsPrompt) {
          content = content.trim() + "\n\n" + toolsPrompt;
        }
        return content;
      }
    }
    if (otherMessages.length < 2) {
      content += otherMessages.reduce((acc, msg) => {
        const text = typeof msg.content === "string" ? msg.content : "";
        return acc + `${msg.role === "user" ? this.wrapUrlsToTags(text) : text}
`;
      }, "");
    } else {
      const latestMessage = otherMessages[otherMessages.length - 1];
      const hasFileOrImage = Array.isArray(latestMessage.content) && latestMessage.content.some((v) => typeof v === "object" && ["file", "image_url"].includes(v.type));
      if (hasFileOrImage) {
        otherMessages.splice(otherMessages.length - 1, 0, {
          content: "Focus on the latest files and messages sent by user",
          role: "system"
        });
      } else {
        otherMessages.splice(otherMessages.length - 1, 0, {
          content: "Focus on the latest message from user",
          role: "system"
        });
      }
      content += otherMessages.reduce((acc, msg) => {
        const text = typeof msg.content === "string" ? msg.content : "";
        return acc + `${msg.role}:${msg.role === "user" ? this.wrapUrlsToTags(text) : text}
`;
      }, "");
    }
    if (toolsPrompt) {
      content = content.trim() + "\n\n" + toolsPrompt;
    }
    return content;
  }
  wrapUrlsToTags(content) {
    return content.replace(
      /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/gi,
      (url) => `<url id="" type="url" status="" title="" wc="">${url}</url>`
    );
  }
  async chatCompletion(request) {
    const { accessToken } = await this.acquireToken();
    const messages = [...request.messages];
    const toolPromptExists = hasToolPromptInjected(messages);
    let toolsPrompt = "";
    if (request.tools && request.tools.length > 0 && !toolPromptExists) {
      toolsPrompt = toolsToSystemPrompt(request.tools, true);
      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].role === "user") {
          const currentContent = messages[i].content;
          if (typeof currentContent === "string") {
            messages[i] = { ...messages[i], content: currentContent + TOOL_WRAP_HINT };
          } else if (Array.isArray(currentContent)) {
            messages[i] = {
              ...messages[i],
              content: [...currentContent, { type: "text", text: TOOL_WRAP_HINT }]
            };
          }
          break;
        }
      }
    }
    const content = this.messagesPrepare(messages, toolsPrompt, false);
    const modelForDetection = request.originalModel || request.model;
    const modelLower = modelForDetection.toLowerCase();
    let enableThinking = request.enableThinking ?? false;
    let enableWebSearch = request.enableWebSearch ?? false;
    if (!enableThinking && (modelLower.includes("think") || modelLower.includes("r1"))) {
      enableThinking = true;
      console.log("[Kimi] Thinking mode enabled (from model name)");
    }
    if (!enableWebSearch && modelLower.includes("search")) {
      enableWebSearch = true;
      console.log("[Kimi] Web search enabled (from model name)");
    }
    const payload = createKimiChatPayload({
      model: request.model,
      content,
      enableWebSearch,
      enableThinking
    });
    const frameBuffer = encodeKimiGrpcFrame(payload);
    console.log("[Kimi] Request body length:", frameBuffer.length, "JSON length:", frameBuffer.length - 5);
    const response = await axios.post(
      `${KIMI_API_BASE$1}/apiv2/kimi.gateway.chat.v1.ChatService/Chat`,
      frameBuffer,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/connect+json",
          ...FAKE_HEADERS$8
        },
        timeout: 12e4,
        validateStatus: () => true,
        responseType: "stream"
      }
    );
    console.log("[Kimi] Completion response status:", response.status);
    if (response.status === 401) {
      accessTokenMap.delete(this.token);
      throw new Error("Token invalid or expired");
    }
    if (response.status !== 200) {
      throw new Error(`Completion request failed: HTTP ${response.status}`);
    }
    return { response, conversationId: "" };
  }
  async deleteConversation(conversationId) {
    try {
      const { accessToken } = await this.acquireToken();
      const response = await axios.post(
        `${KIMI_API_BASE$1}/apiv2/kimi.chat.v1.ChatService/DeleteChat`,
        { chat_id: conversationId },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
            ...FAKE_HEADERS$8
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      console.log("[Kimi] Chat deleted:", conversationId, "Status:", response.status);
      return response.status === 200;
    } catch (error) {
      console.error("[Kimi] Failed to delete conversation:", error);
      return false;
    }
  }
  async listChats(pageToken) {
    const { accessToken } = await this.acquireToken();
    const response = await axios.post(
      `${KIMI_API_BASE$1}/apiv2/kimi.chat.v1.ChatService/ListChats`,
      {
        page_size: 100,
        ...pageToken ? { page_token: pageToken } : {},
        query: ""
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
          ...FAKE_HEADERS$8
        },
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    const data = checkResult$1(response, this.token);
    const chats = Array.isArray(data?.chats) ? data.chats : [];
    const chatIds = chats.map((chat) => typeof chat?.id === "string" ? chat.id : "").filter(Boolean);
    return {
      chatIds,
      nextPageToken: typeof data?.nextPageToken === "string" ? data.nextPageToken : ""
    };
  }
  async batchDeleteChats(chatIds) {
    if (chatIds.length === 0) {
      return true;
    }
    const { accessToken } = await this.acquireToken();
    const response = await axios.post(
      `${KIMI_API_BASE$1}/apiv2/kimi.chat.v1.ChatService/BatchDeleteChats`,
      { chat_ids: chatIds },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
          ...FAKE_HEADERS$8
        },
        timeout: 3e4,
        validateStatus: () => true
      }
    );
    checkResult$1(response, this.token);
    return response.status === 200;
  }
  async deleteAllChats() {
    try {
      let allChatIds = [];
      let pageToken = "";
      for (let page = 0; page < 100; page++) {
        const result = await this.listChats(pageToken || void 0);
        allChatIds = [...allChatIds, ...result.chatIds];
        if (!result.nextPageToken || result.chatIds.length === 0) {
          break;
        }
        pageToken = result.nextPageToken;
      }
      if (allChatIds.length === 0) {
        console.log("[Kimi] No chats to delete");
        return true;
      }
      console.log("[Kimi] Found", allChatIds.length, "chats to delete");
      for (let i = 0; i < allChatIds.length; i += 100) {
        const batch = allChatIds.slice(i, i + 100);
        const success = await this.batchDeleteChats(batch);
        if (!success) {
          return false;
        }
      }
      console.log("[Kimi] All chats deleted successfully");
      return true;
    } catch (error) {
      console.error("[Kimi] Failed to delete all chats:", error);
      return false;
    }
  }
  static isKimiProvider(provider) {
    return provider.id === "kimi" || provider.apiEndpoint.includes("kimi.com");
  }
};
const STAGE_NAME_THINKING = "STAGE_NAME_THINKING";
class KimiStreamHandler {
  constructor(model, conversationId, enableThinking = false, toolCallingPlan) {
    this.realChatId = null;
    this.lastMessageId = null;
    this.hasError = false;
    this.currentPhase = void 0;
    this.reasoningBuffer = "";
    this.model = model;
    this.conversationId = conversationId;
    this.enableThinking = enableThinking;
    this.toolCallingPlan = toolCallingPlan;
    this.toolStreamParser = toolCallingPlan?.shouldParseResponse ? new ToolStreamParser(toolCallingPlan) : void 0;
  }
  getConversationId() {
    if (this.realChatId) {
      return this.realChatId;
    }
    if (this.conversationId && this.conversationId.length > 0 && !this.conversationId.startsWith("kimi-")) {
      return this.conversationId;
    }
    return null;
  }
  getLastMessageId() {
    return this.lastMessageId;
  }
  hasSessionError() {
    return this.hasError;
  }
  detectMultiStage(data) {
    if (!data.block?.multiStage?.stages || !Array.isArray(data.block.multiStage.stages)) {
      return void 0;
    }
    const stages = data.block.multiStage.stages;
    if (stages.length === 0) {
      return void 0;
    }
    const firstStage = stages[0];
    if (firstStage?.name === STAGE_NAME_THINKING) {
      return firstStage.status === "completed" ? "answer" : "thinking";
    }
    return void 0;
  }
  isThinkingMask(mask) {
    if (!mask) return false;
    return mask.includes("block.think");
  }
  isAnswerMask(mask) {
    if (!mask) return false;
    return mask.includes("block.text");
  }
  extractThinkContent(data) {
    return data.block?.think?.content || null;
  }
  extractTextContent(data) {
    return data.block?.text?.content || null;
  }
  async handleStream(stream$1) {
    const transStream = new stream.PassThrough();
    const created = unixTimestamp$2();
    let buffer = Buffer.alloc(0);
    let sentRole = false;
    stream$1.on("data", (chunk) => {
      buffer = Buffer.concat([buffer, chunk]);
      this.processBuffer(buffer, transStream, created, (remaining) => {
        buffer = remaining;
      }, () => sentRole, (v) => {
        sentRole = v;
      });
    });
    stream$1.once("error", (err) => {
      console.error("[Kimi] Stream error:", err.message);
      if (!transStream.closed) transStream.end("data: [DONE]\n\n");
    });
    stream$1.once("close", () => {
      console.log("[Kimi] Stream closed, realChatId:", this.realChatId, "lastMessageId:", this.lastMessageId);
      if (!transStream.closed) transStream.end("data: [DONE]\n\n");
    });
    return transStream;
  }
  processBuffer(buffer, transStream, created, setBuffer, getSentRole, setSentRole) {
    let offset = 0;
    while (offset + 5 <= buffer.length) {
      buffer.readUInt8(offset);
      const length = buffer.readUInt32BE(offset + 1);
      if (offset + 5 + length > buffer.length) {
        break;
      }
      const payload = buffer.slice(offset + 5, offset + 5 + length);
      try {
        const text = payload.toString("utf8");
        if (text.trim()) {
          const data = JSON.parse(text);
          if (data.error) {
            console.error("[Kimi] API Error:", data.error);
            this.hasError = true;
            transStream.write(`data: ${JSON.stringify({
              id: this.conversationId,
              model: this.model,
              object: "chat.completion.chunk",
              choices: [{ index: 0, delta: { content: `Error: ${data.error.message || JSON.stringify(data.error)}` }, finish_reason: null }],
              created
            })}

`);
            transStream.write(`data: ${JSON.stringify({
              id: this.conversationId,
              model: this.model,
              object: "chat.completion.chunk",
              choices: [{ index: 0, delta: {}, finish_reason: "stop" }],
              created
            })}

`);
            transStream.end("data: [DONE]\n\n");
            return;
          }
          this.handleMessage(data, transStream, created, getSentRole, setSentRole);
        }
      } catch (e) {
      }
      offset += 5 + length;
    }
    setBuffer(buffer.slice(offset));
  }
  handleMessage(data, transStream, created, getSentRole, setSentRole) {
    if (data.heartbeat) return;
    if (data.chat?.id && !this.realChatId) {
      this.realChatId = data.chat.id;
      console.log("[Kimi] Extracted real chat_id from chat.id:", this.realChatId);
    }
    if (data.message?.id && data.message?.role === "assistant" && !this.lastMessageId) {
      this.lastMessageId = data.message.id;
      console.log("[Kimi] Extracted assistant message id:", this.lastMessageId);
    }
    const multiStagePhase = this.detectMultiStage(data);
    if (multiStagePhase) {
      this.currentPhase = multiStagePhase;
      console.log("[Kimi] Detected multiStage phase:", this.currentPhase);
    }
    if (data.block?.text?.flags === "thinking") {
      this.currentPhase = "thinking";
    } else if (data.block?.text?.flags === "answer") {
      this.currentPhase = "answer";
    }
    if (data.op === "set" || data.op === "append") {
      const mask = data.mask;
      if (this.isThinkingMask(mask)) {
        const thinkContent = this.extractThinkContent(data);
        if (thinkContent) {
          if (!getSentRole()) {
            transStream.write(`data: ${JSON.stringify({
              id: this.getConversationId(),
              model: this.model,
              object: "chat.completion.chunk",
              choices: [{ index: 0, delta: { role: "assistant" }, finish_reason: null }],
              created
            })}

`);
            setSentRole(true);
          }
          this.reasoningBuffer += thinkContent;
          transStream.write(`data: ${JSON.stringify({
            id: this.getConversationId(),
            model: this.model,
            object: "chat.completion.chunk",
            choices: [{ index: 0, delta: { reasoning_content: thinkContent }, finish_reason: null }],
            created
          })}

`);
        }
      } else if (this.isAnswerMask(mask)) {
        const textContent = this.extractTextContent(data);
        if (textContent) {
          if (!getSentRole()) {
            transStream.write(`data: ${JSON.stringify({
              id: this.getConversationId(),
              model: this.model,
              object: "chat.completion.chunk",
              choices: [{ index: 0, delta: { role: "assistant" }, finish_reason: null }],
              created
            })}

`);
            setSentRole(true);
          }
          this.sendChunk(transStream, textContent, created);
        }
      } else if (data.block?.text?.content) {
        const content = data.block.text.content;
        if (!getSentRole()) {
          transStream.write(`data: ${JSON.stringify({
            id: this.getConversationId(),
            model: this.model,
            object: "chat.completion.chunk",
            choices: [{ index: 0, delta: { role: "assistant" }, finish_reason: null }],
            created
          })}

`);
          setSentRole(true);
        }
        if (this.currentPhase === "thinking") {
          this.reasoningBuffer += content;
          transStream.write(`data: ${JSON.stringify({
            id: this.getConversationId(),
            model: this.model,
            object: "chat.completion.chunk",
            choices: [{ index: 0, delta: { reasoning_content: content }, finish_reason: null }],
            created
          })}

`);
        } else {
          this.sendChunk(transStream, content, created);
        }
      }
    }
    if (data.done !== void 0) {
      const chatId = this.getConversationId() || this.conversationId;
      const baseChunk = createBaseChunk(chatId, this.model, created);
      const flushChunks = this.toolStreamParser?.flush(baseChunk) ?? [];
      for (const outChunk of flushChunks) {
        transStream.write(`data: ${JSON.stringify(outChunk)}

`);
      }
      transStream.write(`data: ${JSON.stringify({
        id: this.getConversationId(),
        model: this.model,
        object: "chat.completion.chunk",
        choices: [{ index: 0, delta: {}, finish_reason: this.toolStreamParser?.hasEmittedToolCall() ? "tool_calls" : "stop" }],
        created
      })}

`);
      transStream.end("data: [DONE]\n\n");
    }
  }
  sendChunk(transStream, content, created) {
    const chatId = this.getConversationId() || this.conversationId;
    const baseChunk = createBaseChunk(chatId, this.model, created);
    const outputChunks = this.toolStreamParser?.push(content, baseChunk, false) ?? [];
    const hasToolCalls = outputChunks.some((c) => c.choices?.[0]?.delta?.tool_calls);
    for (const outChunk of outputChunks) {
      transStream.write(`data: ${JSON.stringify(outChunk)}

`);
    }
    if (!this.toolStreamParser || !this.toolStreamParser.isBuffering() && !this.toolStreamParser.hasEmittedToolCall() && !hasToolCalls && outputChunks.length === 0) {
      transStream.write(`data: ${JSON.stringify({
        ...baseChunk,
        choices: [{ index: 0, delta: { content }, finish_reason: null }]
      })}

`);
    }
  }
  async handleNonStream(stream2) {
    const created = unixTimestamp$2();
    let content = "";
    let reasoningContent = "";
    let buffer = Buffer.alloc(0);
    let currentPhase = void 0;
    return new Promise((resolve, reject) => {
      stream2.on("data", (chunk) => {
        buffer = Buffer.concat([buffer, chunk]);
        let offset = 0;
        while (offset + 5 <= buffer.length) {
          buffer.readUInt8(offset);
          const length = buffer.readUInt32BE(offset + 1);
          if (offset + 5 + length > buffer.length) {
            break;
          }
          const payload = buffer.slice(offset + 5, offset + 5 + length);
          try {
            const text = payload.toString("utf8");
            if (text.trim()) {
              const data = JSON.parse(text);
              if (data.error) {
                reject(new Error(`Kimi API Error: ${data.error.message || JSON.stringify(data.error)}`));
                return;
              }
              if (data.chat?.id && !this.realChatId) {
                this.realChatId = data.chat.id;
                console.log("[Kimi] Non-stream: Extracted real chat_id from chat.id:", this.realChatId);
              }
              if (data.message?.id && data.message?.role === "assistant" && !this.lastMessageId) {
                this.lastMessageId = data.message.id;
                console.log("[Kimi] Non-stream: Extracted assistant message id:", this.lastMessageId);
              }
              const multiStagePhase = this.detectMultiStage(data);
              if (multiStagePhase) {
                currentPhase = multiStagePhase;
                console.log("[Kimi] Non-stream: Detected multiStage phase:", currentPhase);
              }
              if (data.block?.text?.flags === "thinking") {
                currentPhase = "thinking";
              } else if (data.block?.text?.flags === "answer") {
                currentPhase = "answer";
              }
              if (data.op === "set" || data.op === "append") {
                const mask = data.mask;
                if (this.isThinkingMask(mask)) {
                  const thinkContent = this.extractThinkContent(data);
                  if (thinkContent) {
                    reasoningContent += thinkContent;
                  }
                } else if (this.isAnswerMask(mask)) {
                  const textContent = this.extractTextContent(data);
                  if (textContent) {
                    content += textContent;
                  }
                } else if (data.block?.text?.content) {
                  const textContent = data.block.text.content;
                  if (currentPhase === "thinking") {
                    reasoningContent += textContent;
                  } else {
                    content += textContent;
                  }
                }
              }
              if (data.done !== void 0) {
                const { content: cleanContent, toolCalls } = this.toolCallingPlan?.shouldParseResponse ? { content, toolCalls: [] } : parseToolCallsFromText(content, "kimi");
                const message = {
                  role: "assistant",
                  content: toolCalls.length > 0 ? null : cleanContent.trim()
                };
                if (reasoningContent.trim()) {
                  message.reasoning_content = reasoningContent.trim();
                }
                if (toolCalls.length > 0) {
                  message.tool_calls = toolCalls;
                }
                resolve({
                  id: this.realChatId || this.conversationId,
                  model: this.model,
                  object: "chat.completion",
                  created,
                  choices: [{
                    index: 0,
                    message,
                    finish_reason: toolCalls.length > 0 ? "tool_calls" : "stop"
                  }],
                  usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 }
                });
              }
            }
          } catch (e) {
          }
          offset += 5 + length;
        }
        buffer = buffer.slice(offset);
      });
      stream2.once("error", reject);
      stream2.once("close", () => {
        const { content: cleanContent, toolCalls } = this.toolCallingPlan?.shouldParseResponse ? { content, toolCalls: [] } : parseToolCallsFromText(content, "kimi");
        const message = {
          role: "assistant",
          content: toolCalls.length > 0 ? null : cleanContent.trim()
        };
        if (reasoningContent.trim()) {
          message.reasoning_content = reasoningContent.trim();
        }
        if (toolCalls.length > 0) {
          message.tool_calls = toolCalls;
        }
        resolve({
          id: this.conversationId,
          model: this.model,
          object: "chat.completion",
          created,
          choices: [{
            index: 0,
            message,
            finish_reason: toolCalls.length > 0 ? "tool_calls" : "stop"
          }],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 }
        });
      });
    });
  }
}
const MIMO_API_BASE = "https://aistudio.xiaomimimo.com";
function uuid$6(separator = true) {
  const id = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
  return separator ? id : id.replace(/-/g, "");
}
function parseXmlParam(xml) {
  const result = {};
  const re = /<(?:parameter|arg) name="([^"]+)">((?:.|\n|\r)*?)<\/(?:parameter|arg)>/g;
  let m;
  while ((m = re.exec(xml)) !== null) {
    const key = m[1];
    const val = m[2].trim();
    try {
      result[key] = JSON.parse(val);
    } catch {
      result[key] = val;
    }
  }
  return result;
}
function extractName(inner) {
  let m = inner.match(/<name>([^<\n]+?)<\/name>/);
  if (m) return m[1].trim();
  m = inner.match(/<name=([^<>\n\/]+)/);
  if (m) return m[1].trim();
  return null;
}
function parseMimoNativeToolCalls(text) {
  const calls = [];
  const blockRe = /<tool_callgt;([\s\S]*?)<\/tool_call>/g;
  let block;
  while ((block = blockRe.exec(text)) !== null) {
    let inner = block[1].trim();
    if (inner.startsWith("<tool_result>")) inner = inner.slice("<tool_result>".length).trim();
    if (inner.endsWith("</tool_result>")) inner = inner.slice(0, -"</tool_result>".length).trim();
    if (inner.startsWith("{")) {
      try {
        const parsed = JSON.parse(inner);
        if (parsed.name) {
          calls.push({
            id: `call_${Math.random().toString(36).slice(2, 10)}`,
            name: parsed.name,
            arguments: parsed.arguments ?? parsed.parameters ?? parsed.input ?? {}
          });
        }
      } catch {
      }
    } else if (inner.includes("<name")) {
      const name = extractName(inner);
      if (!name) continue;
      const args = parseXmlParam(inner);
      calls.push({
        id: `call_${Math.random().toString(36).slice(2, 10)}`,
        name,
        arguments: args
      });
    } else {
      const tagMatch = inner.match(/^<([a-zA-Z_][a-zA-Z0-9_]*)>/);
      if (!tagMatch) continue;
      const name = tagMatch[1].trim();
      const args = {};
      const paramRe4 = /<([a-zA-Z_][a-zA-Z0-9_]*?)>((?:.|\n|\r)*?)<\/\1>/g;
      let pm;
      while ((pm = paramRe4.exec(inner)) !== null) {
        if (pm[1] === name) continue;
        const key = pm[1].trim();
        const val = pm[2].trim();
        try {
          args[key] = JSON.parse(val);
        } catch {
          args[key] = val;
        }
      }
      calls.push({
        id: `call_${Math.random().toString(36).slice(2, 10)}`,
        name,
        arguments: args
      });
    }
  }
  return calls;
}
function parseToolCalls(text) {
  if (text.includes("<tool_callgt;")) {
    const calls2 = parseMimoNativeToolCalls(text);
    return calls2;
  }
  const calls = [];
  const blockRe = /<function_calls>([\s\S]*?)<\/function_calls>/g;
  let block;
  while ((block = blockRe.exec(text)) !== null) {
    const invokeRe = /<invoke name="([^"]+)">([\s\S]*?)<\/invoke>/g;
    let inv;
    while ((inv = invokeRe.exec(block[1])) !== null) {
      calls.push({
        id: `call_${Math.random().toString(36).slice(2, 10)}`,
        name: inv[1],
        arguments: parseXmlParam(inv[2])
      });
    }
  }
  return calls;
}
function hasToolCallMarker(text) {
  return text.includes("<tool_callgt;") || text.includes("<function_calls>");
}
const CITATION_START = "(citation";
function stripCitations(text) {
  return text.replace(/从\(citation:\d+\)中[：:]\s*/g, "").replace(/-?\s*citation:\d+[：:]\s*/g, "").replace(/[（\(]\s*citation:\d+(?:,\s*citation:\d+)*\s*[）\)]/g, "").replace(/citation:\d+(?:,\s*citation:\d+)*/g, "").replace(/\(citation:\d+\)/g, "").replace(/\[\d+\]/g, "").replace(/\s+/g, " ").trim();
}
function stripCitationsWithBuffer(text, buffer) {
  const combined = buffer.value + text;
  let cleaned = combined.replace(/从\(citation:\d+\)中[：:]\s*/g, "").replace(/-?\s*citation:\d+[：:]\s*/g, "").replace(/[（\(]\s*citation:\d+(?:,\s*citation:\d+)*\s*[）\)]/g, "").replace(/citation:\d+(?:,\s*citation:\d+)*/g, "").replace(/\(citation:\d+\)/g, "").replace(/\[\d+\]/g, "");
  const lastCitationStart = cleaned.lastIndexOf(CITATION_START);
  if (lastCitationStart !== -1) {
    const afterCitation = cleaned.slice(lastCitationStart);
    if (!afterCitation.includes(")")) {
      buffer.value = afterCitation;
      cleaned = cleaned.slice(0, lastCitationStart);
    } else {
      buffer.value = "";
    }
  } else {
    buffer.value = "";
  }
  return cleaned.replace(/\s+/g, " ").trim();
}
function stripThinkTags(text) {
  text = text.replace(/\u0000/g, "");
  text = text.replace(/^<think[^>]*>/, "");
  text = text.replace(/^&gt;/, "");
  text = text.replace(/^hink>/, "");
  text = text.replace(/^ink>/, "");
  text = text.replace(/^nk>/, "");
  text = text.replace(/^k>/, "");
  text = text.replace(/^>/, "");
  return text;
}
function stripThink(text) {
  text = text.replace(/\u0000/g, "");
  text = text.replace(/<think[\s\S]*?<\/think>/g, "");
  text = text.replace(/<think[\s\S]*?<\/thinkgt;/g, "");
  const openIdx = text.indexOf("<think");
  if (openIdx !== -1) text = text.slice(0, openIdx);
  return text.trimStart();
}
function extractThinkContent(text) {
  let thinking = "";
  let content = text;
  const thinkRegex = /<think[^>]*>([\s\S]*?)<\/think>/g;
  let match;
  while ((match = thinkRegex.exec(text)) !== null) {
    thinking += match[1];
  }
  const thinkRegex2 = /<think[^>]*>([\s\S]*?)<\/thinkgt;/g;
  while ((match = thinkRegex2.exec(text)) !== null) {
    thinking += match[1];
  }
  content = stripThink(text);
  const openIdx = text.indexOf("<think");
  if (openIdx !== -1 && !text.includes("</think") && !text.includes("</thinkgt;")) {
    const partialThink = text.slice(openIdx);
    thinking += partialThink.replace(/<think[^>]*>/, "");
  }
  return { thinking, content };
}
function extractTextContent$1(content) {
  if (typeof content === "string") {
    return content;
  }
  if (Array.isArray(content)) {
    return content.filter((part) => typeof part === "object" && part !== null && part.type === "text" && part.text).map((part) => part.text).join("\n");
  }
  return "";
}
function buildMimoQuery(messages) {
  const toolProfile = getProviderToolProfile("mimo");
  const entries = [];
  for (const message of messages) {
    if (message.role === "assistant" && message.tool_calls && message.tool_calls.length > 0) {
      entries.push({
        role: "Assistant",
        content: toolProfile.formatAssistantToolCalls(message.tool_calls.map((toolCall) => ({
          id: toolCall.id,
          name: toolCall.function.name,
          arguments: toolCall.function.arguments
        })))
      });
      continue;
    }
    if (message.role === "tool" && message.tool_call_id) {
      entries.push({
        role: "User",
        content: toolProfile.formatToolResult({
          toolCallId: message.tool_call_id,
          content: extractTextContent$1(message.content)
        })
      });
      continue;
    }
    const content = extractTextContent$1(message.content).trim();
    if (!content) {
      continue;
    }
    const role = message.role === "system" ? "System" : message.role === "assistant" ? "Assistant" : "User";
    entries.push({ role, content });
  }
  if (entries.length === 1 && entries[0].role === "User") {
    return entries[0].content;
  }
  return entries.map((entry) => `${entry.role}: ${entry.content}`).join("\n\n");
}
let MimoAdapter$1 = class MimoAdapter {
  constructor(provider, account) {
    this.provider = provider;
    this.account = account;
  }
  getCredentials() {
    const credentials = this.account.credentials;
    return {
      serviceToken: credentials.service_token || "",
      userId: credentials.user_id || "",
      phToken: credentials.ph_token || ""
    };
  }
  static isMimoProvider(provider) {
    return provider.id === "mimo" || provider.name?.toLowerCase().includes("mimo");
  }
  buildUrl(path2, phToken) {
    return `${MIMO_API_BASE}${path2}?xiaomichatbot_ph=${encodeURIComponent(phToken)}`;
  }
  buildHeaders(serviceToken, userId, phToken) {
    return {
      "Content-Type": "application/json",
      Cookie: `serviceToken=${serviceToken}; userId=${userId}; xiaomichatbot_ph=${phToken}`,
      Origin: MIMO_API_BASE,
      Referer: `${MIMO_API_BASE}/`,
      "X-Timezone": "Asia/Shanghai",
      Accept: "*/*",
      "Accept-Encoding": "gzip, deflate, br, zstd",
      "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
      "Cache-Control": "no-cache",
      Pragma: "no-cache",
      "Sec-Ch-Ua": '"Chromium";v="144", "Not(A:Brand";v="8", "Google Chrome";v="144"',
      "Sec-Ch-Ua-Mobile": "?0",
      "Sec-Ch-Ua-Platform": '"Windows"',
      "Sec-Fetch-Dest": "empty",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Site": "same-origin"
    };
  }
  async saveConversation(conversationId) {
    const { serviceToken, userId, phToken } = this.getCredentials();
    const response = await axios.post(
      this.buildUrl("/open-apis/chat/conversation/save", phToken),
      {
        conversationId,
        title: "新对话",
        type: "chat"
      },
      {
        headers: this.buildHeaders(serviceToken, userId, phToken),
        timeout: 3e4,
        validateStatus: () => true
      }
    );
    const { code, msg, message } = response.data || {};
    if (response.status !== 200 || code !== 0) {
      throw new Error(`Mimo failed to save conversation: ${msg || message || `HTTP ${response.status}`}`);
    }
  }
  async generateConversationTitle(conversationId, query, answer) {
    const content = `${query} ${answer}`.trim();
    if (!conversationId || !content) {
      return false;
    }
    try {
      const { serviceToken, userId, phToken } = this.getCredentials();
      const response = await axios.post(
        this.buildUrl("/open-apis/chat/conversation/genTitle", phToken),
        {
          conversationId,
          content
        },
        {
          headers: this.buildHeaders(serviceToken, userId, phToken),
          timeout: 3e4,
          validateStatus: () => true
        }
      );
      const { code } = response.data || {};
      if (response.status !== 200 || code !== 0) {
        console.warn("[Mimo] Failed to generate conversation title:", response.status, response.data);
        return false;
      }
      return true;
    } catch (error) {
      console.warn("[Mimo] Failed to generate conversation title:", error);
      return false;
    }
  }
  async chatCompletion(request) {
    const { serviceToken, userId, phToken } = this.getCredentials();
    if (!serviceToken || !userId || !phToken) {
      throw new Error("Mimo credentials not configured. Please add service_token, user_id, and ph_token in account settings.");
    }
    const conversationId = uuid$6(false);
    const msgId = uuid$6(false).slice(0, 32);
    const query = buildMimoQuery(request.messages);
    await this.saveConversation(conversationId);
    const modelLower = request.model.toLowerCase();
    let enableThinking = false;
    if (modelLower.includes("think") || modelLower.includes("r1")) {
      enableThinking = true;
    }
    const requestBody = {
      msgId,
      conversationId,
      query,
      isEditedQuery: false,
      modelConfig: {
        enableThinking,
        webSearchStatus: "disabled",
        model: request.model,
        temperature: request.temperature ?? 0.8,
        topP: 0.95
      },
      multiMedias: []
    };
    const response = await axios({
      method: "POST",
      url: this.buildUrl("/open-apis/bot/chat", phToken),
      data: requestBody,
      responseType: "stream",
      headers: this.buildHeaders(serviceToken, userId, phToken)
    });
    return { response, conversationId, query };
  }
  async getConversationList(pageNum = 1, pageSize = 100) {
    const { serviceToken, userId, phToken } = this.getCredentials();
    if (!serviceToken || !userId || !phToken) {
      throw new Error("Mimo credentials not configured");
    }
    const url = `${MIMO_API_BASE}/open-apis/chat/conversation/list?xiaomichatbot_ph=${encodeURIComponent(phToken)}`;
    const response = await axios.post(
      url,
      {
        pageInfo: {
          pageNum,
          pageSize
        }
      },
      {
        headers: {
          "Content-Type": "application/json",
          Cookie: `serviceToken=${serviceToken}; userId=${userId}; xiaomichatbot_ph=${phToken}`,
          Origin: MIMO_API_BASE,
          Referer: `${MIMO_API_BASE}/`
        },
        timeout: 3e4,
        validateStatus: () => true
      }
    );
    console.log("[Mimo] Get conversation list page", pageNum, "response:", JSON.stringify(response.data, null, 2));
    const { code, data } = response.data || {};
    if (response.status !== 200 || code !== 0) {
      console.error("[Mimo] Failed to get conversation list");
      return { conversationIds: [], hasMore: false };
    }
    const conversationList = data?.dataList || [];
    const conversationIds = conversationList.map((c) => c.conversationId).filter(Boolean);
    const hasMore = conversationList.length >= pageSize;
    console.log("[Mimo] Found", conversationIds.length, "conversations, hasMore:", hasMore);
    return { conversationIds, hasMore };
  }
  async deleteConversations(conversationIds) {
    if (conversationIds.length === 0) {
      return true;
    }
    const { serviceToken, userId, phToken } = this.getCredentials();
    if (!serviceToken || !userId || !phToken) {
      throw new Error("Mimo credentials not configured");
    }
    const url = `${MIMO_API_BASE}/open-apis/chat/conversation/delete?xiaomichatbot_ph=${encodeURIComponent(phToken)}`;
    const response = await axios.post(
      url,
      conversationIds,
      {
        headers: {
          "Content-Type": "application/json",
          Cookie: `serviceToken=${serviceToken}; userId=${userId}; xiaomichatbot_ph=${phToken}`,
          Origin: MIMO_API_BASE,
          Referer: `${MIMO_API_BASE}/`
        },
        timeout: 6e4,
        validateStatus: () => true
      }
    );
    console.log("[Mimo] Delete conversations response:", JSON.stringify(response.data, null, 2));
    const { code } = response.data || {};
    return response.status === 200 && code === 0;
  }
  async deleteSession(conversationId) {
    if (!conversationId) {
      return false;
    }
    return await this.deleteConversations([conversationId]);
  }
  async deleteAllChats() {
    try {
      const allConversationIds = [];
      let pageNum = 1;
      let hasMore = true;
      while (hasMore) {
        const { conversationIds, hasMore: more } = await this.getConversationList(pageNum, 100);
        allConversationIds.push(...conversationIds);
        hasMore = more;
        pageNum++;
        if (conversationIds.length === 0) {
          break;
        }
      }
      if (allConversationIds.length === 0) {
        console.log("[Mimo] No conversations to delete");
        return true;
      }
      console.log("[Mimo] Found", allConversationIds.length, "conversations to delete");
      const success = await this.deleteConversations(allConversationIds);
      if (success) {
        console.log("[Mimo] All chats deleted");
      }
      return success;
    } catch (error) {
      console.error("[Mimo] Failed to delete all chats:", error);
      return false;
    }
  }
};
class MimoStreamHandler {
  constructor(model, conversationId, thinkingMode = "strip", toolCallingPlan) {
    this.content = "";
    this.thinking = "";
    this.usage = null;
    this.dialogId = "";
    this.toolCalls = [];
    this.thinkingMode = "strip";
    this.lastSentContentLen = 0;
    this.lastSentThinkLen = 0;
    this.toolCallBuf = null;
    this.pendingText = "";
    this.citationBuffer = { value: "" };
    this.thinkingCitationBuffer = { value: "" };
    this.model = model;
    this.conversationId = conversationId;
    this.thinkingMode = thinkingMode;
    this.toolStreamParser = toolCallingPlan?.shouldParseResponse ? new ToolStreamParser(toolCallingPlan) : void 0;
  }
  async *handleStream(stream2) {
    const id = `chatcmpl-${uuid$6(false)}`;
    const created = Math.floor(Date.now() / 1e3);
    yield this.formatOpenAIChunk(id, created, { role: "assistant", content: "" }, "role");
    let buffer = "";
    let currentEvent = "";
    let state = "init";
    let totalContent = "";
    let lastProcessedIndex = 0;
    let thinkEndTagFound = false;
    const thinkEndTag1 = "</think>";
    const thinkEndTag2 = "</thinkgt;";
    for await (const chunk of stream2) {
      buffer += chunk.toString();
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith("event:")) {
          currentEvent = trimmed.slice(6).trim();
        } else if (trimmed.startsWith("data:")) {
          try {
            const dataStr = trimmed.slice(5).trim();
            const data = JSON.parse(dataStr);
            const mimoChunk = { type: currentEvent, ...data };
            if ((mimoChunk.type === "message" || mimoChunk.type === "text") && mimoChunk.content) {
              const newText = (mimoChunk.content ?? "").replace(/\u0000/g, "");
              totalContent += newText;
              this.content = totalContent;
              if (state === "init") {
                const thinkStartIdx = totalContent.indexOf("<think");
                if (thinkStartIdx !== -1) {
                  state = "thinking";
                  lastProcessedIndex = thinkStartIdx;
                } else {
                  state = "content";
                }
              }
              if (state === "thinking") {
                if (!thinkEndTagFound) {
                  let thinkEndIdx = totalContent.indexOf(thinkEndTag1, lastProcessedIndex);
                  let actualEndTag = thinkEndTag1;
                  if (thinkEndIdx === -1) {
                    thinkEndIdx = totalContent.indexOf(thinkEndTag2, lastProcessedIndex);
                    actualEndTag = thinkEndTag2;
                  }
                  if (thinkEndIdx !== -1) {
                    thinkEndTagFound = true;
                    const thinkContent = totalContent.slice(lastProcessedIndex, thinkEndIdx);
                    const cleanedThink = stripThinkTags(thinkContent);
                    const cleanedThinkWithCitations = stripCitationsWithBuffer(cleanedThink, this.thinkingCitationBuffer);
                    if (cleanedThinkWithCitations && this.thinkingMode === "separate") {
                      yield this.formatOpenAIChunk(id, created, { reasoning_content: cleanedThinkWithCitations });
                    }
                    lastProcessedIndex = thinkEndIdx + actualEndTag.length;
                    state = "content";
                  } else {
                    const thinkContent = totalContent.slice(lastProcessedIndex);
                    const cleanedThink = stripThinkTags(thinkContent);
                    const cleanedThinkWithCitations = stripCitationsWithBuffer(cleanedThink, this.thinkingCitationBuffer);
                    if (cleanedThinkWithCitations && this.thinkingMode === "separate") {
                      yield this.formatOpenAIChunk(id, created, { reasoning_content: cleanedThinkWithCitations });
                    }
                    lastProcessedIndex = totalContent.length;
                  }
                }
              }
              if (state === "content" && lastProcessedIndex < totalContent.length) {
                const contentPart = totalContent.slice(lastProcessedIndex);
                const cleanedContent = stripCitationsWithBuffer(contentPart, this.citationBuffer);
                if (cleanedContent) {
                  if (this.toolStreamParser) {
                    const chunks = this.toolStreamParser.push(cleanedContent, this.createBaseChunk(id, created));
                    for (const chunk2 of chunks) {
                      yield `data: ${JSON.stringify(chunk2)}

`;
                    }
                    if (chunks.length > 0 || this.toolStreamParser.isBuffering() || this.toolStreamParser.hasEmittedToolCall()) {
                      lastProcessedIndex = totalContent.length;
                      continue;
                    }
                  }
                  yield this.formatOpenAIChunk(id, created, { content: cleanedContent });
                }
                lastProcessedIndex = totalContent.length;
              }
            } else if (mimoChunk.type === "usage" && mimoChunk.usage) {
              this.usage = mimoChunk.usage;
            } else if (mimoChunk.type === "dialogId" && mimoChunk.content) {
              this.dialogId = mimoChunk.content;
            }
          } catch {
          }
        }
      }
    }
    const flushChunks = this.toolStreamParser?.flush(this.createBaseChunk(id, created)) ?? [];
    for (const chunk of flushChunks) {
      yield `data: ${JSON.stringify(chunk)}

`;
    }
    yield this.formatOpenAIChunk(id, created, {}, this.toolStreamParser?.hasEmittedToolCall() ? "tool_calls" : "stop");
    if (this.usage) {
      yield this.formatOpenAIUsageChunk(id, created, this.usage);
    }
  }
  async handleNonStream(stream2) {
    let buffer = "";
    let currentEvent = "";
    for await (const chunk of stream2) {
      buffer += chunk.toString();
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (trimmed.startsWith("event:")) {
          currentEvent = trimmed.slice(6).trim();
        } else if (trimmed.startsWith("data:")) {
          try {
            const data = JSON.parse(trimmed.slice(5).trim());
            const mimoChunk = { type: currentEvent, ...data };
            if ((mimoChunk.type === "message" || mimoChunk.type === "text") && mimoChunk.content) {
              const text = (mimoChunk.content ?? "").replace(/\u0000/g, "");
              this.content += text;
            } else if (mimoChunk.type === "usage" && mimoChunk.usage) {
              this.usage = mimoChunk.usage;
            } else if (mimoChunk.type === "dialogId" && mimoChunk.content) {
              this.dialogId = mimoChunk.content;
            }
          } catch {
          }
        }
      }
    }
    if (hasToolCallMarker(this.content)) {
      this.toolCalls = parseToolCalls(this.content);
    }
    let finalContent = this.content;
    let reasoningContent;
    if (this.thinkingMode === "strip") {
      finalContent = stripThink(this.content);
    } else if (this.thinkingMode === "separate") {
      const extracted = extractThinkContent(this.content);
      finalContent = extracted.content;
      reasoningContent = extracted.thinking;
    }
    finalContent = stripCitations(finalContent);
    if (reasoningContent) {
      reasoningContent = stripCitations(reasoningContent);
    }
    const id = `chatcmpl-${uuid$6(false)}`;
    const created = Math.floor(Date.now() / 1e3);
    const response = {
      id,
      object: "chat.completion",
      created,
      model: this.model,
      choices: [
        {
          index: 0,
          message: {
            role: "assistant",
            content: finalContent
          },
          finish_reason: this.toolCalls.length > 0 ? "tool_calls" : "stop"
        }
      ],
      usage: this.usage ? {
        prompt_tokens: this.usage.promptTokens,
        completion_tokens: this.usage.completionTokens,
        total_tokens: this.usage.totalTokens
      } : void 0
    };
    if (this.toolCalls.length > 0) {
      response.choices[0].message.tool_calls = this.toolCalls.map((tc) => ({
        id: tc.id,
        type: "function",
        function: {
          name: tc.name,
          arguments: JSON.stringify(tc.arguments)
        }
      }));
    }
    if (reasoningContent) {
      response.choices[0].message.reasoning_content = reasoningContent;
    }
    return JSON.stringify(response);
  }
  formatOpenAIChunk(id, created, delta, finishReason) {
    const chunk = {
      id,
      object: "chat.completion.chunk",
      created,
      model: this.model,
      choices: [
        {
          index: 0,
          delta,
          finish_reason: finishReason || null
        }
      ]
    };
    return `data: ${JSON.stringify(chunk)}

`;
  }
  createBaseChunk(id, created) {
    return {
      id,
      object: "chat.completion.chunk",
      created,
      model: this.model
    };
  }
  formatOpenAIToolCallChunk(id, created, toolCalls) {
    const chunk = {
      id,
      object: "chat.completion.chunk",
      created,
      model: this.model,
      choices: [
        {
          index: 0,
          delta: {
            tool_calls: toolCalls.map((tc, index) => ({
              index,
              id: tc.id,
              type: "function",
              function: {
                name: tc.name,
                arguments: JSON.stringify(tc.arguments)
              }
            }))
          },
          finish_reason: null
        }
      ]
    };
    return `data: ${JSON.stringify(chunk)}

`;
  }
  formatOpenAIUsageChunk(id, created, usage) {
    const chunk = {
      id,
      object: "chat.completion.chunk",
      created,
      model: this.model,
      choices: [
        {
          index: 0,
          delta: {},
          finish_reason: null
        }
      ],
      usage: {
        prompt_tokens: usage.promptTokens,
        completion_tokens: usage.completionTokens,
        total_tokens: usage.totalTokens
      }
    };
    return `data: ${JSON.stringify(chunk)}

`;
  }
  getConversationId() {
    return this.conversationId;
  }
  getAssistantContentForTitle() {
    let content = this.content;
    if (this.thinkingMode === "strip") {
      content = stripThink(content);
    } else if (this.thinkingMode === "separate") {
      content = extractThinkContent(content).content;
    }
    return stripCitations(content);
  }
  getDialogId() {
    return this.dialogId;
  }
  getUsage() {
    return this.usage;
  }
}
function parseToolUse(content) {
  const toolCalls = [];
  const toolUseRegex = /<?tool_use>\s*([\s\S]*?)\s*<\/tool_use>/gi;
  let match;
  while ((match = toolUseRegex.exec(content)) !== null) {
    const toolUseContent = match[1];
    const nameMatch = /<name>\s*([^<]*)\s*<\/name>/i.exec(toolUseContent);
    const name = nameMatch ? nameMatch[1].trim() : "";
    const argsMatch = /<arguments>\s*([\s\S]*?)\s*<\/arguments>/i.exec(toolUseContent);
    const args = argsMatch ? argsMatch[1].trim() : "{}";
    if (name) {
      toolCalls.push({
        id: `call_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        type: "function",
        function: {
          name,
          arguments: args
        }
      });
    }
  }
  return toolCalls;
}
function hasToolUse(content) {
  return /<?tool_use>/i.test(content);
}
const QWEN_API_BASE$1 = "https://chat2.qianwen.com";
const QWEN_CHAT2_API_BASE = "https://chat2-api.qianwen.com";
const QWEN_CHAT_SIDE_API_BASE = "https://chat-side.qianwen.com";
const MODEL_MAP = {
  "Qwen3.6": "Qwen",
  "Qwen3.7-Max": "Qwen3.7-Max",
  "Qwen3.5-Flash": "Qwen3.5-Flash",
  "Qwen3-Max": "Qwen3-Max",
  "Qwen3-Max-Thinking-Preview": "Qwen3-Max-Thinking-Preview",
  "Qwen3-Coder": "Qwen3-Coder"
};
const DEFAULT_HEADERS$2 = {
  Accept: "application/json, text/event-stream, text/plain, */*",
  "Accept-Language": "zh-CN,zh;q=0.9",
  "Cache-Control": "no-cache",
  Origin: "https://www.qianwen.com",
  Pragma: "no-cache",
  "Sec-Ch-Ua": '"Chromium";v="145", "Not(A:Brand";v="24", "Google Chrome";v="145"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-site",
  Referer: "https://www.qianwen.com/",
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
};
function uuid$5(separator = true) {
  const id = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
  return separator ? id : id.replace(/-/g, "");
}
function generateNonce() {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let result = "";
  for (let i = 0; i < 12; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
function extractTextContent(content) {
  if (typeof content === "string") {
    return content;
  }
  if (Array.isArray(content)) {
    return content.filter((item) => item.type === "text").map((item) => item.text || "").join("\n");
  }
  return "";
}
let QwenAdapter$1 = class QwenAdapter {
  constructor(provider, account) {
    this.axiosInstance = axios.create({
      timeout: 12e4,
      maxBodyLength: Infinity,
      maxContentLength: Infinity
    });
    this.provider = provider;
    this.account = account;
  }
  getTicket() {
    const credentials = this.account.credentials;
    return credentials.ticket || credentials.tongyi_sso_ticket || "";
  }
  mapModel(model) {
    if (MODEL_MAP[model]) {
      return MODEL_MAP[model];
    }
    return model;
  }
  getApiHeaders(ticket) {
    return {
      Cookie: `tongyi_sso_ticket=${ticket}`,
      ...DEFAULT_HEADERS$2,
      "Content-Type": "application/json",
      "X-Platform": "pc_tongyi",
      "X-DeviceId": "5b68c267-cd8e-fd0e-148a-18345bc9a104"
    };
  }
  getApiParams(extra = {}) {
    return {
      biz_id: "ai_qwen",
      chat_client: "h5",
      device: "pc",
      fr: "pc",
      pr: "qwen",
      ut: "5b68c267-cd8e-fd0e-148a-18345bc9a104",
      la: "zh_CN",
      tz: "Asia/Shanghai",
      wv: "1",
      ve: "1",
      ...extra
    };
  }
  extractSessionIds(data) {
    const candidateLists = [
      data?.data?.list,
      data?.data?.sessions,
      data?.data?.sessionList,
      data?.data?.records,
      data?.data?.items,
      data?.data?.dataList,
      data?.data?.result?.list,
      data?.data?.result?.records,
      data?.data?.pageData?.list,
      data?.data?.pageData?.records,
      data?.list,
      data?.sessions
    ].filter(Array.isArray);
    const sessionIds = candidateLists.flatMap((items) => items.map((item) => item?.session_id || item?.sessionId || item?.session?.id || item?.id).filter((sessionId) => typeof sessionId === "string" && sessionId.length > 0));
    return [...new Set(sessionIds)];
  }
  async listSessions(pageNum, cursor) {
    const ticket = this.getTicket();
    if (!ticket) {
      throw new Error("Qwen ticket not configured, please add ticket in account settings");
    }
    const response = await axios.post(
      `${QWEN_CHAT2_API_BASE}/api/v2/session/page/list`,
      {
        pageSize: 100,
        pageNum,
        ...cursor ? { cursor } : {}
      },
      {
        headers: this.getApiHeaders(ticket),
        params: this.getApiParams(),
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    if (response.status !== 200 || response.data?.success === false) {
      throw new Error(`Qwen session list failed: HTTP ${response.status}`);
    }
    const data = response.data?.data || {};
    const nextCursor = data.nextCursor || data.next_cursor || data.cursor || "";
    return {
      sessionIds: this.extractSessionIds(response.data),
      hasMore: Boolean(data.hasMore ?? data.has_more ?? data.page?.hasMore ?? data.result?.hasMore),
      nextCursor: typeof nextCursor === "string" ? nextCursor : ""
    };
  }
  async deleteRelatedFileRecords(sessionIds) {
    const ticket = this.getTicket();
    if (!ticket || sessionIds.length === 0) {
      return true;
    }
    const timestamp = Date.now();
    const response = await axios.post(
      `${QWEN_CHAT_SIDE_API_BASE}/api/v2/file/record/delete`,
      { sessionIds },
      {
        headers: this.getApiHeaders(ticket),
        params: this.getApiParams({
          nonce: generateNonce(),
          timestamp
        }),
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    if (response.status !== 200 || response.data?.success === false) {
      console.warn("[Qwen] Failed to delete related file records:", response.status, response.data);
      return false;
    }
    return true;
  }
  async deleteSessions(sessionIds) {
    const ticket = this.getTicket();
    if (!ticket || sessionIds.length === 0) {
      return sessionIds.length === 0;
    }
    const response = await axios.post(
      `${QWEN_CHAT2_API_BASE}/api/v1/session/delete/batch`,
      { session_ids: sessionIds },
      {
        headers: this.getApiHeaders(ticket),
        params: this.getApiParams(),
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    if (response.status !== 200) {
      console.warn(`[Qwen] Failed to delete sessions: status ${response.status}`);
      return false;
    }
    const { success, code, msg } = response.data || {};
    if (success === false || typeof code === "number" && code !== 0) {
      console.warn(`[Qwen] Failed to delete sessions: ${msg || "Unknown error"}`);
      return false;
    }
    const fileRecordSuccess = await this.deleteRelatedFileRecords(sessionIds);
    if (!fileRecordSuccess) {
      console.warn("[Qwen] Sessions deleted but related file record cleanup failed");
    }
    return true;
  }
  async chatCompletion(request) {
    const ticket = this.getTicket();
    if (!ticket) {
      throw new Error("Qwen ticket not configured, please add ticket in account settings");
    }
    const reqId = uuid$5(false);
    const sessionId = uuid$5(false);
    let actualModel = this.mapModel(request.model);
    const modelForDetection = request.originalModel || request.model;
    const modelLower = modelForDetection.toLowerCase();
    let enableThinking = request.enableThinking ?? false;
    let enableWebSearch = request.enableWebSearch ?? false;
    if (!enableThinking && (modelLower.includes("think") || modelLower.includes("r1"))) {
      enableThinking = true;
      console.log("[Qwen] Thinking mode enabled (from model name)");
    }
    if (!enableWebSearch && modelLower.includes("search")) {
      enableWebSearch = true;
      console.log("[Qwen] Web search enabled (from model name)");
    }
    if (enableThinking) {
      if (actualModel === "Qwen3-Max") {
        actualModel = "Qwen3-Max-Thinking-Preview";
        console.log("[Qwen] Using thinking model:", actualModel);
      }
    }
    console.log("[Qwen] Session info:", {
      sessionId,
      reqId
    });
    console.log("[Qwen] Using model:", actualModel);
    const toolProfile = getProviderToolProfile("qwen");
    let systemPrompt = "";
    const conversationParts = [];
    for (const msg of request.messages) {
      if (msg.role === "system") {
        systemPrompt = extractTextContent(msg.content);
      } else if (msg.role === "user") {
        conversationParts.push(extractTextContent(msg.content));
      } else if (msg.role === "assistant" && msg.tool_calls && msg.tool_calls.length > 0) {
        conversationParts.push(toolProfile.formatAssistantToolCalls(msg.tool_calls.map((tc) => ({
          id: tc.id,
          name: tc.function.name,
          arguments: tc.function.arguments
        }))));
      } else if (msg.role === "assistant") {
        conversationParts.push(`Assistant: ${extractTextContent(msg.content)}`);
      } else if (msg.role === "tool" && msg.tool_call_id) {
        conversationParts.push(toolProfile.formatToolResult({
          toolCallId: msg.tool_call_id,
          content: extractTextContent(msg.content)
        }));
      }
    }
    let userContent = conversationParts.join("\n\n");
    if (request.tools && request.tools.length > 0 && !hasToolPromptInjected(request.messages)) {
      const toolsPrompt = toolsToSystemPrompt(request.tools);
      systemPrompt = systemPrompt ? systemPrompt + "\n\n" + toolsPrompt : toolsPrompt;
      userContent = userContent + TOOL_WRAP_HINT;
    }
    const finalContent = systemPrompt ? `${systemPrompt}

User: ${userContent}` : userContent;
    const timestamp = Date.now();
    const nonce = generateNonce();
    const requestBody = {
      deep_search: enableWebSearch || enableThinking ? "1" : "0",
      req_id: reqId,
      model: actualModel,
      scene: "chat",
      session_id: sessionId,
      sub_scene: "chat",
      temporary: false,
      messages: [
        {
          content: finalContent,
          mime_type: "text/plain",
          meta_data: {
            ori_query: finalContent
          }
        }
      ],
      from: "default",
      parent_req_id: "0",
      enable_search: enableWebSearch,
      biz_data: '{"entryPoint":"tongyigw"}',
      scene_param: "first_turn",
      chat_client: "h5",
      client_tm: timestamp.toString(),
      protocol_version: "v2",
      biz_id: "ai_qwen"
    };
    const queryString = `biz_id=ai_qwen&chat_client=h5&device=pc&fr=pc&pr=qwen&ut=${uuid$5(false)}&nonce=${nonce}&timestamp=${timestamp}`;
    const url = `${QWEN_API_BASE$1}/api/v2/chat?${queryString}`;
    console.log("[Qwen] Sending request to /api/v2/chat...");
    const response = await this.axiosInstance.post(url, requestBody, {
      headers: {
        ...DEFAULT_HEADERS$2,
        "Content-Type": "application/json",
        Cookie: `tongyi_sso_ticket=${ticket}`
      },
      responseType: "stream",
      timeout: 12e4,
      decompress: false
    });
    console.log("[Qwen] Response status:", response.status);
    console.log("[Qwen] Response headers:", JSON.stringify(response.headers, null, 2));
    return { response, sessionId, reqId };
  }
  async deleteSession(sessionId) {
    try {
      if (!sessionId) {
        return false;
      }
      const success = await this.deleteSessions([sessionId]);
      if (success) {
        console.log("[Qwen] Session deleted successfully:", sessionId);
      }
      return success;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.warn("[Qwen] Failed to delete session:", errorMessage);
      return false;
    }
  }
  async deleteAllChats() {
    try {
      let allSessionIds = [];
      let nextCursor = "";
      for (let pageNum = 1; pageNum <= 100; pageNum++) {
        const result = await this.listSessions(pageNum, nextCursor || void 0);
        allSessionIds = [...allSessionIds, ...result.sessionIds];
        if (!result.hasMore || result.sessionIds.length === 0) {
          break;
        }
        nextCursor = result.nextCursor;
      }
      allSessionIds = [...new Set(allSessionIds)];
      if (allSessionIds.length === 0) {
        console.log("[Qwen] No sessions to delete");
        return true;
      }
      console.log("[Qwen] Found", allSessionIds.length, "sessions to delete");
      for (let i = 0; i < allSessionIds.length; i += 100) {
        const batch = allSessionIds.slice(i, i + 100);
        const success = await this.deleteSessions(batch);
        if (!success) {
          return false;
        }
      }
      console.log("[Qwen] All sessions deleted successfully");
      return true;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.warn("[Qwen] Failed to delete all sessions:", errorMessage);
      return false;
    }
  }
  static isQwenProvider(provider) {
    return provider.id === "qwen" || provider.apiEndpoint.includes("qianwen.com") || provider.apiEndpoint.includes("aliyun.com");
  }
};
class QwenStreamHandler {
  constructor(model, onEnd, toolCallingPlan) {
    this.sessionId = "";
    this.content = "";
    this.responseId = "";
    this.stopSent = false;
    this.toolCallsSent = false;
    this.hasError = false;
    this.sentRole = false;
    this.thinkingContent = "";
    this.sentThinkingRole = false;
    this.model = model;
    this.created = Math.floor(Date.now() / 1e3);
    this.onEnd = onEnd;
    this.toolCallingPlan = toolCallingPlan;
    this.toolStreamParser = toolCallingPlan?.shouldParseResponse ? new ToolStreamParser(toolCallingPlan) : void 0;
  }
  hasSessionError() {
    return this.hasError;
  }
  sendToolCalls(transStream) {
    if (this.toolCallsSent) return;
    const { toolCalls } = parseToolCallsFromText(this.content, "default");
    if (toolCalls && toolCalls.length > 0) {
      this.toolCallsSent = true;
      for (let i = 0; i < toolCalls.length; i++) {
        const tc = toolCalls[i];
        transStream.write(
          `data: ${JSON.stringify({
            id: this.responseId || this.sessionId,
            model: this.model,
            object: "chat.completion.chunk",
            choices: [{
              index: 0,
              delta: {
                tool_calls: [{
                  index: i,
                  id: tc.id,
                  type: "function",
                  function: {
                    name: tc.function.name,
                    arguments: tc.function.arguments
                  }
                }]
              },
              finish_reason: null
            }],
            created: this.created
          })}

`
        );
      }
      transStream.write(
        `data: ${JSON.stringify({
          id: this.responseId || this.sessionId,
          model: this.model,
          object: "chat.completion.chunk",
          choices: [{ index: 0, delta: {}, finish_reason: "tool_calls" }],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
          created: this.created
        })}

`
      );
      transStream.end("data: [DONE]\n\n");
      this.onEnd?.(this.sessionId);
    }
  }
  handleStream(stream$1, response) {
    const transStream = new stream.PassThrough();
    console.log("[Qwen] Starting stream handler...");
    const contentEncoding = response?.headers?.["content-encoding"];
    console.log("[Qwen] Content-Encoding:", contentEncoding);
    let buffer = "";
    let streamEnded = false;
    const safeEnd = (data) => {
      if (streamEnded) return;
      streamEnded = true;
      {
        transStream.end(data);
      }
    };
    const processBuffer = () => {
      while (true) {
        const doubleNewlineIndex = buffer.indexOf("\n\n");
        if (doubleNewlineIndex === -1) break;
        const eventBlock = buffer.substring(0, doubleNewlineIndex);
        buffer = buffer.substring(doubleNewlineIndex + 2);
        const lines = eventBlock.split("\n");
        let eventType = "message";
        let eventData = "";
        for (const line of lines) {
          if (line.startsWith("event:")) {
            eventType = line.substring(6).trim();
          } else if (line.startsWith("data:")) {
            eventData = line.substring(5);
          }
        }
        if (eventData && eventData !== "[DONE]") {
          try {
            const result = JSON.parse(eventData);
            console.log("[Qwen] Parsed event:", eventType, "data keys:", Object.keys(result));
            if (result.data?.messages) {
              console.log("[Qwen] Messages count:", result.data.messages.length);
              for (const msg of result.data.messages) {
                console.log("[Qwen] Message:", msg.mime_type, "status:", msg.status, "content length:", msg.content?.length || 0);
              }
            }
            if (result.communication) {
              if (!this.sessionId && result.communication.sessionid) {
                this.sessionId = result.communication.sessionid;
              }
              if (!this.responseId && result.communication.reqid) {
                this.responseId = result.communication.reqid;
              }
            }
            if (result.data?.messages) {
              let eventThinkingContent = "";
              let eventThinkingType = "";
              const eventMessages = [];
              for (const msg of result.data.messages) {
                console.log("[Qwen] Message detail:", JSON.stringify(msg).substring(0, 500));
                const metaData = msg.meta_data || {};
                const multiLoad = metaData.multi_load || [];
                let msgHasMultiLoad = false;
                for (const load of multiLoad) {
                  if (load.type === "deep_think" && load.content) {
                    const newThinkingContent = load.content.think_content || load.content.content || "";
                    if (newThinkingContent.length > eventThinkingContent.length) {
                      eventThinkingContent = newThinkingContent;
                      eventThinkingType = load.type;
                    }
                    msgHasMultiLoad = true;
                  } else if (load.type === "multimodal_chat_think") {
                    if (!msgHasMultiLoad && load.content) {
                      const newThinkingContent = load.content.think_content || load.content.content || "";
                      if (newThinkingContent.length > eventThinkingContent.length) {
                        eventThinkingContent = newThinkingContent;
                        eventThinkingType = load.type;
                      }
                      msgHasMultiLoad = true;
                    }
                  }
                }
                eventMessages.push({ msg, hasMultiLoad: msgHasMultiLoad });
              }
              if (!this.sentRole && eventThinkingContent.length > this.thinkingContent.length) {
                const chunk = eventThinkingContent.substring(this.thinkingContent.length);
                this.thinkingContent = eventThinkingContent;
                console.log("[Qwen] Thinking chunk, length:", chunk.length, "content:", chunk.substring(0, 50), "type:", eventThinkingType, "prev:", this.thinkingContent.length - chunk.length, "->", this.thinkingContent.length);
                if (chunk.trim()) {
                  if (!this.sentThinkingRole) {
                    transStream.write(`data: ${JSON.stringify({
                      id: this.responseId || this.sessionId,
                      model: this.model,
                      object: "chat.completion.chunk",
                      choices: [{ index: 0, delta: { role: "assistant" }, finish_reason: null }],
                      created: this.created
                    })}

`);
                    this.sentThinkingRole = true;
                  }
                  transStream.write(`data: ${JSON.stringify({
                    id: this.responseId || this.sessionId,
                    model: this.model,
                    object: "chat.completion.chunk",
                    choices: [{ index: 0, delta: { reasoning_content: chunk }, finish_reason: null }],
                    created: this.created
                  })}

`);
                }
              }
              for (const { msg } of eventMessages) {
                if ((msg.mime_type === "text/plain" || msg.mime_type === "multi_load/iframe") && msg.content) {
                  let newContent = msg.content;
                  if (newContent === "[(deep_think)]" || newContent.trim() === "[(deep_think)]") {
                    console.log("[Qwen] Skipping deep_think marker");
                    continue;
                  }
                  newContent = newContent.replace(/\[\(deep_think\)\]/g, "");
                  newContent = newContent.replace(/\[\(multimodal_chat_think_\d+\)\]/g, "");
                  if (!newContent.trim()) {
                    console.log("[Qwen] Skipping empty content after filtering");
                    continue;
                  }
                  console.log("[Qwen] newContent.length:", newContent.length, "this.content.length:", this.content.length);
                  if (newContent.length > this.content.length) {
                    const chunk = newContent.substring(this.content.length);
                    this.content = newContent;
                    console.log("[Qwen] Writing chunk, length:", chunk.length);
                    const baseChunk = createBaseChunk(this.responseId || this.sessionId, this.model, this.created);
                    const outputChunks = this.toolStreamParser?.push(chunk, baseChunk, !this.sentRole) ?? [{
                      ...baseChunk,
                      choices: [{ index: 0, delta: { ...!this.sentRole ? { role: "assistant" } : {}, content: chunk }, finish_reason: null }]
                    }];
                    for (const outChunk of outputChunks) {
                      transStream.write(`data: ${JSON.stringify(outChunk)}

`);
                    }
                    if (outputChunks.length > 0) this.sentRole = true;
                    console.log("[Qwen] Chunk written to stream");
                  } else {
                    console.log("[Qwen] Skipping - no new content");
                  }
                }
                if (msg.status === "complete" || msg.status === "finished") {
                  if (msg.mime_type === "multi_load/iframe" && !this.stopSent) {
                    this.stopSent = true;
                    console.log("[Qwen] Sending stop for multi_load/iframe, content so far:", this.content.length);
                    const baseChunk = createBaseChunk(this.responseId || this.sessionId, this.model, this.created);
                    const flushChunks = this.toolStreamParser?.flush(baseChunk) ?? [];
                    for (const outChunk of flushChunks) {
                      transStream.write(`data: ${JSON.stringify(outChunk)}

`);
                    }
                    const finishReason = this.toolStreamParser?.hasEmittedToolCall() ? "tool_calls" : "stop";
                    transStream.write(
                      `data: ${JSON.stringify({
                        id: this.responseId || this.sessionId,
                        model: this.model,
                        object: "chat.completion.chunk",
                        choices: [{ index: 0, delta: {}, finish_reason: finishReason }],
                        usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
                        created: this.created
                      })}

`
                    );
                    safeEnd("data: [DONE]\n\n");
                    this.onEnd?.(this.sessionId);
                  }
                }
              }
            }
            if (result.error_code && result.error_code !== 0) {
              console.error("[Qwen] API error:", result.error_code, result.error_msg);
              this.hasError = true;
              transStream.write(
                `data: ${JSON.stringify({
                  id: this.responseId || this.sessionId,
                  model: this.model,
                  object: "chat.completion.chunk",
                  choices: [{ index: 0, delta: { content: `
[Error: ${result.error_msg || result.error_code}]` }, finish_reason: "stop" }],
                  created: this.created
                })}

`
              );
              safeEnd("data: [DONE]\n\n");
            }
          } catch (err) {
            console.error("[Qwen] Parse error:", err, "Data:", eventData.substring(0, 200));
          }
        }
        if (eventType === "complete") {
          console.log("[Qwen] Received complete event");
          if (!streamEnded && !this.stopSent) {
            this.stopSent = true;
            const baseChunk = createBaseChunk(this.responseId || this.sessionId, this.model, this.created);
            const flushChunks = this.toolStreamParser?.flush(baseChunk) ?? [];
            for (const outChunk of flushChunks) {
              transStream.write(`data: ${JSON.stringify(outChunk)}

`);
            }
            const finishReason = this.toolStreamParser?.hasEmittedToolCall() ? "tool_calls" : "stop";
            transStream.write(
              `data: ${JSON.stringify({
                id: this.responseId || this.sessionId,
                model: this.model,
                object: "chat.completion.chunk",
                choices: [{ index: 0, delta: {}, finish_reason: finishReason }],
                usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
                created: this.created
              })}

`
            );
            safeEnd("data: [DONE]\n\n");
          }
        }
      }
    };
    let decompressStream = stream$1;
    if (contentEncoding === "gzip") {
      console.log("[Qwen] Decompressing gzip stream...");
      decompressStream = stream$1.pipe(zlib.createGunzip());
    } else if (contentEncoding === "deflate") {
      console.log("[Qwen] Decompressing deflate stream...");
      decompressStream = stream$1.pipe(zlib.createInflate());
    } else if (contentEncoding === "br") {
      console.log("[Qwen] Decompressing brotli stream...");
      decompressStream = stream$1.pipe(zlib.createBrotliDecompress());
    } else if (contentEncoding === "zstd") {
      console.log("[Qwen] Decompressing zstd stream...");
      const chunks = [];
      stream$1.on("data", (chunk) => chunks.push(chunk));
      stream$1.once("end", () => {
        if (streamEnded) return;
        try {
          const compressedData = Buffer.concat(chunks);
          ZstdCodec__namespace.run((zstd) => {
            const simple = new zstd.Simple();
            const decompressed = simple.decompress(compressedData);
            const decompressedStr = Buffer.from(decompressed).toString("utf8");
            buffer = decompressedStr;
            processBuffer();
            safeEnd("data: [DONE]\n\n");
          });
        } catch (err) {
          console.error("[Qwen] Zstd decompression error:", err);
          safeEnd("data: [DONE]\n\n");
        }
      });
      stream$1.once("error", (err) => {
        console.error("[Qwen] Stream error:", err);
        safeEnd("data: [DONE]\n\n");
      });
      return transStream;
    }
    decompressStream.on("data", (bufferChunk) => {
      if (streamEnded) return;
      buffer += bufferChunk.toString();
      processBuffer();
    });
    decompressStream.once("error", (err) => {
      console.error("[Qwen] Stream error:", err);
      safeEnd("data: [DONE]\n\n");
    });
    decompressStream.once("close", () => {
      console.log("[Qwen] Stream closed");
      if (streamEnded) return;
      processBuffer();
      safeEnd("data: [DONE]\n\n");
    });
    return transStream;
  }
  async handleNonStream(stream2, response) {
    console.log("[Qwen] Starting non-stream handler...");
    return new Promise((resolve, reject) => {
      const data = {
        id: "",
        model: this.model,
        object: "chat.completion",
        choices: [
          {
            index: 0,
            message: { role: "assistant", content: "" },
            finish_reason: "stop"
          }
        ],
        usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
        created: this.created
      };
      let contentAccumulator = "";
      let thinkingAccumulator = "";
      let buffer = "";
      let resolved = false;
      const finalizeWithData = (content) => {
        const { content: cleanContent, toolCalls } = this.toolCallingPlan?.shouldParseResponse ? { content, toolCalls: [] } : parseToolCallsFromText(content, "qwen");
        if (toolCalls.length > 0) {
          data.choices[0].message.content = null;
          data.choices[0].message.tool_calls = toolCalls;
          data.choices[0].finish_reason = "tool_calls";
        } else {
          data.choices[0].message.content = cleanContent.trim();
        }
      };
      const processBuffer = () => {
        while (true) {
          const doubleNewlineIndex = buffer.indexOf("\n\n");
          if (doubleNewlineIndex === -1) break;
          const eventBlock = buffer.substring(0, doubleNewlineIndex);
          buffer = buffer.substring(doubleNewlineIndex + 2);
          const lines = eventBlock.split("\n");
          let eventType = "message";
          let eventData = "";
          for (const line of lines) {
            if (line.startsWith("event:")) {
              eventType = line.substring(6).trim();
            } else if (line.startsWith("data:")) {
              eventData = line.substring(5);
            }
          }
          if (eventData && eventData !== "[DONE]") {
            try {
              const result = JSON.parse(eventData);
              console.log("[Qwen] Non-stream parsed event:", eventType, "data keys:", Object.keys(result));
              if (result.communication) {
                if (!data.id && result.communication.sessionid) {
                  data.id = result.communication.sessionid;
                  this.sessionId = result.communication.sessionid;
                }
              }
              if (result.data?.messages) {
                for (const msg of result.data.messages) {
                  const metaData = msg.meta_data || {};
                  const multiLoad = metaData.multi_load || [];
                  let hasDeepThink = false;
                  for (const load of multiLoad) {
                    if (load.type === "deep_think" && load.content) {
                      const thinkContent = load.content.think_content || load.content.content || "";
                      if (thinkContent && thinkContent.length > thinkingAccumulator.length) {
                        thinkingAccumulator = thinkContent;
                        console.log("[Qwen] Non-stream: Thinking content length:", thinkingAccumulator.length, "type: deep_think");
                      }
                      hasDeepThink = true;
                    }
                  }
                  if (!hasDeepThink) {
                    for (const load of multiLoad) {
                      if (load.type === "multimodal_chat_think" && load.content) {
                        const thinkContent = load.content.think_content || load.content.content || "";
                        if (thinkContent && thinkContent.length > thinkingAccumulator.length) {
                          thinkingAccumulator = thinkContent;
                          console.log("[Qwen] Non-stream: Thinking content length:", thinkingAccumulator.length, "type: multimodal_chat_think (fallback)");
                        }
                      }
                    }
                  }
                  if (msg.mime_type === "multi_load/iframe" && msg.content) {
                    let filteredContent = msg.content;
                    if (filteredContent === "[(deep_think)]" || filteredContent.trim() === "[(deep_think)]") {
                      console.log("[Qwen] Non-stream: Skipping deep_think marker");
                      continue;
                    }
                    filteredContent = filteredContent.replace(/\[\(deep_think\)\]/g, "");
                    filteredContent = filteredContent.replace(/\[\(multimodal_chat_think_\d+\)\]/g, "");
                    if (filteredContent.length > contentAccumulator.length) {
                      contentAccumulator = filteredContent;
                      console.log("[Qwen] Non-stream multi_load/iframe content length:", contentAccumulator.length);
                    }
                  }
                  if (msg.mime_type === "text/plain" && msg.content) {
                    let filteredContent = msg.content.replace(/\[\(deep_think\)\]/g, "");
                    filteredContent = filteredContent.replace(/\[\(multimodal_chat_think_\d+\)\]/g, "");
                    if (filteredContent.length > contentAccumulator.length) {
                      contentAccumulator = filteredContent;
                    }
                  }
                  if (msg.status === "complete" || msg.status === "finished") {
                    if (msg.mime_type === "multi_load/iframe") {
                      console.log("[Qwen] Non-stream finished, content length:", contentAccumulator.length);
                      this.content = contentAccumulator;
                      const { content: cleanContent, toolCalls } = this.toolCallingPlan?.shouldParseResponse ? { content: contentAccumulator, toolCalls: [] } : parseToolCallsFromText(contentAccumulator, "qwen");
                      if (toolCalls.length > 0) {
                        data.choices[0].message.content = null;
                        data.choices[0].message.tool_calls = toolCalls;
                        data.choices[0].finish_reason = "tool_calls";
                      } else {
                        data.choices[0].message.content = cleanContent.trim();
                      }
                      if (thinkingAccumulator) {
                        data.choices[0].message.reasoning_content = thinkingAccumulator;
                      }
                      this.onEnd?.(this.sessionId);
                      resolved = true;
                      resolve(data);
                      return;
                    }
                  }
                }
              }
            } catch (err) {
              console.error("[Qwen] Non-stream parse error:", err);
            }
          }
          if (eventType === "complete" && !resolved) {
            console.log("[Qwen] Non-stream complete event, content length:", contentAccumulator.length);
            this.content = contentAccumulator;
            finalizeWithData(contentAccumulator);
            if (thinkingAccumulator) {
              data.choices[0].message.reasoning_content = thinkingAccumulator;
            }
            resolved = true;
            resolve(data);
            return;
          }
        }
      };
      let decompressStream = stream2;
      const contentEncoding = response?.headers?.["content-encoding"]?.toLowerCase();
      if (contentEncoding === "gzip") {
        console.log("[Qwen] Decompressing gzip stream...");
        decompressStream = stream2.pipe(zlib.createGunzip());
      } else if (contentEncoding === "deflate") {
        console.log("[Qwen] Decompressing deflate stream...");
        decompressStream = stream2.pipe(zlib.createInflate());
      } else if (contentEncoding === "br") {
        console.log("[Qwen] Decompressing brotli stream...");
        decompressStream = stream2.pipe(zlib.createBrotliDecompress());
      } else if (contentEncoding === "zstd") {
        console.log("[Qwen] Decompressing zstd stream...");
        const chunks = [];
        stream2.on("data", (chunk) => chunks.push(chunk));
        stream2.once("end", () => {
          try {
            const compressedData = Buffer.concat(chunks);
            ZstdCodec__namespace.run((zstd) => {
              const simple = new zstd.Simple();
              const decompressed = simple.decompress(compressedData);
              const decompressedStr = Buffer.from(decompressed).toString("utf8");
              buffer = decompressedStr;
              processBuffer();
              console.log("[Qwen] Zstd non-stream finished, content length:", contentAccumulator.length);
              this.content = contentAccumulator;
              finalizeWithData(contentAccumulator);
              if (thinkingAccumulator) {
                data.choices[0].message.reasoning_content = thinkingAccumulator;
              }
              resolve(data);
            });
          } catch (err) {
            console.error("[Qwen] Zstd decompression error:", err);
            reject(err);
          }
        });
        stream2.once("error", (err) => {
          console.error("[Qwen] Non-stream error:", err);
          reject(err);
        });
        return;
      }
      decompressStream.on("data", (chunk) => {
        if (resolved) return;
        buffer += chunk.toString();
        processBuffer();
      });
      decompressStream.once("error", (err) => {
        if (resolved) return;
        console.error("[Qwen] Non-stream error:", err);
        reject(err);
      });
      decompressStream.once("close", () => {
        console.log("[Qwen] Non-stream closed, content length:", contentAccumulator.length);
        if (!resolved) {
          processBuffer();
          this.content = contentAccumulator;
          finalizeWithData(contentAccumulator);
          if (thinkingAccumulator) {
            data.choices[0].message.reasoning_content = thinkingAccumulator;
          }
          resolve(data);
        }
      });
      decompressStream.once("end", () => {
        console.log("[Qwen] Non-stream ended, content length:", contentAccumulator.length);
        if (!resolved) {
          processBuffer();
          this.content = contentAccumulator;
          finalizeWithData(contentAccumulator);
          if (thinkingAccumulator) {
            data.choices[0].message.reasoning_content = thinkingAccumulator;
          }
          resolve(data);
        }
      });
    });
  }
  getSessionId() {
    return this.sessionId;
  }
}
const QWEN_AI_BASE$2 = "https://chat.qwen.ai";
const REFRESH_THRESHOLD_MS = 6 * 60 * 60 * 1e3;
function decodeJwtPayload(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) {
      return null;
    }
    const base64 = parts[1].replace(/-/g, "+").replace(/_/g, "/");
    const padded = base64.padEnd(base64.length + (4 - base64.length % 4) % 4, "=");
    return JSON.parse(Buffer.from(padded, "base64").toString("utf8"));
  } catch {
    return null;
  }
}
function sha256Hex(value) {
  return crypto$1.createHash("sha256").update(value, "utf8").digest("hex");
}
class QwenAiTokenRefresher {
  isTokenExpiringSoon(token, now = Date.now()) {
    const payload = decodeJwtPayload(token);
    if (!payload?.exp || typeof payload.exp !== "number") {
      return true;
    }
    return payload.exp * 1e3 - now <= REFRESH_THRESHOLD_MS;
  }
  async refreshIfNeeded(account) {
    if (!this.canRefresh(account) || !this.isTokenExpiringSoon(account.credentials.token || "")) {
      return account;
    }
    return this.refresh(account);
  }
  async refreshAfterUnauthorized(account) {
    if (!this.canRefresh(account)) {
      return account;
    }
    return this.refresh(account);
  }
  canRefresh(account) {
    return Boolean(account.credentials.email && account.credentials.password);
  }
  async refresh(account) {
    const response = await axios.post(
      `${QWEN_AI_BASE$2}/api/v1/auths/signin`,
      {
        email: account.credentials.email,
        password: sha256Hex(account.credentials.password)
      },
      {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Origin: QWEN_AI_BASE$2,
          Referer: `${QWEN_AI_BASE$2}/`,
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
        },
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    const token = response.data?.token;
    if (response.status !== 200 || !token || typeof token !== "string") {
      throw new Error(`Qwen AI token refresh failed: HTTP ${response.status}`);
    }
    const updated = server_bootstrapConfig.storeManager.updateAccount(account.id, {
      email: account.credentials.email,
      credentials: {
        ...account.credentials,
        token
      },
      status: "active",
      errorMessage: void 0
    });
    return updated ? {
      ...updated,
      credentials: {
        ...account.credentials,
        token
      }
    } : {
      ...account,
      email: account.credentials.email,
      credentials: {
        ...account.credentials,
        token
      },
      status: "active",
      errorMessage: void 0,
      updatedAt: Date.now()
    };
  }
}
const QWEN_AI_BASE$1 = "https://chat.qwen.ai";
const MAX_FILE_SIZE = 2e3 * 1024 * 1024;
const PARSE_POLL_INTERVAL_MS = 1e3;
const PARSE_POLL_ATTEMPTS = 5;
function uuid$4() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function isDataUrl(url) {
  return /^data:[^;,]+;base64,/i.test(url);
}
function isHttpUrl(url) {
  return /^https?:\/\//i.test(url);
}
function isChat2ApiFileUrl(url) {
  return /^chat2api-file:\/\//i.test(url);
}
function sanitizeFilename(filename) {
  const cleaned = filename.replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").trim();
  return cleaned || `upload-${uuid$4()}`;
}
function filenameFromUrl(url) {
  try {
    const parsed = new URL(url);
    const base = path.posix.basename(decodeURIComponent(parsed.pathname));
    return sanitizeFilename(base || `upload-${uuid$4()}`);
  } catch {
    return `upload-${uuid$4()}`;
  }
}
function filenameFromContentDisposition(header) {
  if (!header) {
    return void 0;
  }
  const utf8Match = header.match(/filename\*=UTF-8''([^;]+)/i);
  if (utf8Match?.[1]) {
    return sanitizeFilename(decodeURIComponent(utf8Match[1]));
  }
  const asciiMatch = header.match(/filename="?([^";]+)"?/i);
  if (asciiMatch?.[1]) {
    return sanitizeFilename(asciiMatch[1]);
  }
  return void 0;
}
function ensureExtension(filename, mimeType) {
  if (path.extname(filename)) {
    return filename;
  }
  const ext = mime.extension(mimeType);
  return ext ? `${filename}.${ext}` : filename;
}
function normalizeAudioMimeType(format, explicitMimeType) {
  if (explicitMimeType) {
    return explicitMimeType;
  }
  const normalizedFormat = format?.toLowerCase().replace(/^\./, "");
  if (!normalizedFormat) {
    return "audio/wav";
  }
  if (normalizedFormat === "mp3") {
    return "audio/mpeg";
  }
  if (normalizedFormat === "m4a") {
    return "audio/x-m4a";
  }
  return mime.lookup(normalizedFormat) || `audio/${normalizedFormat}`;
}
function parseDataUrlPayload(value) {
  const match = value.match(/^data:([^;,]+);base64,(.*)$/is);
  if (!match) {
    return { base64: value };
  }
  return {
    mimeType: match[1],
    base64: match[2]
  };
}
function classifyFile(mimeType, explicitType) {
  if (explicitType === "image_url" || mimeType.startsWith("image/")) {
    return { coarseType: "image", fileClass: "vision" };
  }
  if (mimeType.startsWith("audio/")) {
    return { coarseType: "audio", fileClass: "audio" };
  }
  if (mimeType.startsWith("video/")) {
    return { coarseType: "video", fileClass: "video" };
  }
  return { coarseType: "file", fileClass: "document" };
}
function extractDataUrl(url, filename, explicitMimeType, explicitType) {
  const match = url.match(/^data:([^;,]+);base64,(.*)$/is);
  if (!match) {
    throw new Error("Unsupported data URL. Expected data:<mime>;base64,<content>.");
  }
  const mimeType = explicitMimeType || match[1] || "application/octet-stream";
  const data = Buffer.from(match[2], "base64");
  const rawFilename = filename || `upload-${uuid$4()}`;
  const safeFilename = ensureExtension(sanitizeFilename(rawFilename), mimeType);
  const classification = classifyFile(mimeType, explicitType || (mimeType.startsWith("image/") ? "image_url" : "file"));
  return {
    data,
    filename: safeFilename,
    mimeType,
    ...classification
  };
}
function extractInputAudio(part) {
  const data = part.input_audio?.data;
  if (!data) {
    throw new Error("Missing data for input_audio content part");
  }
  const parsedData = parseDataUrlPayload(data);
  const mimeType = normalizeAudioMimeType(part.input_audio?.format, part.mime_type || parsedData.mimeType);
  const filename = ensureExtension(
    sanitizeFilename(part.filename || `input-audio-${uuid$4()}`),
    mimeType
  );
  return {
    data: Buffer.from(parsedData.base64, "base64"),
    filename,
    mimeType,
    coarseType: "audio",
    fileClass: "audio"
  };
}
function extractLocalFile(part) {
  const localPath = part.local_path;
  if (!localPath) {
    throw new Error("Missing local_path for Chat2API file content part");
  }
  const stat = fs.statSync(localPath);
  if (!stat.isFile()) {
    throw new Error(`Chat2API local file is not a file: ${localPath}`);
  }
  const explicitMimeType = part.mime_type;
  const filename = ensureExtension(
    sanitizeFilename(part.filename || path.basename(localPath)),
    explicitMimeType || mime.lookup(localPath) || "application/octet-stream"
  );
  const mimeType = explicitMimeType || mime.lookup(filename) || "application/octet-stream";
  const classification = classifyFile(String(mimeType), part.type);
  return {
    data: fs.readFileSync(localPath),
    filename,
    mimeType: String(mimeType),
    ...classification
  };
}
function textFromContent(content) {
  if (typeof content === "string") {
    return content;
  }
  if (Array.isArray(content)) {
    validateSupportedParts(content);
    return content.filter((part) => part.type === "text" && typeof part.text === "string").map((part) => part.text).join("");
  }
  return "";
}
function collectFileParts(content) {
  if (!Array.isArray(content)) {
    return [];
  }
  validateSupportedParts(content);
  return content.filter((part) => ["image_url", "file", "input_audio", "video_url"].includes(part.type));
}
function validateSupportedParts(content) {
  for (const part of content) {
    if (!["text", "image_url", "file", "input_audio", "video_url"].includes(part.type)) {
      throw new Error(`Unsupported Qwen AI message content part type: ${part.type}`);
    }
  }
}
function extractPartUrl(part) {
  if (part.type === "image_url" && part.image_url?.url) {
    return part.image_url.url;
  }
  if (part.type === "file" && part.file_url?.url) {
    return part.file_url.url;
  }
  if (part.type === "video_url" && part.video_url?.url) {
    return part.video_url.url;
  }
  throw new Error(`Missing URL for ${part.type} content part`);
}
function normalizeStsResponse(data) {
  const source = data?.data || data || {};
  const filePath = source.file_path || source.filePath || source.path || "";
  const fileId = source.file_id || source.fileId || source.id || "";
  const fileUrl = source.file_url || source.fileUrl || source.url || source.cdn_url || "";
  const sts = {
    accessKeyId: source.access_key_id || source.accessKeyId || source.AccessKeyId || "",
    accessKeySecret: source.access_key_secret || source.accessKeySecret || source.AccessKeySecret || "",
    securityToken: source.security_token || source.securityToken || source.SecurityToken,
    bucket: source.bucketname || source.bucket || source.bucketName || "",
    region: source.region || "",
    endpoint: source.endpoint || "",
    fileId,
    filePath,
    fileUrl
  };
  if (!sts.accessKeyId || !sts.accessKeySecret || !sts.bucket || !sts.endpoint || !sts.filePath || !sts.fileId) {
    throw new Error("Qwen AI upload STS response is missing required fields");
  }
  return sts;
}
function createQwenFileItem(file, sts) {
  const now = Date.now();
  const fileUrl = sts.fileUrl || file.sourceUrl || "";
  const type = file.coarseType;
  return {
    id: sts.fileId,
    itemId: uuid$4(),
    type,
    url: fileUrl,
    name: file.filename,
    collection_name: "",
    progress: 100,
    status: "uploaded",
    greenNet: "success",
    size: file.data.length,
    error: "",
    filetype: file.coarseType,
    file_type: file.mimeType,
    showType: type,
    file_class: file.fileClass,
    uploadStatus: "success",
    meta: {
      name: file.filename,
      size: file.data.length,
      content_type: file.mimeType
    },
    file: {
      created_at: now,
      data: {},
      filename: file.filename,
      hash: null,
      id: sts.fileId,
      user_id: "",
      meta: {
        name: file.filename,
        size: file.data.length,
        content_type: file.mimeType
      },
      update_at: now,
      name: file.filename,
      size: file.data.length,
      type: file.mimeType,
      url: fileUrl
    }
  };
}
class QwenAiFileUploader {
  constructor(axiosInstance, getHeaders, postWithRefreshRetry) {
    this.axiosInstance = axiosInstance;
    this.getHeaders = getHeaders;
    this.postWithRefreshRetry = postWithRefreshRetry;
  }
  async uploadPart(part) {
    const file = await this.resolveFile(part);
    if (file.data.length > MAX_FILE_SIZE) {
      throw new Error(`Qwen AI file upload exceeds ${MAX_FILE_SIZE} bytes: ${file.filename}`);
    }
    const sts = await this.requestSts(file);
    await this.uploadToOss(file, sts);
    if (file.fileClass === "document") {
      await this.parseDocument(sts.fileId);
    }
    return createQwenFileItem(file, sts);
  }
  async resolveFile(part) {
    if (part.type === "input_audio") {
      return extractInputAudio(part);
    }
    const url = extractPartUrl(part);
    const explicitFilename = part.filename;
    const explicitMimeType = part.mime_type;
    if (isChat2ApiFileUrl(url)) {
      return extractLocalFile(part);
    }
    if (isDataUrl(url)) {
      return extractDataUrl(url, explicitFilename, explicitMimeType, part.type);
    }
    if (!isHttpUrl(url)) {
      throw new Error(`Unsupported Qwen AI file URL scheme for ${part.type}`);
    }
    const response = await this.axiosInstance.get(url, {
      responseType: "arraybuffer",
      maxContentLength: MAX_FILE_SIZE,
      maxBodyLength: MAX_FILE_SIZE,
      timeout: 6e4,
      validateStatus: () => true
    });
    if (response.status >= 400) {
      throw new Error(`Failed to download Qwen AI input file: HTTP ${response.status}`);
    }
    const headerFilename = filenameFromContentDisposition(response.headers?.["content-disposition"]);
    const filename = sanitizeFilename(explicitFilename || headerFilename || filenameFromUrl(url));
    const mimeType = explicitMimeType || response.headers?.["content-type"] || mime.lookup(filename) || "application/octet-stream";
    const safeFilename = ensureExtension(filename, mimeType);
    const classification = classifyFile(String(mimeType), part.type);
    return {
      data: Buffer.from(response.data),
      filename: safeFilename,
      mimeType: String(mimeType),
      sourceUrl: url,
      ...classification
    };
  }
  async requestSts(file) {
    const response = await this.postJson(
      `${QWEN_AI_BASE$1}/api/v2/files/getstsToken`,
      {
        filename: file.filename,
        filesize: String(file.data.length),
        filetype: file.coarseType
      },
      () => ({
        headers: this.getHeaders(),
        timeout: 3e4,
        validateStatus: () => true
      })
    );
    if (response.status >= 400) {
      throw new Error(`Qwen AI upload STS request failed: HTTP ${response.status}`);
    }
    return normalizeStsResponse(response.data);
  }
  async uploadToOss(file, sts) {
    const client = new OSS({
      accessKeyId: sts.accessKeyId,
      accessKeySecret: sts.accessKeySecret,
      stsToken: sts.securityToken,
      bucket: sts.bucket,
      region: sts.region,
      endpoint: sts.endpoint,
      authorizationV4: true
    });
    await client.put(sts.filePath, file.data, {
      headers: {
        "Content-Type": file.mimeType
      }
    });
  }
  async parseDocument(fileId) {
    const parseResponse = await this.postJson(
      `${QWEN_AI_BASE$1}/api/v2/files/parse`,
      { file_id: fileId },
      () => ({
        headers: this.getHeaders(),
        timeout: 3e4,
        validateStatus: () => true
      })
    );
    if (parseResponse.status >= 400) {
      console.warn("[QwenAI] File parse request failed:", parseResponse.status);
      return;
    }
    await this.waitForParse(fileId);
  }
  async waitForParse(fileId) {
    for (let attempt = 0; attempt < PARSE_POLL_ATTEMPTS; attempt++) {
      await delay(PARSE_POLL_INTERVAL_MS);
      const response = await this.postJson(
        `${QWEN_AI_BASE$1}/api/v2/files/parse/status`,
        { file_id_list: [fileId] },
        () => ({
          headers: this.getHeaders(),
          timeout: 3e4,
          validateStatus: () => true
        })
      );
      if (response.status >= 400) {
        console.warn("[QwenAI] File parse status request failed:", response.status);
        return;
      }
      const status = response.data?.data?.[fileId]?.status || response.data?.data?.[0]?.status || response.data?.[fileId]?.status || response.data?.status;
      if (!status || ["success", "finished", "done", "parsed"].includes(String(status).toLowerCase())) {
        return;
      }
      if (["failed", "error"].includes(String(status).toLowerCase())) {
        console.warn("[QwenAI] File parse failed for uploaded document");
        return;
      }
    }
  }
  async postJson(url, payload, createOptions) {
    if (this.postWithRefreshRetry) {
      return this.postWithRefreshRetry(url, payload, createOptions);
    }
    return this.axiosInstance.post(url, payload, createOptions());
  }
}
async function prepareQwenAiMultimodalMessage(messages, uploader) {
  let systemContent = "";
  let userContent = "";
  const fileParts = [];
  for (const msg of messages) {
    if (msg.role === "system") {
      const text = textFromContent(msg.content);
      if (text) {
        systemContent += (systemContent ? "\n\n" : "") + text;
      }
      continue;
    }
    if (msg.role === "user") {
      userContent = textFromContent(msg.content);
      fileParts.splice(0, fileParts.length, ...collectFileParts(msg.content));
    }
  }
  if (systemContent) {
    userContent = `${systemContent}

User: ${userContent}`;
  }
  const files = [];
  for (const part of fileParts) {
    files.push(await uploader.uploadPart(part));
  }
  return {
    content: userContent,
    files
  };
}
const QWEN_AI_BASE = "https://chat.qwen.ai";
const DEFAULT_HEADERS$1 = {
  Accept: "application/json",
  "Accept-Language": "zh-CN,zh;q=0.9",
  "Content-Type": "application/json",
  source: "web",
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
  "sec-ch-ua": '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
  "sec-ch-ua-mobile": "?0",
  "sec-ch-ua-platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  Version: "0.2.67",
  Origin: "https://chat.qwen.ai"
};
const MODEL_ALIASES = {
  qwen: "qwen3.7-max",
  qwen3: "qwen3.7-max",
  "qwen3.7": "qwen3.7-max",
  "qwen3.7-plus": "qwen3.7-plus",
  "qwen3.6": "qwen3.6-plus",
  "qwen3.6-35b": "qwen3.6-35b-a3b",
  "qwen3.6-27b": "qwen3.6-27b",
  "qwen3-coder": "qwen3-coder-plus"
};
function uuid$3() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
function currentTimezoneHeader() {
  return (/* @__PURE__ */ new Date()).toString().replace(/\s*\(.+\)$/, "");
}
function isObjectValue(value) {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}
let QwenAiAdapter$1 = class QwenAiAdapter {
  constructor(provider, account) {
    this.tokenRefresher = new QwenAiTokenRefresher();
    this.axiosInstance = axios.create({
      timeout: 12e4,
      maxBodyLength: Infinity,
      maxContentLength: Infinity
    });
    this.provider = provider;
    this.account = account;
  }
  async refreshTokenIfNeeded() {
    this.account = await this.tokenRefresher.refreshIfNeeded(this.account);
  }
  async postWithRefreshRetry(url, payload, createOptions) {
    let response = await this.axiosInstance.post(url, payload, createOptions());
    if (response.status === 401) {
      this.account = await this.tokenRefresher.refreshAfterUnauthorized(this.account);
      response = await this.axiosInstance.post(url, payload, createOptions());
    }
    return response;
  }
  getToken() {
    const credentials = this.account.credentials;
    return credentials.token || credentials.accessToken || credentials.apiKey || "";
  }
  getCookies() {
    const credentials = this.account.credentials;
    const cookies = credentials.cookies || credentials.cookie || "";
    if (typeof cookies === "string") {
      return cookies;
    }
    if (isObjectValue(cookies)) {
      return Object.entries(cookies).filter(([, value]) => typeof value === "string" && value).map(([key, value]) => `${key}=${value}`).join("; ");
    }
    return "";
  }
  getCredentialValue(...keys) {
    const credentials = this.account.credentials;
    for (const key of keys) {
      const value = credentials[key];
      if (typeof value === "string" && value.trim()) {
        return value.trim();
      }
    }
    return "";
  }
  getHeaders(chatId) {
    const cookies = this.getCookies();
    const headers = {
      ...DEFAULT_HEADERS$1,
      "X-Request-Id": uuid$3(),
      Timezone: currentTimezoneHeader()
    };
    const token = this.getToken();
    if (token && !cookies) {
      headers.source = "desktop";
      headers.Authorization = `Bearer ${token}`;
    }
    if (chatId) {
      headers["Referer"] = `https://chat.qwen.ai/c/${chatId}`;
    }
    const baxiaUidToken = this.getCredentialValue("baxiaUidToken", "baxia_uid_token", "uidToken");
    if (baxiaUidToken) {
      headers["bx-umidtoken"] = baxiaUidToken;
    }
    const baxiaUa = this.getCredentialValue("baxiaUa", "baxia_ua", "bxUa", "bx_ua");
    if (baxiaUa) {
      headers["bx-ua"] = baxiaUa;
    }
    const baxiaVersion = this.getCredentialValue("baxiaVersion", "baxia_version", "bxV", "bx_v");
    if (baxiaVersion) {
      headers["bx-v"] = baxiaVersion;
    }
    const x5secdata = this.getCredentialValue("x5secdata");
    if (x5secdata) {
      headers["x5secdata"] = x5secdata;
    }
    const x5sectag = this.getCredentialValue("x5sectag");
    if (x5sectag) {
      headers["x5sectag"] = x5sectag;
    }
    if (cookies) {
      headers["Cookie"] = cookies;
    } else {
      console.warn("[QwenAI] Warning: No cookies provided. This may cause Bad_Request error.");
      console.warn("[QwenAI] Required cookies: cnaui, aui, sca, xlly_s, cna, token, _bl_uid, x-ap");
    }
    return headers;
  }
  sanitizeHeadersForLog(headers) {
    const sensitiveHeaders = /* @__PURE__ */ new Set([
      "authorization",
      "cookie",
      "set-cookie",
      "bx-ua",
      "bx-umidtoken",
      "x5secdata",
      "x5sectag"
    ]);
    return Object.fromEntries(
      Object.entries(headers).map(([key, value]) => [
        key,
        sensitiveHeaders.has(key.toLowerCase()) ? "[REDACTED]" : value
      ])
    );
  }
  sanitizePayloadForLog(value) {
    if (Array.isArray(value)) {
      return value.map((item) => this.sanitizePayloadForLog(item));
    }
    if (value && typeof value === "object") {
      return Object.fromEntries(
        Object.entries(value).map(([key, item]) => [
          key,
          key === "url" ? "[REDACTED_URL]" : this.sanitizePayloadForLog(item)
        ])
      );
    }
    return value;
  }
  async readStreamPreview(stream2, maxBytes = 4096) {
    if (!stream2) return "";
    if (typeof stream2 === "string") return stream2.slice(0, maxBytes);
    if (Buffer.isBuffer(stream2)) return stream2.toString("utf8", 0, maxBytes);
    if (typeof stream2 !== "object" || typeof stream2.on !== "function") {
      try {
        return JSON.stringify(stream2).slice(0, maxBytes);
      } catch {
        return String(stream2).slice(0, maxBytes);
      }
    }
    const chunks = [];
    let total = 0;
    await new Promise((resolve) => {
      let done = false;
      const finish = () => {
        if (!done) {
          done = true;
          resolve();
        }
      };
      stream2.on("data", (chunk) => {
        const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk));
        const remaining = maxBytes - total;
        if (remaining > 0) {
          chunks.push(buffer.subarray(0, remaining));
          total += Math.min(buffer.length, remaining);
        }
        if (total >= maxBytes && typeof stream2.destroy === "function") {
          stream2.destroy();
        }
      });
      stream2.once("end", finish);
      stream2.once("close", finish);
      stream2.once("error", finish);
    });
    return Buffer.concat(chunks).toString("utf8");
  }
  extractUpstreamErrorMessage(body) {
    const trimmed = body.trim();
    if (!trimmed) return "";
    try {
      const parsed = JSON.parse(trimmed);
      const ret = Array.isArray(parsed?.ret) ? parsed.ret.filter((item) => typeof item === "string" && item.trim()).join("; ") : "";
      const message = parsed?.message || parsed?.msg || parsed?.error?.message || parsed?.data?.message || parsed?.data?.msg || ret;
      if (typeof message === "string" && message.trim()) {
        return message.trim();
      }
    } catch {
    }
    return trimmed.replace(/https?:\/\/[^\s"',}]+/gi, "[REDACTED_URL]").replace(/(x5secdata|x5sectag|cookie|authorization|token)=([^&\s"',}]+)/gi, "$1=[REDACTED]").replace(/\s+/g, " ").slice(0, 500);
  }
  hasRiskControlHeaders(headers) {
    const setCookie = headers["set-cookie"];
    const setCookieText = Array.isArray(setCookie) ? setCookie.join("\n") : String(setCookie || "");
    return Boolean(
      headers.bxpunish || headers["bxpunish"] || headers["x5secdata"] || headers["x5sectag"] || /x5sec/i.test(setCookieText)
    );
  }
  isRiskControlMessage(message) {
    return /FAIL_SYS_USER_VALIDATE|RGV587|risk-control|challenge|captcha|x5sec|baxia|punish|哎哟喂|被挤爆/i.test(message);
  }
  async createInvalidStreamError(response, reason) {
    const contentType = String(response.headers?.["content-type"] || "unknown");
    const body = await this.readStreamPreview(response.data);
    const upstreamMessage = this.extractUpstreamErrorMessage(body);
    const detail = upstreamMessage ? `: ${upstreamMessage}` : "";
    const error = new Error(`Qwen AI upstream ${reason} (HTTP ${response.status}, content-type ${contentType})${detail}`);
    if (this.isRiskControlMessage(upstreamMessage) || reason.includes("risk-control")) {
      error.status = 403;
      error.code = "qwen_ai_risk_control";
    }
    return error;
  }
  async assertChatCompletionStreamResponse(response) {
    const contentType = String(response.headers?.["content-type"] || "").toLowerCase();
    if (response.status >= 400) {
      throw await this.createInvalidStreamError(response, `returned HTTP ${response.status}`);
    }
    if (this.hasRiskControlHeaders(response.headers || {})) {
      throw await this.createInvalidStreamError(response, "returned a risk-control or challenge response instead of a chat event stream");
    }
    if (contentType.includes("application/json") || contentType.includes("text/html")) {
      throw await this.createInvalidStreamError(response, "returned a non-stream response instead of a chat event stream");
    }
  }
  mapModel(openaiModel) {
    let model = openaiModel;
    let forceThinking;
    if (model.endsWith("-thinking")) {
      forceThinking = true;
      model = model.slice(0, -9);
    } else if (model.endsWith("-fast")) {
      forceThinking = false;
      model = model.slice(0, -5);
    }
    this._forceThinking = forceThinking;
    const lowerModel = model.toLowerCase();
    if (MODEL_ALIASES[lowerModel]) {
      return MODEL_ALIASES[lowerModel];
    }
    if (this.provider.modelMappings) {
      for (const [key, value] of Object.entries(this.provider.modelMappings)) {
        if (key.toLowerCase() === lowerModel) {
          return value;
        }
      }
    }
    return model;
  }
  async createChat(modelId, title = "New Chat") {
    await this.refreshTokenIfNeeded();
    const url = `${QWEN_AI_BASE}/api/v2/chats/new`;
    const payload = {
      title,
      models: [modelId],
      chat_mode: "normal",
      chat_type: "t2t",
      timestamp: Date.now(),
      project_id: ""
    };
    try {
      const response = await this.postWithRefreshRetry(url, payload, () => ({
        headers: this.getHeaders(),
        validateStatus: () => true
      }));
      console.log("[QwenAI] Create chat response:", JSON.stringify(response.data, null, 2));
      if (response.data?.data?.id) {
        console.log("[QwenAI] Created chat:", response.data.data.id);
        return response.data.data.id;
      }
      throw new Error("Failed to create chat: no chat ID returned");
    } catch (error) {
      console.error("[QwenAI] Failed to create chat:", error);
      throw error;
    }
  }
  async deleteChat(chatId) {
    const url = `${QWEN_AI_BASE}/api/v2/chats/${chatId}`;
    try {
      const response = await this.axiosInstance.delete(url, {
        headers: this.getHeaders()
      });
      if (response.data?.success) {
        console.log("[QwenAI] Deleted chat:", chatId);
        return true;
      }
      console.warn("[QwenAI] Failed to delete chat:", response.data);
      return false;
    } catch (error) {
      console.error("[QwenAI] Failed to delete chat:", error);
      return false;
    }
  }
  /**
   * Delete all chats for the current account
   * @returns Promise<boolean> - true if deletion was successful
   */
  async deleteAllChats() {
    const url = `${QWEN_AI_BASE}/api/v2/chats/`;
    try {
      console.log("[QwenAI] Deleting all chats for account");
      const response = await this.axiosInstance.delete(url, {
        headers: this.getHeaders()
      });
      if (response.data?.success) {
        console.log("[QwenAI] All chats deleted successfully");
        return true;
      }
      console.warn("[QwenAI] Failed to delete all chats:", response.data);
      return false;
    } catch (error) {
      console.error("[QwenAI] Failed to delete all chats:", error);
      return false;
    }
  }
  async chatCompletion(request) {
    await this.refreshTokenIfNeeded();
    const token = this.getToken();
    if (!token) {
      throw new Error("Qwen AI token not configured, please add token in account settings");
    }
    const modelId = this.mapModel(request.model);
    const modelForThinking = request.originalModel || request.model;
    const modelLower = modelForThinking.toLowerCase();
    let forceThinking;
    if (modelForThinking.endsWith("-thinking")) {
      forceThinking = true;
    } else if (modelForThinking.endsWith("-fast")) {
      forceThinking = false;
    } else if (modelLower.includes("think") || modelLower.includes("r1")) {
      forceThinking = true;
      console.log("[QwenAI] Thinking mode enabled (from model name keyword)");
    } else {
      forceThinking = this._forceThinking;
    }
    const chatId = await this.createChat(modelId, "OpenAI_API_Chat");
    console.log("[QwenAI] Created new chat:", chatId);
    const messages = request.messages;
    const uploader = new QwenAiFileUploader(
      this.axiosInstance,
      () => this.getHeaders(chatId),
      this.postWithRefreshRetry.bind(this)
    );
    const preparedUserMessage = await prepareQwenAiMultimodalMessage(messages, uploader);
    const qwenFiles = preparedUserMessage.files;
    const fid = uuid$3();
    const childId = uuid$3();
    const ts = Math.floor(Date.now() / 1e3);
    const shouldEnableThinking = forceThinking !== void 0 ? forceThinking : request.enable_thinking === true;
    const featureConfig = {
      thinking_enabled: shouldEnableThinking,
      output_schema: "phase",
      research_mode: "normal",
      auto_thinking: shouldEnableThinking,
      thinking_format: "summary",
      auto_search: false
      // Default to disable auto search
    };
    if (request.thinking_budget) {
      featureConfig.thinking_budget = request.thinking_budget;
    }
    const payload = {
      stream: true,
      version: "2.1",
      incremental_output: true,
      chat_id: chatId,
      chat_mode: "normal",
      model: modelId,
      parent_id: null,
      messages: [
        {
          fid,
          parentId: null,
          childrenIds: [childId],
          role: "user",
          content: preparedUserMessage.content,
          user_action: "chat",
          files: qwenFiles,
          timestamp: ts,
          models: [modelId],
          chat_type: "t2t",
          feature_config: featureConfig,
          extra: { meta: { subChatType: "t2t" } },
          sub_chat_type: "t2t",
          parent_id: null
        }
      ],
      timestamp: ts + 1
    };
    const url = `${QWEN_AI_BASE}/api/v2/chat/completions?chat_id=${chatId}`;
    console.log("[QwenAI] Sending request to /api/v2/chat/completions...");
    console.log("[QwenAI] Request URL:", url);
    console.log("[QwenAI] Request payload:", JSON.stringify(this.sanitizePayloadForLog(payload), null, 2));
    console.log("[QwenAI] Request headers:", JSON.stringify(this.sanitizeHeadersForLog(this.getHeaders(chatId)), null, 2));
    const response = await this.postWithRefreshRetry(url, payload, () => ({
      headers: {
        ...this.getHeaders(chatId),
        "x-accel-buffering": "no"
      },
      responseType: "stream",
      timeout: 12e4,
      validateStatus: () => true
    }));
    console.log("[QwenAI] Response status:", response.status);
    console.log("[QwenAI] Response headers:", JSON.stringify(this.sanitizeHeadersForLog(response.headers), null, 2));
    await this.assertChatCompletionStreamResponse(response);
    return {
      response,
      chatId,
      parentId: null
    };
  }
  static isQwenAiProvider(provider) {
    return provider.id === "qwen-ai" || provider.apiEndpoint.includes("chat.qwen.ai");
  }
};
class QwenAiStreamHandler {
  constructor(model, onEnd) {
    this.chatId = "";
    this.responseId = "";
    this.content = "";
    this.toolCallsSent = false;
    this.model = model;
    this.created = Math.floor(Date.now() / 1e3);
    this.onEnd = onEnd;
  }
  setChatId(chatId) {
    this.chatId = chatId;
  }
  sendToolCalls(transStream) {
    if (this.toolCallsSent) return;
    const toolCalls = parseToolUse(this.content);
    if (toolCalls && toolCalls.length > 0) {
      this.toolCallsSent = true;
      for (let i = 0; i < toolCalls.length; i++) {
        const tc = toolCalls[i];
        transStream.write(
          `data: ${JSON.stringify({
            id: this.responseId || this.chatId,
            model: this.model,
            object: "chat.completion.chunk",
            choices: [{
              index: 0,
              delta: {
                tool_calls: [{
                  index: i,
                  id: tc.id,
                  type: "function",
                  function: {
                    name: tc.function.name,
                    arguments: tc.function.arguments
                  }
                }]
              },
              finish_reason: null
            }],
            created: this.created
          })}

`
        );
      }
      transStream.write(
        `data: ${JSON.stringify({
          id: this.responseId || this.chatId,
          model: this.model,
          object: "chat.completion.chunk",
          choices: [{ index: 0, delta: {}, finish_reason: "tool_calls" }],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
          created: this.created
        })}

`
      );
      transStream.end("data: [DONE]\n\n");
      if (this.onEnd && this.chatId) {
        this.onEnd(this.chatId);
      }
    }
  }
  async handleStream(stream$1) {
    const transStream = new stream.PassThrough();
    console.log("[QwenAI] Starting stream handler...");
    let reasoningText = "";
    let hasSentReasoning = false;
    let summaryText = "";
    let initialChunkSent = false;
    const sendInitialChunk = () => {
      if (!initialChunkSent) {
        const initialChunk = `data: ${JSON.stringify({
          id: "",
          model: this.model,
          object: "chat.completion.chunk",
          choices: [{ index: 0, delta: { role: "assistant", content: "" }, finish_reason: null }],
          created: this.created
        })}

`;
        transStream.write(initialChunk);
        initialChunkSent = true;
        console.log("[QwenAI] Initial chunk written");
      }
    };
    const parser = eventsourceParser.createParser({
      onEvent: (event) => {
        try {
          console.log("[QwenAI] Parsed event:", event.event, "data:", event.data?.substring(0, 200));
          if (event.data === "[DONE]") {
            console.log("[QwenAI] Received [DONE] signal");
            return;
          }
          const data = JSON.parse(event.data);
          console.log("[QwenAI] Parsed JSON data keys:", Object.keys(data));
          if (data["response.created"]?.response_id) {
            this.responseId = data["response.created"].response_id;
            console.log("[QwenAI] Got response_id:", this.responseId);
          }
          if (data.choices && data.choices.length > 0) {
            const choice = data.choices[0];
            const delta = choice.delta || {};
            const phase = delta.phase;
            const status = delta.status;
            const content = delta.content || "";
            console.log("[QwenAI] Phase:", phase, "Status:", status, "Content:", content.substring(0, 50));
            if (phase === "think") {
              if (status !== "finished") {
                reasoningText += content;
                if (!hasSentReasoning) {
                  transStream.write(
                    `data: ${JSON.stringify({
                      id: this.responseId || this.chatId,
                      model: this.model,
                      object: "chat.completion.chunk",
                      choices: [{ index: 0, delta: { role: "assistant", reasoning_content: "" }, finish_reason: null }],
                      created: this.created
                    })}

`
                  );
                  hasSentReasoning = true;
                  console.log("[QwenAI] Sent reasoning role chunk");
                }
                if (content) {
                  transStream.write(
                    `data: ${JSON.stringify({
                      id: this.responseId || this.chatId,
                      model: this.model,
                      object: "chat.completion.chunk",
                      choices: [{ index: 0, delta: { reasoning_content: content }, finish_reason: null }],
                      created: this.created
                    })}

`
                  );
                }
              }
            } else if (phase === "thinking_summary") {
              const extra = delta.extra || {};
              console.log("[QwenAI] thinking_summary extra:", JSON.stringify(extra).substring(0, 300));
              if (extra.summary_thought?.content) {
                const newSummary = extra.summary_thought.content.join("\n");
                if (newSummary && newSummary.length > summaryText.length) {
                  const diff = newSummary.substring(summaryText.length);
                  if (diff) {
                    if (!hasSentReasoning) {
                      transStream.write(
                        `data: ${JSON.stringify({
                          id: this.responseId || this.chatId,
                          model: this.model,
                          object: "chat.completion.chunk",
                          choices: [{ index: 0, delta: { role: "assistant", reasoning_content: "" }, finish_reason: null }],
                          created: this.created
                        })}

`
                      );
                      hasSentReasoning = true;
                    }
                    transStream.write(
                      `data: ${JSON.stringify({
                        id: this.responseId || this.chatId,
                        model: this.model,
                        object: "chat.completion.chunk",
                        choices: [{ index: 0, delta: { reasoning_content: diff }, finish_reason: null }],
                        created: this.created
                      })}

`
                    );
                  }
                  summaryText = newSummary;
                  console.log("[QwenAI] Updated summaryText, length:", summaryText.length);
                }
              }
            } else if (phase === "answer") {
              if (!initialChunkSent) {
                sendInitialChunk();
              }
              console.log("[QwenAI] Entering answer branch, content:", content);
              this.content += content;
              if (content) {
                console.log("[QwenAI] Sending content chunk:", content);
                const chunk = {
                  id: this.responseId || this.chatId,
                  model: this.model,
                  object: "chat.completion.chunk",
                  choices: [{ index: 0, delta: { content }, finish_reason: null }],
                  created: this.created
                };
                transStream.write(`data: ${JSON.stringify(chunk)}

`);
                console.log("[QwenAI] Content chunk written");
              }
            } else if (phase === null && content) {
              if (!initialChunkSent) {
                sendInitialChunk();
              }
              this.content += content;
              const chunk = {
                id: this.responseId || this.chatId,
                model: this.model,
                object: "chat.completion.chunk",
                choices: [{ index: 0, delta: { content }, finish_reason: null }],
                created: this.created
              };
              transStream.write(`data: ${JSON.stringify(chunk)}

`);
            }
            if (status === "finished" && (phase === "answer" || phase === null)) {
              if (hasToolUse(this.content)) {
                console.log("[QwenAI] Found tool_use in stream, sending tool_calls");
                this.sendToolCalls(transStream);
                return;
              }
              const finishReason = delta.finish_reason || "stop";
              const finalChunk = {
                id: this.responseId || this.chatId,
                model: this.model,
                object: "chat.completion.chunk",
                choices: [{ index: 0, delta: {}, finish_reason: finishReason }],
                created: this.created
              };
              transStream.write(`data: ${JSON.stringify(finalChunk)}

`);
              transStream.end("data: [DONE]\n\n");
              if (this.onEnd && this.chatId) {
                this.onEnd(this.chatId);
              }
            }
          }
        } catch (err) {
          console.error("[QwenAI] Stream parse error:", err);
        }
      }
    });
    stream$1.on("data", (buffer) => {
      const text = buffer.toString();
      console.log("[QwenAI] Raw stream data:", text.substring(0, 500));
      parser.feed(text);
    });
    stream$1.once("error", (err) => {
      console.error("[QwenAI] Stream error:", err);
      transStream.end("data: [DONE]\n\n");
    });
    stream$1.once("close", () => {
      console.log("[QwenAI] Stream closed");
      transStream.end("data: [DONE]\n\n");
    });
    return transStream;
  }
  async handleNonStream(stream2) {
    return new Promise((resolve, reject) => {
      const data = {
        id: "",
        model: this.model,
        object: "chat.completion",
        choices: [
          {
            index: 0,
            message: { role: "assistant", content: "", reasoning_content: "" },
            finish_reason: "stop"
          }
        ],
        usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
        created: this.created
      };
      let reasoningText = "";
      let summaryText = "";
      let resolved = false;
      let sawAnswerFinish = false;
      const resolveOnce = (value) => {
        if (!resolved) {
          resolved = true;
          resolve(value);
        }
      };
      const rejectOnce = (reason) => {
        if (!resolved) {
          resolved = true;
          reject(reason);
        }
      };
      const parser = eventsourceParser.createParser({
        onEvent: (event) => {
          try {
            if (event.data === "[DONE]") return;
            const parsed = JSON.parse(event.data);
            if (parsed["response.created"]?.response_id) {
              this.responseId = parsed["response.created"].response_id;
              data.id = this.responseId;
            }
            if (parsed.choices && parsed.choices.length > 0) {
              const delta = parsed.choices[0].delta || {};
              const phase = delta.phase;
              const status = delta.status;
              const content = delta.content || "";
              if (phase === "think" && status !== "finished") {
                reasoningText += content;
              } else if (phase === "thinking_summary") {
                const extra = delta.extra || {};
                if (extra.summary_thought?.content) {
                  const newSummary = extra.summary_thought.content.join("\n");
                  if (newSummary && newSummary.length > summaryText.length) {
                    summaryText = newSummary;
                  }
                }
              } else if (phase === "answer") {
                if (content) {
                  data.choices[0].message.content += content;
                }
                if (status === "finished") {
                  sawAnswerFinish = true;
                  const finalReasoning = reasoningText || summaryText;
                  if (finalReasoning) {
                    data.choices[0].message.reasoning_content = finalReasoning;
                  }
                  if (this.onEnd && this.chatId) {
                    this.onEnd(this.chatId);
                  }
                  resolveOnce(data);
                }
              } else if (phase === null && content) {
                data.choices[0].message.content += content;
              }
            }
          } catch (err) {
            console.error("[QwenAI] Non-stream parse error:", err);
            rejectOnce(err);
          }
        }
      });
      stream2.on("data", (buffer) => parser.feed(buffer.toString()));
      stream2.once("error", (err) => {
        console.error("[QwenAI] Non-stream error:", err);
        rejectOnce(err);
      });
      stream2.once("close", () => {
        const finalReasoning = reasoningText || summaryText;
        if (finalReasoning) {
          data.choices[0].message.reasoning_content = finalReasoning;
        }
        const answerText = data.choices[0].message.content || "";
        const hasAnyOutput = Boolean(answerText.trim() || finalReasoning.trim());
        if (!hasAnyOutput) {
          rejectOnce(new Error("Qwen AI returned an empty response stream without answer or reasoning content"));
          return;
        }
        if (!sawAnswerFinish) {
          console.warn("[QwenAI] Non-stream closed before an answer finished event; returning accumulated content.");
        }
        resolveOnce(data);
      });
    });
  }
  getChatId() {
    return this.chatId;
  }
  getResponseId() {
    return this.responseId;
  }
}
const ZAI_API_BASE$1 = "https://chat.z.ai";
const X_FE_VERSION = "prod-fe-1.1.37";
const ZAI_USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36";
const FAKE_HEADERS$7 = {
  Accept: "*/*",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN",
  "Cache-Control": "no-cache",
  Origin: ZAI_API_BASE$1,
  Pragma: "no-cache",
  "Sec-Ch-Ua": '"Not/A)Brand";v="99", "Chromium";v="148"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": ZAI_USER_AGENT,
  "X-Region": "domestic"
};
const SEARCH_CITATION_LOOSE_PATTERN = "【[^】]*turn\\d+search\\d+[^】]*】";
const SEARCH_CITATION_BRACKET_START = "【";
const SEARCH_CITATION_BRACKET_END = "】";
function cleanSearchCitationsWithBuffer(text, buffer) {
  const combined = buffer.value + text;
  let cleaned = combined.replace(new RegExp(SEARCH_CITATION_LOOSE_PATTERN, "g"), "");
  const lastOpenBracket = cleaned.lastIndexOf(SEARCH_CITATION_BRACKET_START);
  if (lastOpenBracket !== -1) {
    const afterBracket = cleaned.slice(lastOpenBracket);
    if (afterBracket.includes("turn") || afterBracket.includes("search")) {
      buffer.value = afterBracket;
      cleaned = cleaned.slice(0, lastOpenBracket);
    } else if (!afterBracket.includes(SEARCH_CITATION_BRACKET_END)) {
      buffer.value = afterBracket;
      cleaned = cleaned.slice(0, lastOpenBracket);
    } else {
      buffer.value = "";
    }
  } else {
    buffer.value = "";
  }
  return cleaned;
}
function uuid$2(separator = true) {
  const id = "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
  return separator ? id : id.replace(/-/g, "");
}
let ZaiAdapter$1 = class ZaiAdapter {
  constructor(provider, account) {
    this.token = null;
    this.provider = provider;
    this.account = account;
  }
  getToken() {
    const credentials = this.account.credentials;
    return credentials.token || credentials.accessToken || credentials.jwt || "";
  }
  getCaptchaVerifyParam() {
    const credentials = this.account.credentials;
    return credentials.captcha_verify_param || credentials.captchaVerifyParam || void 0;
  }
  async ensureToken() {
    const token = this.getToken();
    if (token) {
      return token;
    }
    throw new Error("Z.ai token not configured, please add token in account settings");
  }
  extractLastUserMessage(messages) {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].role === "user") {
        const content = messages[i].content;
        if (typeof content === "string") {
          return content;
        }
        if (Array.isArray(content)) {
          const textParts = [];
          for (const part of content) {
            if (typeof part === "object" && part !== null && part.type === "text" && part.text) {
              textParts.push(part.text);
            }
          }
          if (textParts.length > 0) {
            return textParts.join("\n");
          }
        }
        return "";
      }
    }
    return "";
  }
  extractUserIDFromToken(token) {
    try {
      const parts = token.split(".");
      if (parts.length < 2) {
        return "guest";
      }
      let payload = parts[1];
      const padding = payload.length % 4;
      if (padding > 0) {
        payload += "=".repeat(4 - padding);
      }
      payload = payload.replace(/-/g, "+").replace(/_/g, "/");
      const decoded = Buffer.from(payload, "base64").toString("utf8");
      const data = JSON.parse(decoded);
      return data.id || data.user_id || data.uid || data.sub || "guest";
    } catch {
      return "guest";
    }
  }
  generateSignature(messageText, requestId2, timestampMs, userId) {
    const secret = "key-@@@@)))()((9))-xxxx&&&%%%%%";
    const r = timestampMs;
    const i = String(timestampMs);
    const e = `requestId,${requestId2},timestamp,${timestampMs},user_id,${userId}`;
    const a = Buffer.from(messageText, "utf-8");
    const w = a.toString("base64");
    const canonicalString = `${e}|${w}|${i}`;
    const windowIndex = Math.floor(r / (5 * 60 * 1e3));
    const derivedKeyHex = crypto$1.createHmac("sha256", secret).update(String(windowIndex)).digest("hex");
    const signature = crypto$1.createHmac("sha256", derivedKeyHex).update(canonicalString).digest("hex");
    return signature;
  }
  async createChat(model = "glm-5", firstMessageContent = "") {
    const token = await this.ensureToken();
    const timestamp = Math.floor(Date.now() / 1e3);
    const messageId = uuid$2();
    console.log("[Z.ai] Creating chat with model:", model);
    const requestBody = {
      chat: {
        id: "",
        title: "新聊天",
        models: [model],
        params: {},
        history: {
          messages: firstMessageContent ? {
            [messageId]: {
              id: messageId,
              parentId: null,
              childrenIds: [],
              role: "user",
              content: firstMessageContent,
              timestamp,
              models: [model]
            }
          } : {},
          currentId: firstMessageContent ? messageId : ""
        },
        tags: [],
        flags: [],
        features: [
          {
            type: "tool_selector",
            server: "tool_selector_h",
            status: "hidden"
          }
        ],
        mcp_servers: [],
        enable_thinking: true,
        auto_web_search: false,
        message_version: 1,
        extra: {},
        timestamp: Date.now(),
        type: "default"
      }
    };
    const response = await axios.post(
      `${ZAI_API_BASE$1}/api/v1/chats/new`,
      requestBody,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          ...FAKE_HEADERS$7,
          "Cookie": `token=${token}`,
          Referer: `${ZAI_API_BASE$1}/`
        },
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    if (response.status !== 200 && response.status !== 201) {
      console.error("[Z.ai] Create chat response:", response.status, response.data);
      throw new Error(`Failed to create chat: HTTP ${response.status}`);
    }
    console.log("[Z.ai] Chat created:", response.data.id);
    return { chatId: response.data.id, messageId };
  }
  async deleteChat(chatId) {
    try {
      const token = await this.ensureToken();
      const response = await axios.delete(
        `${ZAI_API_BASE$1}/api/v1/chats/${chatId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            ...FAKE_HEADERS$7,
            Referer: `${ZAI_API_BASE$1}/`
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      console.log("[Z.ai] Chat deleted:", chatId, "Status:", response.status);
      return response.status === 200 || response.status === 204;
    } catch (error) {
      console.error("[Z.ai] Failed to delete chat:", error);
      return false;
    }
  }
  async deleteAllChats() {
    try {
      const token = await this.ensureToken();
      console.log("[Z.ai] Deleting all chats...");
      const response = await axios.delete(
        `${ZAI_API_BASE$1}/api/v1/chats/`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            ...FAKE_HEADERS$7,
            Referer: `${ZAI_API_BASE$1}/`
          },
          timeout: 3e4,
          validateStatus: () => true
        }
      );
      console.log("[Z.ai] Delete all chats response:", response.status, response.data);
      if (response.status === 200 && response.data === true) {
        console.log("[Z.ai] All chats deleted successfully");
        return true;
      }
      console.warn("[Z.ai] Delete all chats failed:", response.status, response.data);
      return false;
    } catch (error) {
      console.error("[Z.ai] Failed to delete all chats:", error);
      return false;
    }
  }
  async chatCompletion(request) {
    const token = await this.ensureToken();
    const userId = this.extractUserIDFromToken(token);
    console.log("[Z.ai] chatCompletion called with request.model:", request.model);
    const modelMapping = {
      "glm-5.1": "GLM-5.1",
      "glm-5-turbo": "GLM-5-Turbo",
      "glm-5v-turbo": "GLM-5v-Turbo",
      "glm-5": "glm-5",
      "glm-4.7": "glm-4.7",
      // Also handle uppercase input
      "GLM-5.1": "GLM-5.1",
      "GLM-5-Turbo": "GLM-5-Turbo",
      "GLM-5V-Turbo": "GLM-5v-Turbo",
      "GLM-5v-Turbo": "GLM-5v-Turbo",
      "GLM-5": "glm-5",
      "GLM-4.7": "glm-4.7"
    };
    const mappedModel = modelMapping[request.model] || modelMapping[request.model.toLowerCase()] || request.model;
    console.log("[Z.ai] Original model:", request.model, "-> Mapped model:", mappedModel);
    let systemContent = "";
    let processedMessages = [];
    for (const msg of request.messages) {
      if (msg.role === "system") {
        systemContent += (systemContent ? "\n\n" : "") + (typeof msg.content === "string" ? msg.content : "");
      } else {
        processedMessages.push(msg);
      }
    }
    if (systemContent && processedMessages.length > 0) {
      const firstUserIdx = processedMessages.findIndex((m) => m.role === "user");
      if (firstUserIdx !== -1) {
        const firstUserMsg = processedMessages[firstUserIdx];
        const originalContent = typeof firstUserMsg.content === "string" ? firstUserMsg.content : Array.isArray(firstUserMsg.content) ? firstUserMsg.content.find((p) => p.type === "text")?.text || "" : "";
        processedMessages[firstUserIdx] = {
          ...firstUserMsg,
          content: `${systemContent}

User: ${originalContent}`
        };
      }
    }
    const signaturePrompt = this.extractLastUserMessage(processedMessages);
    const chatResult = await this.createChat(mappedModel, signaturePrompt);
    const chatId = chatResult.chatId;
    const messageId = chatResult.messageId;
    const parentMessageId = null;
    console.log("[Z.ai] Created new chat:", chatId);
    const requestId2 = uuid$2();
    const timestamp = Date.now();
    const signature = this.generateSignature(signaturePrompt, requestId2, timestamp, userId);
    const modelForDetection = request.originalModel || request.model;
    const modelLower = modelForDetection.toLowerCase();
    let enableThinking = request.reasoning_effort === false ? false : true;
    let enableWebSearch = !!request.web_search;
    if (!enableThinking && (modelLower.includes("think") || modelLower.includes("r1"))) {
      enableThinking = true;
      console.log("[Z.ai] Thinking mode enabled (from model name)");
    }
    if (!enableWebSearch && modelLower.includes("search")) {
      enableWebSearch = true;
      console.log("[Z.ai] Web search enabled (from model name)");
    }
    const features = {
      image_generation: false,
      web_search: false,
      auto_web_search: enableWebSearch,
      preview_mode: true,
      flags: [],
      vlm_tools_enable: false,
      vlm_web_search_enable: false,
      vlm_website_mode: false,
      enable_thinking: enableThinking
    };
    const requestBody = {
      stream: request.stream !== false,
      model: mappedModel,
      messages: processedMessages,
      signature_prompt: signaturePrompt,
      params: {},
      extra: {},
      features,
      variables: {
        "{{USER_NAME}}": "User",
        "{{USER_LOCATION}}": "Unknown",
        "{{CURRENT_DATETIME}}": (/* @__PURE__ */ new Date()).toISOString().replace("T", " ").substring(0, 19),
        "{{CURRENT_DATE}}": (/* @__PURE__ */ new Date()).toISOString().substring(0, 10),
        "{{CURRENT_TIME}}": (/* @__PURE__ */ new Date()).toISOString().substring(11, 19),
        "{{CURRENT_WEEKDAY}}": ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][(/* @__PURE__ */ new Date()).getDay()],
        "{{CURRENT_TIMEZONE}}": "Asia/Shanghai",
        "{{USER_LANGUAGE}}": "zh-CN"
      },
      chat_id: chatId,
      id: requestId2,
      current_user_message_id: messageId,
      current_user_message_parent_id: parentMessageId,
      background_tasks: {
        title_generation: true,
        tags_generation: true
      }
    };
    const captchaVerifyParam = this.getCaptchaVerifyParam();
    if (captchaVerifyParam) {
      requestBody.captcha_verify_param = captchaVerifyParam;
    }
    console.log("[Z.ai] Sending chat request...");
    console.log("[Z.ai] Model:", request.model);
    console.log("[Z.ai] ChatId:", chatId);
    console.log("[Z.ai] MessageId (current_user_message_id):", messageId);
    console.log("[Z.ai] ParentMessageId:", "(none)");
    const queryParams = new URLSearchParams({
      timestamp: String(timestamp),
      requestId: requestId2,
      user_id: userId,
      version: "0.0.1",
      platform: "web",
      token,
      user_agent: ZAI_USER_AGENT,
      language: "zh-CN",
      languages: "zh-CN,zh",
      timezone: "Asia/Shanghai",
      cookie_enabled: "true",
      screen_width: "1512",
      screen_height: "982",
      screen_resolution: "1512x982",
      viewport_height: "945",
      viewport_width: "923",
      viewport_size: "923x945",
      color_depth: "30",
      pixel_ratio: "2",
      current_url: `${ZAI_API_BASE$1}/c/${chatId}`,
      pathname: `/c/${chatId}`,
      search: "",
      hash: "",
      host: "chat.z.ai",
      hostname: "chat.z.ai",
      protocol: "https:",
      referrer: "",
      title: "Z.ai - Free AI Chatbot & Agent powered by GLM-5 & GLM-4.7",
      timezone_offset: "-480",
      local_time: (/* @__PURE__ */ new Date()).toISOString(),
      utc_time: (/* @__PURE__ */ new Date()).toUTCString(),
      is_mobile: "false",
      is_touch: "false",
      max_touch_points: "0",
      browser_name: "Chrome",
      os_name: "Mac OS",
      signature_timestamp: String(timestamp)
    });
    const response = await axios.post(
      `${ZAI_API_BASE$1}/api/v2/chat/completions?${queryParams.toString()}`,
      requestBody,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          ...FAKE_HEADERS$7,
          "X-Signature": signature,
          "X-FE-Version": X_FE_VERSION,
          "Cookie": `token=${token}`,
          Referer: `${ZAI_API_BASE$1}/c/${chatId}`,
          Priority: "u=1, i"
        },
        responseType: "stream",
        timeout: 12e4,
        validateStatus: () => true
      }
    );
    console.log("[Z.ai] Response status:", response.status);
    if (response.status !== 200) {
      console.log("[Z.ai] Request body:", JSON.stringify(requestBody, null, 2));
      console.log("[Z.ai] Signature:", signature);
      console.log("[Z.ai] Timestamp:", timestamp);
      console.log("[Z.ai] RequestId:", requestId2);
      console.log("[Z.ai] UserId:", userId);
      if (response.data && typeof response.data.on === "function") {
        const chunks = [];
        response.data.on("data", (chunk) => chunks.push(chunk));
        await new Promise((resolve) => {
          response.data.on("end", () => resolve());
          response.data.on("error", () => resolve());
        });
        const errorBody = Buffer.concat(chunks).toString("utf8");
        console.log("[Z.ai] Error response body:", errorBody);
      } else if (response.data) {
        console.log("[Z.ai] Error response data:", JSON.stringify(response.data, null, 2));
      }
    }
    return { response, chatId, requestId: requestId2 };
  }
  static isZaiProvider(provider) {
    return provider.id === "zai" || provider.apiEndpoint.includes("z.ai") || provider.apiEndpoint.includes("chat.z.ai");
  }
};
class ZaiStreamHandler {
  constructor(model, onEnd) {
    this.chatId = "";
    this.content = "";
    this.toolCallsSent = false;
    this.lastMessageId = "";
    this.sentRole = false;
    this.sentThinkingRole = false;
    this.streamEnded = false;
    this.citationBuffer = { value: "" };
    this.thinkingCitationBuffer = { value: "" };
    this.model = model;
    this.created = Math.floor(Date.now() / 1e3);
    this.onEnd = onEnd;
    this.toolCallState = createToolCallState();
  }
  setChatId(chatId) {
    this.chatId = chatId;
  }
  getLastMessageId() {
    return this.lastMessageId;
  }
  sendToolCalls(transStream) {
    if (this.toolCallsSent) return;
    const toolCalls = parseToolUse(this.content);
    if (toolCalls && toolCalls.length > 0) {
      this.toolCallsSent = true;
      for (let i = 0; i < toolCalls.length; i++) {
        const tc = toolCalls[i];
        transStream.write(
          `data: ${JSON.stringify({
            id: this.chatId,
            model: this.model,
            object: "chat.completion.chunk",
            choices: [{
              index: 0,
              delta: {
                tool_calls: [{
                  index: i,
                  id: tc.id,
                  type: "function",
                  function: {
                    name: tc.function.name,
                    arguments: tc.function.arguments
                  }
                }]
              },
              finish_reason: null
            }],
            created: this.created
          })}

`
        );
      }
      transStream.write(
        `data: ${JSON.stringify({
          id: this.chatId,
          model: this.model,
          object: "chat.completion.chunk",
          choices: [{ index: 0, delta: {}, finish_reason: "tool_calls" }],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
          created: this.created
        })}

`
      );
      transStream.end("data: [DONE]\n\n");
      if (this.onEnd) {
        try {
          this.onEnd(this.chatId);
        } catch (e) {
          console.error("[Z.ai] onEnd callback error:", e);
        }
      }
    }
  }
  async handleStream(stream$1) {
    const transStream = new stream.PassThrough();
    console.log("[Z.ai] Starting stream handler...");
    let streamEnded = false;
    const safeEnd = (data) => {
      if (streamEnded) return;
      streamEnded = true;
      {
        transStream.end(data);
      }
    };
    const parser = eventsourceParser.createParser({
      onEvent: (event) => {
        try {
          if (event.data === "[DONE]") return;
          const data = JSON.parse(event.data);
          if (data.type !== "chat:completion") return;
          const result = data.data;
          if (!result) return;
          if (result.id && result.role === "assistant" && !this.lastMessageId) {
            this.lastMessageId = result.id;
            console.log("[Z.ai] Extracted assistant message id:", this.lastMessageId);
          }
          if (result.phase === "thinking" && result.delta_content) {
            const cleanedContent = cleanSearchCitationsWithBuffer(result.delta_content, this.thinkingCitationBuffer);
            if (!cleanedContent) return;
            if (!this.sentThinkingRole) {
              transStream.write(
                `data: ${JSON.stringify({
                  id: this.chatId,
                  model: this.model,
                  object: "chat.completion.chunk",
                  choices: [{ index: 0, delta: { role: "assistant", reasoning_content: "" }, finish_reason: null }],
                  created: this.created
                })}

`
              );
              this.sentThinkingRole = true;
            }
            transStream.write(
              `data: ${JSON.stringify({
                id: this.chatId,
                model: this.model,
                object: "chat.completion.chunk",
                choices: [{ index: 0, delta: { reasoning_content: cleanedContent }, finish_reason: null }],
                created: this.created
              })}

`
            );
          } else if (result.phase === "answer" && result.delta_content) {
            const cleanedContent = cleanSearchCitationsWithBuffer(result.delta_content, this.citationBuffer);
            if (!cleanedContent) return;
            this.content += cleanedContent;
            const baseChunk = createBaseChunk(this.chatId, this.model, this.created);
            const { chunks: outputChunks } = processStreamContent(
              cleanedContent,
              this.toolCallState,
              baseChunk,
              !this.sentRole && !this.sentThinkingRole,
              "zai"
            );
            for (const outChunk of outputChunks) {
              transStream.write(`data: ${JSON.stringify(outChunk)}

`);
            }
            if (outputChunks.length > 0) this.sentRole = true;
          } else if (result.phase === "done" && result.done) {
            console.log("[Z.ai] Stream finished, content length:", this.content.length);
            const baseChunk = createBaseChunk(this.chatId, this.model, this.created);
            const flushChunks = flushToolCallBuffer(this.toolCallState, baseChunk, "zai");
            for (const outChunk of flushChunks) {
              transStream.write(`data: ${JSON.stringify(outChunk)}

`);
            }
            const finishReason = this.toolCallState.hasEmittedToolCall ? "tool_calls" : "stop";
            const usage = result.usage || { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 };
            transStream.write(
              `data: ${JSON.stringify({
                id: this.chatId,
                model: this.model,
                object: "chat.completion.chunk",
                choices: [{ index: 0, delta: {}, finish_reason: finishReason }],
                usage,
                created: this.created
              })}

`
            );
            safeEnd("data: [DONE]\n\n");
            if (this.onEnd) {
              try {
                this.onEnd(this.chatId);
              } catch (e) {
                console.error("[Z.ai] onEnd callback error:", e);
              }
            }
          } else if (result.error || data.error) {
            const error = result.error || data.error;
            console.error("[Z.ai] Stream error:", error);
            transStream.write(
              `data: ${JSON.stringify({
                id: this.chatId,
                model: this.model,
                object: "chat.completion.chunk",
                choices: [{ index: 0, delta: { content: `
Error: ${error.detail || JSON.stringify(error)}` }, finish_reason: "stop" }],
                created: this.created
              })}

`
            );
            safeEnd("data: [DONE]\n\n");
          }
        } catch (err) {
          console.error("[Z.ai] Stream parse error:", err);
        }
      }
    });
    stream$1.on("data", (buffer) => {
      if (streamEnded) return;
      parser.feed(buffer.toString());
    });
    stream$1.once("error", (err) => {
      console.error("[Z.ai] Stream error:", err);
      safeEnd("data: [DONE]\n\n");
    });
    stream$1.once("close", () => {
      console.log("[Z.ai] Stream closed");
      safeEnd("data: [DONE]\n\n");
    });
    return transStream;
  }
  async handleNonStream(response) {
    console.log("[Z.ai] Starting non-stream handler...");
    return new Promise((resolve, reject) => {
      const data = {
        id: "",
        model: this.model,
        object: "chat.completion",
        choices: [
          {
            index: 0,
            message: { role: "assistant", content: "", reasoning_content: "" },
            finish_reason: "stop"
          }
        ],
        usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
        created: this.created
      };
      let resolved = false;
      let reasoningContent = "";
      const resolveOnce = (result) => {
        if (resolved) return;
        resolved = true;
        if (reasoningContent) {
          result.choices[0].message.reasoning_content = reasoningContent;
        }
        resolve(result);
      };
      const rejectOnce = (err) => {
        if (resolved) return;
        resolved = true;
        reject(err);
      };
      setTimeout(() => {
        if (!resolved) {
          console.log("[Z.ai] Non-stream timeout, resolving with current data, content length:", data.choices[0].message.content.length);
          resolveOnce(data);
        }
      }, 6e4);
      const streamData = response;
      console.log("[Z.ai] Non-stream: streamData type:", typeof streamData);
      console.log("[Z.ai] Non-stream: streamData.on type:", typeof streamData?.on);
      console.log("[Z.ai] Non-stream: streamData is function?", typeof streamData?.on === "function");
      if (streamData && typeof streamData.on === "function") {
        console.log("[Z.ai] Non-stream: taking stream path");
        const thinkingBuffer = { value: "" };
        const answerBuffer = { value: "" };
        const parser = eventsourceParser.createParser({
          onEvent: (event) => {
            try {
              if (event.data === "[DONE]") return;
              const eventData = JSON.parse(event.data);
              if (eventData.type !== "chat:completion") return;
              const result = eventData.data;
              if (!result) return;
              if (result.phase === "thinking" && result.delta_content) {
                reasoningContent += cleanSearchCitationsWithBuffer(result.delta_content, thinkingBuffer);
              } else if (result.phase === "answer" && result.delta_content) {
                data.choices[0].message.content += cleanSearchCitationsWithBuffer(result.delta_content, answerBuffer);
              } else if (result.phase === "done" && result.done) {
                console.log("[Z.ai] Non-stream finished, content length:", data.choices[0].message.content.length);
                if (result.usage) {
                  data.usage = result.usage;
                }
                resolveOnce(data);
              } else if (result.error || eventData.error) {
                const error = result.error || eventData.error;
                data.choices[0].message.content += `
Error: ${error.detail || JSON.stringify(error)}`;
                resolveOnce(data);
              }
            } catch (err) {
              console.error("[Z.ai] Non-stream parse error:", err);
              rejectOnce(err instanceof Error ? err : new Error(String(err)));
            }
          }
        });
        streamData.on("data", (buffer) => parser.feed(buffer.toString()));
        streamData.once("error", rejectOnce);
        streamData.once("close", () => {
          console.log("[Z.ai] Non-stream closed, resolving with current data, content length:", data.choices[0].message.content.length);
          resolveOnce(data);
        });
      } else if (streamData) {
        try {
          if (typeof streamData === "string") {
            let content = "";
            let reasoning = "";
            const thinkingBuffer = { value: "" };
            const answerBuffer = { value: "" };
            const lines = streamData.split("\n");
            for (const line of lines) {
              if (line.startsWith("data:")) {
                const jsonStr = line.substring(5).trim();
                if (jsonStr === "[DONE]") continue;
                try {
                  const event = JSON.parse(jsonStr);
                  if (event.type === "chat:completion" && event.data) {
                    if (event.data.phase === "thinking" && event.data.delta_content) {
                      reasoning += cleanSearchCitationsWithBuffer(event.data.delta_content, thinkingBuffer);
                    } else if (event.data.phase === "answer" && event.data.delta_content) {
                      content += cleanSearchCitationsWithBuffer(event.data.delta_content, answerBuffer);
                    } else if (event.data.phase === "done" && event.data.done) {
                      if (event.data.usage) {
                        data.usage = event.data.usage;
                      }
                    }
                  }
                } catch (e) {
                }
              }
            }
            data.choices[0].message.content = content;
            if (reasoning) {
              data.choices[0].message.reasoning_content = reasoning;
            }
          } else {
            data.choices[0].message.content = streamData.choices?.[0]?.message?.content || "";
          }
          console.log("[Z.ai] Non-stream JSON finished, content length:", data.choices[0].message.content.length);
          resolveOnce(data);
        } catch (err) {
          console.error("[Z.ai] Non-stream JSON parse error:", err);
          rejectOnce(err instanceof Error ? err : new Error(String(err)));
        }
      } else {
        console.log("[Z.ai] Non-stream: streamData is falsy, taking empty path");
        resolveOnce(data);
      }
    });
  }
  getChatId() {
    return this.chatId;
  }
}
const AGENT_BASE_URL = "https://agent.minimaxi.com";
const FAKE_HEADERS$6 = {
  Accept: "application/json, text/plain, */*",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9",
  "Cache-Control": "no-cache",
  Origin: "https://agent.minimaxi.com",
  Pragma: "no-cache",
  "Sec-Ch-Ua": '"Chromium";v="142", "Google Chrome";v="142", "Not_A Brand";v="99"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36"
};
const FAKE_USER_DATA$1 = {
  device_platform: "web",
  biz_id: "3",
  app_id: "3001",
  version_code: "22201",
  uuid: null,
  device_id: null,
  os_name: "Mac",
  browser_name: "chrome",
  device_memory: 8,
  cpu_core_num: 11,
  browser_language: "zh-CN",
  browser_platform: "MacIntel",
  user_id: null,
  screen_width: 1920,
  screen_height: 1080,
  unix: null,
  lang: "zh",
  token: null,
  timezone_offset: 28800,
  sys_language: "zh",
  client: "web"
};
const deviceInfoMap = /* @__PURE__ */ new Map();
const DEVICE_INFO_EXPIRES = 10800;
function uuid$1() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
function md5$1(input) {
  return crypto$1.createHash("md5").update(input).digest("hex");
}
function unixTimestamp$1() {
  return Math.floor(Date.now() / 1e3);
}
function tokenSplit(authorization) {
  const token = authorization.replace("Bearer ", "");
  if (token.includes("+")) {
    return [token];
  }
  return [token];
}
function parseJWTUserID(jwtToken) {
  try {
    const parts = jwtToken.split(".");
    if (parts.length !== 3) {
      console.log("[MiniMax] Invalid JWT format, expected 3 parts, got:", parts.length);
      return "";
    }
    const payload = parts[1];
    const padding = 4 - payload.length % 4;
    const paddedPayload = padding !== 4 ? payload + "=".repeat(padding) : payload;
    const decoded = Buffer.from(paddedPayload, "base64").toString("utf8");
    const payloadObj = JSON.parse(decoded);
    const userID = payloadObj?.user?.id || "";
    console.log("[MiniMax] Parsed userID from JWT:", userID);
    return userID;
  } catch (error) {
    console.error("[MiniMax] Failed to parse JWT:", error);
    return "";
  }
}
function checkResult(result) {
  if (!result.data) return null;
  const { statusInfo, data } = result.data;
  if (typeof statusInfo !== "object") return result.data;
  const { code, message } = statusInfo;
  if (code === 0) return data;
  throw new Error(`[请求hailuo失败]: ${message}`);
}
let MiniMaxAdapter$1 = class MiniMaxAdapter {
  constructor(provider, account) {
    this.provider = provider;
    this.account = account;
    this.rawToken = account.credentials.token || "";
    this.model = "MiniMax-M2.7";
    this.created = unixTimestamp$1();
    const providedRealUserID = account.credentials.realUserID;
    if (providedRealUserID && providedRealUserID.trim()) {
      this.realUserID = providedRealUserID.trim();
      this.jwtToken = this.rawToken;
      console.log("[MiniMax] Using provided realUserID:", this.realUserID);
    } else {
      const tokens = tokenSplit(this.rawToken);
      const fullToken = tokens[0];
      if (fullToken.includes("+")) {
        const parts = fullToken.split("+");
        this.realUserID = parts[0];
        this.jwtToken = parts[1];
        console.log("[MiniMax] Token contains realUserID+JWT format, realUserID:", this.realUserID);
      } else {
        this.jwtToken = fullToken;
        this.realUserID = parseJWTUserID(this.jwtToken);
        console.log("[MiniMax] Parsed realUserID from JWT:", this.realUserID);
      }
    }
    console.log("[MiniMax] Token parsed - realUserID:", this.realUserID, "jwtToken:", this.jwtToken.substring(0, 30) + "...");
  }
  async requestDeviceInfo() {
    const cacheKey = this.rawToken;
    let result = deviceInfoMap.get(cacheKey);
    if (result && result.refreshTime > unixTimestamp$1()) {
      return result;
    }
    const randomUuid = uuid$1();
    const unix = `${Date.now()}`;
    const timestamp = unixTimestamp$1();
    const userData = { ...FAKE_USER_DATA$1 };
    userData.uuid = randomUuid;
    userData.user_id = this.realUserID;
    userData.unix = unix;
    userData.token = this.jwtToken;
    let queryStr = "";
    for (const key in userData) {
      if (userData[key] === void 0) continue;
      queryStr += `&${key}=${userData[key]}`;
    }
    queryStr = queryStr.substring(1);
    const dataJson = JSON.stringify({ uuid: randomUuid });
    const fullUri = `/v1/api/user/device/register?${queryStr}`;
    const yy = md5$1(`${encodeURIComponent(fullUri)}_${dataJson}${md5$1(unix)}ooui`);
    const signature = md5$1(`${timestamp}${this.jwtToken}${dataJson}`);
    console.log("[MiniMax] Registering device - randomUuid:", randomUuid, "realUserID:", this.realUserID);
    const response = await axios.post(
      `${AGENT_BASE_URL}${fullUri}`,
      { uuid: randomUuid },
      {
        headers: {
          ...FAKE_HEADERS$6,
          "Content-Type": "application/json",
          "Referer": `${AGENT_BASE_URL}/`,
          "token": this.jwtToken,
          "x-timestamp": String(timestamp),
          "x-signature": signature,
          "yy": yy
        },
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    console.log("[MiniMax] Device register response:", response.status, JSON.stringify(response.data));
    if (response.status !== 200 || response.data?.statusInfo?.code !== 0) {
      throw new Error(`Failed to register device: ${response.data?.statusInfo?.message || response.status}`);
    }
    const data = checkResult(response);
    result = {
      deviceId: data?.deviceIDStr || "",
      userId: this.realUserID,
      realUserID: data?.realUserID || this.realUserID,
      jwtToken: this.jwtToken,
      refreshTime: unixTimestamp$1() + DEVICE_INFO_EXPIRES,
      uuid: randomUuid
    };
    deviceInfoMap.set(cacheKey, result);
    console.log("[MiniMax] Device info cached:", { deviceId: result.deviceId, userId: result.userId, realUserID: result.realUserID, uuid: result.uuid });
    return result;
  }
  async request(method, uri, data, deviceInfo) {
    const unix = `${Date.now()}`;
    const timestamp = unixTimestamp$1();
    const userData = { ...FAKE_USER_DATA$1 };
    const realUserID = deviceInfo.realUserID || deviceInfo.userId;
    userData.uuid = realUserID;
    userData.device_id = deviceInfo.deviceId || void 0;
    userData.user_id = realUserID;
    userData.unix = unix;
    userData.token = this.jwtToken;
    let queryStr = "";
    for (const key in userData) {
      if (userData[key] === void 0) continue;
      queryStr += `&${key}=${userData[key]}`;
    }
    queryStr = queryStr.substring(1);
    const dataJson = JSON.stringify(data || {});
    const fullUri = `${uri}${uri.lastIndexOf("?") != -1 ? "&" : "?"}${queryStr}`;
    const yy = md5$1(`${encodeURIComponent(fullUri)}_${dataJson}${md5$1(unix)}ooui`);
    const signature = md5$1(`${timestamp}${this.jwtToken}${dataJson}`);
    console.log("[MiniMax] Request - uuid:", realUserID, "user_id:", realUserID, "device_id:", deviceInfo.deviceId);
    return await axios.request({
      method,
      url: `${AGENT_BASE_URL}${fullUri}`,
      data,
      timeout: 15e3,
      validateStatus: () => true,
      headers: {
        Referer: `${AGENT_BASE_URL}/`,
        token: this.jwtToken,
        ...FAKE_HEADERS$6,
        "Content-Type": "application/json",
        "x-timestamp": String(timestamp),
        "x-signature": signature,
        yy
      }
    });
  }
  async requestStream(method, uri, requestBody, deviceInfo) {
    const unix = `${Date.now()}`;
    const timestamp = unixTimestamp$1();
    const userData = { ...FAKE_USER_DATA$1 };
    const realUserID = deviceInfo.realUserID || deviceInfo.userId;
    userData.uuid = realUserID;
    userData.device_id = deviceInfo.deviceId || void 0;
    userData.user_id = realUserID;
    userData.unix = unix;
    userData.token = this.jwtToken;
    let queryStr = "";
    for (const key in userData) {
      if (userData[key] === void 0) continue;
      queryStr += `&${key}=${userData[key]}`;
    }
    queryStr = queryStr.substring(1);
    const dataJson = JSON.stringify(requestBody);
    const yy = md5$1(`${encodeURIComponent(`${uri}?${queryStr}`)}_${dataJson}${md5$1(unix)}ooui`);
    const signature = md5$1(`${timestamp}${this.jwtToken}${dataJson}`);
    console.log("[MiniMax] Stream Request - uuid:", realUserID, "user_id:", realUserID, "device_id:", deviceInfo.deviceId);
    console.log("[MiniMax] Request body:", dataJson);
    console.log("[MiniMax] Query string:", queryStr);
    console.log("[MiniMax] Headers - timestamp:", timestamp, "signature:", signature.substring(0, 16) + "...", "yy:", yy.substring(0, 16) + "...");
    const session = await new Promise((resolve, reject) => {
      const session2 = http2.connect(AGENT_BASE_URL);
      session2.on("connect", () => resolve(session2));
      session2.on("error", reject);
    });
    const headers = {
      ":method": method,
      ":path": `${uri}?${queryStr}`,
      ":scheme": "https",
      "content-type": "application/json",
      Referer: "https://agent.minimaxi.com/",
      token: this.jwtToken,
      ...FAKE_HEADERS$6,
      "x-timestamp": `${timestamp}`,
      "x-signature": signature,
      Accept: "text/event-stream",
      // Must be after FAKE_HEADERS to override
      yy
    };
    const stream2 = session.request(headers);
    stream2.setTimeout(12e4);
    stream2.setEncoding("utf8");
    stream2.on("response", (respHeaders) => {
      console.log("[MiniMax] HTTP/2 response headers:", JSON.stringify(respHeaders));
    });
    stream2.on("data", (chunk) => {
      console.log("[MiniMax] HTTP/2 data chunk:", chunk.toString().substring(0, 200));
    });
    stream2.on("error", (err) => {
      console.error("[MiniMax] HTTP/2 stream error:", err);
    });
    stream2.on("close", () => {
      console.log("[MiniMax] HTTP/2 stream closed");
    });
    stream2.end(Buffer.from(dataJson, "utf8"));
    return { session, stream: stream2 };
  }
  messagesPrepare(messages, toolsPrompt, isMultiTurn = false) {
    const processedMessages = messages.map((msg) => {
      if (msg.role === "assistant" && msg.tool_calls && msg.tool_calls.length > 0) {
        const toolCallsText = msg.tool_calls.map((tc) => {
          return `[call:${tc.function.name}]${tc.function.arguments}[/call]`;
        }).join("\n");
        return { ...msg, content: `[function_calls]
${toolCallsText}
[/function_calls]` };
      }
      if (msg.role === "tool" && msg.tool_call_id) {
        return {
          ...msg,
          role: "user",
          content: `[TOOL_RESULT for ${msg.tool_call_id}] ${msg.content || ""}`
        };
      }
      return msg;
    });
    let systemContent = "";
    const otherMessages = processedMessages.filter((msg) => {
      if (msg.role === "system") {
        const text = typeof msg.content === "string" ? msg.content : "";
        systemContent = text;
        return false;
      }
      return true;
    });
    let content = "";
    if (systemContent) {
      content = `system:${systemContent}
`;
    }
    if (isMultiTurn) {
      let lastUserIdx = -1;
      for (let i = otherMessages.length - 1; i >= 0; i--) {
        if (otherMessages[i].role === "user") {
          lastUserIdx = i;
          break;
        }
      }
      if (lastUserIdx !== -1) {
        const lastUserMsg = otherMessages[lastUserIdx];
        const text = typeof lastUserMsg.content === "string" ? lastUserMsg.content : "";
        content += `user:${text}
`;
        for (let i = lastUserIdx + 1; i < otherMessages.length; i++) {
          if (otherMessages[i].role === "user") {
            const toolText = typeof otherMessages[i].content === "string" ? otherMessages[i].content : "";
            content += `user:${toolText}
`;
          }
        }
        if (toolsPrompt) {
          content = content.trim() + "\n\n" + toolsPrompt;
        }
        return {
          msg_type: 1,
          text: content,
          chat_type: 1,
          attachments: [],
          selected_mcp_tools: [],
          backend_config: {},
          sub_agent_ids: []
        };
      }
    }
    if (otherMessages.length < 2) {
      content += otherMessages.reduce((acc, msg) => {
        const text = typeof msg.content === "string" ? msg.content : "";
        return acc + `${msg.role}:${text}
`;
      }, "");
    } else {
      const latestMessage = otherMessages[otherMessages.length - 1];
      const hasFileOrImage = Array.isArray(latestMessage.content) && latestMessage.content.some((v) => typeof v === "object" && ["file", "image_url"].includes(v.type));
      if (hasFileOrImage) {
        const newFileMessage = {
          content: "关注用户最新发送文件和消息",
          role: "system"
        };
        otherMessages.push(newFileMessage);
      }
      content += otherMessages.reduce((acc, msg) => {
        const text = typeof msg.content === "string" ? msg.content : "";
        return acc + `${msg.role}:${text}
`;
      }, "") + "assistant:\n";
      content = content.trim().replace(/\!\[.+\]\(.+\)/g, "");
    }
    if (toolsPrompt) {
      content = content.trim() + "\n\n" + toolsPrompt;
    }
    return {
      msg_type: 1,
      text: content,
      chat_type: 1,
      attachments: [],
      selected_mcp_tools: [],
      backend_config: {},
      sub_agent_ids: []
    };
  }
  async chatCompletion(request) {
    console.log("[MiniMax] chatCompletion called with model:", request.model, "stream:", request.stream);
    this.model = request.model || "MiniMax-M2.7";
    this.created = unixTimestamp$1();
    const deviceInfo = await this.requestDeviceInfo();
    const messages = [...request.messages];
    let toolsPrompt = "";
    if (request.tools && request.tools.length > 0 && !hasToolPromptInjected(request.messages)) {
      toolsPrompt = toolsToSystemPrompt(request.tools);
      for (let i = messages.length - 1; i >= 0; i--) {
        if (messages[i].role === "user") {
          const currentContent = messages[i].content;
          if (typeof currentContent === "string") {
            messages[i] = { ...messages[i], content: currentContent + TOOL_WRAP_HINT };
          }
          break;
        }
      }
    }
    const requestBody = this.messagesPrepare(messages, toolsPrompt, false);
    let msgId = "";
    let chatId = request.chatId || "";
    if (chatId) {
      console.log("[MiniMax] Using existing chat:", chatId);
      const sendResponse = await this.request("POST", "/matrix/api/v1/chat/send_msg", {
        ...requestBody,
        chat_id: chatId
      }, deviceInfo);
      if (sendResponse.status !== 200) {
        throw new Error(`MiniMax API error: HTTP ${sendResponse.status}`);
      }
      const { msg_id, base_resp } = sendResponse.data;
      if (base_resp?.status_code !== 0) {
        throw new Error(`Send message failed: ${base_resp?.status_msg || "Unknown error"}`);
      }
      msgId = msg_id;
    } else {
      const sendResponse = await this.request("POST", "/matrix/api/v1/chat/send_msg", requestBody, deviceInfo);
      console.log("[MiniMax] Send response status:", sendResponse.status);
      if (sendResponse.status !== 200) {
        console.error("[MiniMax] Error response:", JSON.stringify(sendResponse.data));
        throw new Error(`MiniMax API error: HTTP ${sendResponse.status} - ${JSON.stringify(sendResponse.data)}`);
      }
      const result = sendResponse.data;
      const base_resp = result.base_resp;
      if (base_resp?.status_code !== 0) {
        throw new Error(`Send message failed: ${base_resp?.status_msg || "Unknown error"}`);
      }
      chatId = result.chat_id;
      msgId = result.msg_id;
      console.log("[MiniMax] Message sent, chat_id:", chatId, "msg_id:", msgId);
    }
    if (request.stream === true) {
      const shouldDeleteSession22 = () => {
        const config = global.storeManager?.getConfig();
        return config?.mode === "single" && config?.deleteAfterTimeout;
      };
      const onEnd = shouldDeleteSession22() ? async (chatId2) => {
        await this.deleteChat(chatId2);
      } : void 0;
      const transStream = this.createPollingStream(chatId, deviceInfo, this.model, onEnd);
      return {
        response: null,
        stream: { session: null, stream: transStream },
        chatId
      };
    }
    const aiMessage = await this.pollForResponse(chatId, deviceInfo);
    const shouldDeleteSession2 = () => {
      const config = global.storeManager?.getConfig();
      return config?.mode === "single" && config?.deleteAfterTimeout;
    };
    if (shouldDeleteSession2()) {
      await this.deleteChat(chatId).catch((err) => console.error("[MiniMax] Failed to delete chat:", err));
    }
    const content = aiMessage?.msg_content || "";
    const thinkingContent = aiMessage?.extra_info?.thinking_content || "";
    const { content: cleanContent, toolCalls } = parseToolCallsFromText(content, "minimax");
    const response = {
      status: 200,
      statusText: "OK",
      headers: {},
      config: {},
      data: {
        id: String(chatId),
        model: this.model,
        object: "chat.completion",
        choices: [{
          index: 0,
          message: {
            role: "assistant",
            content: toolCalls.length > 0 ? null : cleanContent,
            ...thinkingContent ? { reasoning_content: thinkingContent } : {},
            ...toolCalls.length > 0 ? { tool_calls: toolCalls } : {}
          },
          finish_reason: toolCalls.length > 0 ? "tool_calls" : "stop"
        }],
        usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
        created: this.created
      }
    };
    return { response, stream: null, chatId };
  }
  async pollForResponse(chatId, deviceInfo, maxPolls = 120, pollInterval = 1e3) {
    let pollCount = 0;
    while (pollCount < maxPolls) {
      await new Promise((resolve) => setTimeout(resolve, pollInterval));
      pollCount++;
      const detailResponse = await this.request("POST", "/matrix/api/v1/chat/get_chat_detail", { chat_id: chatId }, deviceInfo);
      if (detailResponse.status !== 200) {
        console.log("[MiniMax] Poll failed, status:", detailResponse.status);
        continue;
      }
      const { messages, base_resp } = detailResponse.data;
      if (base_resp?.status_code !== 0) {
        console.log("[MiniMax] Poll failed, status_code:", base_resp?.status_code);
        continue;
      }
      const aiMessage = messages?.find((msg) => msg.msg_type === 2);
      if (aiMessage && aiMessage.msg_content) {
        console.log("[MiniMax] AI response received after", pollCount, "polls");
        return aiMessage;
      }
    }
    throw new Error(`No AI response after ${maxPolls} polls`);
  }
  createPollingStream(chatId, deviceInfo, model, onEnd) {
    const transStream = new stream.PassThrough();
    const created = this.created;
    let lastContent = "";
    let lastThinkingContent = "";
    let pollCount = 0;
    const maxPolls = 120;
    const pollInterval = 500;
    const toolCallState = createToolCallState();
    let sentRole = false;
    let sentThinkingRole = false;
    let lastMsgId = "";
    const poll = async () => {
      try {
        while (pollCount < maxPolls) {
          await new Promise((resolve) => setTimeout(resolve, pollInterval));
          pollCount++;
          const detailResponse = await this.request("POST", "/matrix/api/v1/chat/get_chat_detail", { chat_id: chatId }, deviceInfo);
          if (detailResponse.status !== 200) {
            console.log("[MiniMax] Poll status:", detailResponse.status);
            continue;
          }
          const { messages, chat, base_resp } = detailResponse.data;
          if (base_resp?.status_code !== 0) {
            console.log("[MiniMax] Poll base_resp:", base_resp);
            continue;
          }
          const chatStatus = chat?.chat_status || 0;
          console.log("[MiniMax] Poll #" + pollCount + " - chat_status:", chatStatus, "messages count:", messages?.length);
          if (messages && messages.length > 0) {
            console.log("[MiniMax] Message details:", messages.map((m) => ({
              msg_id: m.msg_id,
              msg_type: m.msg_type,
              content_len: m.msg_content?.length || 0,
              has_thinking: !!m.extra_info?.thinking_content,
              thinking_len: m.extra_info?.thinking_content?.length || 0
            })));
          }
          const aiMessages = messages?.filter((msg) => msg.msg_type === 2);
          const aiMessage = aiMessages?.length > 0 ? aiMessages[aiMessages.length - 1] : null;
          console.log("[MiniMax] AI messages count:", aiMessages?.length, "using last message");
          if (aiMessage && aiMessage.msg_content) {
            const currentContent = aiMessage.msg_content;
            const currentThinkingContent = aiMessage?.extra_info?.thinking_content || "";
            const currentMsgId = aiMessage.msg_id || "";
            if (currentMsgId !== lastMsgId && lastMsgId !== "") {
              console.log("[MiniMax] New AI message detected, msg_id changed from", lastMsgId, "to", currentMsgId);
              lastContent = "";
              lastThinkingContent = "";
            }
            console.log(
              "[MiniMax] AI message found - msg_id:",
              currentMsgId,
              "content_len:",
              currentContent.length,
              "thinking_len:",
              currentThinkingContent.length,
              "last_content_len:",
              lastContent.length,
              "last_thinking_len:",
              lastThinkingContent.length
            );
            if (currentThinkingContent && currentThinkingContent.length > lastThinkingContent.length) {
              const newThinkingChunk = currentThinkingContent.substring(lastThinkingContent.length);
              if (newThinkingChunk.trim()) {
                if (!sentThinkingRole) {
                  transStream.write(`data: ${JSON.stringify({
                    id: chatId.toString(),
                    model,
                    object: "chat.completion.chunk",
                    choices: [{ index: 0, delta: { role: "assistant" }, finish_reason: null }],
                    created
                  })}

`);
                  sentThinkingRole = true;
                }
                transStream.write(`data: ${JSON.stringify({
                  id: chatId.toString(),
                  model,
                  object: "chat.completion.chunk",
                  choices: [{ index: 0, delta: { reasoning_content: newThinkingChunk }, finish_reason: null }],
                  created
                })}

`);
              }
              lastThinkingContent = currentThinkingContent;
            }
            if (currentContent.length > lastContent.length) {
              const newChunk = currentContent.substring(lastContent.length);
              const baseChunk = createBaseChunk(chatId.toString(), model, created);
              const { chunks: outputChunks } = processStreamContent(
                newChunk,
                toolCallState,
                baseChunk,
                !sentRole,
                "minimax"
              );
              for (const outChunk of outputChunks) {
                transStream.write(`data: ${JSON.stringify(outChunk)}

`);
              }
              if (outputChunks.length > 0) sentRole = true;
              lastContent = currentContent;
            }
            lastMsgId = currentMsgId;
            if (chatStatus === 2 && aiMessage.msg_content) {
              console.log("[MiniMax] Stream completed - chat_status: 2, polls:", pollCount, "content length:", lastContent.length, "thinking length:", lastThinkingContent.length);
              const baseChunk = createBaseChunk(chatId.toString(), model, created);
              const flushChunks = flushToolCallBuffer(toolCallState, baseChunk, "minimax");
              for (const outChunk of flushChunks) {
                transStream.write(`data: ${JSON.stringify(outChunk)}

`);
              }
              const finishReason = toolCallState.hasEmittedToolCall ? "tool_calls" : "stop";
              transStream.write(
                `data: ${JSON.stringify({
                  id: chatId.toString(),
                  model,
                  object: "chat.completion.chunk",
                  choices: [{ index: 0, delta: {}, finish_reason: finishReason }],
                  created
                })}

`
              );
              transStream.end("data: [DONE]\n\n");
              if (onEnd) {
                onEnd(chatId).catch((err) => console.error("[MiniMax] Failed to delete chat:", err));
              }
              return;
            }
            lastMsgId = currentMsgId;
          }
        }
        console.log("[MiniMax] Stream timeout after", maxPolls, "polls");
        transStream.end("data: [DONE]\n\n");
      } catch (err) {
        console.error("[MiniMax] Polling error:", err);
        transStream.end("data: [DONE]\n\n");
      }
    };
    poll();
    return transStream;
  }
  async deleteChat(chatId) {
    const maxRetries = 3;
    const retryDelay = 2e3;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      try {
        const deviceInfo = await this.requestDeviceInfo();
        const response = await this.request("POST", "/matrix/api/v1/chat/delete_chat", { chat_id: parseInt(chatId, 10) }, deviceInfo);
        console.log("[MiniMax] Chat deleted attempt", attempt, ":", chatId, "Status:", response.status, "Response:", JSON.stringify(response.data));
        if (response.status === 200 && response.data?.base_resp?.status_code === 0) {
          return true;
        }
        const errorMsg = response.data?.base_resp?.status_msg || "Unknown error";
        if (errorMsg.includes("chat is running") && attempt < maxRetries) {
          console.log(`[MiniMax] Chat still running, waiting ${retryDelay}ms before retry...`);
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
          continue;
        }
        console.warn("[MiniMax] Delete chat failed:", errorMsg);
        return false;
      } catch (error) {
        console.error("[MiniMax] Failed to delete chat:", error);
        if (attempt < maxRetries) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
          continue;
        }
        return false;
      }
    }
    return false;
  }
  async getUserInfo() {
    const deviceInfo = await this.requestDeviceInfo();
    const response = await this.request("GET", "/v1/api/user/info", {}, deviceInfo);
    if (response.status !== 200 || response.data?.statusInfo?.code !== 0) {
      throw new Error(`Failed to get user info: ${response.data?.statusInfo?.message || response.status}`);
    }
    return response.data.data;
  }
  async getCredits() {
    try {
      const deviceInfo = await this.requestDeviceInfo();
      const response = await this.request("POST", "/matrix/api/v1/commerce/get_membership_info", {}, deviceInfo);
      console.log("[MiniMax] get_membership_info status:", response.status);
      if (response.status === 200 && response.data?.base_resp?.status_code === 0) {
        const data = response.data;
        const remainingCredits = data?.daily_login_gift_credit_remaining || 0;
        let expiresAt = void 0;
        const creditsData = data?.credits?.["4"]?.[0];
        if (creditsData?.expires_at) {
          expiresAt = creditsData.expires_at;
        }
        if (expiresAt) {
          console.log("[MiniMax] Credit expires at:", new Date(expiresAt).toISOString());
        }
        console.log("[MiniMax] Credits:", { remainingCredits, expiresAt: expiresAt ? new Date(expiresAt).toISOString() : void 0 });
        return {
          totalCredits: 0,
          // Not available
          usedCredits: 0,
          // Not available
          remainingCredits,
          expiresAt
        };
      }
      console.warn("[MiniMax] Failed to get membership info, token may be expired or invalid");
      return { totalCredits: 0, usedCredits: 0, remainingCredits: 0 };
    } catch (error) {
      console.error("[MiniMax] Failed to get credits:", error instanceof Error ? error.message : "Unknown error");
      return { totalCredits: 0, usedCredits: 0, remainingCredits: 0 };
    }
  }
  async getChatList() {
    const allChats = [];
    let nextPageIndexId = void 0;
    const pageSize = 100;
    try {
      const deviceInfo = await this.requestDeviceInfo();
      while (true) {
        const requestBody = {
          page_size: pageSize,
          workspace_storage_mode: 0
        };
        if (nextPageIndexId !== void 0) {
          requestBody.next_page_index_id = nextPageIndexId;
        }
        const response = await this.request("POST", "/matrix/api/v1/chat/list_chat", requestBody, deviceInfo);
        console.log("[MiniMax] list_chat response status:", response.status);
        if (response.status !== 200 || response.data?.base_resp?.status_code !== 0) {
          console.error("[MiniMax] Failed to get chat list:", response.data?.base_resp?.status_msg);
          break;
        }
        const chatList = response.data?.chats || response.data?.chat_list || [];
        console.log("[MiniMax] Received chats count:", chatList.length);
        if (chatList.length === 0) {
          break;
        }
        allChats.push(...chatList);
        if (chatList.length < pageSize) {
          break;
        }
        nextPageIndexId = chatList[chatList.length - 1]?.chat_id;
      }
      console.log("[MiniMax] Got chat list, total:", allChats.length);
      return allChats;
    } catch (error) {
      console.error("[MiniMax] Failed to get chat list:", error);
      return [];
    }
  }
  async deleteAllChats() {
    try {
      console.log("[MiniMax] Starting to delete all chats...");
      const chatList = await this.getChatList();
      if (chatList.length === 0) {
        console.log("[MiniMax] No chats to delete");
        return true;
      }
      console.log("[MiniMax] Found", chatList.length, "chats to delete");
      let successCount = 0;
      let failCount = 0;
      for (const chat of chatList) {
        const result = await this.deleteChat(String(chat.chat_id));
        if (result) {
          successCount++;
        } else {
          failCount++;
        }
        if (successCount % 10 === 0) {
          console.log(`[MiniMax] Deleted ${successCount}/${chatList.length} chats...`);
        }
      }
      console.log(`[MiniMax] Delete all chats completed. Success: ${successCount}, Failed: ${failCount}`);
      return failCount === 0;
    } catch (error) {
      console.error("[MiniMax] Failed to delete all chats:", error);
      return false;
    }
  }
  static isMiniMaxProvider(provider) {
    return provider.id === "minimax" || provider.apiEndpoint.includes("minimaxi.com") || provider.apiEndpoint.includes("hailuoai.com");
  }
};
const PERPLEXITY_URL = "https://www.perplexity.ai";
const QUERY_ENDPOINT = `${PERPLEXITY_URL}/rest/sse/perplexity_ask`;
const FAKE_HEADERS$5 = {
  "Accept": "text/event-stream",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "en-US,en;q=0.9",
  "Cache-Control": "no-cache",
  "Origin": PERPLEXITY_URL,
  "Sec-Ch-Ua": '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36"
};
const sessionCache = /* @__PURE__ */ new Map();
function uuid() {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
function extractQuery(messages) {
  let systemPrompt = "";
  for (const msg of messages) {
    if (msg.role === "system") {
      const content = msg.content;
      if (typeof content === "string") {
        systemPrompt = content;
      } else if (Array.isArray(content)) {
        const texts = content.filter((item) => item.type === "text").map((item) => item.text);
        systemPrompt = texts.join("\n");
      }
      break;
    }
  }
  const conversationParts = [];
  for (const msg of messages) {
    if (msg.role === "system") continue;
    let content = "";
    if (typeof msg.content === "string") {
      content = msg.content;
    } else if (Array.isArray(msg.content)) {
      const texts = msg.content.filter((item) => item.type === "text").map((item) => item.text);
      content = texts.join("\n");
    }
    if (content) {
      const roleLabel = msg.role === "user" ? "User" : "Assistant";
      conversationParts.push(`[${roleLabel}]: ${content}`);
    }
  }
  const conversationHistory = conversationParts.join("\n\n");
  if (systemPrompt && conversationHistory) {
    return `${systemPrompt}

---

${conversationHistory}`;
  }
  return conversationHistory || systemPrompt;
}
function mapModel(model) {
  const directMappings = {
    "Auto": "turbo",
    "Turbo": "turbo",
    "PPLX-Pro": "pplx_pro",
    "GPT-5": "gpt5",
    "Gemini-2.5-Pro": "gemini25pro",
    "Claude-Sonnet-4": "claude4sonnet",
    "Claude-Opus-4": "claude4opus",
    "Nemotron": "nemotron"
  };
  if (directMappings[model]) {
    return directMappings[model];
  }
  const modelLower = model.toLowerCase();
  const legacyMappings = {
    "gpt-5": "gpt5",
    "gemini-2.5-pro": "gemini25pro",
    "claude-sonnet-4": "claude4sonnet",
    "claude-opus-4": "claude4opus",
    "nemotron": "nemotron"
  };
  if (legacyMappings[modelLower]) {
    return legacyMappings[modelLower];
  }
  if (modelLower.includes("turbo")) return "turbo";
  if (modelLower.includes("gpt5") || modelLower.includes("gpt-5")) return "gpt5";
  if (modelLower.includes("pplx")) return "pplx_pro";
  if (modelLower.includes("gemini")) return "gemini25pro";
  if (modelLower.includes("claude")) {
    if (modelLower.includes("opus")) return "claude4opus";
    if (modelLower.includes("sonnet")) return "claude4sonnet";
    return "claude4sonnet";
  }
  if (modelLower.includes("nemotron")) return "nemotron";
  return "turbo";
}
let PerplexityAdapter$1 = class PerplexityAdapter {
  constructor(provider, account) {
    this.provider = provider;
    this.account = account;
    this.cookie = account.credentials.sessionToken || account.credentials.cookie || account.credentials.token || "";
    this.allCookies = account.credentials.cookies || {};
    if (this.cookie && !this.allCookies["__Secure-next-auth.session-token"]) {
      this.allCookies["__Secure-next-auth.session-token"] = this.cookie;
    }
  }
  buildCookieHeader() {
    const cookieParts = [];
    for (const [name, value] of Object.entries(this.allCookies)) {
      cookieParts.push(`${name}=${value}`);
    }
    if (this.cookie && !this.allCookies["__Secure-next-auth.session-token"]) {
      cookieParts.push(`__Secure-next-auth.session-token=${this.cookie}`);
    }
    return cookieParts.join("; ");
  }
  formatNetworkError(error) {
    const errorMsg = error.message || String(error);
    if (errorMsg.includes("ERR_CONNECTION_RESET") || errorMsg.includes("net::ERR_CONNECTION_RESET")) {
      return "Network connection reset. Please check your network connection and try again.";
    }
    if (errorMsg.includes("ERR_CONNECTION_REFUSED") || errorMsg.includes("net::ERR_CONNECTION_REFUSED")) {
      return "Connection refused. The server may be temporarily unavailable.";
    }
    if (errorMsg.includes("ERR_CONNECTION_TIMED_OUT") || errorMsg.includes("net::ERR_CONNECTION_TIMED_OUT")) {
      return "Connection timed out. Please check your network and try again.";
    }
    if (errorMsg.includes("ERR_SSL") || errorMsg.includes("SSL")) {
      return "SSL/TLS handshake failed. Please check your network security settings.";
    }
    if (errorMsg.includes("ERR_NAME_NOT_RESOLVED") || errorMsg.includes("net::ERR_NAME_NOT_RESOLVED")) {
      return "DNS resolution failed. Please check your network connection.";
    }
    if (errorMsg.includes("ERR_NETWORK_CHANGED") || errorMsg.includes("net::ERR_NETWORK_CHANGED")) {
      return "Network changed during request. Please try again.";
    }
    if (errorMsg.includes("ERR_INTERNET_DISCONNECTED") || errorMsg.includes("net::ERR_INTERNET_DISCONNECTED")) {
      return "No internet connection. Please check your network settings.";
    }
    return `Network error: ${errorMsg}. Please check your connection and try again.`;
  }
  buildRequestData(query, model) {
    const frontendUuid = uuid();
    const frontendContextUuid = uuid();
    const baseParams = {
      attachments: [],
      language: "en-US",
      timezone: "America/Los_Angeles",
      search_focus: "internet",
      sources: ["web"],
      search_recency_filter: null,
      frontend_uuid: frontendUuid,
      mode: "copilot",
      model_preference: model,
      is_related_query: false,
      is_sponsored: false,
      frontend_context_uuid: frontendContextUuid,
      prompt_source: "user",
      query_source: "home",
      is_incognito: false,
      time_from_first_type: 18361,
      local_search_enabled: false,
      use_schematized_api: true,
      send_back_text_in_streaming_api: false,
      supported_block_use_cases: [
        "answer_modes",
        "media_items",
        "knowledge_cards",
        "inline_entity_cards",
        "place_widgets",
        "finance_widgets",
        "prediction_market_widgets",
        "sports_widgets",
        "flight_status_widgets",
        "news_widgets",
        "shopping_widgets",
        "jobs_widgets",
        "search_result_widgets",
        "inline_images",
        "inline_assets",
        "placeholder_cards",
        "diff_blocks",
        "inline_knowledge_cards",
        "entity_group_v2",
        "refinement_filters",
        "canvas_mode",
        "maps_preview",
        "answer_tabs",
        "price_comparison_widgets",
        "preserve_latex",
        "generic_onboarding_widgets",
        "in_context_suggestions",
        "inline_claims"
      ],
      client_coordinates: null,
      mentions: [],
      dsl_query: query,
      skip_search_enabled: true,
      is_nav_suggestions_disabled: false,
      source: "default",
      always_search_override: false,
      override_no_search: false,
      should_ask_for_mcp_tool_confirmation: true,
      browser_agent_allow_once_from_toggle: false,
      force_enable_browser_agent: false,
      supported_features: ["browser_agent_permission_banner_v1.1"],
      version: "2.18"
    };
    return {
      params: baseParams,
      query_str: query
    };
  }
  async chatCompletion(request) {
    const query = extractQuery(request.messages);
    if (!query) {
      throw new Error("No user message found in request");
    }
    const model = mapModel(request.model);
    const requestId2 = uuid();
    const referer = `${PERPLEXITY_URL}/`;
    const headers = {
      ...FAKE_HEADERS$5,
      "Content-Type": "application/json",
      "Cookie": `__Secure-next-auth.session-token=${this.cookie}`,
      "x-perplexity-request-reason": "perplexity-query-state-provider",
      "x-request-id": requestId2,
      "Referer": referer
    };
    const data = this.buildRequestData(query, model);
    const response = await axios.post(QUERY_ENDPOINT, data, {
      headers,
      responseType: "stream",
      timeout: 12e4,
      validateStatus: () => true
    });
    if (response.status === 403) {
      throw new Error("Cloudflare challenge detected");
    }
    if (response.status === 429) {
      throw new Error("Rate limit exceeded");
    }
    if (response.status >= 400) {
      const errorBody = await this.readErrorBody(response.data);
      throw new Error(`HTTP ${response.status}: ${errorBody.substring(0, 200)}`);
    }
    return { stream: response.data, sessionId: requestId2 };
  }
  async readErrorBody(stream2) {
    const chunks = [];
    return new Promise((resolve) => {
      stream2.on("data", (chunk) => {
        chunks.push(Buffer.from(chunk));
      });
      stream2.on("end", () => {
        resolve(Buffer.concat(chunks).toString("utf8"));
      });
      stream2.on("error", () => {
        resolve("");
      });
    });
  }
  updateSessionData(data) {
    const cacheKey = this.account.id;
    const existing = sessionCache.get(cacheKey);
    const newData = {
      backend_uuid: data.backend_uuid || existing?.backend_uuid || "",
      read_write_token: data.read_write_token || existing?.read_write_token || "",
      thread_url_slug: data.thread_url_slug || existing?.thread_url_slug || "",
      frontend_context_uuid: data.frontend_context_uuid || existing?.frontend_context_uuid || uuid(),
      frontend_uuid: data.frontend_uuid || existing?.frontend_uuid || uuid(),
      createdAt: existing?.createdAt || Date.now()
    };
    sessionCache.set(cacheKey, newData);
  }
  async deleteSession(sessionId) {
    const cacheKey = this.account.id;
    const sessionData = sessionCache.get(cacheKey);
    if (!sessionData?.backend_uuid) {
      sessionCache.delete(cacheKey);
      return true;
    }
    try {
      const deleteUrl = `${PERPLEXITY_URL}/rest/thread/delete_thread_by_entry_uuid?version=2.18&source=default`;
      const headers = {
        "Accept": "*/*",
        "Accept-Encoding": "gzip, deflate, br, zstd",
        "Accept-Language": "en-US,en;q=0.9",
        "Content-Type": "application/json",
        "Cookie": this.buildCookieHeader(),
        "Origin": PERPLEXITY_URL,
        "Referer": `${PERPLEXITY_URL}/`,
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
        "sec-ch-ua": '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"macOS"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "x-app-apiclient": "default",
        "x-app-apiversion": "2.18",
        "x-perplexity-request-endpoint": deleteUrl,
        "x-perplexity-request-reason": "home-sidebar",
        "x-perplexity-request-try-number": "1"
      };
      const requestBody = {
        entry_uuid: sessionData.backend_uuid,
        read_write_token: sessionData.read_write_token || ""
      };
      const response = await axios.delete(deleteUrl, {
        headers,
        data: requestBody,
        timeout: 3e4,
        validateStatus: () => true
      });
      sessionCache.delete(cacheKey);
      return response.status >= 200 && response.status < 300;
    } catch (error) {
      console.error("[Perplexity] Delete session error:", error);
      sessionCache.delete(cacheKey);
      return false;
    }
  }
  async deleteAllChats() {
    const deleteUrl = `${PERPLEXITY_URL}/rest/thread/delete_all_threads?version=2.18&source=default`;
    const headers = {
      "Accept": "*/*",
      "Accept-Encoding": "gzip, deflate, br, zstd",
      "Accept-Language": "en-US,en;q=0.9",
      "Content-Type": "application/json",
      "Cookie": this.buildCookieHeader(),
      "Origin": PERPLEXITY_URL,
      "Referer": `${PERPLEXITY_URL}/library`,
      "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
      "sec-ch-ua": '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
      "sec-ch-ua-mobile": "?0",
      "sec-ch-ua-platform": '"macOS"',
      "sec-fetch-dest": "empty",
      "sec-fetch-mode": "cors",
      "sec-fetch-site": "same-origin",
      "x-app-apiclient": "default",
      "x-app-apiversion": "2.18",
      "x-perplexity-request-endpoint": deleteUrl,
      "x-perplexity-request-reason": "threads-list",
      "x-perplexity-request-try-number": "1"
    };
    try {
      const response = await axios.delete(deleteUrl, {
        headers,
        data: { delete_all: true },
        timeout: 3e4,
        validateStatus: () => true
      });
      if (response.status >= 200 && response.status < 300 && response.data?.status === "success") {
        sessionCache.delete(this.account.id);
        return true;
      }
      return false;
    } catch (error) {
      console.error("[Perplexity] Delete all chats error:", error);
      return false;
    }
  }
  static isPerplexityProvider(provider) {
    return provider.id === "perplexity" || provider.apiEndpoint.includes("perplexity.ai");
  }
  static clearSessionCache(accountId) {
    sessionCache.delete(accountId);
  }
  static getSessionData(accountId) {
    return sessionCache.get(accountId);
  }
};
function filterCitations(content) {
  return content.replace(/\[(?:perplexity[+-])?\d+\]/g, "");
}
class PerplexityStreamHandler {
  constructor(model, sessionId, onEnd, adapter) {
    this.isFirstChunk = true;
    this.sessionTokens = {};
    this.accumulatedContent = "";
    this.accumulatedReasoning = "";
    this.sources = [];
    this.model = model;
    this.sessionId = sessionId;
    this.created = Math.floor(Date.now() / 1e3);
    this.onEnd = onEnd;
    this.toolCallState = createToolCallState();
    this.adapter = adapter;
  }
  getSessionTokens() {
    return this.sessionTokens;
  }
  formatStreamError(errorMsg) {
    if (errorMsg.includes("ERR_CONNECTION_RESET") || errorMsg.includes("net::ERR_CONNECTION_RESET")) {
      return "Network connection reset during streaming. Please check your network connection and try again.";
    }
    if (errorMsg.includes("ERR_CONNECTION_REFUSED") || errorMsg.includes("net::ERR_CONNECTION_REFUSED")) {
      return "Connection refused during streaming. The server may be temporarily unavailable.";
    }
    if (errorMsg.includes("ERR_CONNECTION_TIMED_OUT") || errorMsg.includes("net::ERR_CONNECTION_TIMED_OUT")) {
      return "Connection timed out during streaming. Please check your network and try again.";
    }
    if (errorMsg.includes("ERR_SSL") || errorMsg.includes("SSL")) {
      return "SSL/TLS handshake failed during streaming. Please check your network security settings.";
    }
    if (errorMsg.includes("ERR_NETWORK_CHANGED") || errorMsg.includes("net::ERR_NETWORK_CHANGED")) {
      return "Network changed during streaming. Please try again.";
    }
    return `Stream error: ${errorMsg}`;
  }
  parseSSE(data) {
    try {
      return JSON.parse(data);
    } catch {
      return null;
    }
  }
  createChunk(delta, finishReason) {
    return `data: ${JSON.stringify({
      id: this.sessionId,
      model: this.model,
      object: "chat.completion.chunk",
      choices: [{
        index: 0,
        delta,
        finish_reason: finishReason || null
      }],
      created: this.created
    })}

`;
  }
  async handleStream(stream$1) {
    const transStream = new stream.PassThrough();
    let buffer = "";
    let doneCalled = false;
    stream$1.on("data", (chunk) => {
      const chunkStr = chunk.toString();
      buffer += chunkStr;
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";
      for (const line of lines) {
        if (!line.trim()) continue;
        if (line.startsWith("event:")) continue;
        if (line.startsWith("data:")) {
          const data = line.slice(5).trim();
          if (data === "[DONE]") {
            if (!doneCalled) {
              doneCalled = true;
              this.handleDone(transStream);
            }
            return;
          }
          const parsed = this.parseSSE(data);
          if (!parsed) continue;
          this.processEvent(parsed, transStream);
        }
      }
    });
    stream$1.on("end", () => {
      if (buffer.trim()) ;
      if (!doneCalled) {
        doneCalled = true;
        this.handleDone(transStream);
      }
    });
    stream$1.on("error", (err) => {
      console.error("[Perplexity Stream] Stream error:", err);
      const errorMessage = err.message || String(err);
      const userFriendlyError = this.formatStreamError(errorMessage);
      transStream.emit("error", new Error(userFriendlyError));
    });
    return transStream;
  }
  processEvent(event, transStream) {
    if (event.backend_uuid) {
      this.sessionTokens.backend_uuid = event.backend_uuid;
      if (this.adapter) {
        this.adapter.updateSessionData({ backend_uuid: event.backend_uuid });
      }
    }
    if (event.read_write_token && !this.sessionTokens.read_write_token) {
      this.sessionTokens.read_write_token = event.read_write_token;
      if (this.adapter) {
        this.adapter.updateSessionData({ read_write_token: event.read_write_token });
      }
    }
    if (event.thread_url_slug && !this.sessionTokens.thread_url_slug) {
      this.sessionTokens.thread_url_slug = event.thread_url_slug;
      if (this.adapter) {
        this.adapter.updateSessionData({ thread_url_slug: event.thread_url_slug });
      }
    }
    if (event.blocks) {
      for (const block of event.blocks) {
        this.processBlock(block, transStream);
      }
    }
  }
  processBlock(block, transStream) {
    if (block.intended_usage === "sources_answer_mode") {
      this.sources = block.sources_mode_block?.web_results || [];
      return;
    }
    if (block.intended_usage === "media_items") {
      return;
    }
    if (!block.diff_block?.patches) return;
    const field = block.diff_block.field;
    const isMarkdownBlock = field === "markdown_block";
    for (const patch of block.diff_block.patches) {
      const path2 = patch.path || "";
      if (path2 === "/progress") continue;
      let value = patch.value;
      if (!value) continue;
      if (typeof value === "object" && "chunks" in value) {
        value = value.chunks?.join("") || "";
      }
      if (path2.startsWith("/goals")) {
        this.handleReasoning(value, transStream);
        continue;
      }
      if (!isMarkdownBlock) continue;
      if (typeof value === "object" && "answer" in value) {
        value = value.answer || "";
      }
      if (typeof value === "string" && value) {
        this.handleContent(value, transStream);
      }
    }
  }
  handleReasoning(value, transStream) {
    let content = "";
    if (typeof value === "string") {
      content = value;
    } else if (typeof value === "object" && value !== null) {
      return;
    }
    if (!content) return;
    if (content.startsWith(this.accumulatedReasoning)) {
      content = content.slice(this.accumulatedReasoning.length);
    }
    if (!content) return;
    this.accumulatedReasoning += content;
    const delta = {};
    if (this.isFirstChunk) {
      delta.role = "assistant";
      this.isFirstChunk = false;
    }
    delta.reasoning_content = content;
    transStream.write(this.createChunk(delta));
  }
  handleContent(content, transStream) {
    if (content.startsWith(this.accumulatedContent)) {
      content = content.slice(this.accumulatedContent.length);
    } else if (this.accumulatedContent.endsWith(content)) {
      return;
    }
    if (!content) return;
    this.accumulatedContent += content;
    const filteredContent = filterCitations(content);
    if (!filteredContent) return;
    const baseChunk = createBaseChunk(this.sessionId, this.model, this.created);
    const { chunks, shouldFlush } = processStreamContent(
      filteredContent,
      this.toolCallState,
      baseChunk,
      this.isFirstChunk,
      "perplexity"
    );
    for (const chunk of chunks) {
      transStream.write(`data: ${JSON.stringify(chunk)}

`);
      this.isFirstChunk = false;
    }
    if (this.toolCallState.isBufferingToolCall || this.toolCallState.hasEmittedToolCall) {
      return;
    }
    if (chunks.length > 0) {
      return;
    }
    const delta = {};
    if (this.isFirstChunk) {
      delta.role = "assistant";
      this.isFirstChunk = false;
    }
    delta.content = content;
    transStream.write(this.createChunk(delta));
  }
  handleDone(transStream) {
    const baseChunk = createBaseChunk(this.sessionId, this.model, this.created);
    const flushChunks = flushToolCallBuffer(this.toolCallState, baseChunk, "perplexity");
    for (const outChunk of flushChunks) {
      transStream.write(`data: ${JSON.stringify(outChunk)}

`);
    }
    if (this.sources.length > 0) {
      const citations = this.sources.filter((r) => r.cite_index).sort((a, b) => a.cite_index - b.cite_index).map((r) => `[${r.cite_index}]: [${r.title}](${r.url})`).join("\n");
      if (citations) {
        transStream.write(this.createChunk({ content: `

${citations}` }));
      }
    }
    const finishReason = this.toolCallState.hasEmittedToolCall ? "tool_calls" : "stop";
    transStream.write(this.createChunk({}, finishReason));
    transStream.write("data: [DONE]\n\n");
    transStream.end();
    this.onEnd?.();
  }
  async handleNonStream(stream2) {
    return new Promise((resolve, reject) => {
      let buffer = "";
      stream2.on("data", (chunk) => {
        buffer += chunk.toString();
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (!line.trim()) continue;
          if (line.startsWith("event:")) continue;
          if (line.startsWith("data:")) {
            const data = line.slice(5).trim();
            if (data === "[DONE]") return;
            try {
              const parsed = JSON.parse(data);
              this.processEventForNonStream(parsed);
            } catch {
            }
          }
        }
      });
      stream2.on("end", () => {
        const filteredAccumulatedContent = filterCitations(this.accumulatedContent);
        const { content: cleanContent, toolCalls } = parseToolCallsFromText(filteredAccumulatedContent);
        const message = {
          role: "assistant"
        };
        if (this.accumulatedReasoning) {
          message.reasoning_content = filterCitations(this.accumulatedReasoning.trim());
        }
        message.content = toolCalls.length > 0 ? null : cleanContent.trim();
        if (toolCalls.length > 0) {
          message.tool_calls = toolCalls;
        }
        resolve({
          id: this.sessionId,
          model: this.model,
          object: "chat.completion",
          choices: [{
            index: 0,
            message,
            finish_reason: toolCalls.length > 0 ? "tool_calls" : "stop"
          }],
          usage: { prompt_tokens: 1, completion_tokens: 1, total_tokens: 2 },
          created: this.created
        });
      });
      stream2.on("error", (err) => {
        const errorMessage = err.message || String(err);
        const userFriendlyError = this.formatStreamError(errorMessage);
        reject(new Error(userFriendlyError));
      });
    });
  }
  processEventForNonStream(event) {
    if (event.backend_uuid) {
      this.sessionTokens.backend_uuid = event.backend_uuid;
      if (this.adapter) {
        this.adapter.updateSessionData({ backend_uuid: event.backend_uuid });
      }
    }
    if (event.read_write_token && !this.sessionTokens.read_write_token) {
      this.sessionTokens.read_write_token = event.read_write_token;
      if (this.adapter) {
        this.adapter.updateSessionData({ read_write_token: event.read_write_token });
      }
    }
    if (event.thread_url_slug && !this.sessionTokens.thread_url_slug) {
      this.sessionTokens.thread_url_slug = event.thread_url_slug;
      if (this.adapter) {
        this.adapter.updateSessionData({ thread_url_slug: event.thread_url_slug });
      }
    }
    if (event.blocks) {
      for (const block of event.blocks) {
        this.processBlockForNonStream(block);
      }
    }
  }
  processBlockForNonStream(block) {
    if (block.intended_usage === "sources_answer_mode") {
      this.sources = block.sources_mode_block?.web_results || [];
      return;
    }
    if (!block.diff_block?.patches) return;
    const field = block.diff_block.field;
    const isMarkdownBlock = field === "markdown_block";
    for (const patch of block.diff_block.patches) {
      const path2 = patch.path || "";
      if (path2 === "/progress") continue;
      let value = patch.value;
      if (!value) continue;
      if (typeof value === "object" && "chunks" in value) {
        value = value.chunks?.join("") || "";
      }
      if (path2.startsWith("/goals")) {
        if (typeof value === "string") {
          if (value.startsWith(this.accumulatedReasoning)) {
            value = value.slice(this.accumulatedReasoning.length);
          }
          if (value) {
            this.accumulatedReasoning += value;
          }
        }
        continue;
      }
      if (!isMarkdownBlock) continue;
      if (typeof value === "object" && "answer" in value) {
        value = value.answer || "";
      }
      if (typeof value === "string" && value) {
        if (value.startsWith(this.accumulatedContent)) {
          value = value.slice(this.accumulatedContent.length);
        } else if (this.accumulatedContent.endsWith(value)) {
          continue;
        }
        if (value) {
          this.accumulatedContent += value;
        }
      }
    }
  }
}
function normalizeOpenAiTools(tools, source) {
  return (tools ?? []).filter((tool) => tool.type === "function" && Boolean(tool.function?.name)).map((tool) => ({
    name: tool.function.name,
    description: tool.function.description,
    parameters: tool.function.parameters ?? {},
    source
  }));
}
function normalizeToolChoice(request, toolNames2) {
  const choice = request.tool_choice;
  if (choice === "none") return { mode: "none" };
  if (choice === "required") return { mode: "required" };
  if (choice && typeof choice === "object" && choice.type === "function") {
    return { mode: "forced", forcedName: choice.function.name };
  }
  if (toolNames2.size === 1) return { mode: "auto" };
  return { mode: "auto" };
}
const standardOpenAiToolsAdapter = {
  id: "standard-openai-tools",
  displayName: "Standard OpenAI Tools",
  normalizeRequest(request) {
    const tools = normalizeOpenAiTools(request.tools, "openai");
    const toolChoice = normalizeToolChoice(request, new Set(tools.map((tool) => tool.name)));
    return {
      clientAdapterId: "standard-openai-tools",
      toolSource: tools.length > 0 ? "openai" : "none",
      tools,
      toolChoice,
      diagnostics: {
        rawToolCount: request.tools?.length ?? 0,
        normalizedToolNames: tools.map((tool) => tool.name)
      }
    };
  }
};
const cherryStudioMcpAdapter = {
  id: "cherry-studio-mcp",
  displayName: "Cherry Studio MCP",
  normalizeRequest(request) {
    const tools = normalizeOpenAiTools(request.tools, "mcp");
    const toolChoice = normalizeToolChoice(request, new Set(tools.map((tool) => tool.name)));
    return {
      clientAdapterId: "cherry-studio-mcp",
      toolSource: tools.length > 0 ? "mcp" : "none",
      tools,
      toolChoice,
      diagnostics: {
        rawToolCount: request.tools?.length ?? 0,
        normalizedToolNames: tools.map((tool) => tool.name)
      }
    };
  }
};
const adapters = /* @__PURE__ */ new Map([
  [standardOpenAiToolsAdapter.id, standardOpenAiToolsAdapter],
  [cherryStudioMcpAdapter.id, cherryStudioMcpAdapter]
]);
function getToolClientAdapter(clientAdapterId) {
  const adapter = adapters.get(clientAdapterId);
  if (adapter) return adapter;
  return {
    ...standardOpenAiToolsAdapter,
    normalizeRequest(request) {
      const result = standardOpenAiToolsAdapter.normalizeRequest(request);
      return {
        ...result,
        diagnostics: {
          ...result.diagnostics,
          requestedClientAdapterId: clientAdapterId,
          fallbackClientAdapterId: standardOpenAiToolsAdapter.id
        }
      };
    }
  };
}
function buildToolCallingRuntimePlan(input) {
  const profile = getProviderToolProfile(input.providerId);
  const tools = input.clientRequest.tools;
  const toolNames2 = new Set(tools.map((tool) => tool.name));
  const forcedName = input.clientRequest.toolChoice.forcedName;
  if (input.clientRequest.toolChoice.mode === "forced" && forcedName && !toolNames2.has(forcedName)) {
    throw new Error(`Forced tool ${forcedName} is not declared`);
  }
  const allowedToolNames = forcedName ? /* @__PURE__ */ new Set([forcedName]) : toolNames2;
  const allowedTools = forcedName ? tools.filter((tool) => tool.name === forcedName) : tools;
  const disabledReason = getDisabledReason(
    input.config,
    allowedTools.length,
    input.clientRequest.toolChoice.mode,
    profile.managedSupport
  );
  const mode = disabledReason ? "disabled" : "managed";
  const protocol = profile.preferredManagedProtocol;
  const shouldInjectPrompt = mode === "managed";
  const shouldParseResponse = mode === "managed";
  return {
    mode,
    protocol,
    clientAdapterId: input.clientRequest.clientAdapterId,
    providerId: input.providerId,
    tools: allowedTools,
    shouldInjectPrompt,
    shouldParseResponse,
    toolChoiceMode: input.clientRequest.toolChoice.mode,
    allowedToolNames,
    forcedToolName: forcedName,
    diagnostics: {
      requestId: input.requestId,
      clientAdapterId: input.clientRequest.clientAdapterId,
      providerId: input.providerId,
      model: input.model,
      actualModel: input.actualModel,
      toolSource: input.clientRequest.toolSource,
      mode,
      protocol,
      toolCount: allowedTools.length,
      injected: shouldInjectPrompt,
      reason: disabledReason ?? `managed_${input.config.mode}`,
      toolChoiceMode: input.clientRequest.toolChoice.mode,
      forcedToolName: forcedName,
      allowedToolNames: [...allowedToolNames]
    }
  };
}
function getDisabledReason(config, toolCount, toolChoiceMode, managedSupport) {
  if (!config.enabled || config.mode === "off") return "mode_off";
  if (toolChoiceMode === "none") return "tool_choice_none";
  if (toolCount === 0) return "no_tools";
  if (!managedSupport && config.mode === "auto") return "provider_not_supported";
  return void 0;
}
class ToolCallingEngine {
  constructor(config = {}) {
    this.config = server_bootstrapConfig.normalizeToolCallingConfig({
      ...server_bootstrapConfig.DEFAULT_TOOL_CALLING_CONFIG,
      ...config,
      advanced: {
        ...server_bootstrapConfig.DEFAULT_TOOL_CALLING_CONFIG.advanced,
        ...config.advanced
      }
    });
  }
  transformRequest(input) {
    const { request, provider, actualModel, requestId: requestId2 } = input;
    const adapter = getToolClientAdapter(this.config.clientAdapterId);
    const clientRequest = adapter.normalizeRequest(request);
    const plan = buildToolCallingRuntimePlan({
      requestId: requestId2,
      providerId: provider.id,
      actualModel,
      model: request.model,
      config: this.config,
      clientRequest
    });
    const shouldInjectPrompt = plan.shouldInjectPrompt;
    if (!shouldInjectPrompt) {
      return {
        messages: request.messages,
        tools: plan.mode === "disabled" ? request.tools : void 0,
        plan
      };
    }
    return {
      messages: injectPrompt(request.messages, renderPrompt(plan.protocol, plan.tools, this.config)),
      tools: void 0,
      plan
    };
  }
  applyNonStreamResponse(result, plan) {
    if (!plan.shouldParseResponse) return;
    const message = result?.choices?.[0]?.message;
    if (!message || typeof message.content !== "string") return;
    const parseResult = parseSelectedProtocol(message.content, plan);
    plan.diagnostics.parserFormat = parseResult.protocol;
    plan.diagnostics.parsedToolCallCount = parseResult.toolCalls.length;
    plan.diagnostics.invalidToolNames = parseResult.invalidToolNames;
    plan.diagnostics.malformedReason = parseResult.malformedReason;
    if (parseResult.toolCalls.length === 0) return;
    message.content = parseResult.content || null;
    message.tool_calls = parseResult.toolCalls;
    const choice = result.choices[0];
    choice.finish_reason = "tool_calls";
  }
}
function renderPrompt(protocol, tools, config) {
  const prompt = getToolProtocol(protocol).renderPrompt(tools);
  const customPromptTemplate = config.diagnosticsEnabled ? config.advanced.customPromptTemplate : void 0;
  if (!customPromptTemplate) return prompt;
  return customPromptTemplate.replace(/\{\{tools\}\}/g, prompt).replace(/\{\{tool_names\}\}/g, tools.map((tool) => tool.name).join(", ")).replace(/\{\{format\}\}/g, protocol);
}
function injectPrompt(messages, prompt) {
  const [first, ...rest] = messages;
  if (first?.role === "system" && typeof first.content === "string") {
    return [{ ...first, content: `${first.content}

${prompt}` }, ...rest];
  }
  return [{ role: "system", content: prompt }, ...messages];
}
function parseSelectedProtocol(content, plan) {
  const selected = getToolProtocol(plan.protocol);
  return selected.parse(content, { tools: plan.tools, protocol: plan.protocol });
}
class SessionManagerClass {
  constructor() {
    this.cleanupInterval = null;
  }
  initialize() {
    this.startCleanupScheduler();
    console.log("[SessionManager] Initialized");
  }
  destroy() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
    console.log("[SessionManager] Destroyed");
  }
  startCleanupScheduler() {
    const CLEANUP_INTERVAL_MS = 60 * 1e3;
    this.cleanupInterval = setInterval(() => {
      this.cleanExpiredSessions();
    }, CLEANUP_INTERVAL_MS);
    console.log("[SessionManager] Cleanup scheduler started, interval: 1 minute");
  }
  getSessionConfig() {
    return server_bootstrapConfig.storeManager.getSessionConfig();
  }
  updateSessionConfig(updates) {
    const newConfig = server_bootstrapConfig.storeManager.updateSessionConfig(updates);
    console.log("[SessionManager] Session config updated:", newConfig);
    return newConfig;
  }
  getOrCreateSession(options) {
    const { providerId, accountId, model } = options;
    const existingSession = this.getActiveSession(providerId, accountId);
    if (existingSession) {
      return {
        sessionId: existingSession.id,
        providerSessionId: void 0,
        parentMessageId: void 0,
        messages: existingSession.messages,
        isNew: false
      };
    }
    const newSession = this.createSession({
      providerId,
      accountId,
      model
    });
    return {
      sessionId: newSession.id,
      providerSessionId: void 0,
      parentMessageId: void 0,
      messages: newSession.messages,
      isNew: true
    };
  }
  getActiveSession(providerId, accountId) {
    const sessions = server_bootstrapConfig.storeManager.getSessionsByProviderId(providerId);
    const accountSessions = sessions.filter((s) => s.accountId === accountId);
    const config = this.getSessionConfig();
    const timeoutMs = config.sessionTimeout * 60 * 1e3;
    const now = Date.now();
    return accountSessions.find(
      (s) => s.status === "active" && now - s.lastActiveAt < timeoutMs
    );
  }
  createSession(options) {
    const { providerId, accountId, model, sessionType = "chat" } = options;
    const now = Date.now();
    const session = {
      id: this.generateSessionId(),
      providerId,
      accountId,
      sessionType,
      messages: [],
      createdAt: now,
      lastActiveAt: now,
      status: "active",
      model
    };
    server_bootstrapConfig.storeManager.addSession(session);
    return session;
  }
  getSession(sessionId) {
    return server_bootstrapConfig.storeManager.getSessionById(sessionId);
  }
  getAllActiveSessions() {
    return server_bootstrapConfig.storeManager.getActiveSessions();
  }
  getAllSessions() {
    return server_bootstrapConfig.storeManager.getSessions();
  }
  deleteSession(sessionId) {
    const result = server_bootstrapConfig.storeManager.deleteSession(sessionId);
    if (result) {
      console.log("[SessionManager] Deleted session:", sessionId);
    }
    return result;
  }
  cleanExpiredSessions() {
    const removedCount = server_bootstrapConfig.storeManager.cleanExpiredSessions();
    if (removedCount > 0) {
      console.log("[SessionManager] Cleaned expired sessions:", removedCount);
    }
    return removedCount;
  }
  clearAllSessions() {
    server_bootstrapConfig.storeManager.clearAllSessions();
    console.log("[SessionManager] Cleared all sessions");
  }
  getSessionsByAccount(accountId) {
    return server_bootstrapConfig.storeManager.getSessionsByAccountId(accountId);
  }
  getSessionsByProvider(providerId) {
    return server_bootstrapConfig.storeManager.getSessionsByProviderId(providerId);
  }
  shouldDeleteAfterChat() {
    const config = this.getSessionConfig();
    return config.deleteAfterTimeout;
  }
  generateSessionId() {
    return `session-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
  }
}
const sessionManager = new SessionManagerClass();
const DEFAULT_SLIDING_WINDOW_CONFIG = {
  enabled: true,
  maxMessages: 20
};
const DEFAULT_TOKEN_LIMIT_CONFIG = {
  enabled: false,
  maxTokens: 4e3
};
const DEFAULT_SUMMARY_CONFIG = {
  enabled: false,
  keepRecentMessages: 20,
  summaryPrompt: "Please summarize the following conversation concisely, keeping key information and context:"
};
const DEFAULT_CONTEXT_MANAGEMENT_CONFIG = {
  enabled: false,
  strategies: {
    slidingWindow: DEFAULT_SLIDING_WINDOW_CONFIG,
    tokenLimit: DEFAULT_TOKEN_LIMIT_CONFIG,
    summary: DEFAULT_SUMMARY_CONFIG
  },
  executionOrder: ["slidingWindow", "tokenLimit", "summary"]
};
function estimateTokens(content) {
  if (content === null || content === void 0) {
    return 0;
  }
  if (typeof content === "string") {
    return Math.ceil(content.length / 3);
  }
  if (Array.isArray(content)) {
    return content.reduce((total, part) => {
      if (part.type === "text" && part.text) {
        return total + Math.ceil(part.text.length / 3);
      }
      return total;
    }, 0);
  }
  return 0;
}
class SlidingWindowStrategy {
  constructor(config = DEFAULT_SLIDING_WINDOW_CONFIG) {
    this.config = { ...DEFAULT_SLIDING_WINDOW_CONFIG, ...config };
  }
  execute(messages) {
    const originalCount = messages.length;
    if (!this.config.enabled || originalCount <= this.config.maxMessages) {
      return {
        messages,
        originalCount,
        processedCount: originalCount,
        strategyName: "slidingWindow",
        trimmed: false
      };
    }
    const systemMessages = messages.filter((msg) => msg.role === "system");
    const nonSystemMessages = messages.filter((msg) => msg.role !== "system");
    const maxNonSystemMessages = this.config.maxMessages - systemMessages.length;
    const keptNonSystemMessages = nonSystemMessages.slice(-maxNonSystemMessages);
    const result = [...systemMessages, ...keptNonSystemMessages];
    console.log(
      `[SlidingWindowStrategy] Trimmed from ${originalCount} to ${result.length} messages (system: ${systemMessages.length}, non-system: ${keptNonSystemMessages.length})`
    );
    return {
      messages: result,
      originalCount,
      processedCount: result.length,
      strategyName: "slidingWindow",
      trimmed: result.length < originalCount
    };
  }
}
class TokenLimitStrategy {
  constructor(config = DEFAULT_TOKEN_LIMIT_CONFIG) {
    this.config = { ...DEFAULT_TOKEN_LIMIT_CONFIG, ...config };
  }
  execute(messages) {
    const originalCount = messages.length;
    if (!this.config.enabled) {
      return {
        messages,
        originalCount,
        processedCount: originalCount,
        strategyName: "tokenLimit",
        trimmed: false
      };
    }
    const systemMessages = messages.filter((msg) => msg.role === "system");
    const nonSystemMessages = messages.filter((msg) => msg.role !== "system");
    const systemTokens = systemMessages.reduce(
      (total, msg) => total + estimateTokens(msg.content),
      0
    );
    const availableTokens = this.config.maxTokens - systemTokens;
    if (availableTokens <= 0) {
      console.warn(
        `[TokenLimitStrategy] System messages already exceed token limit (${systemTokens} > ${this.config.maxTokens})`
      );
      return {
        messages: systemMessages,
        originalCount,
        processedCount: systemMessages.length,
        strategyName: "tokenLimit",
        trimmed: true
      };
    }
    const keptNonSystemMessages = [];
    let currentTokens = 0;
    for (let i = nonSystemMessages.length - 1; i >= 0; i--) {
      const msg = nonSystemMessages[i];
      const msgTokens = estimateTokens(msg.content);
      if (currentTokens + msgTokens <= availableTokens) {
        keptNonSystemMessages.unshift(msg);
        currentTokens += msgTokens;
      } else {
        break;
      }
    }
    const result = [...systemMessages, ...keptNonSystemMessages];
    const totalTokens = systemTokens + currentTokens;
    console.log(
      `[TokenLimitStrategy] Trimmed from ${originalCount} to ${result.length} messages (tokens: ${totalTokens}/${this.config.maxTokens})`
    );
    return {
      messages: result,
      originalCount,
      processedCount: result.length,
      strategyName: "tokenLimit",
      trimmed: result.length < originalCount
    };
  }
}
class SummaryStrategy {
  constructor(config = DEFAULT_SUMMARY_CONFIG, summaryGenerator) {
    this.config = { ...DEFAULT_SUMMARY_CONFIG, ...config };
    this.summaryGenerator = summaryGenerator;
  }
  async execute(messages) {
    const originalCount = messages.length;
    if (!this.config.enabled) {
      return {
        messages,
        originalCount,
        processedCount: originalCount,
        strategyName: "summary",
        trimmed: false
      };
    }
    if (originalCount <= this.config.keepRecentMessages) {
      return {
        messages,
        originalCount,
        processedCount: originalCount,
        strategyName: "summary",
        trimmed: false
      };
    }
    if (!this.summaryGenerator) {
      console.warn("[SummaryStrategy] No summary generator provided, falling back to sliding window");
      const fallbackMessages = messages.slice(-this.config.keepRecentMessages);
      return {
        messages: fallbackMessages,
        originalCount,
        processedCount: fallbackMessages.length,
        strategyName: "summary",
        trimmed: true
      };
    }
    const systemMessages = messages.filter((msg) => msg.role === "system");
    const nonSystemMessages = messages.filter((msg) => msg.role !== "system");
    const recentMessages = nonSystemMessages.slice(-this.config.keepRecentMessages);
    const oldMessages = nonSystemMessages.slice(0, -this.config.keepRecentMessages);
    if (oldMessages.length === 0) {
      return {
        messages,
        originalCount,
        processedCount: originalCount,
        strategyName: "summary",
        trimmed: false
      };
    }
    try {
      console.log(
        `[SummaryStrategy] Generating summary for ${oldMessages.length} old messages`
      );
      const summary = await this.summaryGenerator(
        oldMessages,
        this.config.summaryPrompt
      );
      const summaryMessage = {
        role: "system",
        content: `[Conversation Summary]
${summary}`
      };
      const result = [...systemMessages, summaryMessage, ...recentMessages];
      console.log(
        `[SummaryStrategy] Compressed from ${originalCount} to ${result.length} messages (summary generated for ${oldMessages.length} messages)`
      );
      return {
        messages: result,
        originalCount,
        processedCount: result.length,
        strategyName: "summary",
        trimmed: true
      };
    } catch (error) {
      console.error("[SummaryStrategy] Failed to generate summary:", error);
      const fallbackMessages = [...systemMessages, ...recentMessages];
      return {
        messages: fallbackMessages,
        originalCount,
        processedCount: fallbackMessages.length,
        strategyName: "summary",
        trimmed: true
      };
    }
  }
}
class ContextManagementService {
  constructor(config = DEFAULT_CONTEXT_MANAGEMENT_CONFIG, summaryGenerator) {
    this.config = { ...DEFAULT_CONTEXT_MANAGEMENT_CONFIG, ...config };
    this.slidingWindowStrategy = new SlidingWindowStrategy(
      this.config.strategies.slidingWindow
    );
    this.tokenLimitStrategy = new TokenLimitStrategy(
      this.config.strategies.tokenLimit
    );
    this.summaryStrategy = new SummaryStrategy(
      this.config.strategies.summary,
      summaryGenerator
    );
  }
  /**
   * Update configuration
   */
  updateConfig(config) {
    this.config = {
      ...this.config,
      ...config,
      strategies: {
        ...this.config.strategies,
        ...config.strategies || {}
      }
    };
    this.slidingWindowStrategy = new SlidingWindowStrategy(
      this.config.strategies.slidingWindow
    );
    this.tokenLimitStrategy = new TokenLimitStrategy(
      this.config.strategies.tokenLimit
    );
    this.summaryStrategy = new SummaryStrategy(
      this.config.strategies.summary,
      this.summaryStrategy["summaryGenerator"]
    );
  }
  /**
   * Process messages through all enabled strategies
   */
  async process(messages) {
    const originalCount = messages.length;
    const strategyResults = [];
    if (!this.config.enabled) {
      return {
        messages,
        originalCount,
        finalCount: originalCount,
        strategyResults: [],
        summaryGenerated: false
      };
    }
    console.log(
      `[ContextManagementService] Processing ${originalCount} messages with order: ${this.config.executionOrder.join(", ")}`
    );
    let currentMessages = [...messages];
    let summaryGenerated = false;
    for (const strategyName of this.config.executionOrder) {
      let result;
      switch (strategyName) {
        case "slidingWindow":
          result = this.slidingWindowStrategy.execute(currentMessages);
          break;
        case "tokenLimit":
          result = this.tokenLimitStrategy.execute(currentMessages);
          break;
        case "summary":
          result = await this.summaryStrategy.execute(currentMessages);
          if (result.trimmed) {
            summaryGenerated = true;
          }
          break;
        default:
          console.warn(`[ContextManagementService] Unknown strategy: ${strategyName}`);
          continue;
      }
      strategyResults.push(result);
      currentMessages = result.messages;
      if (result.trimmed) {
        console.log(
          `[ContextManagementService] Strategy ${strategyName} trimmed ${result.originalCount} -> ${result.processedCount} messages`
        );
      }
    }
    console.log(
      `[ContextManagementService] Final result: ${originalCount} -> ${currentMessages.length} messages`
    );
    return {
      messages: currentMessages,
      originalCount,
      finalCount: currentMessages.length,
      strategyResults,
      summaryGenerated
    };
  }
  /**
   * Get current configuration
   */
  getConfig() {
    return { ...this.config };
  }
  /**
   * Estimate total tokens for messages
   */
  static estimateTotalTokens(messages) {
    return messages.reduce((total, msg) => total + estimateTokens(msg.content), 0);
  }
}
function createContextManagementService(config, summaryGenerator) {
  const finalConfig = {
    ...DEFAULT_CONTEXT_MANAGEMENT_CONFIG,
    ...config,
    strategies: {
      ...DEFAULT_CONTEXT_MANAGEMENT_CONFIG.strategies,
      ...config?.strategies || {}
    }
  };
  return new ContextManagementService(finalConfig, summaryGenerator);
}
function shouldDeleteSession() {
  return sessionManager.shouldDeleteAfterChat();
}
function statusFromError(error) {
  const maybeStatus = error?.status;
  if (typeof maybeStatus === "number") {
    return maybeStatus;
  }
  const maybeStatusCode = error?.statusCode;
  if (typeof maybeStatusCode === "number") {
    return maybeStatusCode;
  }
  return void 0;
}
class RequestForwarder {
  constructor() {
    this.axiosInstance = axios.create({
      timeout: 12e4,
      maxBodyLength: Infinity,
      maxContentLength: Infinity
    });
    this.providerForwarders = [
      {
        name: "deepseek",
        matches: DeepSeekAdapter$1.isDeepSeekProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardDeepSeek(request, account, provider, actualModel, startTime)
      },
      {
        name: "glm",
        matches: GLMAdapter$1.isGLMProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardGLM(request, account, provider, actualModel, startTime)
      },
      {
        name: "kimi",
        matches: KimiAdapter$1.isKimiProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardKimi(request, account, provider, actualModel, startTime)
      },
      {
        name: "qwen",
        matches: QwenAdapter$1.isQwenProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardQwen(request, account, provider, actualModel, startTime)
      },
      {
        name: "qwen-ai",
        matches: QwenAiAdapter$1.isQwenAiProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardQwenAi(request, account, provider, actualModel, startTime)
      },
      {
        name: "zai",
        matches: ZaiAdapter$1.isZaiProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardZai(request, account, provider, actualModel, startTime)
      },
      {
        name: "minimax",
        matches: MiniMaxAdapter$1.isMiniMaxProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardMiniMax(request, account, provider, actualModel, startTime)
      },
      {
        name: "mimo",
        matches: MimoAdapter$1.isMimoProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardMimo(request, account, provider, actualModel, startTime)
      },
      {
        name: "perplexity",
        matches: PerplexityAdapter$1.isPerplexityProvider,
        forward: (request, account, provider, actualModel, startTime) => this.forwardPerplexity(request, account, provider, actualModel, startTime)
      }
    ];
  }
  /**
   * Transform request for prompt-based tool calling
   * For models that don't support native function calling
   * Delegates tool normalization, prompt injection, and parser planning to ToolCallingEngine.
   */
  transformRequestForPromptToolUse(request, provider) {
    const config = server_bootstrapConfig.storeManager.getConfig().toolCallingConfig;
    const engine = new ToolCallingEngine(config);
    return engine.transformRequest({
      request,
      provider: provider ?? {
        id: "custom",
        name: "Custom",
        type: "custom",
        authType: "token",
        apiEndpoint: "",
        headers: {},
        enabled: true,
        createdAt: 0,
        updatedAt: 0
      },
      actualModel: request.model
    });
  }
  applyToolCallsToResponse(result, transformed) {
    const engine = new ToolCallingEngine(server_bootstrapConfig.storeManager.getConfig().toolCallingConfig);
    engine.applyNonStreamResponse(result, transformed.plan);
  }
  /**
   * Create summary generator function for context management
   * Uses the current provider and account to generate summaries
   */
  createSummaryGenerator(account, provider, actualModel, context) {
    return async (messages, prompt) => {
      try {
        console.log("[SummaryGenerator] Generating summary for", messages.length, "messages");
        const summaryPrompt = prompt || "Please summarize the following conversation concisely, keeping key information and context:";
        const conversationText = messages.map((msg) => {
          const role = msg.role.toUpperCase();
          const content = typeof msg.content === "string" ? msg.content : Array.isArray(msg.content) ? msg.content.filter((part) => part.type === "text" && part.text).map((part) => part.text).join("\n") : "";
          return `${role}: ${content}`;
        }).join("\n\n");
        const summaryRequest = {
          model: actualModel,
          messages: [
            {
              role: "system",
              content: summaryPrompt
            },
            {
              role: "user",
              content: conversationText
            }
          ],
          stream: false,
          temperature: 0.3
        };
        const result = await this.doForward(
          summaryRequest,
          account,
          provider,
          actualModel,
          context
        );
        if (result.success && result.body) {
          const summaryContent = result.body.choices?.[0]?.message?.content || "";
          console.log("[SummaryGenerator] Summary generated successfully, length:", summaryContent.length);
          return summaryContent;
        }
        console.warn("[SummaryGenerator] Failed to generate summary:", result.error);
        return "Failed to generate conversation summary.";
      } catch (error) {
        console.error("[SummaryGenerator] Error generating summary:", error);
        return "Failed to generate conversation summary due to an error.";
      }
    };
  }
  /**
   * Forward Chat Completions Request
   */
  async forwardChatCompletion(request, account, provider, actualModel, context) {
    const startTime = Date.now();
    const config = server_bootstrapConfig.storeManager.getConfig();
    const maxRetries = config.retryCount;
    let lastError;
    let lastStatus;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      if (attempt > 0) {
        await this.delay(5e3);
      }
      let modifiedRequest = request;
      if (config.contextManagement?.enabled && modifiedRequest.messages && modifiedRequest.messages.length > 0) {
        try {
          const summaryGenerator = this.createSummaryGenerator(
            account,
            provider,
            actualModel,
            context
          );
          const contextService = createContextManagementService(
            config.contextManagement || {},
            summaryGenerator
          );
          const originalCount = modifiedRequest.messages.length;
          const contextMessages = modifiedRequest.messages.map((msg) => ({
            role: msg.role,
            content: msg.content,
            timestamp: Date.now()
          }));
          const processResult = await contextService.process(contextMessages);
          if (processResult.finalCount !== originalCount) {
            console.log(
              `[Forwarder] Context management applied: ${originalCount} -> ${processResult.finalCount} messages`
            );
            processResult.strategyResults.forEach((result) => {
              if (result.trimmed) {
                console.log(
                  `[Forwarder] Strategy ${result.strategyName}: ${result.originalCount} -> ${result.processedCount} messages`
                );
              }
            });
            modifiedRequest = {
              ...modifiedRequest,
              messages: processResult.messages.map((msg) => ({
                role: msg.role,
                content: msg.content
              }))
            };
          }
        } catch (error) {
          console.error("[Forwarder] Context management failed:", error);
        }
      }
      try {
        const result = await this.doForward(modifiedRequest, account, provider, actualModel, context);
        if (result.success) {
          return result;
        }
        lastError = result.error;
        lastStatus = result.status;
        if (result.status && result.status < 500 && result.status !== 429) {
          break;
        }
      } catch (error) {
        lastError = error instanceof Error ? error.message : "Unknown error";
        lastStatus = statusFromError(error);
      }
    }
    return {
      success: false,
      status: lastStatus,
      error: lastError || "Request failed after retries",
      latency: Date.now() - startTime
    };
  }
  /**
   * Execute Forward
   */
  async doForward(request, account, provider, actualModel, context) {
    const startTime = Date.now();
    const dedicatedForwarder = this.providerForwarders.find((forwarder) => forwarder.matches(provider));
    if (dedicatedForwarder) {
      return dedicatedForwarder.forward(request, account, provider, actualModel, startTime);
    }
    try {
      const chatPath = provider.chatPath || "/chat/completions";
      const url = this.buildUrl(provider, chatPath);
      const headers = this.buildHeaders(provider, account);
      const body = this.buildRequestBody(request, actualModel, account);
      const axiosConfig = {
        method: "POST",
        url,
        headers,
        data: body,
        timeout: proxyStatusManager.getConfig().timeout,
        responseType: request.stream ? "stream" : "json",
        validateStatus: () => true
      };
      const response = await this.axiosInstance.request(axiosConfig);
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        return {
          success: false,
          status: response.status,
          error: this.extractErrorMessage(response),
          latency
        };
      }
      if (request.stream) {
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: response.data,
          latency
        };
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: response.data,
        latency
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      if (error instanceof axios.AxiosError) {
        return {
          success: false,
          status: error.response?.status,
          error: error.message,
          latency
        };
      }
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * DeepSeek Dedicated Forward
   */
  async forwardDeepSeek(request, account, provider, actualModel, startTime) {
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const transformedRequest = {
        ...request,
        messages: transformed.messages,
        tools: transformed.tools
      };
      const adapter = new DeepSeekAdapter$1(provider, account);
      const { response, sessionId } = await adapter.chatCompletion({
        model: request.model,
        messages: transformedRequest.messages,
        stream: transformedRequest.stream,
        temperature: transformedRequest.temperature,
        web_search: transformedRequest.web_search,
        reasoning_effort: transformedRequest.reasoning_effort
      });
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        let errorMessage = `HTTP ${response.status}`;
        if (response.data) {
          if (typeof response.data === "string") {
            errorMessage = response.data;
          } else if (response.data.msg) {
            errorMessage = response.data.msg;
          } else if (response.data.error?.message) {
            errorMessage = response.data.error.message;
          }
        }
        return {
          success: false,
          status: response.status,
          error: errorMessage,
          latency
        };
      }
      const deleteSessionCallback = shouldDeleteSession() ? async () => {
        try {
          await adapter.deleteSession(sessionId);
        } catch (error) {
          console.error("[DeepSeek] Failed to delete session:", error);
        }
      } : void 0;
      const handler = new DeepSeekStreamHandler(
        actualModel,
        sessionId,
        deleteSessionCallback,
        transformedRequest.web_search,
        transformedRequest.reasoning_effort,
        transformed.plan,
        request.model
      );
      if (request.stream) {
        const transformedStream = await handler.handleStream(response.data);
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: transformedStream,
          skipTransform: true,
          latency,
          providerSessionId: sessionId
        };
      }
      const result = await handler.handleNonStream(response.data);
      this.applyToolCallsToResponse(result, transformed);
      if (deleteSessionCallback) {
        await deleteSessionCallback();
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: result,
        latency,
        providerSessionId: sessionId
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        status: statusFromError(error),
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * GLM Dedicated Forward
   */
  async forwardGLM(request, account, provider, actualModel, startTime) {
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const transformedRequest = {
        ...request,
        messages: transformed.messages,
        tools: transformed.tools
      };
      const adapter = new GLMAdapter$1(provider, account);
      const { response, conversationId } = await adapter.chatCompletion({
        model: actualModel,
        originalModel: request.model,
        messages: transformedRequest.messages,
        stream: transformedRequest.stream,
        temperature: transformedRequest.temperature,
        web_search: transformedRequest.web_search,
        reasoning_effort: transformedRequest.reasoning_effort,
        deep_research: transformedRequest.deep_research
      });
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        let errorMessage = `HTTP ${response.status}`;
        if (response.data) {
          if (typeof response.data === "string") {
            errorMessage = response.data;
          } else if (response.data.msg) {
            errorMessage = response.data.msg;
          } else if (response.data.message) {
            errorMessage = response.data.message;
          } else if (response.data.error?.message) {
            errorMessage = response.data.error.message;
          }
        }
        return {
          success: false,
          status: response.status,
          error: errorMessage,
          latency
        };
      }
      const handler = new GLMStreamHandler(actualModel, void 0, void 0, transformed.plan);
      if (request.stream) {
        const transformedStream = await handler.handleStream(response.data);
        if (shouldDeleteSession()) {
          const originalEnd = transformedStream.end.bind(transformedStream);
          transformedStream.end = function(chunk, encoding, callback) {
            const convId = handler.getConversationId();
            if (convId) {
              adapter.deleteConversation(convId).catch((err) => {
                console.error("[GLM] Failed to delete session:", err);
              });
            }
            return originalEnd(chunk, encoding, callback);
          };
        }
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: transformedStream,
          skipTransform: true,
          latency,
          providerSessionId: handler.getConversationId()
        };
      }
      const result = await handler.handleNonStream(response.data);
      this.applyToolCallsToResponse(result, transformed);
      if (shouldDeleteSession()) {
        const convId = handler.getConversationId();
        if (convId) {
          await adapter.deleteConversation(convId);
        }
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: result,
        latency,
        providerSessionId: handler.getConversationId() ?? void 0
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        status: statusFromError(error),
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  async forwardKimi(request, account, provider, actualModel, startTime) {
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const adapter = new KimiAdapter$1(provider, account);
      const { response, conversationId } = await adapter.chatCompletion({
        model: actualModel,
        originalModel: request.model,
        messages: transformed.messages,
        stream: request.stream,
        temperature: request.temperature,
        enableThinking: !!request.reasoning_effort,
        enableWebSearch: !!request.web_search
      });
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        let errorMessage = `HTTP ${response.status}`;
        return {
          success: false,
          status: response.status,
          error: errorMessage,
          latency
        };
      }
      const handler = new KimiStreamHandler(actualModel, conversationId, !!request.reasoning_effort, transformed.plan);
      if (request.stream) {
        const transformedStream = await handler.handleStream(response.data);
        if (shouldDeleteSession()) {
          const originalEnd = transformedStream.end.bind(transformedStream);
          transformedStream.end = function(chunk, encoding, callback) {
            const realChatId = handler.getConversationId();
            if (realChatId) {
              adapter.deleteConversation(realChatId).catch((err) => {
                console.error("[Kimi] Failed to delete conversation:", err);
              });
            }
            return originalEnd(chunk, encoding, callback);
          };
        }
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: transformedStream,
          skipTransform: true,
          latency,
          providerSessionId: void 0
        };
      }
      const result = await handler.handleNonStream(response.data);
      this.applyToolCallsToResponse(result, transformed);
      if (shouldDeleteSession()) {
        const realChatId = handler.getConversationId();
        if (realChatId) {
          await adapter.deleteConversation(realChatId);
        }
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: result,
        latency,
        providerSessionId: handler.getConversationId() ?? void 0
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * Qwen Dedicated Forward
   */
  async forwardQwen(request, account, provider, actualModel, startTime) {
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const transformedRequest = {
        ...request,
        messages: transformed.messages,
        tools: transformed.tools
      };
      const adapter = new QwenAdapter$1(provider, account);
      const { response, sessionId, reqId } = await adapter.chatCompletion({
        model: actualModel,
        originalModel: request.model,
        messages: transformedRequest.messages,
        stream: request.stream,
        temperature: request.temperature,
        enableThinking: !!request.reasoning_effort,
        enableWebSearch: !!request.web_search
      });
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        let errorMessage = `HTTP ${response.status}`;
        return {
          success: false,
          status: response.status,
          error: errorMessage,
          latency
        };
      }
      const deleteSessionCallback = shouldDeleteSession() ? async (sid2) => {
        try {
          await adapter.deleteSession(sid2);
        } catch (err) {
          console.error("[Qwen] Failed to delete session:", err);
        }
      } : void 0;
      const handler = new QwenStreamHandler(actualModel, deleteSessionCallback, transformed.plan);
      if (request.stream) {
        const transformedStream = await handler.handleStream(response.data, response);
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: transformedStream,
          skipTransform: true,
          latency,
          providerSessionId: sessionId
        };
      }
      const result = await handler.handleNonStream(response.data, response);
      this.applyToolCallsToResponse(result, transformed);
      const sid = handler.getSessionId();
      if (deleteSessionCallback && sid) {
        await deleteSessionCallback(sid);
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: result,
        latency,
        providerSessionId: sessionId
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * Qwen AI (International) Dedicated Forward
   */
  async forwardQwenAi(request, account, provider, actualModel, startTime) {
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const adapter = new QwenAiAdapter$1(provider, account);
      const { response, chatId, parentId } = await adapter.chatCompletion({
        model: actualModel,
        originalModel: request.model,
        messages: transformed.messages,
        stream: request.stream,
        temperature: request.temperature,
        enable_thinking: !!request.reasoning_effort
      });
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        let errorMessage = `HTTP ${response.status}`;
        return {
          success: false,
          status: response.status,
          error: errorMessage,
          latency
        };
      }
      const handler = new QwenAiStreamHandler(actualModel);
      handler.setChatId(chatId);
      if (request.stream) {
        const transformedStream = await handler.handleStream(response.data);
        if (shouldDeleteSession()) {
          const originalEnd = transformedStream.end.bind(transformedStream);
          transformedStream.end = function(chunk, encoding, callback) {
            adapter.deleteChat(chatId).catch((err) => {
              console.error("[QwenAI] Failed to delete chat:", err);
            });
            return originalEnd(chunk, encoding, callback);
          };
        }
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: transformedStream,
          skipTransform: true,
          latency,
          providerSessionId: chatId
        };
      }
      const result = await handler.handleNonStream(response.data);
      this.applyToolCallsToResponse(result, transformed);
      if (shouldDeleteSession()) {
        await adapter.deleteChat(chatId);
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: result,
        latency,
        providerSessionId: chatId
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        status: statusFromError(error),
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * Z.ai Dedicated Forward
   */
  async forwardZai(request, account, provider, actualModel, startTime) {
    console.log("[forwardZai] actualModel:", actualModel);
    console.log("[forwardZai] provider.modelMappings:", provider.modelMappings);
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const adapter = new ZaiAdapter$1(provider, account);
      const { response, chatId, requestId: requestId2 } = await adapter.chatCompletion({
        model: actualModel,
        originalModel: request.model,
        messages: transformed.messages,
        stream: request.stream,
        temperature: request.temperature,
        web_search: request.web_search,
        reasoning_effort: request.reasoning_effort
      });
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        let errorMessage = `HTTP ${response.status}`;
        return {
          success: false,
          status: response.status,
          error: errorMessage,
          latency
        };
      }
      const deleteChatCallback = shouldDeleteSession() ? async (cid) => {
        try {
          await adapter.deleteChat(cid);
        } catch (error) {
          console.error("[Z.ai] Failed to delete chat:", error);
        }
      } : void 0;
      const handler = new ZaiStreamHandler(actualModel, deleteChatCallback);
      handler.setChatId(chatId);
      if (request.stream === true) {
        const transformedStream = await handler.handleStream(response.data);
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: transformedStream,
          skipTransform: true,
          latency,
          providerSessionId: chatId
        };
      }
      const result = await handler.handleNonStream(response.data);
      this.applyToolCallsToResponse(result, transformed);
      if (deleteChatCallback) {
        await deleteChatCallback(chatId);
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: result,
        latency,
        providerSessionId: chatId
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * MiniMax Dedicated Forward
   */
  async forwardMiniMax(request, account, provider, actualModel, startTime) {
    console.log("[forwardMiniMax] actualModel:", actualModel);
    console.log("[forwardMiniMax] provider.modelMappings:", provider.modelMappings);
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const adapter = new MiniMaxAdapter$1(provider, account);
      const { response, stream: stream2, chatId } = await adapter.chatCompletion({
        model: actualModel,
        originalModel: request.model,
        messages: transformed.messages,
        stream: request.stream,
        temperature: request.temperature
      });
      const latency = Date.now() - startTime;
      if (response && response.status >= 400) {
        let errorMessage = `HTTP ${response.status}`;
        return {
          success: false,
          status: response.status,
          error: errorMessage,
          latency
        };
      }
      const deleteChatCallback = shouldDeleteSession() ? async (cid) => {
        try {
          await adapter.deleteChat(cid);
        } catch (error) {
          console.error("[MiniMax] Failed to delete chat:", error);
        }
      } : void 0;
      if (request.stream === true && stream2) {
        console.log("[forwardMiniMax] Using polling stream");
        if (deleteChatCallback) {
          const originalStream = stream2.stream;
          const originalEnd = originalStream.end.bind(originalStream);
          originalStream.end = function(chunk, encoding, callback) {
            deleteChatCallback(chatId).catch((err) => {
              console.error("[MiniMax] Failed to delete chat:", err);
            });
            return originalEnd(chunk, encoding, callback);
          };
        }
        return {
          success: true,
          status: 200,
          headers: {},
          stream: stream2.stream,
          skipTransform: true,
          latency,
          providerSessionId: chatId
        };
      }
      if (response) {
        this.applyToolCallsToResponse(response.data, transformed);
        if (deleteChatCallback) {
          await deleteChatCallback(chatId);
        }
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          body: response.data,
          latency,
          providerSessionId: chatId
        };
      }
      return {
        success: false,
        error: "No response or stream received",
        latency
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * Mimo Dedicated Forward
   * Uses Mimo adapter for Xiaomi AI Studio
   */
  async forwardMimo(request, account, provider, actualModel, startTime) {
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const transformedRequest = {
        ...request,
        messages: transformed.messages,
        tools: transformed.tools
      };
      const adapter = new MimoAdapter$1(provider, account);
      const { response, conversationId, query } = await adapter.chatCompletion({
        model: actualModel,
        originalModel: request.originalModel,
        messages: transformedRequest.messages,
        stream: transformedRequest.stream,
        temperature: transformedRequest.temperature
      });
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        let errorMessage = `HTTP ${response.status}`;
        return {
          success: false,
          status: response.status,
          error: errorMessage,
          latency
        };
      }
      const deleteSessionCallback = shouldDeleteSession() ? async (sessionId) => {
        try {
          await adapter.deleteSession(sessionId);
        } catch (error) {
          console.error("[Mimo] Failed to delete session:", error);
        }
      } : void 0;
      const handler = new MimoStreamHandler(actualModel, conversationId, "separate", transformed.plan);
      if (request.stream) {
        const transformedStream = new stream.PassThrough();
        const openAIStream = handler.handleStream(response.data);
        (async () => {
          try {
            for await (const chunk of openAIStream) {
              transformedStream.write(chunk);
            }
            await adapter.generateConversationTitle(
              conversationId,
              query,
              handler.getAssistantContentForTitle()
            );
            if (deleteSessionCallback) {
              await deleteSessionCallback(conversationId);
            }
            transformedStream.end();
          } catch (error) {
            console.error("[Mimo] Stream error:", error);
            transformedStream.end();
          }
        })();
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: transformedStream,
          skipTransform: true,
          latency,
          providerSessionId: conversationId
        };
      }
      const result = await handler.handleNonStream(response.data);
      const parsedResult = JSON.parse(result);
      this.applyToolCallsToResponse(parsedResult, transformed);
      await adapter.generateConversationTitle(
        conversationId,
        query,
        handler.getAssistantContentForTitle()
      );
      if (deleteSessionCallback) {
        await deleteSessionCallback(conversationId);
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: parsedResult,
        skipTransform: true,
        latency,
        providerSessionId: conversationId
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      console.error("[Mimo] Forward error:", error);
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * Perplexity Dedicated Forward
   * Uses Electron's net API to bypass Cloudflare protection
   */
  async forwardPerplexity(request, account, provider, actualModel, startTime) {
    console.log("[forwardPerplexity] actualModel:", actualModel);
    try {
      const transformed = this.transformRequestForPromptToolUse(request, provider);
      const adapter = new PerplexityAdapter$1(provider, account);
      const { stream: stream2, sessionId } = await adapter.chatCompletion({
        model: actualModel,
        messages: transformed.messages,
        stream: request.stream,
        temperature: request.temperature
      });
      const latency = Date.now() - startTime;
      if (request.stream === true) {
        const deleteSessionCallback = shouldDeleteSession() ? async () => {
          try {
            await adapter.deleteSession(sessionId);
          } catch (error) {
            console.error("[Perplexity] Failed to delete session:", error);
          }
        } : void 0;
        const handler2 = new PerplexityStreamHandler(actualModel, sessionId, deleteSessionCallback, adapter);
        const transformedStream = await handler2.handleStream(stream2);
        return {
          success: true,
          status: 200,
          headers: {},
          stream: transformedStream,
          skipTransform: true,
          latency,
          providerSessionId: sessionId
        };
      }
      const handler = new PerplexityStreamHandler(actualModel, sessionId, void 0, adapter);
      const result = await handler.handleNonStream(stream2);
      this.applyToolCallsToResponse(result, transformed);
      if (shouldDeleteSession()) {
        await adapter.deleteSession(sessionId);
      }
      return {
        success: true,
        status: 200,
        headers: {},
        body: result,
        latency,
        providerSessionId: sessionId
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
  /**
   * Build URL
   */
  buildUrl(provider, path2) {
    let baseUrl = provider.apiEndpoint;
    if (baseUrl.endsWith("/")) {
      baseUrl = baseUrl.slice(0, -1);
    }
    if (!path2.startsWith("/")) {
      path2 = "/" + path2;
    }
    if (baseUrl.includes("/v1") && path2.startsWith("/v1")) {
      path2 = path2.slice(3);
    }
    return `${baseUrl}${path2}`;
  }
  /**
   * Build Request Headers
   */
  buildHeaders(provider, account) {
    const headers = {
      "Content-Type": "application/json",
      ...provider.headers
    };
    const credentials = account.credentials;
    if (credentials.token) {
      headers["Authorization"] = `Bearer ${credentials.token}`;
    } else if (credentials.apiKey) {
      headers["Authorization"] = `Bearer ${credentials.apiKey}`;
    } else if (credentials.accessToken) {
      headers["Authorization"] = `Bearer ${credentials.accessToken}`;
    } else if (credentials.refreshToken) {
      headers["Authorization"] = `Bearer ${credentials.refreshToken}`;
    }
    if (credentials.cookie) {
      headers["Cookie"] = credentials.cookie;
    }
    if (credentials.sessionKey) {
      headers["X-Session-Key"] = credentials.sessionKey;
    }
    return headers;
  }
  /**
   * Build Request Body
   */
  buildRequestBody(request, actualModel, account) {
    const body = {
      model: actualModel,
      messages: request.messages,
      stream: request.stream || false
    };
    if (request.temperature !== void 0) {
      body.temperature = request.temperature;
    }
    if (request.top_p !== void 0) {
      body.top_p = request.top_p;
    }
    if (request.n !== void 0) {
      body.n = request.n;
    }
    if (request.stop !== void 0) {
      body.stop = request.stop;
    }
    if (request.max_tokens !== void 0) {
      body.max_tokens = request.max_tokens;
    }
    if (request.presence_penalty !== void 0) {
      body.presence_penalty = request.presence_penalty;
    }
    if (request.frequency_penalty !== void 0) {
      body.frequency_penalty = request.frequency_penalty;
    }
    if (request.logit_bias !== void 0) {
      body.logit_bias = request.logit_bias;
    }
    if (request.user !== void 0) {
      body.user = request.user;
    }
    return body;
  }
  /**
   * Extract Response Headers
   */
  extractHeaders(headers) {
    const result = {};
    for (const [key, value] of Object.entries(headers)) {
      if (typeof value === "string") {
        result[key] = value;
      } else if (Array.isArray(value)) {
        result[key] = value.join(", ");
      }
    }
    return result;
  }
  /**
   * Extract Error Message
   */
  extractErrorMessage(response) {
    if (response.data) {
      if (typeof response.data === "string") {
        return response.data;
      }
      if (response.data.error?.message) {
        return response.data.error.message;
      }
      if (response.data.message) {
        return response.data.message;
      }
      if (response.data.msg) {
        return response.data.msg;
      }
      try {
        return JSON.stringify(response.data);
      } catch {
        return "Unknown error";
      }
    }
    return `HTTP ${response.status}`;
  }
  /**
   * Delay
   */
  delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  /**
   * Forward Request to Specified URL
   */
  async forwardToUrl(url, method, headers, body, isStream = false) {
    const startTime = Date.now();
    try {
      const config = {
        method,
        url,
        headers,
        data: body,
        timeout: proxyStatusManager.getConfig().timeout,
        responseType: isStream ? "stream" : "json",
        validateStatus: () => true
      };
      const response = await this.axiosInstance.request(config);
      const latency = Date.now() - startTime;
      if (response.status >= 400) {
        return {
          success: false,
          status: response.status,
          error: this.extractErrorMessage(response),
          latency
        };
      }
      if (isStream) {
        return {
          success: true,
          status: response.status,
          headers: this.extractHeaders(response.headers),
          stream: response.data,
          latency
        };
      }
      return {
        success: true,
        status: response.status,
        headers: this.extractHeaders(response.headers),
        body: response.data,
        latency
      };
    } catch (error) {
      const latency = Date.now() - startTime;
      return {
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
        latency
      };
    }
  }
}
const requestForwarder = new RequestForwarder();
class SSEParser {
  constructor() {
    this.buffer = "";
  }
  /**
   * Parse SSE data
   */
  parse(data) {
    this.buffer += data;
    const events = [];
    const lines = this.buffer.split("\n");
    this.buffer = lines.pop() || "";
    let currentEvent = {};
    for (const line of lines) {
      if (line === "") {
        if (currentEvent.data !== void 0) {
          events.push({
            event: currentEvent.event,
            data: currentEvent.data,
            id: currentEvent.id,
            retry: currentEvent.retry
          });
        }
        currentEvent = {};
        continue;
      }
      const colonIndex = line.indexOf(":");
      if (colonIndex === -1) {
        continue;
      }
      const field = line.slice(0, colonIndex);
      let value = line.slice(colonIndex + 1);
      if (value.startsWith(" ")) {
        value = value.slice(1);
      }
      switch (field) {
        case "event":
          currentEvent.event = value;
          break;
        case "data":
          currentEvent.data = (currentEvent.data || "") + value;
          break;
        case "id":
          currentEvent.id = value;
          break;
        case "retry":
          currentEvent.retry = parseInt(value, 10);
          break;
      }
    }
    return events;
  }
  /**
   * Reset parser
   */
  reset() {
    this.buffer = "";
  }
}
class SSEFormatter {
  /**
   * Format SSE event
   */
  format(event) {
    let result = "";
    if (event.id) {
      result += `id: ${event.id}
`;
    }
    if (event.event) {
      result += `event: ${event.event}
`;
    }
    if (event.retry !== void 0) {
      result += `retry: ${event.retry}
`;
    }
    result += `data: ${event.data}

`;
    return result;
  }
  /**
   * Format JSON data
   */
  formatJSON(data, event) {
    return this.format({
      event,
      data: JSON.stringify(data)
    });
  }
  /**
   * Format done marker
   */
  formatDone() {
    return "data: [DONE]\n\n";
  }
}
class StreamHandler {
  constructor() {
    this.parser = new SSEParser();
    this.formatter = new SSEFormatter();
  }
  /**
   * Create SSE transform stream
   * Converts upstream response to OpenAI compatible format
   */
  createTransformStream(model, responseId, onEnd) {
    let isFirstChunk = true;
    const created = Math.floor(Date.now() / 1e3);
    const parser = this.parser;
    const formatter = this.formatter;
    const transformChunk = this.transformChunk.bind(this);
    let contentBuffer = "";
    let isBufferingToolCall = false;
    let toolCallIndex = 0;
    return new stream.Transform({
      objectMode: true,
      transform(chunk, encoding, callback) {
        try {
          const events = parser.parse(chunk.toString());
          for (const event of events) {
            if (event.data === "[DONE]") {
              if (contentBuffer) {
                const finalData = transformChunk({ content: contentBuffer }, model, responseId, created, isFirstChunk);
                if (finalData) {
                  isFirstChunk = false;
                  this.push(formatter.formatJSON(finalData));
                }
                contentBuffer = "";
              }
              this.push(formatter.formatDone());
              continue;
            }
            let parsedData;
            try {
              parsedData = JSON.parse(event.data);
            } catch {
              this.push(formatter.format(event));
              continue;
            }
            const transformedData = transformChunk(parsedData, model, responseId, created, isFirstChunk);
            if (!transformedData) continue;
            const deltaContent = transformedData.choices[0].delta?.content || "";
            if (deltaContent) {
              contentBuffer += deltaContent;
              const marker = "[function_calls]";
              if (!isBufferingToolCall) {
                const markerIdx = contentBuffer.indexOf(marker);
                if (markerIdx !== -1) {
                  isBufferingToolCall = true;
                  if (markerIdx > 0) {
                    const textBefore = contentBuffer.substring(0, markerIdx);
                    const textData = {
                      ...transformedData,
                      choices: [{
                        index: 0,
                        delta: { content: textBefore },
                        finish_reason: null
                      }]
                    };
                    this.push(formatter.formatJSON(textData));
                  }
                  contentBuffer = contentBuffer.substring(markerIdx);
                } else {
                  for (let i = 0; i < contentBuffer.length; i++) {
                    if (contentBuffer[i] === "[") {
                      const potentialMarker = contentBuffer.substring(i);
                      if (marker.startsWith(potentialMarker)) {
                        isBufferingToolCall = true;
                        if (i > 0) {
                          const textBefore = contentBuffer.substring(0, i);
                          const textData = {
                            ...transformedData,
                            choices: [{
                              index: 0,
                              delta: { content: textBefore },
                              finish_reason: null
                            }]
                          };
                          this.push(formatter.formatJSON(textData));
                        }
                        contentBuffer = potentialMarker;
                        break;
                      }
                    }
                  }
                }
              }
              if (isBufferingToolCall) {
                const { content: cleanContent, toolCalls } = parseToolCalls$1(contentBuffer);
                if (toolCalls.length > 0) {
                  for (const tc of toolCalls) {
                    tc.index = toolCallIndex++;
                    const toolCallData = {
                      ...transformedData,
                      choices: [{
                        index: 0,
                        delta: {
                          role: isFirstChunk ? "assistant" : void 0,
                          tool_calls: [tc]
                        },
                        finish_reason: null
                      }]
                    };
                    isFirstChunk = false;
                    this.push(formatter.formatJSON(toolCallData));
                  }
                  contentBuffer = cleanContent;
                  isBufferingToolCall = contentBuffer.includes("[function_calls]");
                  if (contentBuffer && !isBufferingToolCall) {
                    const textData = {
                      ...transformedData,
                      choices: [{
                        index: 0,
                        delta: { content: contentBuffer },
                        finish_reason: null
                      }]
                    };
                    this.push(formatter.formatJSON(textData));
                    contentBuffer = "";
                  }
                  continue;
                } else {
                  if (contentBuffer.length > 1e4) {
                    isBufferingToolCall = false;
                  } else {
                    continue;
                  }
                }
              }
              transformedData.choices[0].delta.content = contentBuffer;
              contentBuffer = "";
            }
            if (parsedData.choices?.[0]?.delta?.tool_calls) {
              transformedData.choices[0].delta.tool_calls = parsedData.choices[0].delta.tool_calls;
            }
            if (!isBufferingToolCall) {
              isFirstChunk = false;
              this.push(formatter.formatJSON(transformedData));
            }
          }
          callback();
        } catch (error) {
          callback(error);
        }
      },
      flush(callback) {
        if (contentBuffer) {
          const { content: cleanContent, toolCalls } = parseToolCalls$1(contentBuffer);
          if (toolCalls.length > 0) {
            for (const tc of toolCalls) {
              tc.index = toolCallIndex++;
              const toolCallData = {
                id: responseId,
                object: "chat.completion.chunk",
                created,
                model,
                choices: [{
                  index: 0,
                  delta: {
                    tool_calls: [tc]
                  },
                  finish_reason: null
                }]
              };
              this.push(formatter.formatJSON(toolCallData));
            }
          } else {
            const finalData = transformChunk({ content: contentBuffer }, model, responseId, created, isFirstChunk);
            if (finalData) {
              this.push(formatter.formatJSON(finalData));
            }
          }
        }
        this.push(formatter.formatDone());
        onEnd?.();
        callback();
      }
    });
  }
  /**
   * Transform chunk to OpenAI format
   */
  transformChunk(data, model, responseId, created, isFirstChunk) {
    if (!data) return null;
    const delta = {};
    if (isFirstChunk) {
      delta.role = "assistant";
    }
    if (data.choices?.[0]?.delta?.reasoning_content) {
      delta.reasoning_content = data.choices[0].delta.reasoning_content;
    } else if (data.reasoning_content) {
      delta.reasoning_content = data.reasoning_content;
    }
    if (typeof data === "string") {
      delta.content = data;
    } else if (data.choices?.[0]?.delta?.content !== void 0) {
      delta.content = data.choices[0].delta.content;
    } else if (data.choices?.[0]?.text) {
      delta.content = data.choices[0].text;
    } else if (data.content !== void 0) {
      delta.content = data.content;
    } else if (data.message) {
      delta.content = data.message;
    }
    if (data.choices?.[0]?.delta?.tool_calls) {
      delta.tool_calls = data.choices[0].delta.tool_calls;
    }
    const finishReason = data.choices?.[0]?.finish_reason || data.finish_reason || null;
    if (delta.content === void 0 && !delta.reasoning_content && !delta.tool_calls && !finishReason) {
      return null;
    }
    return {
      id: responseId,
      object: "chat.completion.chunk",
      created,
      model,
      choices: [{
        index: 0,
        delta,
        finish_reason: finishReason
      }]
    };
  }
  /**
   * Convert stream response to non-stream response
   */
  async streamToResponse(stream2, model, responseId) {
    return new Promise((resolve, reject) => {
      let content = "";
      let reasoningContent = "";
      let finishReason = null;
      const toolCalls = [];
      const created = Math.floor(Date.now() / 1e3);
      stream2.on("data", (chunk) => {
        const events = this.parser.parse(chunk.toString());
        for (const event of events) {
          if (event.data === "[DONE]") continue;
          try {
            const data = JSON.parse(event.data);
            if (data.choices?.[0]?.delta?.content) {
              content += data.choices[0].delta.content;
            } else if (data.choices?.[0]?.text) {
              content += data.choices[0].text;
            } else if (data.content) {
              content += data.content;
            } else if (data.text) {
              content += data.text;
            }
            if (data.choices?.[0]?.delta?.reasoning_content) {
              reasoningContent += data.choices[0].delta.reasoning_content;
            } else if (data.reasoning_content) {
              reasoningContent += data.reasoning_content;
            }
            if (data.choices?.[0]?.delta?.tool_calls) {
              const deltaToolCalls = data.choices[0].delta.tool_calls;
              for (const tc of deltaToolCalls) {
                const existing = toolCalls.find((t) => t.index === tc.index);
                if (existing) {
                  if (tc.id) existing.id = tc.id;
                  if (tc.type) existing.type = tc.type;
                  if (tc.function?.name) existing.function.name = tc.function.name;
                  if (tc.function?.arguments) existing.function.arguments += tc.function.arguments;
                } else {
                  toolCalls.push({
                    index: tc.index,
                    id: tc.id || "",
                    type: tc.type || "function",
                    function: {
                      name: tc.function?.name || "",
                      arguments: tc.function?.arguments || ""
                    }
                  });
                }
              }
            }
            if (data.choices?.[0]?.finish_reason) {
              finishReason = data.choices[0].finish_reason;
            }
          } catch {
          }
        }
      });
      stream2.on("end", () => {
        const { content: cleanContent, toolCalls: parsedToolCalls } = parseToolCalls$1(content);
        const finalToolCalls = [...toolCalls];
        if (parsedToolCalls.length > 0) {
          parsedToolCalls.forEach((ptc) => {
            ptc.index += finalToolCalls.length;
            finalToolCalls.push(ptc);
          });
        }
        const message = {
          role: "assistant"
        };
        if (reasoningContent) {
          message.reasoning_content = reasoningContent.trim();
        }
        message.content = finalToolCalls.length > 0 ? null : cleanContent || null;
        if (finalToolCalls.length > 0) {
          message.tool_calls = finalToolCalls.sort((a, b) => (a.index || 0) - (b.index || 0)).map(({ index, ...rest }) => rest);
          if (!finishReason || finishReason === "stop") {
            finishReason = "tool_calls";
          }
        }
        resolve({
          id: responseId,
          object: "chat.completion",
          created,
          model,
          choices: [{
            index: 0,
            message,
            finish_reason: finishReason || "stop"
          }],
          usage: {
            prompt_tokens: 0,
            completion_tokens: 0,
            total_tokens: 0
          }
        });
      });
      stream2.on("error", reject);
    });
  }
  /**
   * Create PassThrough stream for SSE response
   */
  createPassThrough() {
    return new stream.PassThrough();
  }
  /**
   * Write SSE event to stream
   */
  writeSSEEvent(stream2, data) {
    stream2.write(this.formatter.formatJSON(data));
  }
  /**
   * Write SSE done marker
   */
  writeSSEDone(stream2) {
    stream2.write(this.formatter.formatDone());
    stream2.end();
  }
  /**
   * Create error response stream
   */
  createErrorStream(model, responseId, error) {
    const stream$1 = new stream.PassThrough();
    const created = Math.floor(Date.now() / 1e3);
    stream$1.write(this.formatter.formatJSON({
      id: responseId,
      object: "chat.completion.chunk",
      created,
      model,
      choices: [{
        index: 0,
        delta: {
          role: "assistant",
          content: error
        },
        finish_reason: "stop"
      }]
    }));
    stream$1.write(this.formatter.formatDone());
    stream$1.end();
    return stream$1;
  }
}
const streamHandler = new StreamHandler();
class ModelMapper {
  /**
   * Map model name
   * @param requestedModel Requested model name
   * @param provider Provider (optional, for provider-specific mapping)
   */
  mapModel(requestedModel, provider) {
    const config = server_bootstrapConfig.storeManager.getConfig();
    const mappings = config.modelMappings;
    const directMapping = mappings[requestedModel];
    if (directMapping) {
      if (!provider || !directMapping.preferredProviderId || directMapping.preferredProviderId === provider.id) {
        return directMapping.actualModel;
      }
    }
    const wildcardMapping = this.findWildcardMapping(requestedModel, mappings, provider);
    if (wildcardMapping) {
      return wildcardMapping.actualModel;
    }
    return requestedModel;
  }
  /**
   * Find wildcard mapping
   */
  findWildcardMapping(requestedModel, mappings, provider) {
    const normalizedRequested = requestedModel.toLowerCase();
    for (const [pattern, mapping] of Object.entries(mappings)) {
      if (pattern.includes("*")) {
        const normalizedPattern = pattern.toLowerCase();
        if (this.matchesPattern(normalizedRequested, normalizedPattern)) {
          if (!provider || !mapping.preferredProviderId || mapping.preferredProviderId === provider.id) {
            return mapping;
          }
        }
      }
    }
    return null;
  }
  /**
   * Check if model name matches wildcard pattern
   */
  matchesPattern(modelName, pattern) {
    if (pattern === "*") {
      return true;
    }
    if (pattern.startsWith("*")) {
      return modelName.endsWith(pattern.slice(1));
    }
    if (pattern.endsWith("*")) {
      return modelName.startsWith(pattern.slice(0, -1));
    }
    const parts = pattern.split("*");
    if (parts.length === 2) {
      return modelName.startsWith(parts[0]) && modelName.endsWith(parts[1]);
    }
    return false;
  }
  /**
   * Get actual model name for a model
   */
  getActualModel(requestedModel, providerId) {
    const config = server_bootstrapConfig.storeManager.getConfig();
    const mapping = config.modelMappings[requestedModel];
    if (mapping) {
      if (!providerId || !mapping.preferredProviderId || mapping.preferredProviderId === providerId) {
        return mapping.actualModel;
      }
    }
    return requestedModel;
  }
  /**
   * Get preferred provider for a model
   */
  getPreferredProvider(requestedModel) {
    const config = server_bootstrapConfig.storeManager.getConfig();
    const mapping = config.modelMappings[requestedModel];
    return mapping?.preferredProviderId;
  }
  /**
   * Get preferred account for a model
   */
  getPreferredAccount(requestedModel) {
    const config = server_bootstrapConfig.storeManager.getConfig();
    const mapping = config.modelMappings[requestedModel];
    return mapping?.preferredAccountId;
  }
  /**
   * Add model mapping
   */
  addMapping(requestModel, actualModel, preferredProviderId, preferredAccountId) {
    const config = server_bootstrapConfig.storeManager.getConfig();
    config.modelMappings[requestModel] = {
      requestModel,
      actualModel,
      preferredProviderId,
      preferredAccountId
    };
    server_bootstrapConfig.storeManager.getStore()?.set("config", config);
  }
  /**
   * Remove model mapping
   */
  removeMapping(requestModel) {
    const config = server_bootstrapConfig.storeManager.getConfig();
    if (config.modelMappings[requestModel]) {
      delete config.modelMappings[requestModel];
      server_bootstrapConfig.storeManager.getStore()?.set("config", config);
      return true;
    }
    return false;
  }
  /**
   * Get all mappings
   */
  getAllMappings() {
    const config = server_bootstrapConfig.storeManager.getConfig();
    return { ...config.modelMappings };
  }
  /**
   * Get list of providers supporting specified model
   */
  getProvidersForModel(model) {
    const providers = server_bootstrapConfig.storeManager.getProviders().filter((p) => p.enabled);
    const preferredProviderId = this.getPreferredProvider(model);
    if (preferredProviderId) {
      const preferred = providers.find((p) => p.id === preferredProviderId);
      if (preferred) {
        return [preferred];
      }
    }
    return providers.filter((provider) => {
      const effectiveModels = server_bootstrapConfig.storeManager.getEffectiveModels(provider.id);
      if (effectiveModels.length === 0) {
        return true;
      }
      const normalizedModel = model.toLowerCase();
      return effectiveModels.some((m) => {
        const normalizedSupported = m.displayName.toLowerCase();
        if (normalizedSupported.endsWith("*")) {
          return normalizedModel.startsWith(normalizedSupported.slice(0, -1));
        }
        return normalizedSupported === normalizedModel;
      });
    });
  }
}
const modelMapper = new ModelMapper();
function isAnthropicToolFormat(toolFormat) {
  return toolFormat === "native";
}
function openaiToAnthropicToolCalls(toolCalls) {
  return toolCalls.map((tc) => ({
    type: "tool_use",
    id: tc.id,
    name: tc.function.name,
    input: JSON.parse(tc.function.arguments)
  }));
}
function transformResponseToAnthropic(response) {
  if (!response.choices || !Array.isArray(response.choices)) {
    return response;
  }
  const transformedChoices = response.choices.map((choice) => {
    if (!choice.message) {
      return choice;
    }
    const message = choice.message;
    const toolCalls = message.tool_calls;
    if (!toolCalls || !Array.isArray(toolCalls) || toolCalls.length === 0) {
      return choice;
    }
    const content = [];
    if (message.content) {
      content.push({ type: "text", text: message.content });
    }
    const toolUseBlocks = openaiToAnthropicToolCalls(toolCalls);
    content.push(...toolUseBlocks.map((tu) => ({
      type: "tool_use",
      id: tu.id,
      name: tu.name,
      input: tu.input
    })));
    return {
      ...choice,
      message: {
        role: message.role,
        content
      },
      finish_reason: choice.finish_reason
    };
  });
  return {
    ...response,
    choices: transformedChoices
  };
}
const router$c = new Router({ prefix: "/v1/chat" });
function generateRequestId$1() {
  return `chatcmpl-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function getClientIP(ctx) {
  return ctx.headers["x-real-ip"] || ctx.headers["x-forwarded-for"] || ctx.ip || "unknown";
}
function extractUserInput(messages) {
  for (let i = messages.length - 1; i >= 0; i--) {
    const msg = messages[i];
    if (msg.role === "user" && msg.content) {
      let content = "";
      if (typeof msg.content === "string") {
        content = msg.content;
      } else if (Array.isArray(msg.content)) {
        const textParts = msg.content.filter((p) => p.type === "text");
        if (textParts.length > 0) {
          content = textParts.map((p) => p.text || "").join(" ");
        }
      }
      if (content) {
        return content;
      }
    }
  }
  return void 0;
}
router$c.post("/completions", async (ctx) => {
  const startTime = Date.now();
  const requestId2 = generateRequestId$1();
  const clientIP = getClientIP(ctx);
  let request;
  try {
    request = ctx.request.body;
  } catch (error) {
    ctx.status = 400;
    ctx.body = {
      error: {
        message: "Invalid request body",
        type: "invalid_request_error",
        param: null,
        code: null
      }
    };
    return;
  }
  if (!request.model) {
    ctx.status = 400;
    ctx.body = {
      error: {
        message: "Missing required field: model",
        type: "invalid_request_error",
        param: "model",
        code: null
      }
    };
    return;
  }
  if (!request.messages || !Array.isArray(request.messages) || request.messages.length === 0) {
    ctx.status = 400;
    ctx.body = {
      error: {
        message: "Missing required field: messages",
        type: "invalid_request_error",
        param: "messages",
        code: null
      }
    };
    return;
  }
  const webSearchFromHeader = ctx.headers["x-web-search"] === "true";
  const reasoningEffortFromHeader = ctx.headers["x-reasoning-effort"];
  const deepResearchFromHeader = ctx.headers["x-deep-research"] === "true";
  const requestAny = request;
  if (requestAny.reasoningEffort && !request.reasoning_effort) {
    request.reasoning_effort = requestAny.reasoningEffort;
    console.log("[Chat] Reasoning effort set via reasoningEffort (camelCase):", requestAny.reasoningEffort);
    delete requestAny.reasoningEffort;
  }
  if (webSearchFromHeader && request.web_search === void 0) {
    request.web_search = true;
    console.log("[Chat] Web search enabled via X-Web-Search header");
  }
  if (reasoningEffortFromHeader && request.reasoning_effort === void 0) {
    request.reasoning_effort = reasoningEffortFromHeader;
    console.log("[Chat] Reasoning effort set via X-Reasoning-Effort header:", reasoningEffortFromHeader);
  }
  if (deepResearchFromHeader && request.deep_research === void 0) {
    request.deep_research = true;
    console.log("[Chat] Deep research enabled via X-Deep-Research header");
  }
  const config = server_bootstrapConfig.storeManager.getConfig();
  const preferredProviderId = modelMapper.getPreferredProvider(request.model);
  const preferredAccountId = modelMapper.getPreferredAccount(request.model);
  const selection = loadBalancer.selectAccount(
    request.model,
    config.loadBalanceStrategy,
    preferredProviderId,
    preferredAccountId
  );
  if (!selection) {
    ctx.status = 503;
    ctx.body = {
      error: {
        message: `No available account for model: ${request.model}`,
        type: "service_unavailable_error",
        param: null,
        code: "no_available_account"
      }
    };
    return;
  }
  const { account, provider, actualModel } = selection;
  const context = {
    requestId: requestId2,
    providerId: provider.id,
    accountId: account.id,
    model: request.model,
    actualModel,
    startTime,
    isStream: request.stream || false,
    clientIP
  };
  proxyStatusManager.recordRequestStart(request.model, provider.id, account.id);
  try {
    const result = await requestForwarder.forwardChatCompletion(
      request,
      account,
      provider,
      actualModel,
      context
    );
    const latency = Date.now() - startTime;
    if (!result.success) {
      proxyStatusManager.recordRequestFailure(latency);
      if (result.status && result.status >= 400 && result.status !== 429) {
        loadBalancer.markAccountFailed(account.id);
      }
      ctx.status = result.status || 500;
      ctx.body = {
        error: {
          message: result.error || "Request failed",
          type: "api_error",
          param: null,
          code: null
        }
      };
      server_bootstrapConfig.storeManager.addLog("error", `Request failed: ${result.error}`, {
        requestId: requestId2,
        providerId: provider.id,
        accountId: account.id,
        model: request.model,
        latency
      });
      const userInput2 = extractUserInput(request.messages);
      const errorResponseBody = JSON.stringify({
        error: {
          message: result.error || "Request failed",
          type: "api_error",
          param: null,
          code: null
        }
      });
      server_bootstrapConfig.storeManager.addRequestLog({
        timestamp: startTime,
        status: "error",
        statusCode: result.status || 500,
        method: "POST",
        url: "/v1/chat/completions",
        model: request.model,
        actualModel,
        providerId: provider.id,
        providerName: provider.name,
        accountId: account.id,
        accountName: account.name,
        requestBody: JSON.stringify(request),
        userInput: userInput2,
        webSearch: request.web_search,
        reasoningEffort: request.reasoning_effort,
        responseStatus: result.status || 500,
        responseBody: errorResponseBody,
        latency,
        isStream: request.stream || false,
        errorMessage: result.error
      });
      server_bootstrapConfig.storeManager.recordRequestInStats(false, latency, request.model, provider.id, account.id);
      return;
    }
    loadBalancer.clearAccountFailure(account.id);
    proxyStatusManager.recordRequestSuccess(latency);
    server_bootstrapConfig.storeManager.updateAccount(account.id, {
      lastUsed: Date.now(),
      requestCount: (account.requestCount || 0) + 1,
      todayUsed: (account.todayUsed || 0) + 1
    });
    server_bootstrapConfig.storeManager.addLog("debug", `Request succeeded`, {
      requestId: requestId2,
      providerId: provider.id,
      accountId: account.id,
      model: request.model,
      actualModel,
      latency,
      isStream: request.stream
    });
    const userInput = extractUserInput(request.messages);
    const responseBodyForLog = !request.stream && result.body ? JSON.stringify(result.body) : void 0;
    let logEntryId;
    if (!request.stream) {
      const logEntry = server_bootstrapConfig.storeManager.addRequestLog({
        timestamp: startTime,
        status: "success",
        statusCode: 200,
        method: "POST",
        url: "/v1/chat/completions",
        model: request.model,
        actualModel,
        providerId: provider.id,
        providerName: provider.name,
        accountId: account.id,
        accountName: account.name,
        requestBody: JSON.stringify(request),
        userInput,
        webSearch: request.web_search,
        reasoningEffort: request.reasoning_effort,
        responseStatus: 200,
        responseBody: responseBodyForLog,
        latency,
        isStream: false
      });
      logEntryId = logEntry.id;
    } else {
      const logEntry = server_bootstrapConfig.storeManager.addRequestLog({
        timestamp: startTime,
        status: "success",
        statusCode: 200,
        method: "POST",
        url: "/v1/chat/completions",
        model: request.model,
        actualModel,
        providerId: provider.id,
        providerName: provider.name,
        accountId: account.id,
        accountName: account.name,
        requestBody: JSON.stringify(request),
        userInput,
        webSearch: request.web_search,
        reasoningEffort: request.reasoning_effort,
        responseStatus: 200,
        latency,
        isStream: true
      });
      logEntryId = logEntry.id;
    }
    server_bootstrapConfig.storeManager.recordRequestInStats(true, latency, request.model, provider.id, account.id);
    if (request.stream === true && result.stream) {
      ctx.set("Content-Type", "text/event-stream");
      ctx.set("Cache-Control", "no-cache");
      ctx.set("Connection", "keep-alive");
      ctx.set("X-Accel-Buffering", "no");
      const wrapperStream = new stream.PassThrough();
      let collectedContent = "";
      result.stream.once("error", (err) => {
        console.error("[Chat] Stream error:", err.message);
        const errorEvent = {
          id: requestId2,
          object: "chat.completion.chunk",
          created: Math.floor(Date.now() / 1e3),
          model: actualModel,
          choices: [{
            index: 0,
            delta: {
              content: `

[Error: ${err.message}]`
            },
            finish_reason: "stop"
          }]
        };
        wrapperStream.write(`data: ${JSON.stringify(errorEvent)}

`);
        wrapperStream.write("data: [DONE]\n\n");
        wrapperStream.end();
        server_bootstrapConfig.storeManager.addLog("error", `Stream error: ${err.message}`, {
          requestId: requestId2,
          providerId: provider.id,
          accountId: account.id,
          model: request.model
        });
      });
      if (result.skipTransform) {
        result.stream.on("data", (chunk) => {
          collectedContent += chunk.toString();
        });
        result.stream.pipe(wrapperStream, { end: false });
        result.stream.once("end", () => {
          if (logEntryId) {
            server_bootstrapConfig.storeManager.updateRequestLog(logEntryId, {
              responseBody: collectedContent || void 0
            });
          }
          wrapperStream.end();
        });
      } else {
        const transformStream = streamHandler.createTransformStream(
          actualModel,
          requestId2,
          () => {
            server_bootstrapConfig.storeManager.addLog("debug", `Stream response completed`, { requestId: requestId2 });
          }
        );
        transformStream.on("data", (chunk) => {
          collectedContent += chunk.toString();
        });
        result.stream.pipe(transformStream);
        transformStream.pipe(wrapperStream, { end: false });
        transformStream.once("end", () => {
          if (logEntryId) {
            server_bootstrapConfig.storeManager.updateRequestLog(logEntryId, {
              responseBody: collectedContent || void 0
            });
          }
          wrapperStream.end();
        });
      }
      ctx.body = wrapperStream;
    } else {
      ctx.set("Content-Type", "application/json");
      if (result.body) {
        if (isAnthropicToolFormat(request.tool_format)) {
          ctx.body = transformResponseToAnthropic(result.body);
          console.log("[Chat] Transformed response to Anthropic tool format");
        } else {
          ctx.body = result.body;
        }
      } else {
        ctx.body = {
          id: requestId2,
          object: "chat.completion",
          created: Math.floor(Date.now() / 1e3),
          model: actualModel,
          choices: [{
            index: 0,
            message: {
              role: "assistant",
              content: ""
            },
            finish_reason: "stop"
          }],
          usage: {
            prompt_tokens: 0,
            completion_tokens: 0,
            total_tokens: 0
          }
        };
      }
    }
  } catch (error) {
    const latency = Date.now() - startTime;
    proxyStatusManager.recordRequestFailure(latency);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    const errorStack = error instanceof Error ? error.stack : void 0;
    ctx.status = 500;
    ctx.body = {
      error: {
        message: errorMessage,
        type: "internal_error",
        param: null,
        code: null
      }
    };
    server_bootstrapConfig.storeManager.addLog("error", `Request exception: ${errorMessage}`, {
      requestId: requestId2,
      providerId: provider.id,
      accountId: account.id,
      model: request.model,
      latency,
      error: errorMessage
    });
    const userInput = extractUserInput(request.messages);
    const exceptionResponseBody = JSON.stringify({
      error: {
        message: errorMessage,
        type: "internal_error",
        param: null,
        code: null
      }
    });
    server_bootstrapConfig.storeManager.addRequestLog({
      timestamp: startTime,
      status: "error",
      statusCode: 500,
      method: "POST",
      url: "/v1/chat/completions",
      model: request.model,
      actualModel,
      providerId: provider.id,
      providerName: provider.name,
      accountId: account.id,
      accountName: account.name,
      requestBody: JSON.stringify(request),
      userInput,
      webSearch: request.web_search,
      reasoningEffort: request.reasoning_effort,
      responseStatus: 500,
      responseBody: exceptionResponseBody,
      latency,
      isStream: request.stream || false,
      errorMessage,
      errorStack
    });
    server_bootstrapConfig.storeManager.recordRequestInStats(false, latency, request.model, provider.id, account.id);
  }
});
const router$b = new Router({ prefix: "/v1" });
router$b.get("/models", async (ctx) => {
  const providers = server_bootstrapConfig.storeManager.getProviders().filter((p) => p.enabled);
  const models = [];
  const addedModels = /* @__PURE__ */ new Set();
  for (const provider of providers) {
    const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(provider.id).filter((account) => account.status === "active");
    if (accounts.length === 0) {
      continue;
    }
    const effectiveModels = server_bootstrapConfig.storeManager.getEffectiveModels(provider.id);
    for (const model of effectiveModels) {
      if (!addedModels.has(model.displayName)) {
        addedModels.add(model.displayName);
        models.push({
          id: model.displayName,
          object: "model",
          created: Math.floor(provider.createdAt / 1e3),
          owned_by: provider.name
        });
      }
    }
  }
  const config = server_bootstrapConfig.storeManager.getConfig();
  const mappings = config.modelMappings || {};
  for (const [requestModel, mapping] of Object.entries(mappings)) {
    if (!addedModels.has(requestModel)) {
      addedModels.add(requestModel);
      models.push({
        id: requestModel,
        object: "model",
        created: Math.floor(Date.now() / 1e3),
        owned_by: "model-mapping"
      });
    }
  }
  const response = {
    object: "list",
    data: models
  };
  ctx.set("Content-Type", "application/json");
  ctx.body = response;
});
router$b.get("/models/:model", async (ctx) => {
  const modelId = ctx.params.model;
  const config = server_bootstrapConfig.storeManager.getConfig();
  const mappings = config.modelMappings || {};
  if (mappings[modelId]) {
    ctx.set("Content-Type", "application/json");
    ctx.body = {
      id: modelId,
      object: "model",
      created: Math.floor(Date.now() / 1e3),
      owned_by: "model-mapping"
    };
    return;
  }
  const providers = server_bootstrapConfig.storeManager.getProviders().filter((p) => p.enabled);
  for (const provider of providers) {
    const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(provider.id).filter((account) => account.status === "active");
    if (accounts.length === 0) {
      continue;
    }
    const effectiveModels = server_bootstrapConfig.storeManager.getEffectiveModels(provider.id);
    const normalizedModelId = modelId.toLowerCase();
    const found = effectiveModels.some((m) => {
      const normalizedSupported = m.displayName.toLowerCase();
      if (normalizedSupported.endsWith("*")) {
        return normalizedModelId.startsWith(normalizedSupported.slice(0, -1));
      }
      return normalizedSupported === normalizedModelId;
    });
    if (found) {
      ctx.set("Content-Type", "application/json");
      ctx.body = {
        id: modelId,
        object: "model",
        created: Math.floor(provider.createdAt / 1e3),
        owned_by: provider.name
      };
      return;
    }
  }
  ctx.status = 404;
  ctx.body = {
    error: {
      message: `Model '${modelId}' not found`,
      type: "invalid_request_error",
      param: "model",
      code: "model_not_found"
    }
  };
});
const router$a = new Router({ prefix: "/v1" });
function generateRequestId() {
  return `cmpl-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function promptToMessages(prompt) {
  if (Array.isArray(prompt)) {
    return prompt.map((p, index) => ({
      role: index % 2 === 0 ? "user" : "assistant",
      content: p
    }));
  }
  return [{ role: "user", content: prompt }];
}
router$a.post("/completions", async (ctx) => {
  const startTime = Date.now();
  const requestId2 = generateRequestId();
  let request;
  try {
    request = ctx.request.body;
  } catch (error) {
    ctx.status = 400;
    ctx.body = {
      error: {
        message: "Invalid request body",
        type: "invalid_request_error"
      }
    };
    return;
  }
  if (!request.model) {
    ctx.status = 400;
    ctx.body = {
      error: {
        message: "Missing required field: model",
        type: "invalid_request_error",
        param: "model"
      }
    };
    return;
  }
  if (request.prompt === void 0) {
    ctx.status = 400;
    ctx.body = {
      error: {
        message: "Missing required field: prompt",
        type: "invalid_request_error",
        param: "prompt"
      }
    };
    return;
  }
  const config = server_bootstrapConfig.storeManager.getConfig();
  const preferredProviderId = modelMapper.getPreferredProvider(request.model);
  const preferredAccountId = modelMapper.getPreferredAccount(request.model);
  const selection = loadBalancer.selectAccount(
    request.model,
    config.loadBalanceStrategy,
    preferredProviderId,
    preferredAccountId
  );
  if (!selection) {
    ctx.status = 503;
    ctx.body = {
      error: {
        message: `No available account for model: ${request.model}`,
        type: "service_unavailable_error",
        code: "no_available_account"
      }
    };
    return;
  }
  const { account, provider, actualModel } = selection;
  const chatRequest = {
    model: actualModel,
    messages: promptToMessages(request.prompt),
    max_tokens: request.max_tokens,
    temperature: request.temperature,
    top_p: request.top_p,
    n: request.n,
    stream: request.stream,
    stop: request.stop
  };
  proxyStatusManager.recordRequestStart(request.model, provider.id, account.id);
  try {
    const result = await requestForwarder.forwardChatCompletion(
      chatRequest,
      account,
      provider,
      actualModel,
      {
        requestId: requestId2,
        providerId: provider.id,
        accountId: account.id,
        model: request.model,
        actualModel,
        startTime,
        isStream: request.stream || false
      }
    );
    const latency = Date.now() - startTime;
    if (!result.success) {
      proxyStatusManager.recordRequestFailure(latency);
      ctx.status = result.status || 500;
      ctx.body = {
        error: {
          message: result.error || "Request failed",
          type: "api_error"
        }
      };
      return;
    }
    proxyStatusManager.recordRequestSuccess(latency);
    server_bootstrapConfig.storeManager.updateAccount(account.id, {
      lastUsed: Date.now(),
      requestCount: (account.requestCount || 0) + 1,
      todayUsed: (account.todayUsed || 0) + 1
    });
    server_bootstrapConfig.storeManager.addLog("debug", `Request succeeded`, {
      requestId: requestId2,
      providerId: provider.id,
      accountId: account.id,
      model: request.model,
      actualModel,
      latency,
      isStream: request.stream
    });
    if (request.stream && result.stream) {
      ctx.set("Content-Type", "text/event-stream");
      ctx.set("Cache-Control", "no-cache");
      ctx.set("Connection", "keep-alive");
      ctx.set("X-Accel-Buffering", "no");
      const transformStream = streamHandler.createTransformStream(actualModel, requestId2);
      result.stream.pipe(transformStream);
      ctx.body = transformStream;
    } else {
      ctx.set("Content-Type", "application/json");
      ctx.body = result.body;
    }
  } catch (error) {
    const latency = Date.now() - startTime;
    proxyStatusManager.recordRequestFailure(latency);
    ctx.status = 500;
    ctx.body = {
      error: {
        message: error instanceof Error ? error.message : "Unknown error",
        type: "internal_error"
      }
    };
  }
});
const GEMINI_FILE_TTL_MS = 48 * 60 * 60 * 1e3;
function randomId() {
  return "xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.floor(Math.random() * 16);
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
}
function safeFileName(value) {
  return value.replace(/[\\/:*?"<>|]/g, "_").replace(/\s+/g, " ").trim() || "upload";
}
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function expiresIso(createdAt = Date.now()) {
  return new Date(createdAt + GEMINI_FILE_TTL_MS).toISOString();
}
function geminiFileName(file) {
  return `files/${file.id}`;
}
function getBodyBuffer(ctx) {
  const body = ctx.request.rawBody || ctx.request.body;
  if (Buffer.isBuffer(body)) {
    return body;
  }
  if (typeof body === "string") {
    return Buffer.from(body);
  }
  if (body === void 0 || body === null) {
    return Buffer.alloc(0);
  }
  return Buffer.from(JSON.stringify(body));
}
class GeminiFileStore {
  constructor() {
    this.pendingUploads = /* @__PURE__ */ new Map();
    this.uploadDir = path.join(server_bootstrapConfig.getRuntime().getDataDir(), "gemini-files");
  }
  ensureReady() {
    fs.mkdirSync(this.uploadDir, { recursive: true });
  }
  createUploadSession(ctx) {
    this.ensureReady();
    const now = Date.now();
    const uploadProtocol = ctx.get("X-Goog-Upload-Protocol");
    const uploadCommand = ctx.get("X-Goog-Upload-Command");
    const mimeType = ctx.get("X-Goog-Upload-Header-Content-Type") || "application/octet-stream";
    const sizeBytes = Number.parseInt(ctx.get("X-Goog-Upload-Header-Content-Length") || "0", 10) || 0;
    const body = ctx.request.body || {};
    const bodyFile = body.file || {};
    const displayName = safeFileName(
      ctx.get("X-Goog-Upload-File-Name") || bodyFile.displayName || bodyFile.display_name || `upload-${randomId()}`
    );
    const id = randomId();
    const filePath = path.join(this.uploadDir, `${id}-${displayName}`);
    if (uploadProtocol || uploadCommand) {
      if (uploadProtocol !== "resumable" || !uploadCommand.includes("start")) {
        throw new Error("Unsupported Gemini upload command");
      }
    }
    const pending = {
      id,
      displayName,
      mimeType,
      sizeBytes,
      offset: 0,
      createdAt: now,
      path: filePath
    };
    this.pendingUploads.set(id, pending);
    ctx.set("X-Goog-Upload-URL", `${ctx.origin}/upload/v1beta/files/${id}`);
    ctx.set("X-Goog-Upload-Status", "active");
    return this.toFile(pending, "PROCESSING");
  }
  storeUploadChunk(uploadId, ctx) {
    this.ensureReady();
    const pending = this.pendingUploads.get(uploadId);
    if (!pending) {
      throw new Error(`Gemini upload session not found: ${uploadId}`);
    }
    const command = ctx.get("X-Goog-Upload-Command") || "upload, finalize";
    const offset = Number.parseInt(ctx.get("X-Goog-Upload-Offset") || "0", 10) || 0;
    if (offset !== pending.offset) {
      throw new Error(`Invalid Gemini upload offset: expected ${pending.offset}, got ${offset}`);
    }
    const chunk = getBodyBuffer(ctx);
    fs.writeFileSync(pending.path, chunk, { flag: offset === 0 ? "w" : "a" });
    pending.offset += chunk.length;
    const finalized = command.includes("finalize");
    if (finalized) {
      const sizeBytes = fs.statSync(pending.path).size;
      const stored = this.toFile({ ...pending, sizeBytes }, "ACTIVE");
      this.pendingUploads.delete(uploadId);
      ctx.set("X-Goog-Upload-Status", "final");
      return stored;
    }
    ctx.set("X-Goog-Upload-Status", "active");
    return this.toFile(pending, "PROCESSING");
  }
  createSimpleFile(ctx) {
    this.ensureReady();
    const body = ctx.request.body || {};
    const bodyFile = body.file || {};
    const id = randomId();
    const file = { id };
    const displayName = safeFileName(bodyFile.displayName || bodyFile.display_name || `upload-${id}`);
    const mimeType = bodyFile.mimeType || bodyFile.mime_type || ctx.get("Content-Type") || "application/octet-stream";
    const filePath = path.join(this.uploadDir, `${id}-${displayName}`);
    const data = bodyFile.data ? Buffer.from(String(bodyFile.data), "base64") : getBodyBuffer(ctx);
    fs.writeFileSync(filePath, data);
    return {
      id,
      name: geminiFileName(file),
      uri: geminiFileName(file),
      displayName,
      mimeType,
      sizeBytes: fs.statSync(filePath).size,
      createTime: nowIso(),
      expirationTime: expiresIso(),
      path: filePath,
      state: "ACTIVE"
    };
  }
  getFile(nameOrUri) {
    this.ensureReady();
    const id = this.extractId(nameOrUri);
    const filePath = this.findPathById(id);
    if (!filePath) {
      return null;
    }
    const stat = fs.statSync(filePath);
    const createdAt = stat.birthtimeMs || stat.ctimeMs;
    if (Date.now() - createdAt > GEMINI_FILE_TTL_MS) {
      fs.rmSync(filePath, { force: true });
      return null;
    }
    const displayName = safeFileName(filePath.split(/[\\/]/).pop()?.replace(`${id}-`, "") || id);
    return {
      id,
      name: geminiFileName({ id }),
      uri: geminiFileName({ id }),
      displayName,
      mimeType: this.guessMimeType(displayName),
      sizeBytes: stat.size,
      createTime: new Date(createdAt).toISOString(),
      expirationTime: expiresIso(createdAt),
      path: filePath,
      state: "ACTIVE"
    };
  }
  readFile(nameOrUri) {
    const file = this.getFile(nameOrUri);
    if (!file || !fs.existsSync(file.path)) {
      return null;
    }
    return { file, data: fs.readFileSync(file.path) };
  }
  deleteFile(nameOrUri) {
    const id = this.extractId(nameOrUri);
    const filePath = this.findPathById(id);
    if (!filePath) {
      return false;
    }
    fs.rmSync(filePath, { force: true });
    return true;
  }
  toFile(upload, state) {
    return {
      id: upload.id,
      name: geminiFileName(upload),
      uri: geminiFileName(upload),
      displayName: upload.displayName,
      mimeType: upload.mimeType,
      sizeBytes: upload.sizeBytes,
      createTime: new Date(upload.createdAt).toISOString(),
      expirationTime: expiresIso(upload.createdAt),
      path: upload.path,
      state
    };
  }
  extractId(nameOrUri) {
    return nameOrUri.replace(/^https?:\/\/[^/]+\//, "").replace(/^\/?v1beta\//, "").replace(/^files\//, "");
  }
  findPathById(id) {
    if (!fs.existsSync(this.uploadDir)) {
      return null;
    }
    const { readdirSync } = require("fs");
    const match = readdirSync(this.uploadDir).find((fileName) => fileName.startsWith(`${id}-`));
    return match ? path.join(this.uploadDir, match) : null;
  }
  guessMimeType(fileName) {
    const lower = fileName.toLowerCase();
    if (lower.endsWith(".mp4")) return "video/mp4";
    if (lower.endsWith(".mov")) return "video/quicktime";
    if (lower.endsWith(".webm")) return "video/webm";
    if (lower.endsWith(".mp3")) return "audio/mpeg";
    if (lower.endsWith(".wav")) return "audio/wav";
    if (lower.endsWith(".png")) return "image/png";
    if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) return "image/jpeg";
    if (lower.endsWith(".pdf")) return "application/pdf";
    return "application/octet-stream";
  }
}
const geminiFileStore = new GeminiFileStore();
function normalizeRole(role) {
  if (role === "model") {
    return "assistant";
  }
  return role === "system" ? "system" : "user";
}
const CHAT2API_FILE_SCHEME = "chat2api-file://";
function filePartFromMime(url, mimeType, filename, localPath) {
  if (mimeType.startsWith("image/")) {
    return { type: "image_url", image_url: { url }, mime_type: mimeType, filename, local_path: localPath };
  }
  if (mimeType.startsWith("audio/")) {
    if (url.startsWith("data:")) {
      return {
        type: "input_audio",
        input_audio: {
          data: url,
          format: mimeType.split("/")[1]
        },
        mime_type: mimeType,
        filename,
        local_path: localPath
      };
    }
    return { type: "file", file_url: { url }, mime_type: mimeType, filename, local_path: localPath };
  }
  if (mimeType.startsWith("video/")) {
    return { type: "video_url", video_url: { url }, mime_type: mimeType, filename, local_path: localPath };
  }
  return { type: "file", file_url: { url }, mime_type: mimeType, filename, local_path: localPath };
}
function convertPart(part) {
  if (typeof part.text === "string") {
    return { type: "text", text: part.text };
  }
  const inlineData = part.inlineData || (part.inline_data ? {
    mimeType: part.inline_data.mime_type,
    data: part.inline_data.data
  } : void 0);
  if (inlineData?.data) {
    const mimeType = inlineData.mimeType || "application/octet-stream";
    return filePartFromMime(`data:${mimeType};base64,${inlineData.data}`, mimeType);
  }
  const fileData = part.fileData || (part.file_data ? {
    mimeType: part.file_data.mime_type,
    fileUri: part.file_data.file_uri
  } : void 0);
  if (fileData?.fileUri) {
    const stored = geminiFileStore.readFile(fileData.fileUri);
    if (stored) {
      const mimeType2 = fileData.mimeType || stored.file.mimeType;
      const url = `${CHAT2API_FILE_SCHEME}${encodeURIComponent(stored.file.name)}`;
      return filePartFromMime(url, mimeType2, stored.file.displayName, stored.file.path);
    }
    const mimeType = fileData.mimeType || "application/octet-stream";
    return filePartFromMime(fileData.fileUri, mimeType);
  }
  return null;
}
function getTextFromChoice(response) {
  return response.choices.map((choice) => choice.message?.content || choice.delta?.content || choice.message?.reasoning_content || choice.delta?.reasoning_content || "").join("");
}
function mapFinishReason(reason) {
  if (reason === "length") return "MAX_TOKENS";
  if (reason === "content_filter") return "SAFETY";
  if (reason === "tool_calls") return "STOP";
  return "STOP";
}
function geminiToChatCompletionRequest(model, body) {
  const messages = (body.contents || []).map((content) => {
    const parts = (content.parts || []).map(convertPart).filter(Boolean);
    return {
      role: normalizeRole(content.role),
      content: parts.length === 1 && parts[0].type === "text" ? parts[0].text || "" : parts
    };
  });
  if (body.systemInstruction?.parts?.length) {
    messages.unshift({
      role: "system",
      content: body.systemInstruction.parts.map((part) => part.text || "").join("")
    });
  }
  const generationConfig = body.generationConfig || {};
  return {
    model,
    messages,
    stream: false,
    temperature: generationConfig.temperature,
    top_p: generationConfig.topP,
    max_tokens: generationConfig.maxOutputTokens,
    stop: generationConfig.stopSequences
  };
}
function chatCompletionToGeminiResponse(response, model) {
  const firstChoice = response.choices[0];
  return {
    candidates: [
      {
        content: {
          role: "model",
          parts: [{ text: getTextFromChoice(response) }]
        },
        finishReason: mapFinishReason(firstChoice?.finish_reason),
        index: firstChoice?.index || 0
      }
    ],
    modelVersion: model,
    usageMetadata: response.usage ? {
      promptTokenCount: response.usage.prompt_tokens,
      candidatesTokenCount: response.usage.completion_tokens,
      totalTokenCount: response.usage.total_tokens
    } : void 0
  };
}
function chatCompletionStreamToGeminiSse(stream$1, model) {
  const output = new stream.PassThrough();
  let buffer = "";
  stream$1.on("data", (chunk) => {
    buffer += chunk.toString();
    const events = buffer.split("\n\n");
    buffer = events.pop() || "";
    for (const event of events) {
      const line = event.split("\n").find((item) => item.startsWith("data: "));
      if (!line) continue;
      const data = line.slice(6);
      if (data === "[DONE]") {
        continue;
      }
      try {
        const parsed = JSON.parse(data);
        const text = parsed.choices?.map((choice) => choice.delta?.content || choice.message?.content || "").join("") || "";
        if (!text) continue;
        output.write(`data: ${JSON.stringify({
          candidates: [{ content: { role: "model", parts: [{ text }] }, finishReason: "STOP", index: 0 }],
          modelVersion: model
        })}

`);
      } catch {
      }
    }
  });
  stream$1.on("end", () => output.end());
  stream$1.on("error", (error) => output.destroy(error));
  return output;
}
const router$9 = new Router();
const generateContentRoutePattern = /^\/v1beta\/models\/(.+):generateContent$/;
const streamGenerateContentRoutePattern = /^\/v1beta\/models\/(.+):streamGenerateContent$/;
function requestId() {
  return `gemini-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
function getModelResource(model, ownedBy = "chat2api") {
  return {
    name: `models/${model}`,
    version: model,
    displayName: model,
    description: `Chat2API routed model ${model}`,
    inputTokenLimit: 1048576,
    outputTokenLimit: 65536,
    supportedGenerationMethods: ["generateContent", "streamGenerateContent"],
    owned_by: ownedBy
  };
}
function selectModel(model) {
  const config = server_bootstrapConfig.storeManager.getConfig();
  const selection = loadBalancer.selectAccount(
    model,
    config.loadBalanceStrategy,
    modelMapper.getPreferredProvider(model),
    modelMapper.getPreferredAccount(model)
  );
  return selection;
}
async function forwardGemini(ctx, stream2) {
  const model = ctx.params.model;
  const startTime = Date.now();
  const selection = selectModel(model);
  if (!selection) {
    ctx.status = 503;
    ctx.body = {
      error: {
        code: 503,
        message: `No available account for model: ${model}`,
        status: "UNAVAILABLE"
      }
    };
    return;
  }
  const { account, provider, actualModel } = selection;
  const chatRequest = {
    ...geminiToChatCompletionRequest(model, ctx.request.body || {}),
    stream: stream2
  };
  const context = {
    requestId: requestId(),
    providerId: provider.id,
    accountId: account.id,
    model,
    actualModel,
    startTime,
    isStream: stream2,
    clientIP: ctx.ip
  };
  proxyStatusManager.recordRequestStart(model, provider.id, account.id);
  const result = await requestForwarder.forwardChatCompletion(chatRequest, account, provider, actualModel, context);
  if (!result.success) {
    proxyStatusManager.recordRequestFailure(Date.now() - startTime);
    ctx.status = result.status || 500;
    ctx.body = {
      error: {
        code: ctx.status,
        message: result.error || "Gemini-compatible request failed",
        status: "INTERNAL"
      }
    };
    return;
  }
  proxyStatusManager.recordRequestSuccess(Date.now() - startTime);
  if (stream2 && result.stream) {
    ctx.set("Content-Type", "text/event-stream");
    ctx.set("Cache-Control", "no-cache");
    ctx.body = result.skipTransform ? chatCompletionStreamToGeminiSse(result.stream, actualModel) : chatCompletionStreamToGeminiSse(result.stream, actualModel);
    return;
  }
  ctx.set("Content-Type", "application/json");
  ctx.body = chatCompletionToGeminiResponse(result.body, actualModel);
}
function setCapturedModelParam(ctx) {
  const captures = ctx.captures || [];
  const model = captures[0] || "";
  ctx.params = {
    ...ctx.params,
    model: decodeURIComponent(model.replace(/^models\//, ""))
  };
}
router$9.get("/v1beta/models", async (ctx) => {
  const providers = server_bootstrapConfig.storeManager.getProviders().filter((provider) => provider.enabled);
  const models = [];
  const added = /* @__PURE__ */ new Set();
  for (const provider of providers) {
    const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(provider.id).filter((account) => account.status === "active");
    if (accounts.length === 0) continue;
    for (const model of server_bootstrapConfig.storeManager.getEffectiveModels(provider.id)) {
      if (added.has(model.displayName)) continue;
      added.add(model.displayName);
      models.push(getModelResource(model.displayName, provider.name));
    }
  }
  ctx.body = { models };
});
router$9.get("/v1beta/models/:model", async (ctx) => {
  ctx.body = getModelResource(ctx.params.model);
});
router$9.post(generateContentRoutePattern, async (ctx) => {
  setCapturedModelParam(ctx);
  await forwardGemini(ctx, false);
});
router$9.post(streamGenerateContentRoutePattern, async (ctx) => {
  setCapturedModelParam(ctx);
  await forwardGemini(ctx, true);
});
router$9.post("/upload/v1beta/files", async (ctx) => {
  try {
    const file = ctx.get("X-Goog-Upload-Protocol") ? geminiFileStore.createUploadSession(ctx) : geminiFileStore.createSimpleFile(ctx);
    ctx.body = { file };
  } catch (error) {
    ctx.status = 400;
    ctx.body = { error: { message: error instanceof Error ? error.message : "Gemini file upload failed" } };
  }
});
router$9.post("/upload/v1beta/files/:id", async (ctx) => {
  try {
    const file = geminiFileStore.storeUploadChunk(ctx.params.id, ctx);
    ctx.body = { file };
  } catch (error) {
    ctx.status = 400;
    ctx.body = { error: { message: error instanceof Error ? error.message : "Gemini file upload failed" } };
  }
});
router$9.get("/v1beta/files/:id", async (ctx) => {
  const file = geminiFileStore.getFile(`files/${ctx.params.id}`);
  if (!file) {
    ctx.status = 404;
    ctx.body = { error: { message: `File not found: files/${ctx.params.id}` } };
    return;
  }
  ctx.body = { file };
});
router$9.delete("/v1beta/files/:id", async (ctx) => {
  geminiFileStore.deleteFile(`files/${ctx.params.id}`);
  ctx.status = 200;
  ctx.body = {};
});
const routes = [
  router$c,
  router$b,
  router$a,
  router$9
];
function generateManagementSecret() {
  const uuid2 = crypto$1.randomUUID();
  return `mgmt_${uuid2}`;
}
function createUnauthorizedResponse(message, code) {
  return {
    success: false,
    error: {
      code,
      message
    }
  };
}
function extractAuthToken(ctx) {
  const authHeader = ctx.get("Authorization");
  if (authHeader) {
    if (authHeader.startsWith("Bearer ")) {
      return authHeader.slice(7).trim();
    }
  }
  const secretHeader = ctx.get("X-Management-Secret");
  if (secretHeader) {
    return secretHeader.trim();
  }
  return null;
}
async function managementAuthMiddleware(ctx, next) {
  const config = server_bootstrapConfig.storeManager.getConfig();
  const managementConfig = config.managementApi;
  if (!managementConfig.enableManagementApi) {
    ctx.status = 404;
    ctx.body = createUnauthorizedResponse(
      "Management API is not enabled",
      "management_api_disabled"
    );
    return;
  }
  if (!managementConfig.managementApiSecret) {
    ctx.status = 500;
    ctx.body = createUnauthorizedResponse(
      "Management API secret is not configured",
      "management_api_misconfigured"
    );
    return;
  }
  const providedToken = extractAuthToken(ctx);
  if (!providedToken) {
    ctx.status = 401;
    ctx.body = createUnauthorizedResponse(
      "Authentication required. Provide Authorization: Bearer <secret> or X-Management-Secret header",
      "missing_authentication"
    );
    return;
  }
  if (providedToken !== managementConfig.managementApiSecret) {
    ctx.status = 401;
    ctx.body = createUnauthorizedResponse(
      "Invalid management API secret",
      "invalid_secret"
    );
    return;
  }
  await next();
}
class ConfigManager {
  /**
   * Get complete configuration
   */
  static get() {
    return server_bootstrapConfig.storeManager.getConfig();
  }
  /**
   * Update configuration
   * @param updates Configuration items to update
   * @returns Updated complete configuration
   */
  static update(updates) {
    const current = this.get();
    ({ ...current, ...updates });
    const updated = server_bootstrapConfig.storeManager.updateConfig(updates);
    server_bootstrapConfig.storeManager.addLog("info", "Update app configuration", {
      data: { updates }
    });
    return updated;
  }
  /**
   * Reset configuration to default values
   * @returns Default configuration
   */
  static reset() {
    server_bootstrapConfig.storeManager.resetConfig();
    server_bootstrapConfig.storeManager.addLog("info", "Reset app configuration to default values");
    return server_bootstrapConfig.DEFAULT_CONFIG;
  }
  // ==================== Proxy Configuration ====================
  /**
   * Get proxy port
   */
  static getProxyPort() {
    const config = this.get();
    return config.proxyPort;
  }
  /**
   * Set proxy port
   * @param port Port number
   */
  static setProxyPort(port) {
    if (port < 1 || port > 65535) {
      throw new Error("Port number must be between 1-65535");
    }
    this.update({ proxyPort: port });
  }
  /**
   * Get load balance strategy
   */
  static getLoadBalanceStrategy() {
    const config = this.get();
    return config.loadBalanceStrategy;
  }
  /**
   * Set load balance strategy
   * @param strategy Strategy type
   */
  static setLoadBalanceStrategy(strategy) {
    this.update({ loadBalanceStrategy: strategy });
  }
  // ==================== Model Mapping Configuration ====================
  /**
   * Get all model mappings
   */
  static getModelMappings() {
    const config = this.get();
    return config.modelMappings;
  }
  /**
   * Get mapping config for specified model
   * @param model Model name
   */
  static getModelMapping(model) {
    const mappings = this.getModelMappings();
    return mappings[model];
  }
  /**
   * Add or update model mapping
   * @param mapping Mapping config
   */
  static setModelMapping(mapping) {
    const config = this.get();
    const mappings = { ...config.modelMappings };
    mappings[mapping.requestModel] = mapping;
    this.update({ modelMappings: mappings });
    server_bootstrapConfig.storeManager.addLog("info", `Set model mapping: ${mapping.requestModel} -> ${mapping.actualModel}`);
  }
  /**
   * Delete model mapping
   * @param model Model name
   */
  static removeModelMapping(model) {
    const config = this.get();
    const mappings = { ...config.modelMappings };
    if (!(model in mappings)) {
      return false;
    }
    delete mappings[model];
    this.update({ modelMappings: mappings });
    server_bootstrapConfig.storeManager.addLog("info", `Delete model mapping: ${model}`);
    return true;
  }
  /**
   * Batch set model mappings
   * @param mappings Mapping config list
   */
  static setModelMappings(mappings) {
    const mappingRecord = {};
    for (const mapping of mappings) {
      mappingRecord[mapping.requestModel] = mapping;
    }
    this.update({ modelMappings: mappingRecord });
    server_bootstrapConfig.storeManager.addLog("info", `Batch set model mappings: ${mappings.length} items`);
  }
  /**
   * Resolve actual model to use
   * @param requestedModel Requested model name
   * @returns Actual model name to use
   */
  static resolveActualModel(requestedModel) {
    const mapping = this.getModelMapping(requestedModel);
    return mapping?.actualModel || requestedModel;
  }
  // ==================== UI Configuration ====================
  /**
   * Get theme setting
   */
  static getTheme() {
    const config = this.get();
    return config.theme;
  }
  /**
   * Set theme
   * @param theme Theme type
   */
  static setTheme(theme) {
    this.update({ theme });
  }
  /**
   * Get auto-start on boot setting
   */
  static getAutoStart() {
    const config = this.get();
    return config.autoStart;
  }
  /**
   * Set auto-start on boot
   * @param autoStart Whether to auto-start on boot
   */
  static setAutoStart(autoStart) {
    this.update({ autoStart });
  }
  /**
   * Get minimize to tray setting
   */
  static getMinimizeToTray() {
    const config = this.get();
    return config.minimizeToTray;
  }
  /**
   * Set minimize to tray
   * @param minimizeToTray Whether to minimize to tray
   */
  static setMinimizeToTray(minimizeToTray) {
    this.update({ minimizeToTray });
  }
  // ==================== Log Configuration ====================
  /**
   * Get log level
   */
  static getLogLevel() {
    const config = this.get();
    return config.logLevel;
  }
  /**
   * Set log level
   * @param level Log level
   */
  static setLogLevel(level) {
    this.update({ logLevel: level });
  }
  /**
   * Get log retention days
   */
  static getLogRetentionDays() {
    const config = this.get();
    return config.logRetentionDays;
  }
  /**
   * Set log retention days
   * @param days Number of days
   */
  static setLogRetentionDays(days) {
    if (days < 1 || days > 365) {
      throw new Error("Log retention days must be between 1-365");
    }
    this.update({ logRetentionDays: days });
  }
  // ==================== Request Configuration ====================
  /**
   * Get request timeout
   */
  static getRequestTimeout() {
    const config = this.get();
    return config.requestTimeout;
  }
  /**
   * Set request timeout
   * @param timeout Timeout in milliseconds
   */
  static setRequestTimeout(timeout) {
    if (timeout < 1e3 || timeout > 3e5) {
      throw new Error("Request timeout must be between 1000-300000 milliseconds");
    }
    this.update({ requestTimeout: timeout });
  }
  /**
   * Get retry count
   */
  static getRetryCount() {
    const config = this.get();
    return config.retryCount;
  }
  /**
   * Set retry count
   * @param count Retry count
   */
  static setRetryCount(count) {
    if (count < 0 || count > 10) {
      throw new Error("Retry count must be between 0-10");
    }
    this.update({ retryCount: count });
  }
  // ==================== Utility Methods ====================
  /**
   * Validate if configuration is valid
   * @param config Configuration to validate
   * @returns Validation result
   */
  static validate(config) {
    const errors = [];
    if (config.proxyPort !== void 0) {
      if (config.proxyPort < 1 || config.proxyPort > 65535) {
        errors.push("Proxy port must be between 1-65535");
      }
    }
    if (config.logRetentionDays !== void 0) {
      if (config.logRetentionDays < 1 || config.logRetentionDays > 365) {
        errors.push("Log retention days must be between 1-365");
      }
    }
    if (config.requestTimeout !== void 0) {
      if (config.requestTimeout < 1e3 || config.requestTimeout > 3e5) {
        errors.push("Request timeout must be between 1000-300000 milliseconds");
      }
    }
    if (config.retryCount !== void 0) {
      if (config.retryCount < 0 || config.retryCount > 10) {
        errors.push("Retry count must be between 0-10");
      }
    }
    if (config.toolCallingConfig) {
      const normalized = server_bootstrapConfig.normalizeToolCallingConfig(config.toolCallingConfig);
      if (config.toolCallingConfig.mode !== void 0 && normalized.mode !== config.toolCallingConfig.mode) {
        errors.push("toolCallingConfig.mode must be one of: off, auto, force");
      }
      if (config.toolCallingConfig.clientAdapterId !== void 0 && !["standard-openai-tools", "cherry-studio-mcp"].includes(String(config.toolCallingConfig.clientAdapterId))) {
        errors.push("toolCallingConfig.clientAdapterId must be one of: standard-openai-tools, cherry-studio-mcp");
      }
    }
    return {
      valid: errors.length === 0,
      errors
    };
  }
  /**
   * Get configuration diff
   * @param newConfig New configuration
   * @returns Diff from default configuration
   */
  static getDiff(newConfig) {
    const diff = {};
    const current = this.get();
    for (const key of Object.keys(newConfig)) {
      if (JSON.stringify(current[key]) !== JSON.stringify(newConfig[key])) {
        diff[key] = newConfig[key];
      }
    }
    return diff;
  }
  /**
   * Export configuration (for backup)
   */
  static export() {
    return this.get();
  }
  /**
   * Import configuration (for restore)
   * @param config Configuration data
   */
  static import(config) {
    const validation = this.validate(config);
    if (!validation.valid) {
      return { success: false, errors: validation.errors };
    }
    this.update(config);
    server_bootstrapConfig.storeManager.addLog("info", "Import app configuration");
    return { success: true, errors: [] };
  }
}
const router$8 = new Router({ prefix: "/v0/management/config" });
router$8.use(managementAuthMiddleware);
const SENSITIVE_KEYS = ["managementApiSecret", "apiKeys", "credentials"];
function maskSensitiveValue(value, key) {
  if (typeof value === "string") {
    if (key && SENSITIVE_KEYS.some((k) => key.toLowerCase().includes(k.toLowerCase()))) {
      return "***";
    }
    return value;
  }
  if (Array.isArray(value)) {
    return value.map((item, index) => {
      if (typeof item === "object" && item !== null) {
        return maskSensitiveObject(item);
      }
      return maskSensitiveValue(item);
    });
  }
  if (typeof value === "object" && value !== null) {
    return maskSensitiveObject(value);
  }
  return value;
}
function maskSensitiveObject(obj) {
  const masked = {};
  for (const [key, value] of Object.entries(obj)) {
    if (key === "key" || key === "managementApiSecret" || key === "credentials") {
      masked[key] = "***";
    } else if (key === "apiKeys" && Array.isArray(value)) {
      masked[key] = value.map((apiKey) => ({
        ...apiKey,
        key: "***"
      }));
    } else if (typeof value === "object" && value !== null) {
      masked[key] = maskSensitiveValue(value, key);
    } else {
      masked[key] = value;
    }
  }
  return masked;
}
router$8.get("/", async (ctx) => {
  try {
    const config = ConfigManager.get();
    ctx.body = {
      success: true,
      data: config
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: {
        code: "internal_error",
        message: errorMessage
      }
    };
  }
});
router$8.put("/", async (ctx) => {
  try {
    const updates = ctx.request.body;
    if (!updates || typeof updates !== "object") {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: {
          code: "invalid_request",
          message: "Request body must be a valid configuration object"
        }
      };
      return;
    }
    const validation = ConfigManager.validate(updates);
    if (!validation.valid) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: {
          code: "validation_error",
          message: validation.errors.join("; "),
          details: { errors: validation.errors }
        }
      };
      return;
    }
    const updatedConfig = ConfigManager.update(updates);
    ctx.body = {
      success: true,
      data: updatedConfig
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: {
        code: "internal_error",
        message: errorMessage
      }
    };
  }
});
router$8.get("/:key", async (ctx) => {
  try {
    const key = ctx.params.key;
    const config = ConfigManager.get();
    if (!(key in config)) {
      ctx.status = 404;
      ctx.body = {
        success: false,
        error: {
          code: "config_key_not_found",
          message: `Configuration key '${key}' not found`
        }
      };
      return;
    }
    const value = config[key];
    const maskedValue = maskSensitiveValue(value, key);
    ctx.body = {
      success: true,
      data: maskedValue
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: {
        code: "internal_error",
        message: errorMessage
      }
    };
  }
});
router$8.put("/:key", async (ctx) => {
  try {
    const key = ctx.params.key;
    const { value } = ctx.request.body;
    if (value === void 0) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: {
          code: "invalid_request",
          message: 'Request body must contain a "value" field'
        }
      };
      return;
    }
    const config = ConfigManager.get();
    if (!(key in config)) {
      ctx.status = 404;
      ctx.body = {
        success: false,
        error: {
          code: "config_key_not_found",
          message: `Configuration key '${key}' not found`
        }
      };
      return;
    }
    const updates = { [key]: value };
    const validation = ConfigManager.validate(updates);
    if (!validation.valid) {
      ctx.status = 400;
      ctx.body = {
        success: false,
        error: {
          code: "validation_error",
          message: validation.errors.join("; "),
          details: { errors: validation.errors }
        }
      };
      return;
    }
    const updatedConfig = ConfigManager.update(updates);
    const maskedValue = maskSensitiveValue(updatedConfig[key], key);
    ctx.body = {
      success: true,
      data: maskedValue
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: {
        code: "internal_error",
        message: errorMessage
      }
    };
  }
});
class ProviderManager {
  /**
   * Get All Providers
   */
  static getAll() {
    return server_bootstrapConfig.storeManager.getProviders();
  }
  /**
   * Get Provider By ID
   * @param id Provider ID
   */
  static getById(id) {
    return server_bootstrapConfig.storeManager.getProviderById(id);
  }
  /**
   * Get All Enabled Providers
   */
  static getEnabled() {
    const providers = server_bootstrapConfig.storeManager.getProviders();
    return providers.filter((p) => p.enabled);
  }
  /**
   * Get Providers By Type
   * @param type Provider type
   */
  static getByType(type) {
    const providers = server_bootstrapConfig.storeManager.getProviders();
    return providers.filter((p) => p.type === type);
  }
  /**
   * Get Providers By Auth Type
   * @param authType Authentication type
   */
  static getByAuthType(authType) {
    const providers = server_bootstrapConfig.storeManager.getProviders();
    return providers.filter((p) => p.authType === authType);
  }
  /**
   * Create Provider
   * @param data Provider data
   * @returns Created provider
   */
  static create(data) {
    const existing = server_bootstrapConfig.storeManager.getProviders();
    if (data.id) {
      const existingById = existing.find((p) => p.id === data.id);
      if (existingById) {
        return existingById;
      }
    }
    const nameExists = existing.some(
      (p) => p.name.toLowerCase() === data.name.toLowerCase()
    );
    if (nameExists) {
      const existingByName = existing.find(
        (p) => p.name.toLowerCase() === data.name.toLowerCase()
      );
      if (existingByName) {
        return existingByName;
      }
    }
    const now = Date.now();
    const provider = {
      id: data.id || server_bootstrapConfig.storeManager.generateId(),
      name: data.name,
      type: data.type || "custom",
      authType: data.authType,
      apiEndpoint: data.apiEndpoint,
      chatPath: data.chatPath,
      headers: data.headers || {},
      enabled: true,
      createdAt: now,
      updatedAt: now,
      description: data.description,
      icon: data.icon,
      supportedModels: data.supportedModels,
      modelMappings: data.modelMappings,
      modelsApiEndpoint: data.modelsApiEndpoint,
      modelsApiHeaders: data.modelsApiHeaders,
      credentialFields: data.credentialFields
    };
    server_bootstrapConfig.storeManager.addProvider(provider);
    server_bootstrapConfig.storeManager.addLog("info", `Create provider: ${provider.name}`, {
      providerId: provider.id
    });
    return provider;
  }
  /**
   * Update Provider
   * @param id Provider ID
   * @param updates Update data
   * @returns Updated provider
   */
  static update(id, updates) {
    const existing = server_bootstrapConfig.storeManager.getProviderById(id);
    if (!existing) {
      throw new Error(`Provider not found: ${id}`);
    }
    if (existing.type === "builtin") {
      const restricted = ["name", "authType", "apiEndpoint"];
      const hasRestricted = restricted.some((key) => key in updates);
      if (hasRestricted) {
        throw new Error("Built-in providers cannot modify core configuration");
      }
    }
    const updated = server_bootstrapConfig.storeManager.updateProvider(id, updates);
    if (updated) {
      server_bootstrapConfig.storeManager.addLog("info", `Update provider: ${existing.name}`, {
        providerId: id
      });
    }
    return updated;
  }
  /**
   * Delete Provider
   * @param id Provider ID
   * @returns Whether deletion was successful
   */
  static delete(id) {
    const provider = server_bootstrapConfig.storeManager.getProviderById(id);
    if (!provider) {
      return false;
    }
    const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(id);
    for (const account of accounts) {
      server_bootstrapConfig.storeManager.deleteAccount(account.id);
    }
    const result = server_bootstrapConfig.storeManager.deleteProvider(id);
    if (result) {
      server_bootstrapConfig.storeManager.addLog("info", `Delete provider: ${provider.name}`, {
        providerId: id,
        deletedAccounts: accounts.length
      });
    }
    return result;
  }
  /**
   * Enable Provider
   * @param id Provider ID
   */
  static enable(id) {
    return this.update(id, { enabled: true });
  }
  /**
   * Disable Provider
   * @param id Provider ID
   */
  static disable(id) {
    return this.update(id, { enabled: false });
  }
  /**
   * Check if Provider Exists
   * @param id Provider ID
   */
  static exists(id) {
    return !!server_bootstrapConfig.storeManager.getProviderById(id);
  }
  /**
   * Get Provider's Account Count
   * @param id Provider ID
   */
  static getAccountCount(id) {
    const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(id);
    return accounts.length;
  }
  /**
   * Get Provider's Active Account Count
   * @param id Provider ID
   */
  static getActiveAccountCount(id) {
    const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(id);
    return accounts.filter((a) => a.status === "active").length;
  }
  /**
   * Reset Built-in Providers
   * Restore built-in providers to default configuration
   */
  static resetBuiltinProviders() {
    const providers = server_bootstrapConfig.storeManager.getProviders();
    const customProviders = providers.filter((p) => p.type === "custom");
    const now = Date.now();
    const defaultBuiltin = server_bootstrapConfig.builtinProviders.map((p) => ({
      ...p,
      createdAt: now,
      updatedAt: now
    }));
    const allProviders = [...defaultBuiltin, ...customProviders];
    server_bootstrapConfig.storeManager.getStore()?.set("providers", allProviders);
    server_bootstrapConfig.storeManager.addLog("info", "Reset built-in provider configuration");
  }
  /**
   * Get Provider's Supported Models List
   * @param id Provider ID
   */
  static getSupportedModels(id) {
    const provider = server_bootstrapConfig.storeManager.getProviderById(id);
    return provider?.supportedModels || [];
  }
  /**
   * Add Supported Model
   * @param id Provider ID
   * @param model Model name
   */
  static addSupportedModel(id, model) {
    const provider = server_bootstrapConfig.storeManager.getProviderById(id);
    if (!provider) {
      return null;
    }
    const models = provider.supportedModels || [];
    if (models.includes(model)) {
      return provider;
    }
    return this.update(id, {
      supportedModels: [...models, model]
    });
  }
  /**
   * Remove Supported Model
   * @param id Provider ID
   * @param model Model name
   */
  static removeSupportedModel(id, model) {
    const provider = server_bootstrapConfig.storeManager.getProviderById(id);
    if (!provider) {
      return null;
    }
    const models = provider.supportedModels || [];
    const filtered = models.filter((m) => m !== model);
    return this.update(id, { supportedModels: filtered });
  }
  /**
   * Get Provider Statistics
   */
  static getStatistics() {
    const providers = server_bootstrapConfig.storeManager.getProviders();
    return {
      total: providers.length,
      builtin: providers.filter((p) => p.type === "builtin").length,
      custom: providers.filter((p) => p.type === "custom").length,
      enabled: providers.filter((p) => p.enabled).length,
      disabled: providers.filter((p) => !p.enabled).length
    };
  }
  /**
   * Batch Update Provider Status
   * @param ids Provider ID list
   * @param enabled Whether to enable
   */
  static batchUpdateStatus(ids, enabled) {
    for (const id of ids) {
      const provider = server_bootstrapConfig.storeManager.getProviderById(id);
      if (provider) {
        server_bootstrapConfig.storeManager.updateProvider(id, { enabled });
      }
    }
    server_bootstrapConfig.storeManager.addLog("info", `Batch update provider status: ${ids.length} providers`, {
      data: { ids, enabled }
    });
  }
}
class CustomProviderManager {
  static validateName(name, existingId) {
    const errors = [];
    if (!name || name.trim().length === 0) {
      errors.push("Provider name cannot be empty");
    }
    if (name.length > 50) {
      errors.push("Provider name cannot exceed 50 characters");
    }
    const existing = server_bootstrapConfig.storeManager.getProviders();
    const duplicate = existing.find((p) => p.name.toLowerCase() === name.toLowerCase());
    if (duplicate && duplicate.id !== existingId) {
      errors.push("Provider name already exists");
    }
    return { valid: errors.length === 0, errors };
  }
  static validateApiEndpoint(endpoint) {
    const errors = [];
    if (!endpoint || endpoint.trim().length === 0) {
      errors.push("API endpoint cannot be empty");
    }
    try {
      new URL(endpoint);
    } catch {
      errors.push("Invalid API endpoint format");
    }
    if (!endpoint.startsWith("http://") && !endpoint.startsWith("https://")) {
      errors.push("API endpoint must start with http:// or https://");
    }
    return { valid: errors.length === 0, errors };
  }
  static validateAuthType(authType) {
    const validAuthTypes = [
      "oauth",
      "token",
      "cookie",
      "userToken",
      "refresh_token",
      "jwt",
      "realUserID_token",
      "tongyi_sso_ticket"
    ];
    if (!validAuthTypes.includes(authType)) {
      return { valid: false, errors: ["Invalid authentication type"] };
    }
    return { valid: true, errors: [] };
  }
  static validateHeaders(headers) {
    const errors = [];
    for (const [key, value] of Object.entries(headers)) {
      if (!key || key.trim().length === 0) {
        errors.push("Header name cannot be empty");
      }
      if (key.includes(":") || key.includes("\n")) {
        errors.push(`Header name "${key}" contains invalid characters`);
      }
    }
    return { valid: errors.length === 0, errors };
  }
  static validateCredentialFields(fields) {
    const errors = [];
    if (!fields || fields.length === 0) {
      return { valid: true, errors: [] };
    }
    const names = /* @__PURE__ */ new Set();
    for (const field of fields) {
      if (!field.name || field.name.trim().length === 0) {
        errors.push("Credential field name cannot be empty");
      }
      if (names.has(field.name)) {
        errors.push(`Duplicate credential field name "${field.name}"`);
      }
      names.add(field.name);
      if (!field.label || field.label.trim().length === 0) {
        errors.push(`Label for credential field "${field.name}" cannot be empty`);
      }
      const validTypes = ["text", "password", "textarea"];
      if (!validTypes.includes(field.type)) {
        errors.push(`Invalid type for credential field "${field.name}"`);
      }
    }
    return { valid: errors.length === 0, errors };
  }
  static validate(data) {
    const errors = [];
    const nameValidation = this.validateName(data.name, data.id);
    errors.push(...nameValidation.errors);
    const endpointValidation = this.validateApiEndpoint(data.apiEndpoint);
    errors.push(...endpointValidation.errors);
    const authTypeValidation = this.validateAuthType(data.authType);
    errors.push(...authTypeValidation.errors);
    if (data.headers) {
      const headersValidation = this.validateHeaders(data.headers);
      errors.push(...headersValidation.errors);
    }
    if (data.credentialFields) {
      const fieldsValidation = this.validateCredentialFields(data.credentialFields);
      errors.push(...fieldsValidation.errors);
    }
    return { valid: errors.length === 0, errors };
  }
  static create(data) {
    if (data.id) {
      const existing = server_bootstrapConfig.storeManager.getProviderById(data.id);
      if (existing) {
        return existing;
      }
    }
    const validation = this.validate(data);
    if (!validation.valid) {
      throw new Error(`Validation failed: ${validation.errors.join(", ")}`);
    }
    const now = Date.now();
    const provider = {
      id: data.id || server_bootstrapConfig.storeManager.generateId(),
      name: data.name.trim(),
      type: data.type || "custom",
      authType: data.authType,
      apiEndpoint: data.apiEndpoint.trim(),
      chatPath: data.chatPath,
      headers: data.headers || {},
      enabled: true,
      createdAt: now,
      updatedAt: now,
      description: data.description?.trim(),
      icon: data.icon?.trim(),
      supportedModels: data.supportedModels || [],
      modelMappings: data.modelMappings,
      modelsApiEndpoint: data.modelsApiEndpoint,
      modelsApiHeaders: data.modelsApiHeaders,
      credentialFields: data.credentialFields
    };
    server_bootstrapConfig.storeManager.addProvider(provider);
    server_bootstrapConfig.storeManager.addLog("info", `Created provider: ${provider.name}`, {
      providerId: provider.id
    });
    return provider;
  }
  static update(id, updates) {
    const existing = server_bootstrapConfig.storeManager.getProviderById(id);
    if (!existing) {
      throw new Error(`Provider not found: ${id}`);
    }
    if (existing.type === "builtin") {
      throw new Error("Cannot modify built-in provider");
    }
    if (updates.name && updates.name !== existing.name) {
      const nameValidation = this.validateName(updates.name);
      if (!nameValidation.valid) {
        throw new Error(nameValidation.errors.join(", "));
      }
    }
    if (updates.apiEndpoint) {
      const endpointValidation = this.validateApiEndpoint(updates.apiEndpoint);
      if (!endpointValidation.valid) {
        throw new Error(endpointValidation.errors.join(", "));
      }
    }
    if (updates.authType) {
      const authTypeValidation = this.validateAuthType(updates.authType);
      if (!authTypeValidation.valid) {
        throw new Error(authTypeValidation.errors.join(", "));
      }
    }
    if (updates.headers) {
      const headersValidation = this.validateHeaders(updates.headers);
      if (!headersValidation.valid) {
        throw new Error(headersValidation.errors.join(", "));
      }
    }
    const updated = server_bootstrapConfig.storeManager.updateProvider(id, {
      ...updates,
      updatedAt: Date.now()
    });
    if (updated) {
      server_bootstrapConfig.storeManager.addLog("info", `Updated custom provider: ${existing.name}`, {
        providerId: id
      });
    }
    return updated;
  }
  static delete(id) {
    const provider = server_bootstrapConfig.storeManager.getProviderById(id);
    if (!provider) {
      return false;
    }
    const accounts = server_bootstrapConfig.storeManager.getAccountsByProviderId(id);
    for (const account of accounts) {
      server_bootstrapConfig.storeManager.deleteAccount(account.id);
    }
    const result = server_bootstrapConfig.storeManager.deleteProvider(id);
    if (result) {
      server_bootstrapConfig.storeManager.addLog("info", `Deleted provider: ${provider.name}`, {
        providerId: id
      });
    }
    return result;
  }
  static duplicate(id, newName) {
    const existing = server_bootstrapConfig.storeManager.getProviderById(id);
    if (!existing) {
      throw new Error(`Provider not found: ${id}`);
    }
    const name = newName || `${existing.name} (Copy)`;
    return this.create({
      name,
      authType: existing.authType,
      apiEndpoint: existing.apiEndpoint,
      headers: { ...existing.headers },
      description: existing.description,
      icon: existing.icon,
      supportedModels: existing.supportedModels ? [...existing.supportedModels] : []
    });
  }
  static exportProvider(id) {
    const provider = server_bootstrapConfig.storeManager.getProviderById(id);
    if (!provider) {
      throw new Error(`Provider not found: ${id}`);
    }
    const exportData = {
      name: provider.name,
      authType: provider.authType,
      apiEndpoint: provider.apiEndpoint,
      headers: provider.headers,
      description: provider.description,
      icon: provider.icon,
      supportedModels: provider.supportedModels
    };
    return JSON.stringify(exportData, null, 2);
  }
  static importProvider(jsonData) {
    let data;
    try {
      data = JSON.parse(jsonData);
    } catch {
      throw new Error("Invalid JSON format");
    }
    return this.create(data);
  }
  static getTemplate(authType) {
    const baseTemplate = {
      name: "",
      authType,
      apiEndpoint: "",
      headers: {
        "Content-Type": "application/json"
      },
      description: "",
      supportedModels: []
    };
    switch (authType) {
      case "token":
        return {
          ...baseTemplate,
          credentialFields: [
            {
              name: "apiKey",
              label: "API Key",
              type: "password",
              required: true,
              placeholder: "Enter API Key"
            }
          ]
        };
      case "userToken":
        return {
          ...baseTemplate,
          credentialFields: [
            {
              name: "token",
              label: "User Token",
              type: "password",
              required: true,
              placeholder: "Enter User Token"
            }
          ]
        };
      case "refresh_token":
        return {
          ...baseTemplate,
          credentialFields: [
            {
              name: "refresh_token",
              label: "Refresh Token",
              type: "password",
              required: true,
              placeholder: "Enter Refresh Token"
            }
          ]
        };
      case "jwt":
        return {
          ...baseTemplate,
          credentialFields: [
            {
              name: "token",
              label: "JWT Token",
              type: "password",
              required: true,
              placeholder: "Enter JWT Token"
            }
          ]
        };
      case "realUserID_token":
        return {
          ...baseTemplate,
          credentialFields: [
            {
              name: "realUserID",
              label: "User ID",
              type: "text",
              required: true,
              placeholder: "Enter User ID"
            },
            {
              name: "token",
              label: "JWT Token",
              type: "password",
              required: true,
              placeholder: "Enter JWT Token"
            }
          ]
        };
      case "tongyi_sso_ticket":
        return {
          ...baseTemplate,
          credentialFields: [
            {
              name: "ticket",
              label: "SSO Ticket",
              type: "password",
              required: true,
              placeholder: "Enter SSO Ticket"
            }
          ]
        };
      case "cookie":
        return {
          ...baseTemplate,
          credentialFields: [
            {
              name: "cookie",
              label: "Cookie",
              type: "textarea",
              required: true,
              placeholder: "Enter Cookie"
            }
          ]
        };
      case "oauth":
        return {
          ...baseTemplate,
          credentialFields: [],
          description: "OAuth authentication provider"
        };
      default:
        return baseTemplate;
    }
  }
}
function extractModelsPayload(responseData) {
  if (Array.isArray(responseData)) {
    return responseData;
  }
  if (!responseData || typeof responseData !== "object") {
    return [];
  }
  const data = responseData.data;
  if (Array.isArray(data)) {
    return data;
  }
  if (data && typeof data === "object") {
    const nestedData = data.data;
    if (Array.isArray(nestedData)) {
      return nestedData;
    }
  }
  return [];
}
function parseProviderModelsResponse(responseData) {
  const models = extractModelsPayload(responseData);
  const supportedModels = [];
  const modelMappings = {};
  for (const model of models) {
    if (typeof model === "string") {
      supportedModels.push(model);
      modelMappings[model] = model;
      continue;
    }
    if (!model || typeof model !== "object") {
      continue;
    }
    const candidate = model;
    const modelId = String(candidate.id || candidate.model_id || candidate.name || "");
    const modelName = String(candidate.name || candidate.display_name || modelId);
    if (modelId) {
      supportedModels.push(modelName);
      modelMappings[modelName] = modelId;
    }
  }
  return { supportedModels, modelMappings };
}
const CHECK_TIMEOUT = 15e3;
class ProviderChecker {
  static async checkProviderStatus(provider) {
    const startTime = Date.now();
    try {
      const builtinConfig = provider.type === "builtin" ? server_bootstrapConfig.getBuiltinProvider(provider.id) : null;
      if (builtinConfig) {
        return await this.checkBuiltinProvider(builtinConfig);
      }
      return await this.checkCustomProvider(provider);
    } catch (error) {
      return {
        providerId: provider.id,
        status: "offline",
        latency: Date.now() - startTime,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  static async checkBuiltinProvider(config) {
    const startTime = Date.now();
    try {
      const checkUrl = `${config.apiEndpoint.replace("/api", "")}${config.tokenCheckEndpoint || "/health"}`;
      const response = await axios({
        method: "GET",
        url: checkUrl,
        timeout: CHECK_TIMEOUT,
        validateStatus: () => true
      });
      const latency = Date.now() - startTime;
      if (response.status >= 200 && response.status < 500) {
        return {
          providerId: config.id,
          status: "online",
          latency
        };
      }
      return {
        providerId: config.id,
        status: "offline",
        latency,
        error: `HTTP ${response.status}`
      };
    } catch (error) {
      return {
        providerId: config.id,
        status: "offline",
        latency: Date.now() - startTime,
        error: error instanceof Error ? error.message : "Connection failed"
      };
    }
  }
  static async checkCustomProvider(provider) {
    const startTime = Date.now();
    try {
      const response = await axios({
        method: "GET",
        url: `${provider.apiEndpoint}/models`,
        headers: provider.headers,
        timeout: CHECK_TIMEOUT,
        validateStatus: () => true
      });
      const latency = Date.now() - startTime;
      if (response.status >= 200 && response.status < 500) {
        return {
          providerId: provider.id,
          status: "online",
          latency
        };
      }
      return {
        providerId: provider.id,
        status: "offline",
        latency,
        error: `HTTP ${response.status}`
      };
    } catch (error) {
      return {
        providerId: provider.id,
        status: "offline",
        latency: Date.now() - startTime,
        error: error instanceof Error ? error.message : "Connection failed"
      };
    }
  }
  static async checkAccountToken(provider, account) {
    const builtinConfig = provider.type === "builtin" ? server_bootstrapConfig.getBuiltinProvider(provider.id) : null;
    if (!builtinConfig) {
      return this.checkCustomAccountToken(provider, account);
    }
    switch (provider.id) {
      case "deepseek":
        return this.checkDeepSeekToken(account.credentials.token);
      case "glm":
        return this.checkGLMToken(account.credentials.refresh_token);
      case "kimi":
        return this.checkKimiToken(account.credentials.token);
      case "minimax":
        return this.checkMiniMaxToken(
          account.credentials.realUserID || "",
          account.credentials.token
        );
      case "qwen":
        return this.checkQwenToken(account.credentials.ticket);
      case "qwen-ai":
        return this.checkQwenAiToken(account.credentials);
      case "perplexity":
        return this.checkPerplexityToken(account.credentials.sessionToken || account.credentials.token);
      case "mimo":
        return this.checkMimoToken(
          account.credentials.service_token,
          account.credentials.user_id,
          account.credentials.ph_token
        );
      default:
        if (!builtinConfig.tokenCheckEndpoint) {
          return { valid: true };
        }
        return this.checkGenericToken(builtinConfig, account);
    }
  }
  static checkMimoToken(serviceToken, userId, phToken) {
    if (!serviceToken || !userId || !phToken) {
      return { valid: false, error: "Missing required credentials: service_token, user_id, ph_token" };
    }
    return {
      valid: true,
      userInfo: {
        name: "Mimo User"
      }
    };
  }
  static async checkDeepSeekToken(token) {
    try {
      console.log("[DeepSeek] Validating Token:", token.substring(0, 20) + "...");
      const response = await axios.get(
        "https://chat.deepseek.com/api/v0/users/current",
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Origin": "https://chat.deepseek.com",
            "Referer": "https://chat.deepseek.com/"
          },
          timeout: CHECK_TIMEOUT,
          validateStatus: () => true
        }
      );
      console.log("[DeepSeek] Response status:", response.status);
      console.log("[DeepSeek] Response data:", JSON.stringify(response.data, null, 2));
      if (response.status === 200 && response.data?.code === 0 && response.data?.data?.biz_data) {
        const bizData = response.data.data.biz_data;
        return {
          valid: true,
          userInfo: {
            name: bizData.id_profile?.name,
            email: bizData.email
          }
        };
      }
      if (response.status === 401 || response.data?.code === 40003 || response.data?.data?.biz_code === 40003) {
        return { valid: false, error: "Token expired or invalid" };
      }
      return { valid: false, error: `Validation failed: ${response.data?.msg || response.data?.message || JSON.stringify(response.data)}` };
    } catch (error) {
      console.error("[DeepSeek] Validation error:", error);
      return {
        valid: false,
        error: error instanceof axios.AxiosError ? error.message : "Connection failed"
      };
    }
  }
  static async checkGLMToken(refreshToken) {
    try {
      console.log("[GLM] Validating Token:", refreshToken.substring(0, 20) + "...");
      const sign = await this.generateGLMSignV2();
      const response = await axios.post(
        "https://chatglm.cn/chatglm/user-api/user/refresh",
        {},
        {
          headers: {
            "Accept": "text/event-stream",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "App-Name": "chatglm",
            "Cache-Control": "no-cache",
            "Content-Type": "application/json",
            "Origin": "https://chatglm.cn",
            "Pragma": "no-cache",
            "Priority": "u=1, i",
            "Sec-Ch-Ua": '"Microsoft Edge";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "X-App-Fr": "browser_extension",
            "X-App-Platform": "pc",
            "X-App-Version": "0.0.1",
            "X-Device-Brand": "",
            "X-Device-Model": "",
            "X-Exp-Groups": "na_android_config:exp:NA,na_4o_config:exp:4o_A,tts_config:exp:tts_config_a,na_glm4plus_config:exp:open,mainchat_server_app:exp:A,mobile_history_daycheck:exp:a,desktop_toolbar:exp:A,chat_drawing_server:exp:A,drawing_server_cogview:exp:cogview4,app_welcome_v2:exp:A,chat_drawing_streamv2:exp:A,mainchat_rm_fc:exp:add,mainchat_dr:exp:open,chat_auto_entrance:exp:A,drawing_server_hi_dream:control:A,homepage_square:exp:close,assistant_recommend_prompt:exp:3,app_home_regular_user:exp:A,memory_common:exp:enable,mainchat_moe:exp:300,assistant_greet_user:exp:greet_user,app_welcome_personalize:exp:A,assistant_model_exp_group:exp:glm4.5,ai_wallet:exp:ai_wallet_enable",
            "X-Lang": "zh",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
            Authorization: `Bearer ${refreshToken}`,
            "X-Device-Id": this.generateUUID().replace(/-/g, ""),
            "X-Nonce": sign.nonce,
            "X-Request-Id": this.generateUUID().replace(/-/g, ""),
            "X-Sign": sign.sign,
            "X-Timestamp": `${sign.timestamp}`
          },
          timeout: CHECK_TIMEOUT,
          validateStatus: () => true
        }
      );
      console.log("[GLM] Response status:", response.status);
      console.log("[GLM] Response data:", JSON.stringify(response.data, null, 2));
      if (response.status === 200 && response.data?.result?.access_token) {
        return {
          valid: true,
          userInfo: {
            name: response.data.result.user?.name
          }
        };
      }
      if (response.status === 401 || response.data?.status === 40001) {
        return { valid: false, error: "Token expired or invalid" };
      }
      return { valid: false, error: `Validation failed: ${response.data?.message || response.data?.msg || JSON.stringify(response.data)}` };
    } catch (error) {
      console.error("[GLM] Validation error:", error);
      return {
        valid: false,
        error: error instanceof axios.AxiosError ? error.message : "Connection failed"
      };
    }
  }
  static async generateGLMSignV2() {
    const crypto2 = await import("crypto");
    const secret = "8a1317a7468aa3ad86e997d08f3f31cb";
    const now = Date.now();
    const timestampStr = now.toString();
    const len = timestampStr.length;
    const digits = timestampStr.split("").map((d) => parseInt(d));
    const sum = digits.reduce((a, b) => a + b, 0) - digits[len - 2];
    const checkDigit = sum % 10;
    const timestamp = timestampStr.substring(0, len - 2) + checkDigit + timestampStr.substring(len - 1);
    const nonce = this.generateUUID().replace(/-/g, "");
    const sign = crypto2.createHash("md5").update(`${timestamp}-${nonce}-${secret}`).digest("hex");
    return { timestamp, nonce, sign };
  }
  static async checkKimiToken(token) {
    try {
      console.log("[Kimi] Validating Token:", token.substring(0, 20) + "...");
      const response = await axios.post(
        "https://www.kimi.com/apiv2/kimi.gateway.order.v1.SubscriptionService/GetSubscription",
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            "Connect-Protocol-Version": "1",
            "Accept": "*/*",
            "Origin": "https://www.kimi.com",
            "Referer": "https://www.kimi.com/"
          },
          timeout: CHECK_TIMEOUT,
          validateStatus: () => true
        }
      );
      console.log("[Kimi] Response status:", response.status);
      console.log("[Kimi] Response data:", JSON.stringify(response.data, null, 2));
      if (response.status === 200 && response.data?.subscription) {
        return {
          valid: true,
          userInfo: {
            name: response.data.subscription.userName
          }
        };
      }
      return { valid: false, error: "Token expired or invalid" };
    } catch (error) {
      console.error("[Kimi] Validation error:", error);
      return {
        valid: false,
        error: error instanceof axios.AxiosError ? error.message : "Connection failed"
      };
    }
  }
  static async checkMiniMaxToken(_realUserID, token) {
    try {
      console.log("[MiniMax] Validating Token:", token.substring(0, 30) + "...");
      const crypto2 = await import("crypto");
      let realUserID = "";
      let jwtToken = token;
      if (token.includes("+")) {
        const parts = token.split("+");
        realUserID = parts[0];
        jwtToken = parts[1];
      } else {
        try {
          const parts = token.split(".");
          if (parts.length >= 2) {
            let payload = parts[1];
            const padding = payload.length % 4;
            if (padding > 0) {
              payload += "=".repeat(4 - padding);
            }
            payload = payload.replace(/-/g, "+").replace(/_/g, "/");
            const decoded = Buffer.from(payload, "base64").toString("utf8");
            const data = JSON.parse(decoded);
            realUserID = data.user?.id || data.id || data.sub || "";
            console.log("[MiniMax] Extracted userId from token:", realUserID);
          }
        } catch (e) {
          console.log("[MiniMax] Failed to parse JWT:", e);
        }
      }
      if (!realUserID) {
        return { valid: false, error: "Cannot extract user ID from token" };
      }
      const uuid2 = realUserID;
      const unix = Date.now().toString();
      const timestamp = Math.floor(Date.now() / 1e3);
      const dataJson = JSON.stringify({ uuid: uuid2 });
      const signature = crypto2.createHash("md5").update(`${timestamp}${jwtToken}${dataJson}`).digest("hex");
      const queryParams = new URLSearchParams({
        device_platform: "web",
        biz_id: "3",
        app_id: "3001",
        version_code: "22201",
        uuid: uuid2,
        user_id: realUserID
      }).toString();
      const fullUri = `/v1/api/user/device/register?${queryParams}`;
      const yy = crypto2.createHash("md5").update(`${encodeURIComponent(fullUri)}_${dataJson}${crypto2.createHash("md5").update(unix).digest("hex")}ooui`).digest("hex");
      const response = await axios.post(
        `https://agent.minimaxi.com${fullUri}`,
        { uuid: uuid2 },
        {
          headers: {
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Cache-Control": "no-cache",
            "Content-Type": "application/json",
            "Origin": "https://agent.minimaxi.com",
            "Pragma": "no-cache",
            "Referer": "https://agent.minimaxi.com/",
            "Sec-Ch-Ua": '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"macOS"',
            "Sec-Fetch-Dest": "empty",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Site": "same-origin",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
            "token": jwtToken,
            "x-timestamp": String(timestamp),
            "x-signature": signature,
            "yy": yy
          },
          timeout: CHECK_TIMEOUT,
          validateStatus: () => true
        }
      );
      console.log("[MiniMax] Response status:", response.status);
      console.log("[MiniMax] Response data:", JSON.stringify(response.data, null, 2));
      if (response.status === 200 && response.data?.data?.deviceIDStr) {
        const userInfo = response.data.data.userInfo;
        return {
          valid: true,
          userInfo: {
            name: userInfo?.name || userInfo?.nickname,
            email: userInfo?.email
          }
        };
      }
      if (response.data?.statusInfo?.code === 1001) {
        return { valid: false, error: "Token expired or invalid" };
      }
      return { valid: false, error: `Validation failed: ${response.data?.statusInfo?.message || "Unknown error"}` };
    } catch (error) {
      console.error("[MiniMax] Validation error:", error);
      return {
        valid: false,
        error: error instanceof axios.AxiosError ? error.message : "Connection failed"
      };
    }
  }
  static async checkQwenToken(ticket) {
    try {
      const response = await axios.post(
        "https://chat2-api.qianwen.com/api/v2/session/page/list",
        {},
        {
          headers: {
            Cookie: `tongyi_sso_ticket=${ticket}`,
            "Content-Type": "application/json",
            "Accept": "*/*",
            "Origin": "https://www.qianwen.com",
            "Referer": "https://www.qianwen.com/",
            "X-Platform": "pc_tongyi",
            "X-DeviceId": "5b68c267-cd8e-fd0e-148a-18345bc9a104"
          },
          params: {
            biz_id: "ai_qwen",
            chat_client: "h5",
            device: "pc",
            fr: "pc",
            pr: "qwen",
            ut: "5b68c267-cd8e-fd0e-148a-18345bc9a104"
          },
          timeout: CHECK_TIMEOUT,
          validateStatus: () => true
        }
      );
      if (response.status === 200 && response.data?.success) {
        return {
          valid: true
        };
      }
      if (!response.data?.success) {
        return { valid: false, error: "SSO ticket expired or invalid" };
      }
      return { valid: false, error: `Validation failed: ${response.data?.errorMsg || "Unknown error"}` };
    } catch (error) {
      return {
        valid: false,
        error: error instanceof axios.AxiosError ? error.message : "Connection failed"
      };
    }
  }
  static getQwenAiCookieHeader(cookies) {
    if (typeof cookies === "string") {
      return cookies;
    }
    if (cookies && typeof cookies === "object" && !Array.isArray(cookies)) {
      return Object.entries(cookies).filter(([, value]) => typeof value === "string" && value).map(([key, value]) => `${key}=${value}`).join("; ");
    }
    return "";
  }
  static async checkQwenAiToken(credentials) {
    const token = typeof credentials.token === "string" ? credentials.token : "";
    if (!token) {
      return { valid: false, error: "Token is required" };
    }
    try {
      const headers = {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        Accept: "application/json",
        source: "web",
        Version: "0.2.67",
        Timezone: (/* @__PURE__ */ new Date()).toString().replace(/\s*\(.+\)$/, "")
      };
      const cookieHeader = this.getQwenAiCookieHeader(credentials.cookies || credentials.cookie);
      if (cookieHeader) {
        headers.Cookie = cookieHeader;
      }
      const response = await axios.get(
        "https://chat.qwen.ai/api/v2/users/user/settings",
        {
          headers,
          timeout: CHECK_TIMEOUT,
          validateStatus: () => true
        }
      );
      if (response.status === 200 && response.data?.success !== false && response.data?.data) {
        const userInfo = response.data.data.user || response.data.data.user_info || response.data.data;
        return {
          valid: true,
          userInfo: {
            name: userInfo.name || userInfo.email,
            email: userInfo.email
          }
        };
      }
      if (response.status === 401) {
        return { valid: false, error: "Token expired or invalid" };
      }
      const upstreamError = response.data?.message || response.data?.msg || response.data?.data?.details || response.data?.data?.code;
      return { valid: false, error: `Validation failed: HTTP ${response.status}${upstreamError ? ` ${upstreamError}` : ""}` };
    } catch (error) {
      return {
        valid: false,
        error: error instanceof axios.AxiosError ? error.message : "Connection failed"
      };
    }
  }
  static checkPerplexityToken(sessionToken) {
    if (!sessionToken) {
      return { valid: false, error: "Session token is required" };
    }
    if (sessionToken.length < 100) {
      return { valid: false, error: "Session token appears to be invalid (too short)" };
    }
    return {
      valid: true,
      userInfo: {
        name: "Perplexity User"
      }
    };
  }
  static async checkGenericToken(config, account) {
    try {
      const headers = {
        ...config.headers
      };
      const credentials = account.credentials;
      if (credentials.token) {
        headers["Authorization"] = `Bearer ${credentials.token}`;
      } else if (credentials.apiKey) {
        headers["Authorization"] = `Bearer ${credentials.apiKey}`;
      }
      const response = await axios({
        method: config.tokenCheckMethod || "GET",
        url: `${config.apiEndpoint.replace("/api", "")}${config.tokenCheckEndpoint}`,
        headers,
        timeout: CHECK_TIMEOUT,
        validateStatus: () => true
      });
      if (response.status >= 200 && response.status < 300) {
        return { valid: true };
      }
      if (response.status === 401) {
        return { valid: false, error: "Authentication failed, please check credentials" };
      }
      return { valid: false, error: `Validation failed: HTTP ${response.status}` };
    } catch (error) {
      return {
        valid: false,
        error: error instanceof axios.AxiosError ? error.message : "Connection failed"
      };
    }
  }
  static async checkCustomAccountToken(provider, account) {
    try {
      const headers = {
        ...provider.headers
      };
      const credentials = account.credentials;
      if (credentials.token) {
        headers["Authorization"] = `Bearer ${credentials.token}`;
      } else if (credentials.apiKey) {
        headers["Authorization"] = `Bearer ${credentials.apiKey}`;
      }
      const response = await axios({
        method: "GET",
        url: `${provider.apiEndpoint}/models`,
        headers,
        timeout: CHECK_TIMEOUT,
        validateStatus: () => true
      });
      if (response.status >= 200 && response.status < 300) {
        return { valid: true };
      }
      if (response.status === 401) {
        return { valid: false, error: "Authentication failed, please check credentials" };
      }
      return { valid: false, error: `Validation failed: HTTP ${response.status}` };
    } catch (error) {
      return {
        valid: false,
        error: error instanceof axios.AxiosError ? error.message : "Connection failed"
      };
    }
  }
  static generateUUID() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
      const r = Math.random() * 16 | 0;
      const v = c === "x" ? r : r & 3 | 8;
      return v.toString(16);
    });
  }
  static async generateGLMSign(timestamp, nonce) {
    const crypto2 = await import("crypto");
    const secret = "8a1317a7468aa3ad86e997d08f3f31cb";
    return crypto2.createHash("md5").update(`${timestamp}-${nonce}-${secret}`).digest("hex");
  }
  static async fetchProviderModels(providerId) {
    const builtinConfig = server_bootstrapConfig.getBuiltinProvider(providerId);
    if (!builtinConfig) {
      throw new Error(`Provider ${providerId} not found`);
    }
    if (!builtinConfig.modelsApiEndpoint) {
      throw new Error(`Provider ${providerId} does not support dynamic model fetching`);
    }
    try {
      const headers = {
        ...builtinConfig.modelsApiHeaders || builtinConfig.headers
      };
      const response = await axios.get(builtinConfig.modelsApiEndpoint, {
        headers,
        timeout: CHECK_TIMEOUT,
        validateStatus: () => true
      });
      if (response.status !== 200) {
        throw new Error(`Failed to fetch models: HTTP ${response.status}`);
      }
      const { supportedModels, modelMappings } = parseProviderModelsResponse(response.data);
      return { supportedModels, modelMappings };
    } catch (error) {
      console.error(`[ProviderChecker] Failed to fetch models for ${providerId}:`, error);
      throw error;
    }
  }
}
class GenericTokenValidator {
  constructor(apiEndpoint, headers) {
    this.apiEndpoint = apiEndpoint;
    this.headers = headers;
  }
  async validate(credentials) {
    const token = credentials.apiKey || credentials.token || credentials.authorization;
    if (!token) {
      return {
        valid: false,
        error: "Missing authentication token",
        validatedAt: Date.now()
      };
    }
    try {
      const headers = {
        ...this.headers,
        Authorization: `Bearer ${token}`
      };
      const response = await axios.get(`${this.apiEndpoint}/models`, {
        headers,
        timeout: 1e4
      });
      if (response.status === 200) {
        return {
          valid: true,
          validatedAt: Date.now()
        };
      }
      return {
        valid: false,
        error: `Validation failed: HTTP ${response.status}`,
        validatedAt: Date.now()
      };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        const axiosError = error;
        if (axiosError.response?.status === 401) {
          return {
            valid: false,
            error: "Invalid authentication token",
            validatedAt: Date.now()
          };
        }
        return {
          valid: false,
          error: `Validation failed: ${axiosError.message}`,
          validatedAt: Date.now()
        };
      }
      return {
        valid: false,
        error: `Validation failed: ${error instanceof Error ? error.message : "Unknown error"}`,
        validatedAt: Date.now()
      };
    }
  }
}
async function validateCredentials(provider, credentials) {
  if (provider.type === "builtin") {
    const tempAccount = {
      id: "temp",
      providerId: provider.id,
      name: "temp",
      credentials,
      status: "active",
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    const result = await ProviderChecker.checkAccountToken(provider, tempAccount);
    return {
      valid: result.valid,
      error: result.error,
      validatedAt: Date.now(),
      accountInfo: result.userInfo
    };
  }
  const validator = new GenericTokenValidator(provider.apiEndpoint, provider.headers);
  try {
    return await validator.validate(credentials);
  } catch (error) {
    return {
      valid: false,
      error: `Validation exception: ${error instanceof Error ? error.message : "Unknown error"}`,
      validatedAt: Date.now()
    };
  }
}
class AccountManager {
  /**
   * Get all accounts
   * @param includeCredentials Whether to include credentials (sensitive data)
   */
  static getAll(includeCredentials = false) {
    return server_bootstrapConfig.storeManager.getAccounts(includeCredentials);
  }
  /**
   * Get account by ID
   * @param id Account ID
   * @param includeCredentials Whether to include credentials
   */
  static getById(id, includeCredentials = false) {
    return server_bootstrapConfig.storeManager.getAccountById(id, includeCredentials);
  }
  /**
   * Get account list by provider ID
   * @param providerId Provider ID
   * @param includeCredentials Whether to include credentials
   */
  static getByProviderId(providerId, includeCredentials = false) {
    return server_bootstrapConfig.storeManager.getAccountsByProviderId(providerId, includeCredentials);
  }
  /**
   * Get all active accounts
   * @param includeCredentials Whether to include credentials
   */
  static getActive(includeCredentials = false) {
    return server_bootstrapConfig.storeManager.getActiveAccounts(includeCredentials);
  }
  /**
   * Create new account
   * @param data Account data
   * @returns Created account
   */
  static create(data) {
    server_bootstrapConfig.storeManager.ensureProviderExists(data.providerId);
    const provider = server_bootstrapConfig.storeManager.getProviderById(data.providerId);
    if (!provider) {
      throw new Error(`Provider not found: ${data.providerId}`);
    }
    const now = Date.now();
    const account = {
      id: server_bootstrapConfig.storeManager.generateId(),
      providerId: data.providerId,
      name: data.name,
      email: data.email,
      credentials: data.credentials,
      status: "active",
      createdAt: now,
      updatedAt: now,
      requestCount: 0,
      todayUsed: 0,
      dailyLimit: data.dailyLimit,
      lastStatusCheck: now,
      lastUsed: now
    };
    server_bootstrapConfig.storeManager.addAccount(account);
    server_bootstrapConfig.storeManager.addLog("info", `Created account: ${account.name}`, {
      accountId: account.id,
      providerId: account.providerId
    });
    return account;
  }
  /**
   * Update account
   * @param id Account ID
   * @param updates Update data
   * @returns Updated account
   */
  static update(id, updates) {
    const existing = server_bootstrapConfig.storeManager.getAccountById(id);
    if (!existing) {
      throw new Error(`Account not found: ${id}`);
    }
    const updated = server_bootstrapConfig.storeManager.updateAccount(id, updates);
    if (updated) {
      server_bootstrapConfig.storeManager.addLog("info", `Updated account: ${existing.name}`, {
        accountId: id,
        providerId: existing.providerId
      });
    }
    return updated;
  }
  /**
   * Delete account
   * @param id Account ID
   * @returns Whether deletion was successful
   */
  static delete(id) {
    const account = server_bootstrapConfig.storeManager.getAccountById(id);
    if (!account) {
      return false;
    }
    const result = server_bootstrapConfig.storeManager.deleteAccount(id);
    if (result) {
      server_bootstrapConfig.storeManager.addLog("info", `Deleted account: ${account.name}`, {
        accountId: id,
        providerId: account.providerId
      });
    }
    return result;
  }
  /**
   * Update account status
   * @param id Account ID
   * @param status New status
   * @param errorMessage Error message (optional)
   */
  static updateStatus(id, status, errorMessage) {
    return this.update(id, { status, errorMessage });
  }
  /**
   * Update last used time
   * @param id Account ID
   */
  static touchLastUsed(id) {
    const account = server_bootstrapConfig.storeManager.getAccountById(id);
    if (account) {
      server_bootstrapConfig.storeManager.updateAccount(id, {
        lastUsed: Date.now()
      });
    }
  }
  /**
   * Increment request count
   * @param id Account ID
   */
  static incrementRequestCount(id) {
    const account = server_bootstrapConfig.storeManager.getAccountById(id);
    if (account) {
      server_bootstrapConfig.storeManager.updateAccount(id, {
        requestCount: (account.requestCount || 0) + 1,
        todayUsed: (account.todayUsed || 0) + 1,
        lastUsed: Date.now()
      });
    }
  }
  /**
   * Reset daily usage count
   * Should be called at midnight
   */
  static resetDailyUsage() {
    const accounts = server_bootstrapConfig.storeManager.getAccounts();
    for (const account of accounts) {
      server_bootstrapConfig.storeManager.updateAccount(account.id, { todayUsed: 0 });
    }
    server_bootstrapConfig.storeManager.addLog("info", "Reset daily usage count for all accounts");
  }
  /**
   * Validate account credentials
   * @param id Account ID
   * @returns Validation result
   */
  static async validate(id) {
    const account = server_bootstrapConfig.storeManager.getAccountById(id, true);
    if (!account) {
      return {
        valid: false,
        error: "Account not found",
        validatedAt: Date.now()
      };
    }
    const provider = server_bootstrapConfig.storeManager.getProviderById(account.providerId);
    if (!provider) {
      return {
        valid: false,
        error: "Provider not found",
        validatedAt: Date.now()
      };
    }
    const result = await validateCredentials(provider, account.credentials);
    if (result.valid) {
      this.updateStatus(id, "active");
      if (result.accountInfo?.email) {
        server_bootstrapConfig.storeManager.updateAccount(id, { email: result.accountInfo.email });
      }
    } else {
      this.updateStatus(id, "error", result.error);
    }
    return result;
  }
  /**
   * Batch validate all accounts
   * @returns Validation result mapping
   */
  static async validateAll() {
    const accounts = server_bootstrapConfig.storeManager.getAccounts(true);
    const results = /* @__PURE__ */ new Map();
    for (const account of accounts) {
      const result = await this.validate(account.id);
      results.set(account.id, result);
    }
    return results;
  }
  /**
   * Check if account is available
   * @param id Account ID
   * @returns Whether account is available
   */
  static isAvailable(id) {
    const account = server_bootstrapConfig.storeManager.getAccountById(id);
    if (!account || account.status !== "active") {
      return false;
    }
    if (account.dailyLimit && account.todayUsed && account.todayUsed >= account.dailyLimit) {
      return false;
    }
    return true;
  }
  /**
   * Get available account list
   * @param providerId Optional, filter by provider
   * @returns Available account list
   */
  static getAvailable(providerId) {
    let accounts = server_bootstrapConfig.storeManager.getActiveAccounts();
    if (providerId) {
      accounts = accounts.filter((a) => a.providerId === providerId);
    }
    return accounts.filter((account) => {
      if (account.status !== "active") {
        return false;
      }
      if (account.dailyLimit && account.todayUsed && account.todayUsed >= account.dailyLimit) {
        return false;
      }
      return true;
    });
  }
  /**
   * Select next available account (load balancing)
   * @param providerId Provider ID
   * @param strategy Load balance strategy
   * @returns Selected account or null
   */
  static selectNext(providerId, strategy = "round-robin") {
    const available = this.getAvailable(providerId);
    if (available.length === 0) {
      return null;
    }
    if (strategy === "fill-first") {
      return available.reduce((prev, curr) => {
        const prevUsed = prev.todayUsed || 0;
        const currUsed = curr.todayUsed || 0;
        return currUsed < prevUsed ? curr : prev;
      });
    }
    const lastUsed = available.reduce((latest, account) => {
      if (!account.lastUsed) return latest;
      if (!latest) return account;
      return account.lastUsed > (latest.lastUsed || 0) ? account : latest;
    }, null);
    if (!lastUsed) {
      return available[0];
    }
    const lastIndex = available.findIndex((a) => a.id === lastUsed.id);
    const nextIndex = (lastIndex + 1) % available.length;
    return available[nextIndex];
  }
  /**
   * Get account statistics
   */
  static getStatistics() {
    const accounts = server_bootstrapConfig.storeManager.getAccounts();
    return {
      total: accounts.length,
      active: accounts.filter((a) => a.status === "active").length,
      inactive: accounts.filter((a) => a.status === "inactive").length,
      expired: accounts.filter((a) => a.status === "expired").length,
      error: accounts.filter((a) => a.status === "error").length
    };
  }
}
const router$7 = new Router({ prefix: "/v0/management/providers" });
router$7.use(managementAuthMiddleware);
function createErrorResponse$5(code, message) {
  return {
    success: false,
    error: {
      code,
      message
    }
  };
}
function createSuccessResponse$5(data) {
  return {
    success: true,
    data
  };
}
router$7.get("/", async (ctx) => {
  try {
    const providers = ProviderManager.getAll();
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(providers);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get providers";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.get("/builtin", async (ctx) => {
  try {
    const builtinProviders = server_bootstrapConfig.builtinProviders.map((provider) => ({
      ...provider,
      credentialFields: provider.credentialFields
    }));
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(builtinProviders);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get built-in providers";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.post("/check-all", async (ctx) => {
  try {
    const providers = ProviderManager.getAll();
    const results = {};
    await Promise.all(providers.map(async (provider) => {
      const result = await ProviderChecker.checkProviderStatus(provider);
      results[provider.id] = result;
      ProviderManager.update(provider.id, {
        status: result.status,
        lastStatusCheck: Date.now()
      });
    }));
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(results);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to check provider status";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.post("/import", async (ctx) => {
  try {
    const body = ctx.request.body;
    if (!body.jsonData) {
      ctx.status = 400;
      ctx.body = createErrorResponse$5("invalid_request", "Missing required field: jsonData");
      return;
    }
    const provider = CustomProviderManager.importProvider(body.jsonData);
    ctx.status = 201;
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(provider);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to import provider";
    ctx.status = 400;
    ctx.body = createErrorResponse$5("import_failed", errorMessage);
  }
});
router$7.get("/:id", async (ctx) => {
  try {
    const id = ctx.params.id;
    const provider = ProviderManager.getById(id);
    if (!provider) {
      ctx.status = 404;
      ctx.body = createErrorResponse$5("not_found", "Provider not found");
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(provider);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get provider";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.post("/:id/check", async (ctx) => {
  try {
    const id = ctx.params.id;
    const provider = ProviderManager.getById(id);
    if (!provider) {
      ctx.status = 404;
      ctx.body = createErrorResponse$5("not_found", "Provider not found");
      return;
    }
    const result = await ProviderChecker.checkProviderStatus(provider);
    ProviderManager.update(id, {
      status: result.status,
      lastStatusCheck: Date.now()
    });
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(result);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to check provider status";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.post("/:id/validate-token", async (ctx) => {
  try {
    const providerId = ctx.params.id;
    const body = ctx.request.body;
    const credentials = body.credentials || {};
    let provider = ProviderManager.getById(providerId);
    const builtinConfig = server_bootstrapConfig.getBuiltinProvider(providerId);
    if (!provider && builtinConfig) {
      provider = {
        id: builtinConfig.id,
        name: builtinConfig.name,
        type: "builtin",
        authType: builtinConfig.authType,
        apiEndpoint: builtinConfig.apiEndpoint,
        chatPath: builtinConfig.chatPath,
        headers: builtinConfig.headers,
        enabled: true,
        description: builtinConfig.description,
        supportedModels: builtinConfig.supportedModels || [],
        modelMappings: builtinConfig.modelMappings || {},
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
    }
    if (!provider) {
      ctx.status = 404;
      ctx.body = createErrorResponse$5("not_found", "Provider not found");
      return;
    }
    const result = await ProviderChecker.checkAccountToken(provider, {
      id: "temp",
      providerId,
      name: "temp",
      credentials,
      status: "active",
      createdAt: Date.now(),
      updatedAt: Date.now()
    });
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(result);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to validate token";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.post("/:id/duplicate", async (ctx) => {
  try {
    const provider = CustomProviderManager.duplicate(ctx.params.id);
    ctx.status = 201;
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(provider);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to duplicate provider";
    ctx.status = errorMessage.includes("not found") ? 404 : 500;
    ctx.body = createErrorResponse$5("duplicate_failed", errorMessage);
  }
});
router$7.get("/:id/export", async (ctx) => {
  try {
    const json = CustomProviderManager.exportProvider(ctx.params.id);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(json);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to export provider";
    ctx.status = errorMessage.includes("not found") ? 404 : 500;
    ctx.body = createErrorResponse$5("export_failed", errorMessage);
  }
});
router$7.post("/:id/models/update", async (ctx) => {
  try {
    const providerId = ctx.params.id;
    const provider = ProviderManager.getById(providerId);
    if (!provider) {
      ctx.status = 404;
      ctx.body = createErrorResponse$5("not_found", "Provider not found");
      return;
    }
    let modelsApiEndpoint;
    let modelsApiHeaders;
    if (provider.type === "builtin") {
      const builtinConfig = server_bootstrapConfig.getBuiltinProvider(providerId);
      modelsApiEndpoint = builtinConfig?.modelsApiEndpoint;
      modelsApiHeaders = builtinConfig?.modelsApiHeaders;
    }
    if (!modelsApiEndpoint) {
      ctx.body = createSuccessResponse$5({
        success: false,
        error: "This provider does not support dynamic model updates"
      });
      return;
    }
    const activeAccount = AccountManager.getByProviderId(providerId, true).find((account) => account.status === "active");
    const headers = {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...modelsApiHeaders
    };
    if (activeAccount?.credentials?.token) {
      headers.Authorization = `Bearer ${activeAccount.credentials.token}`;
    }
    if (activeAccount?.credentials?.cookies) {
      headers.Cookie = activeAccount.credentials.cookies;
    }
    const response = await axios.get(modelsApiEndpoint, {
      headers,
      timeout: 15e3,
      validateStatus: () => true
    });
    if (response.status !== 200) {
      ctx.body = createSuccessResponse$5({
        success: false,
        error: `Failed to fetch models: HTTP ${response.status}`
      });
      return;
    }
    const { supportedModels, modelMappings } = parseProviderModelsResponse(response.data);
    if (supportedModels.length === 0) {
      ctx.body = createSuccessResponse$5({
        success: false,
        error: "No models found in the response"
      });
      return;
    }
    ProviderManager.update(providerId, { supportedModels, modelMappings });
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5({
      success: true,
      modelsCount: supportedModels.length
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to update models";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.get("/:id/models/effective", async (ctx) => {
  try {
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(server_bootstrapConfig.storeManager.getEffectiveModels(ctx.params.id));
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get effective models";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.post("/:id/models/custom", async (ctx) => {
  try {
    const models = server_bootstrapConfig.storeManager.addCustomModel(ctx.params.id, ctx.request.body);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5({ success: true, models });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to add custom model";
    ctx.status = 400;
    ctx.body = createSuccessResponse$5({ success: false, error: errorMessage, models: [] });
  }
});
router$7.delete("/:id/models/:modelName", async (ctx) => {
  try {
    const models = server_bootstrapConfig.storeManager.removeModel(ctx.params.id, decodeURIComponent(ctx.params.modelName));
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5({ success: true, models });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to remove model";
    ctx.status = 400;
    ctx.body = createSuccessResponse$5({ success: false, error: errorMessage, models: [] });
  }
});
router$7.post("/:id/models/reset", async (ctx) => {
  try {
    const models = server_bootstrapConfig.storeManager.resetModels(ctx.params.id);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5({ success: true, models });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to reset models";
    ctx.status = 400;
    ctx.body = createSuccessResponse$5({ success: false, error: errorMessage, models: [] });
  }
});
router$7.post("/", async (ctx) => {
  try {
    const request = ctx.request.body;
    if (!request.name || typeof request.name !== "string") {
      ctx.status = 400;
      ctx.body = createErrorResponse$5("invalid_request", "Missing required field: name");
      return;
    }
    if (!request.authType) {
      ctx.status = 400;
      ctx.body = createErrorResponse$5("invalid_request", "Missing required field: authType");
      return;
    }
    if (!request.apiEndpoint || typeof request.apiEndpoint !== "string") {
      ctx.status = 400;
      ctx.body = createErrorResponse$5("invalid_request", "Missing required field: apiEndpoint");
      return;
    }
    const provider = ProviderManager.create({
      id: request.id,
      name: request.name,
      type: request.type || "custom",
      authType: request.authType,
      apiEndpoint: request.apiEndpoint,
      chatPath: request.chatPath,
      headers: request.headers || {},
      description: request.description,
      icon: request.icon,
      supportedModels: request.supportedModels,
      modelMappings: request.modelMappings,
      modelsApiEndpoint: request.modelsApiEndpoint,
      modelsApiHeaders: request.modelsApiHeaders,
      credentialFields: request.credentialFields
    });
    ctx.status = 201;
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(provider);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to create provider";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.put("/:id", async (ctx) => {
  try {
    const id = ctx.params.id;
    const request = ctx.request.body;
    const existingProvider = ProviderManager.getById(id);
    if (!existingProvider) {
      ctx.status = 404;
      ctx.body = createErrorResponse$5("not_found", "Provider not found");
      return;
    }
    const updates = {};
    if (request.name !== void 0) {
      updates.name = request.name;
    }
    if (request.apiEndpoint !== void 0) {
      updates.apiEndpoint = request.apiEndpoint;
    }
    if (request.chatPath !== void 0) {
      updates.chatPath = request.chatPath;
    }
    if (request.headers !== void 0) {
      updates.headers = request.headers;
    }
    if (request.enabled !== void 0) {
      updates.enabled = request.enabled;
    }
    if (request.description !== void 0) {
      updates.description = request.description;
    }
    if (request.icon !== void 0) {
      updates.icon = request.icon;
    }
    if (request.supportedModels !== void 0) {
      updates.supportedModels = request.supportedModels;
    }
    if (request.modelMappings !== void 0) {
      updates.modelMappings = request.modelMappings;
    }
    const updatedProvider = ProviderManager.update(id, updates);
    if (!updatedProvider) {
      ctx.status = 500;
      ctx.body = createErrorResponse$5("update_failed", "Failed to update provider");
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(updatedProvider);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to update provider";
    if (errorMessage.includes("Built-in providers cannot modify")) {
      ctx.status = 403;
      ctx.body = createErrorResponse$5("forbidden", errorMessage);
      return;
    }
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.delete("/:id", async (ctx) => {
  try {
    const id = ctx.params.id;
    const deleted = ProviderManager.delete(id);
    if (!deleted) {
      ctx.status = 404;
      ctx.body = createErrorResponse$5("not_found", "Provider not found");
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5({ id, deleted: true });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to delete provider";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
router$7.patch("/:id/status", async (ctx) => {
  try {
    const id = ctx.params.id;
    const request = ctx.request.body;
    if (request.enabled === void 0 || typeof request.enabled !== "boolean") {
      ctx.status = 400;
      ctx.body = createErrorResponse$5("invalid_request", "Missing or invalid required field: enabled (must be boolean)");
      return;
    }
    const existingProvider = ProviderManager.getById(id);
    if (!existingProvider) {
      ctx.status = 404;
      ctx.body = createErrorResponse$5("not_found", "Provider not found");
      return;
    }
    const updatedProvider = ProviderManager.update(id, { enabled: request.enabled });
    if (!updatedProvider) {
      ctx.status = 500;
      ctx.body = createErrorResponse$5("update_failed", "Failed to update provider status");
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$5(updatedProvider);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to update provider status";
    ctx.status = 500;
    ctx.body = createErrorResponse$5("internal_error", errorMessage);
  }
});
const router$6 = new Router({ prefix: "/v0/management" });
function maskCredentials(account) {
  const maskedCredentials = {};
  for (const key of Object.keys(account.credentials)) {
    maskedCredentials[key] = "***";
  }
  return {
    ...account,
    credentials: maskedCredentials
  };
}
function shouldIncludeCredentials(ctx) {
  return ctx.query.includeCredentials === "true" || ctx.query.includeCredentials === "1";
}
function maybeMask(account, includeCredentials) {
  return includeCredentials ? account : maskCredentials(account);
}
function createErrorResponse$4(code, message) {
  return {
    success: false,
    error: {
      code,
      message
    }
  };
}
function createSuccessResponse$4(data) {
  return {
    success: true,
    data
  };
}
router$6.get("/accounts", managementAuthMiddleware, async (ctx) => {
  try {
    const includeCredentials = shouldIncludeCredentials(ctx);
    const accounts = AccountManager.getAll(includeCredentials);
    const responseAccounts = accounts.map((account) => maybeMask(account, includeCredentials));
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$4(responseAccounts);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get accounts";
    ctx.status = 500;
    ctx.body = createErrorResponse$4("internal_error", errorMessage);
  }
});
router$6.get("/providers/:providerId/accounts", managementAuthMiddleware, async (ctx) => {
  try {
    const providerId = ctx.params.providerId;
    const includeCredentials = shouldIncludeCredentials(ctx);
    const accounts = AccountManager.getByProviderId(providerId, includeCredentials);
    const responseAccounts = accounts.map((account) => maybeMask(account, includeCredentials));
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$4(responseAccounts);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get accounts by provider";
    ctx.status = 500;
    ctx.body = createErrorResponse$4("internal_error", errorMessage);
  }
});
router$6.get("/accounts/:id", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const includeCredentials = shouldIncludeCredentials(ctx);
    const account = AccountManager.getById(id, includeCredentials);
    if (!account) {
      ctx.status = 404;
      ctx.body = createErrorResponse$4("account_not_found", `Account not found: ${id}`);
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$4(maybeMask(account, includeCredentials));
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get account";
    ctx.status = 500;
    ctx.body = createErrorResponse$4("internal_error", errorMessage);
  }
});
router$6.post("/accounts", managementAuthMiddleware, async (ctx) => {
  try {
    const request = ctx.request.body;
    if (!request.providerId) {
      ctx.status = 400;
      ctx.body = createErrorResponse$4("invalid_request", "Missing required field: providerId");
      return;
    }
    if (!request.name) {
      ctx.status = 400;
      ctx.body = createErrorResponse$4("invalid_request", "Missing required field: name");
      return;
    }
    if (!request.credentials || typeof request.credentials !== "object") {
      ctx.status = 400;
      ctx.body = createErrorResponse$4("invalid_request", "Missing or invalid required field: credentials");
      return;
    }
    const account = AccountManager.create({
      providerId: request.providerId,
      name: request.name,
      email: request.email,
      credentials: request.credentials,
      dailyLimit: request.dailyLimit
    });
    const maskedAccount = maskCredentials(account);
    ctx.status = 201;
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$4(maskedAccount);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to create account";
    if (errorMessage.includes("not found")) {
      ctx.status = 404;
      ctx.body = createErrorResponse$4("provider_not_found", errorMessage);
    } else {
      ctx.status = 500;
      ctx.body = createErrorResponse$4("internal_error", errorMessage);
    }
  }
});
router$6.put("/accounts/:id", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const request = ctx.request.body;
    const existingAccount = AccountManager.getById(id, false);
    if (!existingAccount) {
      ctx.status = 404;
      ctx.body = createErrorResponse$4("account_not_found", `Account not found: ${id}`);
      return;
    }
    const updates = {};
    if (request.name !== void 0) {
      updates.name = request.name;
    }
    if (request.email !== void 0) {
      updates.email = request.email;
    }
    if (request.credentials !== void 0) {
      updates.credentials = request.credentials;
    }
    if (request.dailyLimit !== void 0) {
      updates.dailyLimit = request.dailyLimit;
    }
    const updatedAccount = AccountManager.update(id, updates);
    if (!updatedAccount) {
      ctx.status = 500;
      ctx.body = createErrorResponse$4("update_failed", "Failed to update account");
      return;
    }
    const maskedAccount = maskCredentials(updatedAccount);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$4(maskedAccount);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to update account";
    ctx.status = 500;
    ctx.body = createErrorResponse$4("internal_error", errorMessage);
  }
});
router$6.delete("/accounts/:id", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const deleted = AccountManager.delete(id);
    if (!deleted) {
      ctx.status = 404;
      ctx.body = createErrorResponse$4("account_not_found", `Account not found: ${id}`);
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$4({ id, deleted: true });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to delete account";
    ctx.status = 500;
    ctx.body = createErrorResponse$4("internal_error", errorMessage);
  }
});
router$6.post("/accounts/:id/validate", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const existingAccount = AccountManager.getById(id, false);
    if (!existingAccount) {
      ctx.status = 404;
      ctx.body = createErrorResponse$4("account_not_found", `Account not found: ${id}`);
      return;
    }
    const validationResult = await AccountManager.validate(id);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$4(validationResult);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to validate account";
    ctx.status = 500;
    ctx.body = createErrorResponse$4("internal_error", errorMessage);
  }
});
router$6.get("/accounts/:id/credits", managementAuthMiddleware, async (ctx) => {
  try {
    const account = AccountManager.getById(ctx.params.id, true);
    if (!account) {
      ctx.status = 404;
      ctx.body = createErrorResponse$4("account_not_found", `Account not found: ${ctx.params.id}`);
      return;
    }
    const provider = ProviderManager.getById(account.providerId);
    if (!provider || provider.id !== "minimax") {
      ctx.body = createSuccessResponse$4(null);
      return;
    }
    const adapter = new MiniMaxAdapter$1(provider, account);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$4(await adapter.getCredits());
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get account credits";
    ctx.status = 500;
    ctx.body = createErrorResponse$4("internal_error", errorMessage);
  }
});
router$6.post("/accounts/:id/clear-chats", managementAuthMiddleware, async (ctx) => {
  try {
    const account = AccountManager.getById(ctx.params.id, true);
    if (!account) {
      ctx.status = 404;
      ctx.body = createErrorResponse$4("account_not_found", `Account not found: ${ctx.params.id}`);
      return;
    }
    const provider = ProviderManager.getById(account.providerId);
    if (!provider) {
      ctx.status = 404;
      ctx.body = createErrorResponse$4("provider_not_found", `Provider not found: ${account.providerId}`);
      return;
    }
    const clearChatsHandlers = {
      kimi: () => new KimiAdapter$1(provider, account).deleteAllChats(),
      qwen: () => new QwenAdapter$1(provider, account).deleteAllChats(),
      "qwen-ai": () => new QwenAiAdapter$1(provider, account).deleteAllChats(),
      minimax: () => new MiniMaxAdapter$1(provider, account).deleteAllChats(),
      zai: () => new ZaiAdapter$1(provider, account).deleteAllChats(),
      perplexity: () => new PerplexityAdapter$1(provider, account).deleteAllChats(),
      deepseek: () => new DeepSeekAdapter$1(provider, account).deleteAllChats(),
      glm: () => new GLMAdapter$1(provider, account).deleteAllChats(),
      mimo: () => new MimoAdapter$1(provider, account).deleteAllChats()
    };
    const handler = clearChatsHandlers[provider.id];
    if (!handler) {
      ctx.body = createSuccessResponse$4({
        success: false,
        error: "This feature is not available for this provider"
      });
      return;
    }
    ctx.body = createSuccessResponse$4({ success: await handler() });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to clear chats";
    ctx.status = 500;
    ctx.body = createSuccessResponse$4({ success: false, error: errorMessage });
  }
});
const router$5 = new Router({ prefix: "/v0/management" });
const API_KEY_PREFIX = "sk-mgmt-";
const KEY_RANDOM_LENGTH = 32;
function generateApiKeyValue() {
  const randomBytes = new Uint8Array(KEY_RANDOM_LENGTH);
  crypto.getRandomValues(randomBytes);
  const randomString = Array.from(randomBytes).map((b) => b.toString(16).padStart(2, "0")).join("").slice(0, KEY_RANDOM_LENGTH);
  return `${API_KEY_PREFIX}${randomString}`;
}
function maskApiKey(key) {
  const maskedKey = key.key.length > 8 ? `${API_KEY_PREFIX}...${key.key.slice(-8)}` : `${API_KEY_PREFIX}...`;
  return {
    ...key,
    key: maskedKey
  };
}
function createErrorResponse$3(code, message) {
  return {
    success: false,
    error: {
      code,
      message
    }
  };
}
function createSuccessResponse$3(data) {
  return {
    success: true,
    data
  };
}
router$5.get("/api-keys", managementAuthMiddleware, async (ctx) => {
  try {
    const config = server_bootstrapConfig.storeManager.getConfig();
    const apiKeys = config.apiKeys || [];
    const maskedKeys = apiKeys.map(maskApiKey);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$3(maskedKeys);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get API keys";
    ctx.status = 500;
    ctx.body = createErrorResponse$3("internal_error", errorMessage);
  }
});
router$5.post("/api-keys", managementAuthMiddleware, async (ctx) => {
  try {
    const request = ctx.request.body;
    if (!request.name || typeof request.name !== "string" || request.name.trim() === "") {
      ctx.status = 400;
      ctx.body = createErrorResponse$3("invalid_request", "Missing required field: name");
      return;
    }
    const config = server_bootstrapConfig.storeManager.getConfig();
    const apiKeys = config.apiKeys || [];
    const newKey = {
      id: crypto$1.randomUUID(),
      name: request.name.trim(),
      key: generateApiKeyValue(),
      enabled: true,
      createdAt: Date.now(),
      usageCount: 0,
      description: request.description?.trim()
    };
    apiKeys.push(newKey);
    server_bootstrapConfig.storeManager.updateConfig({ apiKeys });
    server_bootstrapConfig.storeManager.addLog("info", `Created API key: ${newKey.name}`, {
      data: { keyId: newKey.id }
    });
    ctx.status = 201;
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$3(newKey);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to create API key";
    ctx.status = 500;
    ctx.body = createErrorResponse$3("internal_error", errorMessage);
  }
});
router$5.put("/api-keys/:id", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const request = ctx.request.body;
    const config = server_bootstrapConfig.storeManager.getConfig();
    const apiKeys = config.apiKeys || [];
    const keyIndex = apiKeys.findIndex((k) => k.id === id);
    if (keyIndex === -1) {
      ctx.status = 404;
      ctx.body = createErrorResponse$3("api_key_not_found", `API key not found: ${id}`);
      return;
    }
    const existingKey = apiKeys[keyIndex];
    if (request.name !== void 0) {
      if (typeof request.name !== "string" || request.name.trim() === "") {
        ctx.status = 400;
        ctx.body = createErrorResponse$3("invalid_request", "Invalid field: name must be a non-empty string");
        return;
      }
      existingKey.name = request.name.trim();
    }
    if (request.description !== void 0) {
      existingKey.description = request.description?.trim();
    }
    if (request.enabled !== void 0) {
      if (typeof request.enabled !== "boolean") {
        ctx.status = 400;
        ctx.body = createErrorResponse$3("invalid_request", "Invalid field: enabled must be a boolean");
        return;
      }
      existingKey.enabled = request.enabled;
    }
    apiKeys[keyIndex] = existingKey;
    server_bootstrapConfig.storeManager.updateConfig({ apiKeys });
    server_bootstrapConfig.storeManager.addLog("info", `Updated API key: ${existingKey.name}`, {
      data: { keyId: id }
    });
    const maskedKey = maskApiKey(existingKey);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$3(maskedKey);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to update API key";
    ctx.status = 500;
    ctx.body = createErrorResponse$3("internal_error", errorMessage);
  }
});
router$5.delete("/api-keys/:id", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const config = server_bootstrapConfig.storeManager.getConfig();
    const apiKeys = config.apiKeys || [];
    const keyIndex = apiKeys.findIndex((k) => k.id === id);
    if (keyIndex === -1) {
      ctx.status = 404;
      ctx.body = createErrorResponse$3("api_key_not_found", `API key not found: ${id}`);
      return;
    }
    const deletedKey = apiKeys[keyIndex];
    apiKeys.splice(keyIndex, 1);
    server_bootstrapConfig.storeManager.updateConfig({ apiKeys });
    server_bootstrapConfig.storeManager.addLog("info", `Deleted API key: ${deletedKey.name}`, {
      data: { keyId: id }
    });
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$3({ id, deleted: true });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to delete API key";
    ctx.status = 500;
    ctx.body = createErrorResponse$3("internal_error", errorMessage);
  }
});
router$5.post("/api-keys/:id/regenerate", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const config = server_bootstrapConfig.storeManager.getConfig();
    const apiKeys = config.apiKeys || [];
    const keyIndex = apiKeys.findIndex((k) => k.id === id);
    if (keyIndex === -1) {
      ctx.status = 404;
      ctx.body = createErrorResponse$3("api_key_not_found", `API key not found: ${id}`);
      return;
    }
    const existingKey = apiKeys[keyIndex];
    const newKeyValue = generateApiKeyValue();
    existingKey.key = newKeyValue;
    existingKey.usageCount = 0;
    apiKeys[keyIndex] = existingKey;
    server_bootstrapConfig.storeManager.updateConfig({ apiKeys });
    server_bootstrapConfig.storeManager.addLog("info", `Regenerated API key: ${existingKey.name}`, {
      data: { keyId: id }
    });
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$3(existingKey);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to regenerate API key";
    ctx.status = 500;
    ctx.body = createErrorResponse$3("internal_error", errorMessage);
  }
});
const router$4 = new Router({ prefix: "/v0/management" });
function createErrorResponse$2(code, message) {
  return {
    success: false,
    error: {
      code,
      message
    }
  };
}
function createSuccessResponse$2(data) {
  return {
    success: true,
    data
  };
}
router$4.get("/model-mappings", managementAuthMiddleware, async (ctx) => {
  try {
    const mappings = ConfigManager.getModelMappings();
    const mappingList = Object.values(mappings);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$2(mappingList);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get model mappings";
    ctx.status = 500;
    ctx.body = createErrorResponse$2("internal_error", errorMessage);
  }
});
router$4.post("/model-mappings", managementAuthMiddleware, async (ctx) => {
  try {
    const request = ctx.request.body;
    if (!request.requestModel) {
      ctx.status = 400;
      ctx.body = createErrorResponse$2("invalid_request", "Missing required field: requestModel");
      return;
    }
    if (!request.actualModel) {
      ctx.status = 400;
      ctx.body = createErrorResponse$2("invalid_request", "Missing required field: actualModel");
      return;
    }
    const existingMapping = ConfigManager.getModelMapping(request.requestModel);
    if (existingMapping) {
      ctx.status = 409;
      ctx.body = createErrorResponse$2("mapping_exists", `Model mapping already exists: ${request.requestModel}`);
      return;
    }
    const mapping = {
      requestModel: request.requestModel,
      actualModel: request.actualModel,
      preferredProviderId: request.preferredProviderId,
      preferredAccountId: request.preferredAccountId
    };
    ConfigManager.setModelMapping(mapping);
    ctx.status = 201;
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$2(mapping);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to create model mapping";
    ctx.status = 500;
    ctx.body = createErrorResponse$2("internal_error", errorMessage);
  }
});
router$4.put("/model-mappings/:model", managementAuthMiddleware, async (ctx) => {
  try {
    const model = decodeURIComponent(ctx.params.model);
    const request = ctx.request.body;
    const existingMapping = ConfigManager.getModelMapping(model);
    if (!existingMapping) {
      ctx.status = 404;
      ctx.body = createErrorResponse$2("mapping_not_found", `Model mapping not found: ${model}`);
      return;
    }
    const updatedMapping = {
      requestModel: model,
      actualModel: request.actualModel ?? existingMapping.actualModel,
      preferredProviderId: request.preferredProviderId ?? existingMapping.preferredProviderId,
      preferredAccountId: request.preferredAccountId ?? existingMapping.preferredAccountId
    };
    ConfigManager.setModelMapping(updatedMapping);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$2(updatedMapping);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to update model mapping";
    ctx.status = 500;
    ctx.body = createErrorResponse$2("internal_error", errorMessage);
  }
});
router$4.delete("/model-mappings/:model", managementAuthMiddleware, async (ctx) => {
  try {
    const model = decodeURIComponent(ctx.params.model);
    const deleted = ConfigManager.removeModelMapping(model);
    if (!deleted) {
      ctx.status = 404;
      ctx.body = createErrorResponse$2("mapping_not_found", `Model mapping not found: ${model}`);
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$2({ model, deleted: true });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to delete model mapping";
    ctx.status = 500;
    ctx.body = createErrorResponse$2("internal_error", errorMessage);
  }
});
const router$3 = new Router({ prefix: "/v0/management" });
function createErrorResponse$1(code, message) {
  return {
    success: false,
    error: {
      code,
      message
    }
  };
}
function createSuccessResponse$1(data) {
  return {
    success: true,
    data
  };
}
function transformSession(session) {
  return {
    ...session
  };
}
router$3.get("/sessions", managementAuthMiddleware, async (ctx) => {
  try {
    const sessions = sessionManager.getAllActiveSessions();
    const transformedSessions = sessions.map(transformSession);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1(transformedSessions);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get sessions";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.get("/sessions/all", managementAuthMiddleware, async (ctx) => {
  try {
    const sessions = sessionManager.getAllSessions();
    const transformedSessions = sessions.map(transformSession);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1(transformedSessions);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get sessions";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.get("/sessions/config", managementAuthMiddleware, async (ctx) => {
  try {
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1(sessionManager.getSessionConfig());
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get session config";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.put("/sessions/config", managementAuthMiddleware, async (ctx) => {
  try {
    const updates = ctx.request.body;
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1(sessionManager.updateSessionConfig(updates));
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to update session config";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.get("/accounts/:accountId/sessions", managementAuthMiddleware, async (ctx) => {
  try {
    const sessions = sessionManager.getSessionsByAccount(ctx.params.accountId);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1(sessions.map(transformSession));
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get sessions by account";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.get("/providers/:providerId/sessions", managementAuthMiddleware, async (ctx) => {
  try {
    const sessions = sessionManager.getSessionsByProvider(ctx.params.providerId);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1(sessions.map(transformSession));
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get sessions by provider";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.post("/sessions/clean-expired", managementAuthMiddleware, async (ctx) => {
  try {
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1(sessionManager.cleanExpiredSessions());
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to clean expired sessions";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.get("/sessions/:id", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const session = sessionManager.getSession(id);
    if (!session) {
      ctx.status = 404;
      ctx.body = createErrorResponse$1("session_not_found", `Session not found: ${id}`);
      return;
    }
    const transformedSession = transformSession(session);
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1(transformedSession);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get session";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.delete("/sessions/:id", managementAuthMiddleware, async (ctx) => {
  try {
    const id = ctx.params.id;
    const session = sessionManager.getSession(id);
    if (!session) {
      ctx.status = 404;
      ctx.body = createErrorResponse$1("session_not_found", `Session not found: ${id}`);
      return;
    }
    const deleted = sessionManager.deleteSession(id);
    if (!deleted) {
      ctx.status = 500;
      ctx.body = createErrorResponse$1("delete_failed", `Failed to delete session: ${id}`);
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1({ id, deleted: true });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to delete session";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
router$3.delete("/sessions", managementAuthMiddleware, async (ctx) => {
  try {
    const body = ctx.request.body;
    if (!body || body.confirm !== true) {
      ctx.status = 400;
      ctx.body = createErrorResponse$1("confirmation_required", "Request body must include { confirm: true } to clear all sessions");
      return;
    }
    sessionManager.clearAllSessions();
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse$1({ cleared: true });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to clear sessions";
    ctx.status = 500;
    ctx.body = createErrorResponse$1("internal_error", errorMessage);
  }
});
class BaseOAuthAdapter {
  constructor(config) {
    this.callbackServer = null;
    this.state = "";
    this.mainWindow = null;
    this.progressCallback = null;
    this.config = config;
    this.callbackPort = config.callbackPort || 8311;
  }
  /**
   * Get provider type
   */
  getProviderType() {
    return this.config.providerType;
  }
  /**
   * Get supported authentication methods
   */
  getSupportedAuthMethods() {
    return this.config.authMethods;
  }
  /**
   * Set main window reference
   */
  setMainWindow(window) {
    this.mainWindow = window;
  }
  /**
   * Set progress callback
   */
  setProgressCallback(callback) {
    this.progressCallback = callback;
  }
  /**
   * Emit progress event
   */
  emitProgress(status, message, data) {
    if (this.progressCallback) {
      this.progressCallback({ status, message, data });
    }
  }
  /**
   * Generate random state string
   */
  generateState() {
    this.state = crypto$1.randomBytes(16).toString("hex");
    return this.state;
  }
  /**
   * Validate state string
   */
  validateState(state) {
    return state === this.state;
  }
  /**
   * Create local callback server
   */
  async createCallbackServer() {
    return new Promise((resolve, reject) => {
      this.callbackServer = http.createServer((req, res) => {
        this.handleCallback(req, res);
      });
      this.callbackServer.listen(this.callbackPort, () => {
        resolve(this.callbackPort);
      });
      this.callbackServer.on("error", (error) => {
        if (error.code === "EADDRINUSE") {
          this.callbackPort++;
          this.callbackServer?.listen(this.callbackPort);
        } else {
          reject(error);
        }
      });
    });
  }
  /**
   * Close callback server
   */
  closeCallbackServer() {
    if (this.callbackServer) {
      this.callbackServer.close();
      this.callbackServer = null;
    }
  }
  /**
   * Handle OAuth callback
   */
  handleCallback(req, res) {
    const url = new URL(req.url || "/", `http://localhost:${this.callbackPort}`);
    const data = {
      code: url.searchParams.get("code") || void 0,
      token: url.searchParams.get("token") || void 0,
      state: url.searchParams.get("state") || void 0,
      error: url.searchParams.get("error") || void 0,
      errorDescription: url.searchParams.get("error_description") || void 0
    };
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>OAuth Callback</title>
        <style>
          body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
          }
          .container {
            text-align: center;
            padding: 40px;
            background: rgba(255,255,255,0.1);
            border-radius: 16px;
            backdrop-filter: blur(10px);
          }
          .success { color: #4ade80; }
          .error { color: #f87171; }
        </style>
      </head>
      <body>
        <div class="container">
          ${data.error ? `<h1 class="error">❌ Login Failed</h1><p>${data.errorDescription || data.error}</p>` : `<h1 class="success">✅ Login Successful</h1><p>Processing, please wait...</p>`}
          <p style="font-size: 12px; opacity: 0.7;">This window can be closed</p>
        </div>
        <script>
          if (window.electronAPI) {
            window.electronAPI.send('oauth:callback', ${JSON.stringify(data)});
          }
          setTimeout(() => window.close(), 2000);
        <\/script>
      </body>
      </html>
    `);
    this.processCallback(data);
  }
  /**
   * Open URL in system browser
   */
  async openBrowser(url) {
    await server_bootstrapConfig.getRuntime().openExternal(url);
  }
  /**
   * Start OAuth login flow
   */
  async startLogin(options) {
    throw new Error("Subclass must implement startLogin method");
  }
  /**
   * Cancel login flow
   */
  async cancelLogin() {
    this.closeCallbackServer();
    this.emitProgress("cancelled", "Login cancelled");
  }
  /**
   * Process callback data
   */
  async processCallback(data) {
    throw new Error("Subclass must implement processCallback method");
  }
  /**
   * Validate token validity
   */
  async validateToken(credentials) {
    throw new Error("Subclass must implement validateToken method");
  }
  /**
   * Refresh token
   */
  async refreshToken(credentials) {
    throw new Error("Subclass must implement refreshToken method");
  }
  /**
   * Get login URL
   */
  getLoginUrl() {
    return this.config.loginUrl || "";
  }
  /**
   * Get API URL
   */
  getApiUrl() {
    return this.config.apiUrl || "";
  }
  /**
   * Generate UUID
   */
  generateUUID() {
    return crypto$1.randomUUID();
  }
  /**
   * Generate MD5 hash
   */
  md5(input) {
    return crypto$1.createHash("md5").update(input).digest("hex");
  }
  /**
   * Get current timestamp (seconds)
   */
  getTimestamp() {
    return Math.floor(Date.now() / 1e3);
  }
  /**
   * Get current timestamp (milliseconds)
   */
  getTimestampMs() {
    return Date.now();
  }
  /**
   * Parse JWT token
   */
  parseJWT(token) {
    try {
      const parts = token.split(".");
      if (parts.length !== 3) return null;
      const payload = Buffer.from(parts[1], "base64").toString("utf-8");
      return JSON.parse(payload);
    } catch {
      return null;
    }
  }
  /**
   * Check if it is a JWT token
   */
  isJWT(token) {
    return token.startsWith("eyJ") && token.split(".").length === 3;
  }
  /**
   * Clean up resources
   */
  destroy() {
    this.closeCallbackServer();
    this.mainWindow = null;
    this.progressCallback = null;
  }
}
const DEEPSEEK_API_BASE = "https://chat.deepseek.com";
const FAKE_HEADERS$4 = {
  Accept: "*/*",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
  Origin: DEEPSEEK_API_BASE,
  Pragma: "no-cache",
  Priority: "u=1, i",
  Referer: `${DEEPSEEK_API_BASE}/`,
  "Sec-Ch-Ua": '"Chromium";v="134", "Not:A-Brand";v="24", "Google Chrome";v="134"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36",
  "X-App-Version": "20241129.1",
  "X-Client-Locale": "zh-CN",
  "X-Client-Platform": "web",
  "X-Client-Version": "1.6.1"
};
class DeepSeekAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "deepseek",
      authMethods: ["manual"],
      loginUrl: DEEPSEEK_API_BASE,
      apiUrl: DEEPSEEK_API_BASE
    });
  }
  /**
   * Start login flow - Open default browser
   */
  async startLogin(options) {
    this.emitProgress("pending", "Opening browser...");
    try {
      await server_bootstrapConfig.getRuntime().openExternal(DEEPSEEK_API_BASE);
      this.emitProgress("pending", "Please log in via browser and enter Token manually");
      return {
        success: false,
        providerId: options.providerId,
        providerType: "deepseek",
        error: "Please log in via browser, extract Token from Developer Tools and enter manually"
      };
    } catch (error) {
      console.error("[DeepSeek] startLogin error:", error);
      const errorMessage = error instanceof Error ? error.message : "Failed to open browser";
      this.emitProgress("error", errorMessage);
      return {
        success: false,
        providerId: options.providerId,
        providerType: "deepseek",
        error: errorMessage
      };
    }
  }
  /**
   * Complete authentication with manually entered token
   */
  async loginWithToken(providerId, token) {
    this.emitProgress("pending", "Validating Token...");
    try {
      const validation = await this.validateToken({ token });
      if (!validation.valid) {
        return {
          success: false,
          providerId,
          providerType: "deepseek",
          error: validation.error || "Token validation failed"
        };
      }
      this.emitProgress("success", "Token validation successful");
      return {
        success: true,
        providerId,
        providerType: "deepseek",
        credentials: { token },
        accountInfo: validation.accountInfo
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      this.emitProgress("error", `Token validation failed: ${errorMessage}`);
      return {
        success: false,
        providerId,
        providerType: "deepseek",
        error: errorMessage
      };
    }
  }
  /**
   * Handle callback (DeepSeek does not support)
   */
  async processCallback(data) {
  }
  /**
   * Validate token validity
   */
  async validateToken(credentials) {
    const token = credentials.token || credentials.userToken;
    if (!token) {
      return {
        valid: false,
        error: "Token cannot be empty"
      };
    }
    try {
      const response = await axios.get(`${DEEPSEEK_API_BASE}/api/v0/users/current`, {
        headers: {
          Authorization: `Bearer ${token}`,
          ...FAKE_HEADERS$4
        },
        timeout: 15e3,
        validateStatus: () => true
      });
      console.log("[DeepSeek OAuth] Response:", response.status, response.data);
      if (response.status !== 200 || !response.data) {
        return {
          valid: false,
          error: "Token is invalid or expired"
        };
      }
      const bizData = response.data?.data?.biz_data;
      if (!bizData) {
        return {
          valid: false,
          error: "Token validation failed: Invalid response data"
        };
      }
      return {
        valid: true,
        tokenType: "access",
        accountInfo: {
          userId: bizData.id,
          email: bizData.email,
          name: bizData.name
        }
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Validation request failed";
      return {
        valid: false,
        error: errorMessage
      };
    }
  }
  /**
   * Refresh token
   */
  async refreshToken(credentials) {
    const token = credentials.token || credentials.refreshToken;
    if (!token) {
      return null;
    }
    try {
      const response = await axios.get(`${DEEPSEEK_API_BASE}/api/v0/users/current`, {
        headers: {
          Authorization: `Bearer ${token}`,
          ...FAKE_HEADERS$4
        },
        timeout: 15e3,
        validateStatus: () => true
      });
      if (response.status !== 200 || !response.data?.biz_data?.token) {
        return null;
      }
      const newToken = response.data.biz_data.token;
      return {
        type: "access",
        value: newToken,
        expiresAt: this.getTimestamp() + 3600
      };
    } catch {
      return null;
    }
  }
}
const GLM_API_BASE = "https://chatglm.cn";
const FAKE_HEADERS$3 = {
  Accept: "text/event-stream",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
  "App-Name": "chatglm",
  "Cache-Control": "no-cache",
  "Content-Type": "application/json",
  Origin: GLM_API_BASE,
  Pragma: "no-cache",
  Priority: "u=1, i",
  "Sec-Ch-Ua": '"Microsoft Edge";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"Windows"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "X-App-Fr": "browser_extension",
  "X-App-Platform": "pc",
  "X-App-Version": "0.0.1",
  "X-Device-Brand": "",
  "X-Device-Model": "",
  "X-Lang": "zh",
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
};
const SIGN_SECRET = "8a1317a7468aa3ad86e997d08f3f31cb";
class GLMAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "glm",
      authMethods: ["manual"],
      loginUrl: GLM_API_BASE,
      apiUrl: GLM_API_BASE
    });
    this.pendingResolve = null;
  }
  /**
   * Generate signature
   * GLM timestamp signature algorithm
   */
  generateSign() {
    const e = Date.now();
    const A = e.toString();
    const t = A.length;
    const o = A.split("").map((c) => Number(c));
    const i = o.reduce((sum, digit) => sum + digit, 0) - o[t - 2];
    const a = i % 10;
    const timestamp = A.substring(0, t - 2) + a + A.substring(t - 1, t);
    const nonce = this.generateUUID().replace(/-/g, "");
    const sign = this.md5(`${timestamp}-${nonce}-${SIGN_SECRET}`);
    return { timestamp, nonce, sign };
  }
  /**
   * Start login flow - Open default browser
   */
  async startLogin(options) {
    this.emitProgress("pending", "Opening browser...");
    try {
      await server_bootstrapConfig.getRuntime().openExternal(GLM_API_BASE);
      this.emitProgress("pending", "Please log in via browser and enter Token manually");
      return {
        success: false,
        providerId: options.providerId,
        providerType: "glm",
        error: "Please log in via browser, extract Token from Developer Tools and enter manually"
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to open browser";
      this.emitProgress("error", errorMessage);
      return {
        success: false,
        providerId: options.providerId,
        providerType: "glm",
        error: errorMessage
      };
    }
  }
  /**
   * Complete authentication with refresh_token
   */
  async loginWithToken(providerId, refreshToken) {
    this.emitProgress("pending", "Validating Refresh Token...");
    try {
      const tokens = await this.refreshToken({ refreshToken });
      if (!tokens) {
        return {
          success: false,
          providerId,
          providerType: "glm",
          error: "Refresh Token is invalid or expired"
        };
      }
      const validation = await this.validateToken({
        refreshToken,
        accessToken: tokens.value
      });
      this.emitProgress("success", "Token validation successful");
      return {
        success: true,
        providerId,
        providerType: "glm",
        credentials: {
          refreshToken,
          accessToken: tokens.value
        },
        accountInfo: validation.accountInfo
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      this.emitProgress("error", `Token validation failed: ${errorMessage}`);
      return {
        success: false,
        providerId,
        providerType: "glm",
        error: errorMessage
      };
    }
  }
  /**
   * Handle callback (GLM does not support)
   */
  async processCallback(data) {
  }
  /**
   * Validate token validity
   */
  async validateToken(credentials) {
    const refreshToken = credentials.chatglm_refresh_token || credentials.refreshToken || credentials.refresh_token || credentials.token;
    if (!refreshToken) {
      return {
        valid: false,
        error: "Refresh Token cannot be empty"
      };
    }
    try {
      const sign = this.generateSign();
      const deviceId = this.generateUUID().replace(/-/g, "");
      const response = await axios.post(
        `${GLM_API_BASE}/chatglm/user-api/user/refresh`,
        {},
        {
          headers: {
            Authorization: `Bearer ${refreshToken}`,
            "X-Device-Id": deviceId,
            "X-Nonce": sign.nonce,
            "X-Request-Id": this.generateUUID().replace(/-/g, ""),
            "X-Sign": sign.sign,
            "X-Timestamp": sign.timestamp,
            ...FAKE_HEADERS$3
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      console.log("[GLM OAuth] Response:", response.status, response.data);
      if (response.status !== 200) {
        return {
          valid: false,
          error: `Refresh Token is invalid or expired (status: ${response.status})`
        };
      }
      if (!response.data) {
        return {
          valid: false,
          error: "Refresh Token is invalid or expired (no response data)"
        };
      }
      const result = response.data.result || response.data;
      if (!result.access_token) {
        return {
          valid: false,
          error: "Token validation failed: Unable to get access_token"
        };
      }
      if (result.is_guest === true) {
        return {
          valid: false,
          error: "Guest account not allowed, please login with a real account"
        };
      }
      const userInfo = await this.getUserInfo(result.access_token);
      console.log("[GLM OAuth] User info:", userInfo);
      if (userInfo) {
        const email = userInfo.email;
        const phone = userInfo.phone;
        const nickname = userInfo.nickname;
        const isGuest = userInfo.is_guest;
        if (isGuest === true) {
          return {
            valid: false,
            error: "Guest account not allowed, please login with a real account"
          };
        }
        if (nickname && nickname.includes("访客")) {
          return {
            valid: false,
            error: "Guest account not allowed, please login with a real account"
          };
        }
        if (email && email.includes("@guest")) {
          return {
            valid: false,
            error: "Guest account not allowed, please login with a real account"
          };
        }
        if (!phone && !email) {
          return {
            valid: false,
            error: "Guest account not allowed, please login with a real account"
          };
        }
        return {
          valid: true,
          tokenType: "refresh",
          accountInfo: {
            userId: result.user_id,
            email: email || "",
            name: nickname || phone || email || result.user_id
          }
        };
      }
      return {
        valid: true,
        tokenType: "refresh",
        accountInfo: {
          userId: result.user_id
        }
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Validation request failed";
      return {
        valid: false,
        error: errorMessage
      };
    }
  }
  /**
   * Refresh token
   * Get new access_token using refresh_token
   */
  async refreshToken(credentials) {
    const refreshToken = credentials.refreshToken || credentials.token;
    if (!refreshToken) {
      return null;
    }
    try {
      const sign = this.generateSign();
      const deviceId = this.generateUUID().replace(/-/g, "");
      const response = await axios.post(
        `${GLM_API_BASE}/chatglm/user-api/user/refresh`,
        {},
        {
          headers: {
            Authorization: `Bearer ${refreshToken}`,
            "X-Device-Id": deviceId,
            "X-Nonce": sign.nonce,
            "X-Request-Id": this.generateUUID().replace(/-/g, ""),
            "X-Sign": sign.sign,
            "X-Timestamp": sign.timestamp,
            ...FAKE_HEADERS$3
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      if (response.status !== 200 || !response.data?.result) {
        return null;
      }
      const { result } = response.data;
      return {
        type: "access",
        value: result.access_token,
        refreshToken: result.refresh_token,
        expiresAt: this.getTimestamp() + 3600
      };
    } catch {
      return null;
    }
  }
  /**
   * Get user info
   */
  async getUserInfo(accessToken) {
    try {
      const sign = this.generateSign();
      const deviceId = this.generateUUID().replace(/-/g, "");
      const response = await axios.get(`${GLM_API_BASE}/chatglm/user-api/user/info`, {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "X-Device-Id": deviceId,
          "X-Request-Id": this.generateUUID().replace(/-/g, ""),
          "X-Sign": sign.sign,
          "X-Timestamp": sign.timestamp,
          "X-Nonce": sign.nonce,
          ...FAKE_HEADERS$3
        },
        timeout: 15e3,
        validateStatus: () => true
      });
      if (response.status !== 200 || !response.data?.result) {
        return null;
      }
      return response.data.result;
    } catch {
      return null;
    }
  }
}
const KIMI_API_BASE = "https://www.kimi.com";
const FAKE_HEADERS$2 = {
  Accept: "*/*",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
  "Cache-Control": "no-cache",
  Pragma: "no-cache",
  Origin: KIMI_API_BASE,
  "R-Timezone": "Asia/Shanghai",
  "Sec-Ch-Ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"Windows"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
  Priority: "u=1, i",
  "X-Msh-Platform": "web"
};
class KimiAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "kimi",
      authMethods: ["manual"],
      loginUrl: KIMI_API_BASE,
      apiUrl: KIMI_API_BASE
    });
    this.deviceId = this.generateDeviceId();
    this.sessionId = this.generateSessionId();
  }
  /**
   * Generate device ID
   */
  generateDeviceId() {
    return `${Math.floor(Math.random() * 1e18) + 7e18}`;
  }
  /**
   * Generate session ID
   */
  generateSessionId() {
    return `${Math.floor(Math.random() * 1e17) + 17e17}`;
  }
  /**
   * Detect token type
   * Reference: detectTokenType function from Kimi-Free-API
   */
  detectTokenType(token) {
    if (token.startsWith("eyJ") && token.split(".").length === 3) {
      try {
        const payload = this.parseJWT(token);
        if (payload && payload.app_id === "kimi" && payload.typ === "access") {
          return "jwt";
        }
      } catch {
      }
    }
    return "refresh";
  }
  /**
   * Extract device ID from JWT token
   */
  extractDeviceIdFromJWT(token) {
    const payload = this.parseJWT(token);
    return payload?.device_id;
  }
  /**
   * Extract session ID from JWT token
   */
  extractSessionIdFromJWT(token) {
    const payload = this.parseJWT(token);
    return payload?.ssid;
  }
  /**
   * Extract user ID from JWT token
   */
  extractUserIdFromJWT(token) {
    const payload = this.parseJWT(token);
    return payload?.sub;
  }
  /**
   * Get request headers
   */
  getHeaders(token) {
    const headers = {
      ...FAKE_HEADERS$2,
      "X-Msh-Device-Id": this.deviceId,
      "X-Msh-Session-Id": this.sessionId,
      "Connect-Protocol-Version": "1"
    };
    if (token) {
      headers["Authorization"] = `Bearer ${token}`;
    }
    return headers;
  }
  async callGrpcApi(token, service, body) {
    const response = await axios.post(
      `${KIMI_API_BASE}${service}`,
      body,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          "Connect-Protocol-Version": "1",
          ...FAKE_HEADERS$2
        },
        timeout: 15e3,
        validateStatus: () => true
      }
    );
    if (response.status !== 200) {
      return null;
    }
    return response.data;
  }
  /**
   * Start login flow - Open default browser
   */
  async startLogin(options) {
    this.emitProgress("pending", "Opening browser...");
    try {
      await server_bootstrapConfig.getRuntime().openExternal(KIMI_API_BASE);
      this.emitProgress("pending", "Please log in via browser and enter Token manually");
      return {
        success: false,
        providerId: options.providerId,
        providerType: "kimi",
        error: "Please log in via browser, extract Token from Developer Tools and enter manually"
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to open browser";
      this.emitProgress("error", errorMessage);
      return {
        success: false,
        providerId: options.providerId,
        providerType: "kimi",
        error: errorMessage
      };
    }
  }
  /**
   * Complete authentication with token
   */
  async loginWithToken(providerId, token) {
    this.emitProgress("pending", "Validating Token...");
    const tokenType = this.detectTokenType(token);
    this.emitProgress("pending", `Detected token type: ${tokenType === "jwt" ? "JWT Access Token" : "Unknown Token"}`);
    try {
      const credentials = { accessToken: token };
      let accountInfo = {};
      if (tokenType === "jwt") {
        const userId = this.extractUserIdFromJWT(token);
        const deviceId = this.extractDeviceIdFromJWT(token);
        if (deviceId) {
          this.deviceId = deviceId;
        }
        accountInfo = { userId: userId || "" };
      }
      const userResponse = await this.callGrpcApi(token, "/apiv2/kimi.gateway.order.v1.SubscriptionService/GetSubscription", {});
      if (!userResponse || !userResponse.subscription) {
        return {
          success: false,
          providerId,
          providerType: "kimi",
          error: "Token is invalid or expired"
        };
      }
      accountInfo = {
        ...accountInfo,
        userId: userResponse.subscription?.userId || "",
        name: userResponse.subscription?.userName || ""
      };
      this.emitProgress("success", "Token validation successful");
      return {
        success: true,
        providerId,
        providerType: "kimi",
        credentials,
        accountInfo
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      this.emitProgress("error", `Token validation failed: ${errorMessage}`);
      return {
        success: false,
        providerId,
        providerType: "kimi",
        error: errorMessage
      };
    }
  }
  /**
   * Handle callback (Kimi does not support)
   */
  async processCallback(data) {
  }
  /**
   * Validate token validity using gRPC API
   */
  async validateToken(credentials) {
    const accessToken = credentials.accessToken || credentials.token || credentials.access_token || credentials.apiKey || credentials.api_key;
    if (!accessToken) {
      return {
        valid: false,
        error: "Token cannot be empty"
      };
    }
    const tokenType = this.detectTokenType(accessToken);
    try {
      const result = await this.callGrpcApi(accessToken, "/apiv2/kimi.gateway.order.v1.SubscriptionService/GetSubscription", {});
      if (!result || !result.subscription) {
        return {
          valid: false,
          error: "Token is invalid or expired"
        };
      }
      return {
        valid: true,
        tokenType,
        accountInfo: {
          userId: result.subscription?.userId || "",
          name: result.subscription?.userName || ""
        }
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Validation request failed";
      return {
        valid: false,
        error: errorMessage
      };
    }
  }
  /**
   * Refresh token - Kimi no longer supports refresh token API
   */
  async refreshToken(credentials) {
    return null;
  }
  /**
   * Get research version usage
   */
  async getResearchUsage(token) {
    try {
      const response = await axios.get(`${KIMI_API_BASE}/api/chat/research/usage`, {
        headers: this.getHeaders(token),
        timeout: 15e3,
        validateStatus: () => true
      });
      if (response.status !== 200 || !response.data) {
        return null;
      }
      return response.data;
    } catch {
      return null;
    }
  }
}
const MIMO_WEB_BASE = "https://aistudio.xiaomimimo.com";
class MimoAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "mimo",
      authMethods: ["manual", "cookie"],
      loginUrl: MIMO_WEB_BASE,
      apiUrl: MIMO_WEB_BASE
    });
  }
  async startLogin(options) {
    return {
      success: false,
      providerId: options.providerId,
      providerType: "mimo",
      error: "Use startInAppLogin for automatic cookie extraction or manually enter tokens"
    };
  }
  async loginWithCookies(providerId, cookies) {
    this.emitProgress("pending", "Validating cookies...");
    const serviceToken = cookies["serviceToken"] || cookies["service_token"];
    const userId = cookies["userId"] || cookies["user_id"];
    const phToken = cookies["xiaomichatbot_ph"] || cookies["ph_token"];
    if (!serviceToken || !userId || !phToken) {
      const missing = [];
      if (!serviceToken) missing.push("serviceToken");
      if (!userId) missing.push("userId");
      if (!phToken) missing.push("xiaomichatbot_ph");
      return {
        success: false,
        providerId,
        providerType: "mimo",
        error: `Missing required cookies: ${missing.join(", ")}`
      };
    }
    this.emitProgress("success", "Cookie validation successful");
    return {
      success: true,
      providerId,
      providerType: "mimo",
      credentials: {
        service_token: serviceToken,
        user_id: userId,
        ph_token: phToken
      },
      accountInfo: {
        userId,
        name: "Mimo User"
      }
    };
  }
  async processCallback(data) {
  }
  async validateToken(credentials) {
    const serviceToken = credentials["service_token"] || credentials["serviceToken"];
    const userId = credentials["user_id"] || credentials["userId"];
    const phToken = credentials["ph_token"] || credentials["xiaomichatbot_ph"];
    if (!serviceToken || !userId || !phToken) {
      return {
        valid: false,
        error: "Missing required credentials: service_token, user_id, ph_token"
      };
    }
    return {
      valid: true,
      tokenType: "cookie",
      accountInfo: {
        userId,
        name: "Mimo User"
      }
    };
  }
  async refreshToken(credentials) {
    const serviceToken = credentials["service_token"] || credentials["serviceToken"];
    const userId = credentials["user_id"] || credentials["userId"];
    const phToken = credentials["ph_token"] || credentials["xiaomichatbot_ph"];
    if (!serviceToken || !userId || !phToken) {
      return null;
    }
    return {
      type: "cookie",
      value: serviceToken,
      extra: {
        service_token: serviceToken,
        user_id: userId,
        ph_token: phToken
      }
    };
  }
}
const MINIMAX_API_BASE = "https://agent.minimaxi.com";
const FAKE_HEADERS$1 = {
  Accept: "application/json, text/plain, */*",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9",
  "Cache-Control": "no-cache",
  Origin: MINIMAX_API_BASE,
  Pragma: "no-cache",
  "Sec-Ch-Ua": '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
};
const FAKE_USER_DATA = {
  device_platform: "web",
  biz_id: "3",
  app_id: "3001",
  version_code: "22201",
  uuid: null,
  device_id: null,
  os_name: "Mac",
  browser_name: "chrome",
  device_memory: 8,
  cpu_core_num: 11,
  browser_language: "zh-CN",
  browser_platform: "MacIntel",
  user_id: null,
  screen_width: 1920,
  screen_height: 1080,
  unix: null,
  lang: "zh",
  token: null
};
function md5(input) {
  return crypto$1.createHash("md5").update(input).digest("hex");
}
function unixTimestamp() {
  return Math.floor(Date.now() / 1e3);
}
class MiniMaxAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "minimax",
      authMethods: ["manual"],
      loginUrl: MINIMAX_API_BASE,
      apiUrl: MINIMAX_API_BASE
    });
  }
  /**
   * Start login flow - Open default browser
   */
  async startLogin(options) {
    this.emitProgress("pending", "Opening browser...");
    try {
      await server_bootstrapConfig.getRuntime().openExternal(MINIMAX_API_BASE);
      this.emitProgress("pending", "Please log in via browser and enter Token manually");
      return {
        success: false,
        providerId: options.providerId,
        providerType: "minimax",
        error: "Please log in via browser, extract Token from Developer Tools and enter manually"
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to open browser";
      this.emitProgress("error", errorMessage);
      return {
        success: false,
        providerId: options.providerId,
        providerType: "minimax",
        error: errorMessage
      };
    }
  }
  /**
   * Complete authentication with token
   * Supports both:
   * - token: JWT token only (realUserID will be extracted from JWT)
   * - token + realUserID: Will be combined as "realUserID+JWTtoken"
   */
  async loginWithToken(providerId, token, realUserID) {
    this.emitProgress("pending", "Validating Token...");
    try {
      let finalToken = token;
      if (realUserID && realUserID.trim()) {
        finalToken = `${realUserID.trim()}+${token}`;
        console.log("[MiniMax] Combining realUserID with token");
      }
      const validation = await this.validateToken({ token: finalToken });
      if (!validation.valid) {
        return {
          success: false,
          providerId,
          providerType: "minimax",
          error: validation.error || "Token validation failed"
        };
      }
      this.emitProgress("success", "Token validation successful");
      return {
        success: true,
        providerId,
        providerType: "minimax",
        credentials: { token: finalToken },
        accountInfo: validation.accountInfo
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      this.emitProgress("error", `Token validation failed: ${errorMessage}`);
      return {
        success: false,
        providerId,
        providerType: "minimax",
        error: errorMessage
      };
    }
  }
  /**
   * Handle callback (MiniMax does not support)
   */
  async processCallback(data) {
  }
  /**
   * Validate token validity
   * Uses the same request format as proxy adapter
   */
  async validateToken(credentials) {
    const token = credentials.token;
    if (!token) {
      return {
        valid: false,
        error: "Token cannot be empty"
      };
    }
    console.log("[MiniMax OAuth] Validating token:", token.substring(0, 50) + "...");
    try {
      let jwtToken;
      let realUserID;
      if (token.includes("+")) {
        const parts = token.split("+");
        realUserID = parts[0];
        jwtToken = parts[1];
      } else {
        jwtToken = token;
        realUserID = this.extractUserIdFromToken(token) || "";
      }
      console.log("[MiniMax OAuth] realUserID:", realUserID, "jwtToken:", jwtToken.substring(0, 30) + "...");
      const unix = `${Date.now()}`;
      const timestamp = unixTimestamp();
      const userData = { ...FAKE_USER_DATA };
      userData.uuid = realUserID;
      userData.device_id = void 0;
      userData.user_id = realUserID;
      userData.unix = unix;
      userData.token = jwtToken;
      let queryStr = "";
      for (const key in userData) {
        if (userData[key] === void 0) continue;
        queryStr += `&${key}=${userData[key]}`;
      }
      queryStr = queryStr.substring(1);
      const uri = "/v1/api/user/info";
      const fullUri = `${uri}?${queryStr}`;
      const dataJson = "{}";
      const yy = md5(`${encodeURIComponent(fullUri)}_${dataJson}${md5(unix)}ooui`);
      const signature = md5(`${timestamp}${jwtToken}${dataJson}`);
      console.log("[MiniMax OAuth] Request - uuid:", realUserID, "user_id:", realUserID);
      const response = await axios.request({
        method: "GET",
        url: `${MINIMAX_API_BASE}${fullUri}`,
        timeout: 15e3,
        validateStatus: () => true,
        headers: {
          Referer: `${MINIMAX_API_BASE}/`,
          token: jwtToken,
          ...FAKE_HEADERS$1,
          "Content-Type": "application/json",
          "x-timestamp": String(timestamp),
          "x-signature": signature,
          yy
        }
      });
      console.log("[MiniMax OAuth] Validation response status:", response.status);
      console.log("[MiniMax OAuth] Validation response data:", JSON.stringify(response.data));
      if (response.status !== 200 || response.data?.statusInfo?.code !== 0) {
        const errorMsg = response.data?.statusInfo?.message || "Token is invalid or expired";
        console.log("[MiniMax OAuth] Validation failed:", errorMsg);
        return {
          valid: false,
          error: errorMsg
        };
      }
      const userInfo = response.data.data?.userInfo || response.data.data;
      return {
        valid: true,
        tokenType: "jwt",
        accountInfo: {
          userId: realUserID || userInfo?.id,
          name: userInfo?.name || userInfo?.nickname,
          email: userInfo?.email
        }
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Validation request failed";
      console.error("[MiniMax OAuth] Validation error:", errorMessage);
      return {
        valid: false,
        error: errorMessage
      };
    }
  }
  /**
   * Refresh token (MiniMax uses JWT, no refresh mechanism)
   */
  async refreshToken(credentials) {
    return null;
  }
  /**
   * Extract user ID from JWT token
   */
  extractUserIdFromToken(token) {
    try {
      const payload = this.parseJWT(token);
      return payload?.user?.id || payload?.sub;
    } catch {
      return void 0;
    }
  }
  /**
   * Get user credits/balance
   */
  async getCredits(token) {
    try {
      const response = await axios.get(`${MINIMAX_API_BASE}/v1/api/user/credit`, {
        headers: {
          ...FAKE_HEADERS$1,
          "token": token,
          Referer: `${MINIMAX_API_BASE}/`
        },
        timeout: 15e3,
        validateStatus: () => true
      });
      if (response.status === 200 && response.data?.statusInfo?.code === 0) {
        const data = response.data.data;
        return {
          totalCredits: data?.totalCredit || data?.total_credits || 0,
          usedCredits: data?.usedCredit || data?.used_credits || 0,
          remainingCredits: data?.remainCredit || data?.remaining_credits || 0
        };
      }
      return null;
    } catch {
      return null;
    }
  }
}
const PERPLEXITY_WEB_BASE = "https://www.perplexity.ai";
class PerplexityAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "perplexity",
      authMethods: ["manual", "cookie"],
      loginUrl: PERPLEXITY_WEB_BASE,
      apiUrl: PERPLEXITY_WEB_BASE
    });
  }
  async startLogin(options) {
    return {
      success: false,
      providerId: options.providerId,
      providerType: "perplexity",
      error: "Use startInAppLogin for automatic cookie extraction"
    };
  }
  async loginWithCookies(providerId, cookies) {
    this.emitProgress("pending", "Validating cookies...");
    const sessionToken = cookies["__Secure-next-auth.session-token"] || cookies["next-auth.session-token"] || cookies["sessionToken"];
    if (!sessionToken) {
      return {
        success: false,
        providerId,
        providerType: "perplexity",
        error: "Session token is required (__Secure-next-auth.session-token or next-auth.session-token)"
      };
    }
    this.emitProgress("success", "Cookie validation successful");
    return {
      success: true,
      providerId,
      providerType: "perplexity",
      credentials: {
        sessionToken
      },
      accountInfo: {
        name: "Perplexity User"
      }
    };
  }
  async processCallback(data) {
  }
  async validateToken(credentials) {
    const sessionToken = credentials["__Secure-next-auth.session-token"] || credentials["next-auth.session-token"] || credentials["sessionToken"] || credentials["token"];
    if (!sessionToken) {
      return {
        valid: false,
        error: "Session token is required (__Secure-next-auth.session-token or next-auth.session-token)"
      };
    }
    return {
      valid: true,
      tokenType: "cookie",
      accountInfo: {
        name: "Perplexity User"
      }
    };
  }
  async refreshToken(credentials) {
    const sessionToken = credentials["__Secure-next-auth.session-token"] || credentials["next-auth.session-token"] || credentials["sessionToken"] || credentials["token"];
    if (!sessionToken) {
      return null;
    }
    return {
      type: "cookie",
      value: sessionToken,
      extra: credentials
    };
  }
}
const QWEN_API_BASE = "https://chat2-api.qianwen.com";
const QWEN_WEB_BASE = "https://www.qianwen.com";
const DEFAULT_HEADERS = {
  Accept: "application/json, text/plain, */*",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9",
  "Cache-Control": "no-cache",
  Origin: QWEN_WEB_BASE,
  Pragma: "no-cache",
  "Sec-Ch-Ua": '"Chromium";v="145", "Not(A:Brand";v="24", "Google Chrome";v="145"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"macOS"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-site",
  Referer: `${QWEN_WEB_BASE}/`,
  "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
};
class QwenAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "qwen",
      authMethods: ["manual", "cookie"],
      loginUrl: QWEN_WEB_BASE,
      apiUrl: QWEN_API_BASE
    });
  }
  generateCookie(ticket) {
    return `tongyi_sso_ticket=${ticket}`;
  }
  async startLogin(options) {
    this.emitProgress("pending", "Opening browser...");
    try {
      await server_bootstrapConfig.getRuntime().openExternal(QWEN_WEB_BASE);
      this.emitProgress("pending", "Please log in via browser and enter Ticket manually");
      return {
        success: false,
        providerId: options.providerId,
        providerType: "qwen",
        error: "Please log in via browser, extract tongyi_sso_ticket from Developer Tools and enter manually"
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Failed to open browser";
      this.emitProgress("error", errorMessage);
      return {
        success: false,
        providerId: options.providerId,
        providerType: "qwen",
        error: errorMessage
      };
    }
  }
  async loginWithToken(providerId, ticket) {
    this.emitProgress("pending", "Validating Ticket...");
    try {
      const validation = await this.validateToken({ ticket });
      if (!validation.valid) {
        return {
          success: false,
          providerId,
          providerType: "qwen",
          error: validation.error || "Ticket validation failed"
        };
      }
      this.emitProgress("success", "Ticket validation successful");
      return {
        success: true,
        providerId,
        providerType: "qwen",
        credentials: { ticket },
        accountInfo: validation.accountInfo
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      this.emitProgress("error", `Ticket validation failed: ${errorMessage}`);
      return {
        success: false,
        providerId,
        providerType: "qwen",
        error: errorMessage
      };
    }
  }
  async processCallback(data) {
  }
  async validateToken(credentials) {
    const ticket = credentials.ticket || credentials.tongyi_sso_ticket;
    if (!ticket) {
      return {
        valid: false,
        error: "Ticket cannot be empty"
      };
    }
    try {
      const response = await axios.post(
        `${QWEN_API_BASE}/api/v2/session/page/list`,
        {},
        {
          headers: {
            Cookie: this.generateCookie(ticket),
            ...DEFAULT_HEADERS,
            "X-Platform": "pc_tongyi",
            "X-DeviceId": "5b68c267-cd8e-fd0e-148a-18345bc9a104"
          },
          params: {
            biz_id: "ai_qwen",
            chat_client: "h5",
            device: "pc",
            fr: "pc",
            pr: "qwen",
            ut: "5b68c267-cd8e-fd0e-148a-18345bc9a104"
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      if (response.status !== 200) {
        return {
          valid: false,
          error: "Ticket is invalid or expired"
        };
      }
      const { success, errorCode, errorMsg, data } = response.data;
      if (success === false) {
        return {
          valid: false,
          error: errorMsg || `Validation failed: ${errorCode}`
        };
      }
      return {
        valid: true,
        tokenType: "cookie",
        accountInfo: {}
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Validation request failed";
      return {
        valid: false,
        error: errorMessage
      };
    }
  }
  async refreshToken(credentials) {
    return null;
  }
  async getSessionList(ticket) {
    try {
      const response = await axios.post(
        `${QWEN_API_BASE}/api/v2/session/page/list`,
        {},
        {
          headers: {
            Cookie: this.generateCookie(ticket),
            ...DEFAULT_HEADERS,
            "X-Platform": "pc_tongyi",
            "X-DeviceId": "5b68c267-cd8e-fd0e-148a-18345bc9a104"
          },
          params: {
            biz_id: "ai_qwen",
            chat_client: "h5",
            device: "pc",
            fr: "pc",
            pr: "qwen",
            ut: "5b68c267-cd8e-fd0e-148a-18345bc9a104"
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      if (response.status !== 200 || !response.data?.success) {
        return null;
      }
      return response.data.data;
    } catch {
      return null;
    }
  }
  async deleteSession(sessionId, ticket) {
    if (!sessionId || !ticket) {
      return false;
    }
    try {
      const response = await axios.post(
        `${QWEN_API_BASE}/api/v2/session/delete`,
        { session_id: sessionId },
        {
          headers: {
            Cookie: this.generateCookie(ticket),
            ...DEFAULT_HEADERS,
            "X-Platform": "pc_tongyi",
            "X-DeviceId": "5b68c267-cd8e-fd0e-148a-18345bc9a104"
          },
          params: {
            biz_id: "ai_qwen",
            chat_client: "h5",
            device: "pc",
            fr: "pc",
            pr: "qwen",
            ut: "5b68c267-cd8e-fd0e-148a-18345bc9a104"
          },
          timeout: 15e3,
          validateStatus: () => true
        }
      );
      if (response.status !== 200) {
        console.warn(`[Qwen] Failed to delete session ${sessionId}: status ${response.status}`);
        return false;
      }
      const { success, errorMsg } = response.data;
      if (success === false) {
        console.warn(`[Qwen] Failed to delete session ${sessionId}: ${errorMsg}`);
        return false;
      }
      console.log(`[Qwen] Session deleted successfully: ${sessionId}`);
      return true;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.warn(`[Qwen] Failed to delete session ${sessionId}: ${errorMessage}`);
      return false;
    }
  }
}
const QWEN_AI_API_BASE = "https://chat.qwen.ai";
const FAKE_HEADERS = {
  Accept: "application/json",
  "Accept-Encoding": "gzip, deflate, br, zstd",
  "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
  "Cache-Control": "no-cache",
  Origin: QWEN_AI_API_BASE,
  Pragma: "no-cache",
  "Sec-Ch-Ua": '"Chromium";v="144", "Not(A:Brand";v="8", "Google Chrome";v="144"',
  "Sec-Ch-Ua-Mobile": "?0",
  "Sec-Ch-Ua-Platform": '"Windows"',
  "Sec-Fetch-Dest": "empty",
  "Sec-Fetch-Mode": "cors",
  "Sec-Fetch-Site": "same-origin",
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36",
  source: "web"
};
class QwenAiAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "qwen-ai",
      authMethods: ["manual"],
      loginUrl: QWEN_AI_API_BASE,
      apiUrl: QWEN_AI_API_BASE
    });
  }
  async loginWithToken(providerId, token) {
    this.emitProgress("pending", "Validating Token...");
    try {
      const validation = await this.validateToken({ token });
      if (!validation.valid) {
        return {
          success: false,
          providerId,
          providerType: "qwen-ai",
          error: validation.error || "Token validation failed"
        };
      }
      this.emitProgress("success", "Token validation successful");
      return {
        success: true,
        providerId,
        providerType: "qwen-ai",
        credentials: { token },
        accountInfo: validation.accountInfo
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Validation request failed";
      return {
        success: false,
        providerId,
        providerType: "qwen-ai",
        error: errorMessage
      };
    }
  }
  async processCallback(data) {
  }
  async validateToken(credentials) {
    const token = credentials.token;
    if (!token) {
      return {
        valid: false,
        error: "Token cannot be empty"
      };
    }
    if (token.startsWith("eyJ") && token.split(".").length === 3) {
      try {
        const parts = token.split(".");
        const payload = JSON.parse(Buffer.from(parts[1], "base64").toString());
        if (payload.email && payload.email.includes("@guest.com")) {
          return {
            valid: false,
            error: "Guest account not allowed, please login with a real account"
          };
        }
        if (payload && (payload.sub || payload.id || payload.user_id || payload.uid)) {
          const userId = payload.sub || payload.id || payload.user_id || payload.uid;
          try {
            const userInfo = await this.getUserInfo(token);
            console.log("[QwenAi OAuth] User info:", userInfo);
            if (!userInfo) {
              return {
                valid: false,
                error: "Token validation failed against chat.qwen.ai user API. Re-import token and cookies from a logged-in browser session."
              };
            }
            if (userInfo && userInfo.is_guest === true) {
              return {
                valid: false,
                error: "Guest account not allowed, please login with a real account"
              };
            }
            return {
              valid: true,
              tokenType: "access",
              accountInfo: {
                userId,
                email: payload.email || userInfo?.email || "",
                name: payload.name || userInfo?.name || payload.email || userId
              }
            };
          } catch (apiError) {
            console.log("[QwenAi OAuth] API validation failed:", apiError);
            return {
              valid: false,
              error: "Token validation request failed. Re-import token and cookies from a logged-in browser session."
            };
          }
        }
      } catch {
        return {
          valid: false,
          error: "Invalid JWT token"
        };
      }
    }
    return {
      valid: false,
      error: "Token is invalid"
    };
  }
  async getUserInfo(token) {
    try {
      const response = await axios.get(`${QWEN_AI_API_BASE}/api/v2/user/info`, {
        headers: {
          Authorization: `Bearer ${token}`,
          ...FAKE_HEADERS
        },
        timeout: 15e3,
        validateStatus: () => true
      });
      if (response.status !== 200 || !response.data?.success) {
        return null;
      }
      return response.data.data;
    } catch {
      return null;
    }
  }
  async refreshToken(credentials) {
    return null;
  }
}
const ZAI_API_BASE = "https://chat.z.ai";
class ZaiAdapter2 extends BaseOAuthAdapter {
  constructor(config) {
    super({
      ...config,
      providerType: "zai",
      authMethods: ["manual"],
      loginUrl: ZAI_API_BASE,
      apiUrl: ZAI_API_BASE
    });
  }
  /**
   * Complete authentication with manually entered token
   */
  async loginWithToken(providerId, token) {
    this.emitProgress("pending", "Validating Token...");
    try {
      const validation = await this.validateToken({ token });
      if (!validation.valid) {
        return {
          success: false,
          providerId,
          providerType: "zai",
          error: validation.error || "Token validation failed"
        };
      }
      this.emitProgress("success", "Token validation successful");
      return {
        success: true,
        providerId,
        credentials: { token },
        accountInfo: validation.accountInfo
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Validation request failed";
      return {
        success: false,
        providerId,
        providerType: "zai",
        error: errorMessage
      };
    }
  }
  /**
   * Handle callback (Z.ai does not support)
   */
  async processCallback(data) {
  }
  /**
   * Validate token validity
   */
  async validateToken(credentials) {
    const token = credentials.token;
    if (!token) {
      return {
        valid: false,
        error: "Token cannot be empty"
      };
    }
    if (token.startsWith("eyJ") && token.split(".").length === 3) {
      try {
        const parts = token.split(".");
        const payload = JSON.parse(Buffer.from(parts[1], "base64").toString());
        if (payload.email && payload.email.includes("@guest.com")) {
          return {
            valid: false,
            error: "Guest account not allowed, please login with a real account"
          };
        }
        if (payload && payload.id) {
          return {
            valid: true,
            tokenType: "access",
            accountInfo: {
              userId: payload.id,
              email: payload.email || "",
              name: payload.email || payload.id
            }
          };
        }
      } catch {
        return {
          valid: false,
          error: "Invalid JWT token"
        };
      }
    }
    return {
      valid: false,
      error: "Token is invalid"
    };
  }
}
function createAdapter(providerType, config) {
  switch (providerType) {
    case "deepseek":
      return new DeepSeekAdapter2(config);
    case "glm":
      return new GLMAdapter2(config);
    case "kimi":
      return new KimiAdapter2(config);
    case "mimo":
      return new MimoAdapter2(config);
    case "minimax":
      return new MiniMaxAdapter2(config);
    case "perplexity":
      return new PerplexityAdapter2(config);
    case "qwen":
      return new QwenAdapter2(config);
    case "qwen-ai":
      return new QwenAiAdapter2(config);
    case "zai":
      return new ZaiAdapter2(config);
    default:
      throw new Error(`Unsupported provider type: ${providerType}`);
  }
}
const router$2 = new Router({ prefix: "/v0/management" });
const BROWSER_IMPORT_RESULT_TTL_MS = 10 * 60 * 1e3;
const BROWSER_IMPORT_RESULT_LIMIT = 128;
const browserImportResults = /* @__PURE__ */ new Map();
function cleanupBrowserImportResults() {
  const now = Date.now();
  for (const [id, result] of browserImportResults.entries()) {
    if (result.expiresAt <= now) {
      browserImportResults.delete(id);
    }
  }
  if (browserImportResults.size > BROWSER_IMPORT_RESULT_LIMIT) {
    const overflow = browserImportResults.size - BROWSER_IMPORT_RESULT_LIMIT;
    const oldestIds = [...browserImportResults.entries()].sort(([, left], [, right]) => left.createdAt - right.createdAt).slice(0, overflow).map(([id]) => id);
    oldestIds.forEach((id) => browserImportResults.delete(id));
  }
}
function parseBrowserImportBody(body) {
  if (typeof body === "string") {
    try {
      return JSON.parse(body);
    } catch {
      return {};
    }
  }
  return body && typeof body === "object" ? body : {};
}
function normalizeBrowserImportCredentials(providerId, credentials) {
  if (providerId === "qwen-ai") {
    return {
      token: String(credentials.token || ""),
      cookies: String(credentials.cookies || ""),
      baxiaUidToken: String(credentials.baxiaUidToken || credentials.baxia_uid_token || credentials.uidToken || ""),
      baxiaUa: String(credentials.baxiaUa || credentials.baxia_ua || credentials.bxUa || credentials.bx_ua || ""),
      baxiaVersion: String(credentials.baxiaVersion || credentials.baxia_version || credentials.bxV || credentials.bx_v || ""),
      x5secdata: String(credentials.x5secdata || ""),
      x5sectag: String(credentials.x5sectag || "")
    };
  }
  const ticket = String(credentials.ticket || credentials.tongyi_sso_ticket || "");
  return {
    ticket,
    tongyi_sso_ticket: ticket
  };
}
function setBrowserImportResult(input) {
  cleanupBrowserImportResults();
  if (!input.importId || input.importId.length < 16) {
    throw new Error("importId is required");
  }
  if (input.providerId !== "qwen" && input.providerId !== "qwen-ai") {
    throw new Error("Unsupported browser import provider");
  }
  const credentials = normalizeBrowserImportCredentials(
    input.providerId,
    input.credentials || {}
  );
  const error = String(input.error || "");
  const now = Date.now();
  const result = {
    importId: input.importId,
    providerId: input.providerId,
    status: error ? "error" : "success",
    credentials,
    error: error || void 0,
    createdAt: now,
    expiresAt: now + BROWSER_IMPORT_RESULT_TTL_MS
  };
  browserImportResults.set(input.importId, result);
  return result;
}
router$2.post("/browser-import/complete", async (ctx) => {
  const body = parseBrowserImportBody(ctx.request.body);
  try {
    const result = setBrowserImportResult({
      importId: String(body.importId || ""),
      providerId: String(body.providerId || ""),
      credentials: parseBrowserImportBody(body.credentials),
      error: String(body.error || "")
    });
    ctx.body = {
      success: true,
      data: {
        status: result.status,
        providerId: result.providerId
      }
    };
  } catch (error) {
    ctx.status = 400;
    ctx.body = {
      success: false,
      error: {
        code: "invalid_browser_import",
        message: error instanceof Error ? error.message : "Invalid browser import payload"
      }
    };
  }
});
router$2.use(managementAuthMiddleware);
router$2.get("/browser-import/:importId", async (ctx) => {
  cleanupBrowserImportResults();
  const importId = String(ctx.params.importId || "");
  const result = browserImportResults.get(importId);
  ctx.body = {
    success: true,
    data: result || null
  };
});
router$2.get("/statistics", async (ctx) => {
  try {
    const proxyStats = proxyStatusManager.getStatistics();
    const persistentStats = server_bootstrapConfig.storeManager.getStatistics();
    const todayStats = server_bootstrapConfig.storeManager.getTodayStatistics();
    const response = {
      totalRequests: persistentStats.totalRequests,
      successRequests: persistentStats.successRequests,
      failedRequests: persistentStats.failedRequests,
      avgLatency: persistentStats.successRequests > 0 ? persistentStats.totalLatency / persistentStats.successRequests : 0,
      requestsPerMinute: proxyStats.requestsPerMinute,
      activeConnections: proxyStats.activeConnections,
      modelUsage: persistentStats.modelUsage,
      providerUsage: persistentStats.providerUsage,
      accountUsage: persistentStats.accountUsage,
      dailyStats: {
        [todayStats.date]: {
          totalRequests: todayStats.totalRequests,
          successRequests: todayStats.successRequests,
          failedRequests: todayStats.failedRequests
        }
      }
    };
    ctx.body = {
      success: true,
      data: response
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: {
        code: "internal_error",
        message: errorMessage
      }
    };
  }
});
router$2.get("/statistics/persistent", async (ctx) => {
  try {
    ctx.body = {
      success: true,
      data: server_bootstrapConfig.storeManager.getStatistics()
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: { code: "internal_error", message: errorMessage }
    };
  }
});
router$2.get("/statistics/today", async (ctx) => {
  try {
    ctx.body = {
      success: true,
      data: server_bootstrapConfig.storeManager.getTodayStatistics()
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: { code: "internal_error", message: errorMessage }
    };
  }
});
router$2.get("/proxy/statistics", async (ctx) => {
  try {
    const stats = proxyStatusManager.getStatistics();
    ctx.body = {
      success: true,
      data: {
        totalRequests: stats.totalRequests,
        successRequests: stats.successRequests,
        failedRequests: stats.failedRequests,
        avgLatency: stats.avgLatency,
        requestsPerMinute: stats.requestsPerMinute,
        activeConnections: stats.activeConnections,
        modelUsage: stats.modelUsage,
        providerUsage: stats.providerUsage,
        accountUsage: stats.accountUsage
      }
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: { code: "internal_error", message: errorMessage }
    };
  }
});
router$2.get("/health", async (ctx) => {
  try {
    const runningStatus = proxyStatusManager.getRunningStatus();
    const config = server_bootstrapConfig.storeManager.getConfig();
    const proxyConfig = proxyStatusManager.getConfig();
    const proxyStatus = {
      isRunning: runningStatus.isRunning,
      port: proxyConfig.port,
      host: proxyConfig.host,
      uptime: runningStatus.uptime,
      connections: proxyStatusManager.getStatistics().activeConnections
    };
    const healthStatus = {
      status: runningStatus.isRunning ? "healthy" : "unhealthy",
      version: process.env.npm_package_version || "1.0.0",
      uptime: runningStatus.uptime,
      timestamp: Date.now(),
      components: {
        proxy: runningStatus.isRunning ? "up" : "down",
        database: "up",
        managementApi: config.managementApi.enableManagementApi ? "up" : "down"
      }
    };
    ctx.body = {
      success: true,
      data: {
        health: healthStatus,
        proxy: proxyStatus
      }
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: {
        code: "internal_error",
        message: errorMessage
      }
    };
  }
});
router$2.get("/logs", async (ctx) => {
  try {
    const query = ctx.query;
    const page = Math.max(1, parseInt(query.page || "1", 10));
    const limit = Math.min(200, Math.max(1, parseInt(query.limit || "50", 10)));
    const level = query.level;
    const logType = query.type || "request";
    if (logType === "system") {
      const allLogs = server_bootstrapConfig.storeManager.getLogs(level ? { level } : void 0);
      const total = allLogs.length;
      const totalPages = Math.ceil(total / limit);
      const startIndex = (page - 1) * limit;
      const logs = allLogs.slice(startIndex, startIndex + limit);
      ctx.body = {
        success: true,
        data: {
          logs,
          pagination: {
            page,
            limit,
            total,
            totalPages
          }
        }
      };
    } else {
      const allRequestLogs = server_bootstrapConfig.storeManager.getRequestLogs();
      let filteredLogs = allRequestLogs;
      if (level === "error") {
        filteredLogs = allRequestLogs.filter((log) => log.status === "error");
      } else if (level === "info") {
        filteredLogs = allRequestLogs.filter((log) => log.status === "success");
      }
      const total = filteredLogs.length;
      const totalPages = Math.ceil(total / limit);
      const startIndex = (page - 1) * limit;
      const logs = filteredLogs.slice(startIndex, startIndex + limit);
      ctx.body = {
        success: true,
        data: {
          logs,
          pagination: {
            page,
            limit,
            total,
            totalPages
          }
        }
      };
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: {
        code: "internal_error",
        message: errorMessage
      }
    };
  }
});
router$2.get("/app-logs", async (ctx) => {
  try {
    const level = ctx.query.level;
    const keyword = ctx.query.keyword;
    const startTime = ctx.query.startTime ? Number(ctx.query.startTime) : void 0;
    const endTime = ctx.query.endTime ? Number(ctx.query.endTime) : void 0;
    const limit = ctx.query.limit ? Number(ctx.query.limit) : void 0;
    const offset = ctx.query.offset ? Number(ctx.query.offset) : void 0;
    ctx.body = {
      success: true,
      data: server_bootstrapConfig.storeManager.getLogs({ level, keyword, startTime, endTime, limit, offset })
    };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: { code: "internal_error", message: errorMessage }
    };
  }
});
router$2.put("/app-logs", async (ctx) => {
  try {
    server_bootstrapConfig.storeManager.replaceLogs(Array.isArray(ctx.request.body) ? ctx.request.body : []);
    ctx.body = { success: true, data: null };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: { code: "internal_error", message: errorMessage }
    };
  }
});
router$2.delete("/app-logs", async (ctx) => {
  try {
    server_bootstrapConfig.storeManager.clearLogs();
    ctx.body = { success: true, data: null };
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    ctx.status = 500;
    ctx.body = {
      success: false,
      error: { code: "internal_error", message: errorMessage }
    };
  }
});
router$2.get("/app-logs/stats", async (ctx) => {
  ctx.body = { success: true, data: server_bootstrapConfig.storeManager.getLogStats() };
});
router$2.get("/app-logs/trend", async (ctx) => {
  const days = ctx.query.days ? Number(ctx.query.days) : void 0;
  ctx.body = { success: true, data: server_bootstrapConfig.storeManager.getLogTrend(days) };
});
router$2.get("/accounts/:accountId/logs/trend", async (ctx) => {
  const days = ctx.query.days ? Number(ctx.query.days) : void 0;
  ctx.body = {
    success: true,
    data: server_bootstrapConfig.storeManager.getAccountLogTrend(ctx.params.accountId, days)
  };
});
router$2.get("/app-logs/export", async (ctx) => {
  const format = ctx.query.format === "txt" ? "txt" : "json";
  ctx.body = {
    success: true,
    data: server_bootstrapConfig.storeManager.exportLogs(format)
  };
});
router$2.get("/app-logs/:id", async (ctx) => {
  const log = server_bootstrapConfig.storeManager.getLogById(ctx.params.id);
  if (!log) {
    ctx.status = 404;
    ctx.body = {
      success: false,
      error: { code: "not_found", message: "Log not found" }
    };
    return;
  }
  ctx.body = { success: true, data: log };
});
router$2.get("/request-logs", async (ctx) => {
  const limit = ctx.query.limit ? Number(ctx.query.limit) : void 0;
  const filter = {
    status: ctx.query.status,
    providerId: ctx.query.providerId
  };
  ctx.body = {
    success: true,
    data: server_bootstrapConfig.storeManager.getRequestLogs(limit, filter)
  };
});
router$2.get("/request-logs/stats", async (ctx) => {
  ctx.body = { success: true, data: server_bootstrapConfig.storeManager.getRequestLogStats() };
});
router$2.get("/request-logs/trend", async (ctx) => {
  const days = ctx.query.days ? Number(ctx.query.days) : void 0;
  ctx.body = { success: true, data: server_bootstrapConfig.storeManager.getRequestLogTrend(days) };
});
router$2.delete("/request-logs", async (ctx) => {
  server_bootstrapConfig.storeManager.clearRequestLogs();
  ctx.body = { success: true, data: null };
});
router$2.get("/request-logs/:id", async (ctx) => {
  const log = server_bootstrapConfig.storeManager.getRequestLogById(ctx.params.id);
  if (!log) {
    ctx.status = 404;
    ctx.body = {
      success: false,
      error: { code: "not_found", message: "Request log not found" }
    };
    return;
  }
  ctx.body = { success: true, data: log };
});
router$2.get("/prompts", async (ctx) => {
  ctx.body = { success: true, data: server_bootstrapConfig.storeManager.getSystemPrompts() };
});
router$2.get("/prompts/builtin", async (ctx) => {
  ctx.body = { success: true, data: server_bootstrapConfig.storeManager.getBuiltinPrompts() };
});
router$2.get("/prompts/custom", async (ctx) => {
  ctx.body = { success: true, data: server_bootstrapConfig.storeManager.getCustomPrompts() };
});
router$2.get("/prompts/type/:type", async (ctx) => {
  ctx.body = {
    success: true,
    data: server_bootstrapConfig.storeManager.getSystemPromptsByType(ctx.params.type)
  };
});
router$2.get("/prompts/:id", async (ctx) => {
  const prompt = server_bootstrapConfig.storeManager.getSystemPromptById(ctx.params.id);
  if (!prompt) {
    ctx.status = 404;
    ctx.body = {
      success: false,
      error: { code: "not_found", message: "Prompt not found" }
    };
    return;
  }
  ctx.body = { success: true, data: prompt };
});
router$2.post("/prompts", async (ctx) => {
  ctx.status = 201;
  ctx.body = {
    success: true,
    data: server_bootstrapConfig.storeManager.addSystemPrompt(ctx.request.body)
  };
});
router$2.put("/prompts/:id", async (ctx) => {
  ctx.body = {
    success: true,
    data: server_bootstrapConfig.storeManager.updateSystemPrompt(ctx.params.id, ctx.request.body)
  };
});
router$2.delete("/prompts/:id", async (ctx) => {
  ctx.body = {
    success: true,
    data: server_bootstrapConfig.storeManager.deleteSystemPrompt(ctx.params.id)
  };
});
router$2.get("/store/:key", async (ctx) => {
  const key = ctx.params.key;
  ctx.body = {
    success: true,
    data: server_bootstrapConfig.storeManager.getStore()?.get(key)
  };
});
router$2.put("/store/:key", async (ctx) => {
  const key = ctx.params.key;
  const body = ctx.request.body;
  server_bootstrapConfig.storeManager.getStore()?.set(key, body.value);
  ctx.body = { success: true, data: null };
});
router$2.delete("/store/:key", async (ctx) => {
  const key = ctx.params.key;
  server_bootstrapConfig.storeManager.getStore()?.delete(key);
  ctx.body = { success: true, data: null };
});
router$2.delete("/store", async (ctx) => {
  const body = ctx.request.body;
  if (!body || body.confirm !== true) {
    ctx.status = 400;
    ctx.body = {
      success: false,
      error: { code: "confirmation_required", message: "Request body must include { confirm: true }" }
    };
    return;
  }
  server_bootstrapConfig.storeManager.clearAll();
  ctx.body = { success: true, data: null };
});
router$2.get("/oauth/status", async (ctx) => {
  ctx.body = { success: true, data: "idle" };
});
router$2.post("/oauth/start-login", async (ctx) => {
  const body = ctx.request.body;
  if (!body.providerId || !body.providerType) {
    ctx.status = 400;
    ctx.body = {
      success: false,
      error: { code: "invalid_request", message: "providerId and providerType are required" }
    };
    return;
  }
  const adapter = createAdapter(body.providerType, {
    providerId: body.providerId,
    providerType: body.providerType,
    authMethods: [],
    callbackPort: 8311
  });
  ctx.body = { success: true, data: await adapter.startLogin({ providerId: body.providerId, providerType: body.providerType }) };
});
router$2.post("/oauth/cancel-login", async (ctx) => {
  ctx.body = { success: true, data: null };
});
router$2.post("/oauth/login-with-token", async (ctx) => {
  const body = ctx.request.body;
  if (!body.providerId || !body.providerType || !body.token) {
    ctx.status = 400;
    ctx.body = {
      success: false,
      error: { code: "invalid_request", message: "providerId, providerType and token are required" }
    };
    return;
  }
  const adapter = createAdapter(body.providerType, {
    providerId: body.providerId,
    providerType: body.providerType,
    authMethods: [],
    callbackPort: 8311
  });
  if (typeof adapter.loginWithToken === "function") {
    ctx.body = {
      success: true,
      data: await adapter.loginWithToken(body.providerId, body.token, body.realUserID, body.mimoUserId, body.mimoPhToken)
    };
    return;
  }
  const validationCredentials = body.providerType === "mimo" ? { service_token: body.token, user_id: body.mimoUserId || "", ph_token: body.mimoPhToken || "" } : { token: body.token };
  const validation = await adapter.validateToken(validationCredentials);
  ctx.body = {
    success: true,
    data: validation.valid ? {
      success: true,
      providerId: body.providerId,
      providerType: body.providerType,
      credentials: validationCredentials,
      accountInfo: validation.accountInfo
    } : {
      success: false,
      providerId: body.providerId,
      providerType: body.providerType,
      error: validation.error || "Token validation failed"
    }
  };
});
router$2.post("/oauth/validate-token", async (ctx) => {
  const body = ctx.request.body;
  if (!body.providerId || !body.providerType) {
    ctx.status = 400;
    ctx.body = {
      success: false,
      error: { code: "invalid_request", message: "providerId and providerType are required" }
    };
    return;
  }
  const adapter = createAdapter(body.providerType, {
    providerId: body.providerId,
    providerType: body.providerType,
    authMethods: [],
    callbackPort: 8311
  });
  ctx.body = {
    success: true,
    data: await adapter.validateToken(body.credentials || {})
  };
});
router$2.post("/oauth/refresh-token", async (ctx) => {
  const body = ctx.request.body;
  if (!body.providerId || !body.providerType) {
    ctx.status = 400;
    ctx.body = {
      success: false,
      error: { code: "invalid_request", message: "providerId and providerType are required" }
    };
    return;
  }
  const adapter = createAdapter(body.providerType, {
    providerId: body.providerId,
    providerType: body.providerType,
    authMethods: [],
    callbackPort: 8311
  });
  ctx.body = {
    success: true,
    data: await adapter.refreshToken(body.credentials || {})
  };
});
router$2.post("/management-api/generate-secret", async (ctx) => {
  const secret = generateManagementSecret();
  const config = server_bootstrapConfig.storeManager.getConfig();
  server_bootstrapConfig.storeManager.updateConfig({
    managementApi: {
      ...config.managementApi,
      managementApiSecret: secret
    }
  });
  ctx.body = { success: true, data: secret };
});
router$2.post("/app/open-external", async (ctx) => {
  const body = ctx.request.body;
  if (body.url) {
    await server_bootstrapConfig.getRuntime().openExternal(body.url);
  }
  ctx.body = { success: true, data: null };
});
const router$1 = new Router({ prefix: "/v0/management/proxy" });
router$1.use(managementAuthMiddleware);
function createErrorResponse(code, message) {
  return {
    success: false,
    error: {
      code,
      message
    }
  };
}
function createSuccessResponse(data) {
  return {
    success: true,
    data
  };
}
function getProxyStatusData() {
  const status = proxyStatusManager.getRunningStatus();
  const statistics = proxyStatusManager.getStatistics();
  const port = proxyStatusManager.getPort();
  const host = proxyStatusManager.getHost();
  return {
    isRunning: status.isRunning,
    port,
    host,
    uptime: status.uptime,
    connections: statistics.activeConnections
  };
}
router$1.post("/start", async (ctx) => {
  try {
    if (proxyServer.isRunning()) {
      ctx.status = 400;
      ctx.body = createErrorResponse("already_running", "Proxy service is already running");
      return;
    }
    const request = ctx.request.body || {};
    const port = request.port;
    const host = request.host;
    const success = await proxyServer.start(port, host);
    if (!success) {
      ctx.status = 500;
      ctx.body = createErrorResponse("start_failed", "Failed to start proxy service");
      return;
    }
    const statusData = getProxyStatusData();
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse({
      isRunning: statusData.isRunning,
      port: statusData.port,
      host: statusData.host
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to start proxy service";
    ctx.status = 500;
    ctx.body = createErrorResponse("internal_error", errorMessage);
  }
});
router$1.post("/stop", async (ctx) => {
  try {
    if (!proxyServer.isRunning()) {
      ctx.status = 400;
      ctx.body = createErrorResponse("not_running", "Proxy service is not running");
      return;
    }
    const success = await proxyServer.stop();
    if (!success) {
      ctx.status = 500;
      ctx.body = createErrorResponse("stop_failed", "Failed to stop proxy service");
      return;
    }
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse({
      isRunning: false
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to stop proxy service";
    ctx.status = 500;
    ctx.body = createErrorResponse("internal_error", errorMessage);
  }
});
router$1.post("/restart", async (ctx) => {
  try {
    const request = ctx.request.body || {};
    const port = request.port;
    const host = request.host;
    const success = await proxyServer.restart(port, host);
    if (!success) {
      ctx.status = 500;
      ctx.body = createErrorResponse("restart_failed", "Failed to restart proxy service");
      return;
    }
    const statusData = getProxyStatusData();
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse({
      isRunning: statusData.isRunning,
      port: statusData.port,
      host: statusData.host
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to restart proxy service";
    ctx.status = 500;
    ctx.body = createErrorResponse("internal_error", errorMessage);
  }
});
router$1.get("/status", async (ctx) => {
  try {
    const statusData = getProxyStatusData();
    ctx.set("Content-Type", "application/json");
    ctx.body = createSuccessResponse(statusData);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "Failed to get proxy status";
    ctx.status = 500;
    ctx.body = createErrorResponse("internal_error", errorMessage);
  }
});
let latestSmokeResult = {
  success: false,
  category: "not_run",
  message: "No smoke test has been run.",
  clientAdapterId: "standard-openai-tools",
  timestamp: 0
};
function getLatestToolCallingSmokeResult() {
  return latestSmokeResult;
}
function setLatestToolCallingSmokeResult(result) {
  latestSmokeResult = { ...result };
  return latestSmokeResult;
}
function buildSmokeFixture(clientAdapterId) {
  return {
    model: "tool-smoke-test",
    stream: false,
    messages: [{ role: "user", content: "Get weather for Hangzhou with the weather tool." }],
    tools: [{
      type: "function",
      function: {
        name: "weather-test:get_weather",
        description: "Get weather for a city",
        parameters: {
          type: "object",
          properties: { city: { type: "string" } },
          required: ["city"]
        }
      }
    }],
    tool_choice: clientAdapterId === "cherry-studio-mcp" ? { type: "function", function: { name: "weather-test:get_weather" } } : "auto"
  };
}
const router = new Router({ prefix: "/v0/management/tool-calling" });
router.use(managementAuthMiddleware);
router.get("/status", async (ctx) => {
  const config = ConfigManager.get();
  ctx.body = {
    success: true,
    data: {
      config: config.toolCallingConfig,
      latestSmokeResult: getLatestToolCallingSmokeResult()
    }
  };
});
router.post("/smoke", async (ctx) => {
  const body = ctx.request.body;
  const config = ConfigManager.get();
  const clientAdapterId = body.clientAdapterId ?? config.toolCallingConfig.clientAdapterId;
  const fixture = buildSmokeFixture(clientAdapterId);
  const result = setLatestToolCallingSmokeResult({
    success: true,
    category: "pass",
    message: "Smoke fixture generated. Send it through /v1/chat/completions with a mapped model to run a live provider smoke.",
    clientAdapterId,
    timestamp: Date.now()
  });
  ctx.body = {
    success: true,
    data: {
      result,
      fixture
    }
  };
});
const managementRoutes = [
  router$8,
  router$7,
  router$6,
  router$5,
  router$4,
  router$3,
  router$2,
  router$1,
  router
];
const CONTENT_TYPES = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".woff": "font/woff",
  ".woff2": "font/woff2"
};
function resolveAdminDir() {
  return path.resolve(process.cwd(), "out-admin");
}
function isInside(baseDir, targetPath) {
  const normalizedBase = path.normalize(baseDir + path.sep);
  const normalizedTarget = path.normalize(targetPath);
  return normalizedTarget.startsWith(normalizedBase);
}
function sendFile(ctx, filePath) {
  ctx.type = CONTENT_TYPES[path.extname(filePath)] || "application/octet-stream";
  ctx.body = fs.readFileSync(filePath);
}
function mountWebAdminAssets(app) {
  app.use(async (ctx, next) => {
    if (ctx.path === "/admin") {
      ctx.redirect("/admin/");
      return;
    }
    if (!ctx.path.startsWith("/admin/")) {
      await next();
      return;
    }
    const adminDir = resolveAdminDir();
    const indexPath = path.join(adminDir, "admin.html");
    if (!fs.existsSync(indexPath)) {
      ctx.status = 503;
      ctx.body = {
        error: {
          message: "Web admin assets are not built. Run npm run build:admin.",
          type: "admin_assets_missing"
        }
      };
      return;
    }
    const rawPath = decodeURIComponent(ctx.path.slice("/admin/".length));
    const relativePath = rawPath || "admin.html";
    const assetPath = path.join(adminDir, relativePath);
    if (isInside(adminDir, assetPath) && fs.existsSync(assetPath)) {
      sendFile(ctx, assetPath);
      return;
    }
    sendFile(ctx, indexPath);
  });
}
const SLOW_REQUEST_THRESHOLD_MS = 1500;
class ProxyServer {
  constructor() {
    this.server = null;
    this.port = 8080;
    this.host = "127.0.0.1";
    this.app = new Koa();
    this.router = new Router();
    this.setupMiddleware();
    this.setupRoutes();
    this.setupErrorHandler();
  }
  /**
   * Setup middleware
   */
  setupMiddleware() {
    this.app.use(async (ctx, next) => {
      ctx.set("Access-Control-Allow-Origin", "*");
      ctx.set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
      ctx.set("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With, X-API-Key, X-Goog-Api-Key, X-Goog-Upload-Protocol, X-Goog-Upload-Command, X-Goog-Upload-Header-Content-Length, X-Goog-Upload-Header-Content-Type, X-Goog-Upload-File-Name, X-Goog-Upload-Offset");
      ctx.set("Access-Control-Allow-Private-Network", "true");
      ctx.set("Access-Control-Max-Age", "86400");
      if (ctx.method === "OPTIONS") {
        ctx.status = 204;
        return;
      }
      await next();
    });
    this.app.use(async (ctx, next) => {
      const shouldReadRawUpload = ctx.method === "POST" && ctx.path.startsWith("/upload/v1beta/files/") && ctx.get("X-Goog-Upload-Command");
      if (!shouldReadRawUpload) {
        await next();
        return;
      }
      ctx.disableBodyParser = true;
      const chunks = [];
      for await (const chunk of ctx.req) {
        chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
      }
      ctx.request.rawBody = Buffer.concat(chunks);
      await next();
    });
    this.app.use(bodyParser({
      enableTypes: ["json", "form", "text"],
      jsonLimit: "50mb",
      formLimit: "50mb",
      textLimit: "50mb"
    }));
    this.app.use(async (ctx, next) => {
      const publicPaths = ["/", "/health", "/stats"];
      if (publicPaths.includes(ctx.path) || ctx.path.startsWith("/admin")) {
        await next();
        return;
      }
      if (ctx.path.startsWith("/v0/management")) {
        await next();
        return;
      }
      const config = server_bootstrapConfig.storeManager.getConfig();
      if (config.enableApiKey && config.apiKeys && config.apiKeys.length > 0) {
        const authHeader = ctx.get("Authorization") || "";
        const providedKey = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : ctx.query.api_key || ctx.get("X-API-Key") || ctx.get("X-Goog-Api-Key");
        if (!providedKey) {
          ctx.status = 401;
          ctx.body = {
            error: {
              message: "API key is required",
              type: "invalid_request_error",
              code: "missing_api_key"
            }
          };
          return;
        }
        const validKey = config.apiKeys.find(
          (k) => k.key === providedKey && k.enabled
        );
        if (!validKey) {
          ctx.status = 401;
          ctx.body = {
            error: {
              message: "Invalid API key",
              type: "invalid_request_error",
              code: "invalid_api_key"
            }
          };
          return;
        }
        const updatedKeys = config.apiKeys.map(
          (k) => k.id === validKey.id ? {
            ...k,
            lastUsedAt: Date.now(),
            usageCount: k.usageCount + 1
          } : k
        );
        server_bootstrapConfig.storeManager.updateConfig({ apiKeys: updatedKeys });
      }
      await next();
    });
    this.app.use(async (ctx, next) => {
      const startTime = Date.now();
      await next();
      const latency = Date.now() - startTime;
      const shouldRecordAccessLog = !ctx.path.startsWith("/v1/models") && (ctx.status >= 400 || latency >= SLOW_REQUEST_THRESHOLD_MS);
      if (shouldRecordAccessLog) {
        server_bootstrapConfig.storeManager.addLog("warn", `${ctx.method} ${ctx.path} ${ctx.status} ${latency}ms`, {
          data: {
            method: ctx.method,
            path: ctx.path,
            status: ctx.status,
            latency,
            clientIP: ctx.ip,
            slowRequest: latency >= SLOW_REQUEST_THRESHOLD_MS
          }
        });
      }
    });
  }
  /**
   * Setup routes
   */
  setupRoutes() {
    mountWebAdminAssets(this.app);
    for (const route of routes) {
      this.router.use(route.routes());
      this.router.use(route.allowedMethods());
    }
    this.router.get("/", async (ctx) => {
      ctx.body = {
        name: "Chat2API Proxy",
        version: "1.1.2",
        description: "OpenAI API compatible proxy service",
        endpoints: [
          "POST /v1/chat/completions",
          "GET /v1/models",
          "GET /v1/models/:model",
          "POST /v1/completions",
          "GET /v1beta/models",
          "POST /v1beta/models/:model:generateContent",
          "POST /v1beta/models/:model:streamGenerateContent",
          "POST /upload/v1beta/files"
        ]
      };
    });
    this.router.get("/health", async (ctx) => {
      const status = proxyStatusManager.getRunningStatus();
      const statistics = proxyStatusManager.getStatistics();
      ctx.body = {
        status: status.isRunning ? "running" : "stopped",
        uptime: status.uptime,
        statistics: {
          totalRequests: statistics.totalRequests,
          successRequests: statistics.successRequests,
          failedRequests: statistics.failedRequests,
          activeConnections: statistics.activeConnections
        }
      };
    });
    this.router.get("/stats", async (ctx) => {
      const statistics = proxyStatusManager.getStatistics();
      ctx.body = statistics;
    });
    const managementEnableCheck = async (ctx, next) => {
      if (!ctx.path.startsWith("/v0/management")) {
        await next();
        return;
      }
      try {
        const config = server_bootstrapConfig.storeManager.getConfig();
        if (!config.managementApi?.enableManagementApi) {
          ctx.status = 404;
          ctx.body = {
            success: false,
            error: {
              code: "management_api_disabled",
              message: "Management API is not enabled"
            }
          };
          return;
        }
        await next();
      } catch {
        ctx.status = 503;
        ctx.body = {
          success: false,
          error: {
            code: "service_unavailable",
            message: "Service is initializing"
          }
        };
      }
    };
    this.app.use(managementEnableCheck);
    for (const route of managementRoutes) {
      this.app.use(route.routes());
      this.app.use(route.allowedMethods());
    }
    this.app.use(this.router.routes());
    this.app.use(this.router.allowedMethods());
    this.app.use(async (ctx) => {
      ctx.status = 404;
      ctx.body = {
        error: {
          message: `Route not found: ${ctx.method} ${ctx.path}`,
          type: "not_found_error"
        }
      };
    });
  }
  /**
   * Setup error handler
   */
  setupErrorHandler() {
    this.app.on("error", (err, ctx) => {
      const status = err.status || 500;
      const message = err.message || "Internal Server Error";
      server_bootstrapConfig.storeManager.addLog("error", `Server error: ${message}`, {
        data: {
          status,
          path: ctx.path,
          method: ctx.method,
          stack: err.stack
        }
      });
    });
  }
  /**
   * Start server
   */
  async start(port, host) {
    if (this.server) {
      return false;
    }
    this.port = port || proxyStatusManager.getPort();
    this.host = host || proxyStatusManager.getHost();
    sessionManager.initialize();
    return new Promise((resolve) => {
      try {
        this.server = this.app.listen(this.port, this.host, () => {
          proxyStatusManager.start();
          proxyStatusManager.setPort(this.port);
          proxyStatusManager.setHost(this.host);
          server_bootstrapConfig.storeManager.addLog("info", `Proxy server started successfully, listening on ${this.host}:${this.port}`);
          resolve(true);
        });
        this.server.on("error", (err) => {
          if (err.code === "EADDRINUSE") {
            server_bootstrapConfig.storeManager.addLog("error", `Port ${this.port} is already in use`);
          } else {
            server_bootstrapConfig.storeManager.addLog("error", `Server error: ${err.message}`);
          }
          this.server = null;
          resolve(false);
        });
        this.server.on("close", () => {
          this.server = null;
        });
      } catch (error) {
        server_bootstrapConfig.storeManager.addLog("error", `Failed to start server: ${error instanceof Error ? error.message : "Unknown error"}`);
        resolve(false);
      }
    });
  }
  /**
   * Stop server
   */
  async stop() {
    if (!this.server) {
      return false;
    }
    sessionManager.destroy();
    return new Promise((resolve) => {
      this.server.close((err) => {
        if (err) {
          server_bootstrapConfig.storeManager.addLog("error", `Failed to stop server: ${err.message}`);
          resolve(false);
          return;
        }
        this.server = null;
        proxyStatusManager.stop();
        server_bootstrapConfig.storeManager.addLog("info", "Proxy server stopped");
        resolve(true);
      });
    });
  }
  /**
   * Restart server
   */
  async restart(port, host) {
    await this.stop();
    return this.start(port, host);
  }
  /**
   * Check if server is running
   */
  isRunning() {
    return this.server !== null && proxyStatusManager.getRunningStatus().isRunning;
  }
  /**
   * Get server port
   */
  getPort() {
    return this.port;
  }
  /**
   * Get statistics
   */
  getStatistics() {
    return proxyStatusManager.getStatistics();
  }
  /**
   * Get running status
   */
  getStatus() {
    return proxyStatusManager.getRunningStatus();
  }
  /**
   * Reset statistics
   */
  resetStatistics() {
    proxyStatusManager.resetStatistics();
  }
}
const proxyServer = new ProxyServer();
server_bootstrapConfig.setRuntime(main_runtime_nodeRuntime.nodeRuntime);
async function shutdown(signal) {
  console.log(`[Server] Received ${signal}, shutting down`);
  try {
    await proxyServer.stop();
  } finally {
    server_bootstrapConfig.storeManager.flushPendingWrites();
    process.exit(0);
  }
}
async function main() {
  process.on("SIGINT", () => void shutdown("SIGINT"));
  process.on("SIGTERM", () => void shutdown("SIGTERM"));
  process.on("uncaughtException", (error) => {
    console.error("[Server] Uncaught exception:", error);
  });
  process.on("unhandledRejection", (reason) => {
    console.error("[Server] Unhandled rejection:", reason);
  });
  await server_bootstrapConfig.storeManager.initialize();
  const config = server_bootstrapConfig.applyServerConfigOverrides();
  const started = await proxyServer.start(config.proxyPort, config.proxyHost);
  if (!started) {
    throw new Error(`Failed to start server on ${config.proxyHost}:${config.proxyPort}`);
  }
  console.log(`[Server] Chat2API listening on ${config.proxyHost}:${config.proxyPort}`);
}
void main().catch((error) => {
  console.error("[Server] Startup failed:", error);
  process.exit(1);
});
