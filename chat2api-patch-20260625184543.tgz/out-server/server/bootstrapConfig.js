"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const path = require("path");
const node_fs = require("node:fs");
const node_path = require("node:path");
const main_runtime_nodeRuntime = require("../main/runtime/nodeRuntime.js");
const main_store_storage_nodeJsonStore = require("../main/store/storage/nodeJsonStore.js");
require("crypto");
require("fs");
require("os");
let runtime = main_runtime_nodeRuntime.nodeRuntime;
function setRuntime(nextRuntime) {
  runtime = nextRuntime;
}
function getRuntime() {
  return runtime;
}
const DEFAULT_TOOL_CALLING_CONFIG = {
  enabled: true,
  mode: "auto",
  clientAdapterId: "standard-openai-tools",
  diagnosticsEnabled: false,
  advanced: {
    promptPreviewEnabled: false,
    customPromptTemplate: void 0
  }
};
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isMode(value) {
  return value === "off" || value === "auto" || value === "force";
}
function isClientAdapterId(value) {
  return value === "standard-openai-tools" || value === "cherry-studio-mcp";
}
function normalizeToolCallingConfig(value) {
  if (!isRecord(value)) return DEFAULT_TOOL_CALLING_CONFIG;
  if ("defaultFormat" in value || value.mode === "always" || value.mode === "never") {
    const legacy = value;
    const enabled2 = legacy.mode !== "never";
    return {
      enabled: enabled2,
      mode: legacy.mode === "never" ? "off" : legacy.mode === "always" ? "force" : "auto",
      clientAdapterId: "standard-openai-tools",
      diagnosticsEnabled: Boolean(legacy.customPromptTemplate) || legacy.enableToolCallParsing === false,
      advanced: {
        promptPreviewEnabled: false,
        customPromptTemplate: typeof legacy.customPromptTemplate === "string" ? legacy.customPromptTemplate : void 0
      }
    };
  }
  const advanced = isRecord(value.advanced) ? value.advanced : {};
  const enabled = typeof value.enabled === "boolean" ? value.enabled : DEFAULT_TOOL_CALLING_CONFIG.enabled;
  const mode = isMode(value.mode) ? value.mode : DEFAULT_TOOL_CALLING_CONFIG.mode;
  return {
    enabled: mode === "off" ? false : enabled,
    mode,
    clientAdapterId: isClientAdapterId(value.clientAdapterId) ? value.clientAdapterId : DEFAULT_TOOL_CALLING_CONFIG.clientAdapterId,
    diagnosticsEnabled: typeof value.diagnosticsEnabled === "boolean" ? value.diagnosticsEnabled : DEFAULT_TOOL_CALLING_CONFIG.diagnosticsEnabled,
    advanced: {
      promptPreviewEnabled: typeof advanced.promptPreviewEnabled === "boolean" ? advanced.promptPreviewEnabled : DEFAULT_TOOL_CALLING_CONFIG.advanced.promptPreviewEnabled,
      customPromptTemplate: typeof advanced.customPromptTemplate === "string" ? advanced.customPromptTemplate : void 0
    }
  };
}
const deepseekConfig = {
  id: "deepseek",
  name: "DeepSeek",
  type: "builtin",
  authType: "userToken",
  apiEndpoint: "https://chat.deepseek.com/api",
  chatPath: "/v0/chat/completion",
  headers: {
    "Content-Type": "application/json",
    "Accept": "*/*",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Origin": "https://chat.deepseek.com",
    "Referer": "https://chat.deepseek.com/",
    "Sec-Ch-Ua": '"Not/A)Brand";v="99", "Chromium";v="148"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"macOS"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36",
    "X-App-Version": "2.0.0",
    "X-Client-Locale": "zh_CN",
    "X-Client-Platform": "web",
    "X-Client-Version": "2.0.0"
  },
  enabled: true,
  description: "DeepSeek AI assistant, supports deep thinking and web search",
  supportedModels: ["deepseek-v4-flash", "deepseek-v4-pro"],
  modelMappings: {
    "deepseek-v4-flash": "deepseek-v4-flash",
    "deepseek-v4-pro": "deepseek-v4-pro"
  },
  credentialFields: [
    {
      name: "token",
      label: "User Token",
      type: "password",
      required: true,
      placeholder: "Enter DeepSeek user token",
      helpText: "Authentication token obtained from DeepSeek web version, found in browser DevTools Application -> Local Storage"
    }
  ],
  tokenCheckEndpoint: "/v0/users/current",
  tokenCheckMethod: "GET"
};
const glmConfig = {
  id: "glm",
  name: "GLM",
  type: "builtin",
  authType: "refresh_token",
  apiEndpoint: "https://chatglm.cn/api",
  chatPath: "/chatglm/backend-api/assistant/stream",
  headers: {
    "Content-Type": "application/json",
    "Accept": "text/event-stream",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
    "App-Name": "chatglm",
    "Cache-Control": "no-cache",
    "Origin": "https://chatglm.cn",
    "Pragma": "no-cache",
    "Priority": "u=1, i",
    "Sec-Ch-Ua": '"Microsoft Edge";v="143", "Chromium";v="143", "Not A(Brand";v="24"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "X-App-Fr": "browser_extension",
    "X-App-Platform": "pc",
    "X-App-Version": "0.0.1",
    "X-Device-Brand": "",
    "X-Device-Model": "",
    "X-Lang": "zh"
  },
  enabled: true,
  description: "Zhipu Qingyan AI assistant, supports GLM-5.1 flagship model, deep thinking and video generation",
  supportedModels: [
    "GLM-5.1"
  ],
  modelMappings: {
    "GLM-5.1": "glm-5.1"
  },
  credentialFields: [
    {
      name: "refresh_token",
      label: "Refresh Token",
      type: "password",
      required: true,
      placeholder: "Enter GLM refresh token",
      helpText: "Get refresh_token from Zhipu Qingyan web version, found in browser DevTools Application -> Local Storage -> chatglm_refresh_token"
    }
  ],
  tokenCheckEndpoint: "/chatglm/user-api/user/refresh",
  tokenCheckMethod: "POST"
};
const kimiConfig = {
  id: "kimi",
  name: "Kimi",
  type: "builtin",
  authType: "jwt",
  apiEndpoint: "https://www.kimi.com",
  chatPath: "/apiv2/kimi.gateway.chat.v1.ChatService/Chat",
  headers: {
    "Content-Type": "application/connect+json",
    "Accept": "*/*",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Origin": "https://www.kimi.com",
    "Sec-Ch-Ua": '"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
    "Priority": "u=1, i"
  },
  enabled: true,
  description: "Kimi K2.6 AI assistant by Moonshot, supports thinking mode and web search",
  supportedModels: [
    "Kimi-K2.6"
  ],
  modelMappings: {
    "Kimi-K2.6": "kimi-k2.6"
  },
  credentialFields: [
    {
      name: "token",
      label: "访问令牌",
      type: "password",
      required: true,
      placeholder: "请输入 Kimi 访问令牌或刷新令牌",
      helpText: "浏览器 Cookie 中的 kimi-auth 字段值（推荐），或 JWT Token / refresh_token"
    }
  ],
  tokenCheckEndpoint: "/api/auth/token/refresh",
  tokenCheckMethod: "GET"
};
const minimaxConfig = {
  id: "minimax",
  name: "MiniMax",
  type: "builtin",
  authType: "jwt",
  apiEndpoint: "https://agent.minimaxi.com",
  chatPath: "/matrix/api/v1/chat/send_msg",
  headers: {
    "Content-Type": "application/json",
    "Accept": "application/json, text/plain, */*",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Cache-Control": "no-cache",
    "Origin": "https://agent.minimaxi.com",
    "Pragma": "no-cache",
    "Sec-Ch-Ua": '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"macOS"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36"
  },
  enabled: true,
  description: "MiniMax Agent - AI assistant with MCP multi-agent collaboration",
  supportedModels: [
    "MiniMax-M2.7"
  ],
  modelMappings: {
    "MiniMax-M2.7": "MiniMax-M2.7"
  },
  credentialFields: [
    {
      name: "token",
      label: "JWT Token",
      type: "password",
      required: true,
      placeholder: "Enter MiniMax JWT Token or realUserID+JWTtoken",
      helpText: 'Format: "realUserID+JWTtoken" or just JWT token (will extract userID from JWT)'
    },
    {
      name: "realUserID",
      label: "Real User ID (Optional)",
      type: "text",
      required: false,
      placeholder: "Enter Real User ID (optional)",
      helpText: "If provided, use this instead of JWT user ID. Can also use format: realUserID+JWTtoken in token field"
    }
  ],
  tokenCheckEndpoint: "/v1/api/user/device/register",
  tokenCheckMethod: "POST"
};
const mimoConfig = {
  id: "mimo",
  name: "Mimo",
  type: "builtin",
  authType: "cookie",
  apiEndpoint: "https://aistudio.xiaomimimo.com",
  chatPath: "/open-apis/bot/chat",
  headers: {
    "Content-Type": "application/json",
    "Accept": "*/*",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Cache-Control": "no-cache",
    "Origin": "https://aistudio.xiaomimimo.com",
    "Referer": "https://aistudio.xiaomimimo.com/",
    "Pragma": "no-cache",
    "Sec-Ch-Ua": '"Chromium";v="144", "Not(A:Brand";v="8", "Google Chrome";v="144"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "X-Timezone": "Asia/Shanghai"
  },
  enabled: true,
  description: "XiaomiMIMO - Xiaomi General Intelligence Foundation Model",
  supportedModels: [
    "MiMo-V2.5-Pro",
    "MiMo-V2.5",
    "MiMo-V2-Flash"
  ],
  modelMappings: {
    "MiMo-V2.5-Pro": "mimo-v2.5-pro",
    "MiMo-V2.5": "mimo-v2.5",
    "MiMo-V2-Flash": "mimo-v2-flash"
  },
  credentialFields: [
    {
      name: "service_token",
      label: "Service Token",
      type: "password",
      required: true,
      placeholder: "Enter serviceToken from Cookie",
      helpText: "Found in browser DevTools -> Application -> Cookies -> serviceToken"
    },
    {
      name: "user_id",
      label: "User ID",
      type: "text",
      required: true,
      placeholder: "Enter userId from Cookie",
      helpText: "Found in browser DevTools -> Application -> Cookies -> userId"
    },
    {
      name: "ph_token",
      label: "PH Token",
      type: "password",
      required: true,
      placeholder: "Enter xiaomichatbot_ph from Cookie",
      helpText: "Found in browser DevTools -> Application -> Cookies -> xiaomichatbot_ph"
    }
  ]
};
const perplexityConfig = {
  id: "perplexity",
  name: "Perplexity",
  type: "builtin",
  authType: "cookie",
  apiEndpoint: "https://www.perplexity.ai",
  chatPath: "/rest/sse/perplexity_ask",
  headers: {
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36",
    "Accept": "text/event-stream",
    "Content-Type": "application/json",
    "Origin": "https://www.perplexity.ai",
    "Referer": "https://www.perplexity.ai/"
  },
  enabled: true,
  description: "Perplexity AI search assistant with Free Auto mode and web search enhancement",
  supportedModels: [
    "Auto"
  ],
  modelMappings: {
    "Auto": "auto"
  },
  credentialFields: [
    {
      name: "sessionToken",
      label: "Session Token",
      type: "password",
      required: true,
      placeholder: "Enter Perplexity session token",
      helpText: "Session token obtained from Perplexity web version (__Secure-next-auth.session-token cookie)"
    }
  ]
};
const qwenConfig = {
  id: "qwen",
  name: "Qwen",
  type: "builtin",
  authType: "tongyi_sso_ticket",
  apiEndpoint: "https://chat2.qianwen.com",
  chatPath: "/api/v2/chat",
  headers: {
    "Content-Type": "application/json",
    "Accept": "application/json, text/event-stream, text/plain, */*",
    "Origin": "https://www.qianwen.com",
    "Referer": "https://www.qianwen.com/"
  },
  enabled: true,
  description: "Qwen AI assistant by Alibaba Cloud (www.qianwen.com)",
  supportedModels: [
    "Qwen3.6",
    "Qwen3.7-Max",
    "Qwen3.5-Flash",
    "Qwen3-Max",
    "Qwen3-Max-Thinking-Preview",
    "Qwen3-Coder"
  ],
  modelMappings: {
    "Qwen3.6": "Qwen",
    "Qwen3.7-Max": "Qwen3.7-Max",
    "Qwen3.5-Flash": "Qwen3.5-Flash",
    "Qwen3-Max": "Qwen3-Max",
    "Qwen3-Max-Thinking-Preview": "Qwen3-Max-Thinking-Preview",
    "Qwen3-Coder": "Qwen3-Coder"
  },
  credentialFields: [
    {
      name: "ticket",
      label: "SSO Ticket",
      type: "password",
      required: true,
      placeholder: "Enter tongyi_sso_ticket",
      helpText: "SSO ticket obtained from www.qianwen.com, found in browser DevTools Application -> Cookies as tongyi_sso_ticket"
    }
  ]
};
const qwenAiConfig = {
  id: "qwen-ai",
  name: "Qwen AI (International)",
  type: "builtin",
  authType: "jwt",
  apiEndpoint: "https://chat.qwen.ai",
  chatPath: "/api/v2/chat/completions",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
    source: "web"
  },
  enabled: true,
  description: "Qwen AI international version (chat.qwen.ai)",
  modelsApiEndpoint: "https://chat.qwen.ai/api/v2/models/",
  modelsApiHeaders: {
    Accept: "application/json, text/plain, */*",
    Referer: "https://chat.qwen.ai/",
    source: "web",
    Version: "0.2.35"
  },
  supportedModels: [
    "Qwen3.7-Plus",
    "Qwen3.7-Max",
    "Qwen3.6-Plus"
  ],
  modelMappings: {
    "Qwen3.7-Plus": "qwen3.7-plus",
    "Qwen3.7-Max": "qwen3.7-max",
    "Qwen3.6-Plus": "qwen3.6-plus"
  },
  credentialFields: [
    {
      name: "token",
      label: "Auth Token",
      type: "password",
      required: true,
      placeholder: "Enter JWT token from chat.qwen.ai",
      helpText: 'JWT token obtained from chat.qwen.ai Local Storage (key: "token")'
    },
    {
      name: "cookies",
      label: "Cookies (Optional)",
      type: "textarea",
      required: false,
      placeholder: "Optional cookies for enhanced compatibility",
      helpText: "Full cookie string from browser DevTools (optional but recommended)"
    },
    {
      name: "email",
      label: "Login Email (Optional)",
      type: "text",
      required: false,
      placeholder: "Optional account email for automatic token refresh",
      helpText: "Used with password to refresh the chat.qwen.ai web token before it expires"
    },
    {
      name: "password",
      label: "Login Password (Optional)",
      type: "password",
      required: false,
      placeholder: "Optional account password for automatic token refresh",
      helpText: "Stored in encrypted credentials when encryption is available; automatic refresh can fail if Qwen requires captcha, MFA, or risk verification"
    }
  ]
};
const zaiConfig = {
  id: "zai",
  name: "Z.ai",
  type: "builtin",
  authType: "jwt",
  apiEndpoint: "https://chat.z.ai/api",
  chatPath: "/v2/chat/completions",
  headers: {
    "Content-Type": "application/json",
    "Accept": "*/*",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN",
    "Cache-Control": "no-cache",
    "Origin": "https://chat.z.ai",
    "Pragma": "no-cache",
    "Sec-Ch-Ua": '"Not/A)Brand";v="99", "Chromium";v="148"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"macOS"',
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "same-origin",
    "X-FE-Version": "prod-fe-1.1.37",
    "X-Region": "domestic"
  },
  enabled: true,
  description: "Z.ai - Free AI Chatbot powered by GLM-5.1, GLM-5, and GLM-4.7",
  supportedModels: [
    "GLM-5.1",
    "GLM-5-Turbo",
    "GLM-5V-Turbo",
    "GLM-5",
    "GLM-4.7"
  ],
  modelMappings: {
    "GLM-5.1": "GLM-5.1",
    "GLM-5-Turbo": "GLM-5-Turbo",
    "GLM-5V-Turbo": "GLM-5v-Turbo",
    "GLM-5": "glm-5",
    "GLM-4.7": "glm-4.7"
  },
  credentialFields: [
    {
      name: "token",
      label: "Access Token",
      type: "password",
      required: true,
      placeholder: "Enter Z.ai JWT Token",
      helpText: 'Get token from Z.ai web version, found in browser DevTools Application -> Cookie, starts with "eyJ..."'
    },
    {
      name: "captcha_verify_param",
      label: "Captcha Verify Param",
      type: "password",
      required: false,
      placeholder: "Optional captcha_verify_param from chat.z.ai HAR",
      helpText: "Optional. If Z.ai requires verification, copy captcha_verify_param from the latest /api/v2/chat/completions request body."
    }
  ],
  tokenCheckEndpoint: "/api/v1/users/user/settings",
  tokenCheckMethod: "GET"
};
const builtinProviders = [
  deepseekConfig,
  glmConfig,
  kimiConfig,
  minimaxConfig,
  mimoConfig,
  perplexityConfig,
  qwenConfig,
  qwenAiConfig,
  zaiConfig
];
const builtinProviderMap = {
  deepseek: deepseekConfig,
  glm: glmConfig,
  kimi: kimiConfig,
  minimax: minimaxConfig,
  mimo: mimoConfig,
  perplexity: perplexityConfig,
  qwen: qwenConfig,
  "qwen-ai": qwenAiConfig,
  zai: zaiConfig
};
function getBuiltinProvider(id) {
  return builtinProviderMap[id];
}
const DEEPSEEK_PRIMARY_MODELS = ["deepseek-v4-flash", "deepseek-v4-pro"];
const DEEPSEEK_LEGACY_MODEL_MAPPING_NAMES = [
  "deepseek-chat",
  "deepseek-reasoner",
  "DeepSeek-V3.2",
  "DeepSeek-Search",
  "DeepSeek-R1",
  "DeepSeek-R1-Search"
];
const DEFAULT_SESSION_CONFIG = {
  sessionTimeout: 30,
  maxMessagesPerSession: 50,
  deleteAfterTimeout: false,
  maxSessionsPerAccount: 3
};
const DEFAULT_STATISTICS = {
  totalRequests: 0,
  successRequests: 0,
  failedRequests: 0,
  totalLatency: 0,
  lastUpdated: Date.now(),
  modelUsage: {},
  providerUsage: {},
  accountUsage: {},
  dailyStats: {}
};
const DEFAULT_USER_MODEL_OVERRIDES = {};
const DEFAULT_MANAGEMENT_API_CONFIG = {
  enableManagementApi: false,
  managementApiSecret: ""
};
const DEFAULT_CONTEXT_MANAGEMENT_CONFIG = {
  enabled: false,
  strategies: {
    slidingWindow: { enabled: true, maxMessages: 20 },
    tokenLimit: { enabled: false, maxTokens: 4e3 },
    summary: { enabled: false, keepRecentMessages: 20 }
  },
  executionOrder: ["slidingWindow", "tokenLimit", "summary"]
};
const DEFAULT_REQUEST_LOG_CONFIG = {
  enabled: true,
  maxEntries: 200,
  includeBodies: false,
  maxBodyChars: 8e3,
  redactSensitiveData: true
};
const DEFAULT_DEEPSEEK_MODEL_MAPPINGS = {
  "deepseek-v4-flash-think": {
    requestModel: "deepseek-v4-flash-think",
    actualModel: "deepseek-v4-flash",
    preferredProviderId: "deepseek"
  },
  "deepseek-v4-flash-search": {
    requestModel: "deepseek-v4-flash-search",
    actualModel: "deepseek-v4-flash",
    preferredProviderId: "deepseek"
  },
  "deepseek-v4-flash-think-search": {
    requestModel: "deepseek-v4-flash-think-search",
    actualModel: "deepseek-v4-flash",
    preferredProviderId: "deepseek"
  },
  "deepseek-v4-pro-think": {
    requestModel: "deepseek-v4-pro-think",
    actualModel: "deepseek-v4-pro",
    preferredProviderId: "deepseek"
  },
  "deepseek-v4-pro-search": {
    requestModel: "deepseek-v4-pro-search",
    actualModel: "deepseek-v4-pro",
    preferredProviderId: "deepseek"
  },
  "deepseek-v4-pro-think-search": {
    requestModel: "deepseek-v4-pro-think-search",
    actualModel: "deepseek-v4-pro",
    preferredProviderId: "deepseek"
  }
};
function createDefaultModelMappings() {
  return Object.fromEntries(
    Object.entries(DEFAULT_DEEPSEEK_MODEL_MAPPINGS).map(([key, mapping]) => [key, { ...mapping }])
  );
}
function isDefaultModelMapping(requestModel) {
  return requestModel in DEFAULT_DEEPSEEK_MODEL_MAPPINGS;
}
function normalizeModelMappingsWithDefaults(mappings) {
  const legacyModelNames = new Set(DEEPSEEK_LEGACY_MODEL_MAPPING_NAMES);
  const customMappings = Object.fromEntries(
    Object.entries(mappings || {}).filter(
      ([requestModel]) => !isDefaultModelMapping(requestModel) && !legacyModelNames.has(requestModel)
    )
  );
  return {
    ...createDefaultModelMappings(),
    ...customMappings
  };
}
function sanitizeDeepSeekModelOverrides(overrides) {
  const migratedModelNames = /* @__PURE__ */ new Set([
    ...DEEPSEEK_PRIMARY_MODELS,
    ...DEEPSEEK_LEGACY_MODEL_MAPPING_NAMES,
    ...Object.keys(DEFAULT_DEEPSEEK_MODEL_MAPPINGS)
  ]);
  return {
    addedModels: (overrides?.addedModels || []).filter(
      (model) => !migratedModelNames.has(model.displayName)
    ),
    excludedModels: (overrides?.excludedModels || []).filter(
      (model) => DEEPSEEK_PRIMARY_MODELS.includes(model)
    )
  };
}
const DEFAULT_CONFIG = {
  proxyPort: 8080,
  proxyHost: "127.0.0.1",
  loadBalanceStrategy: "round-robin",
  modelMappings: createDefaultModelMappings(),
  defaultModelMappingsSeeded: true,
  theme: "system",
  autoStart: false,
  autoStartProxy: false,
  minimizeToTray: true,
  logLevel: "info",
  logRetentionDays: 7,
  requestLogConfig: DEFAULT_REQUEST_LOG_CONFIG,
  requestTimeout: 6e4,
  retryCount: 3,
  apiKeys: [],
  enableApiKey: false,
  oauthProxyMode: "system",
  sessionConfig: DEFAULT_SESSION_CONFIG,
  toolCallingConfig: DEFAULT_TOOL_CALLING_CONFIG,
  toolPromptConfig: void 0,
  managementApi: DEFAULT_MANAGEMENT_API_CONFIG,
  contextManagement: DEFAULT_CONTEXT_MANAGEMENT_CONFIG
};
const BUILTIN_PROMPTS = [
  // Tool Use prompt removed - now handled by utils/tools.ts with [function_calls] format
];
function normalizeRequestLogConfig(config) {
  return {
    enabled: true,
    maxEntries: 200,
    includeBodies: false,
    maxBodyChars: 8e3,
    redactSensitiveData: true,
    ...config
  };
}
function sanitizeRequestLogEntry(entry, config) {
  const sanitized = {
    ...entry,
    userInput: truncateText(entry.userInput, 500),
    errorStack: void 0
  };
  if (!config.includeBodies) {
    sanitized.requestBody = void 0;
    sanitized.responseBody = void 0;
    sanitized.responsePreview = truncateText(entry.responsePreview, 1e3);
    sanitized.errorMessage = truncateText(entry.errorMessage, 1e3);
    return sanitized;
  }
  sanitized.requestBody = sanitizeRequestLogBody(entry.requestBody, config);
  sanitized.responseBody = sanitizeRequestLogBody(entry.responseBody, config);
  sanitized.responsePreview = truncateText(entry.responsePreview, 1e3);
  sanitized.errorMessage = truncateText(entry.errorMessage, 1e3);
  return sanitized;
}
function sanitizeRequestLogUpdates(updates, config) {
  const sanitized = {
    ...updates,
    userInput: truncateText(updates.userInput, 500),
    errorStack: void 0
  };
  if (!config.includeBodies) {
    sanitized.requestBody = void 0;
    sanitized.responseBody = void 0;
    sanitized.responsePreview = truncateText(updates.responsePreview, 1e3);
    sanitized.errorMessage = truncateText(updates.errorMessage, 1e3);
    return sanitized;
  }
  sanitized.requestBody = sanitizeRequestLogBody(updates.requestBody, config);
  sanitized.responseBody = sanitizeRequestLogBody(updates.responseBody, config);
  sanitized.responsePreview = truncateText(updates.responsePreview, 1e3);
  sanitized.errorMessage = truncateText(updates.errorMessage, 1e3);
  return sanitized;
}
function trimRequestLogsToMaxEntries(entries, config) {
  const maxEntries = Math.max(0, config.maxEntries);
  if (maxEntries === 0) {
    return [];
  }
  if (entries.length <= maxEntries) {
    return entries;
  }
  return entries.slice(entries.length - maxEntries);
}
function sanitizeRequestLogBody(value, config) {
  if (!value) return value;
  const redacted = config.redactSensitiveData ? redactSensitiveText(value) : value;
  return truncateText(redacted, config.maxBodyChars);
}
function truncateText(value, maxChars) {
  if (!value) return value;
  if (maxChars <= 0) return void 0;
  if (value.length <= maxChars) return value;
  return `${value.slice(0, maxChars)}...[truncated ${value.length - maxChars} chars]`;
}
function redactSensitiveText(value) {
  return value.replace(
    /(\"?(?:authorization|api[_-]?key|access[_-]?token|refresh[_-]?token|cookie|set-cookie|password|token)\"?\s*[:=]\s*)\"?[^\",}\]\s]+\"?/gi,
    '$1"[REDACTED]"'
  );
}
class RequestLogManager {
  constructor(options) {
    this.requestLogs = [];
    this.initialized = false;
    this.persistTimer = null;
    this.dirty = false;
    this.persistDelayMs = 2e3;
    this.storageDir = options.storageDir;
    this.logFile = node_path.join(options.storageDir, "request-logs.ndjson");
    this.config = normalizeRequestLogConfig(options.config);
  }
  async initialize() {
    if (this.initialized) return;
    node_fs.mkdirSync(this.storageDir, { recursive: true });
    this.requestLogs = this.loadRequestLogs();
    this.initialized = true;
  }
  setConfig(config) {
    this.config = normalizeRequestLogConfig(config);
    this.requestLogs = trimRequestLogsToMaxEntries(this.requestLogs, this.config);
    this.schedulePersist();
  }
  async migrateLegacyLogs(legacyLogs) {
    this.ensureInitialized();
    if (legacyLogs.length === 0 || this.requestLogs.length > 0) {
      return false;
    }
    this.requestLogs = trimRequestLogsToMaxEntries(
      legacyLogs.sort((a, b) => a.timestamp - b.timestamp).map((entry) => ({
        ...sanitizeRequestLogEntry(stripId(entry), this.config),
        id: entry.id
      })),
      this.config
    );
    this.schedulePersist();
    return true;
  }
  addRequestLog(entry) {
    this.ensureInitialized();
    const logEntry = {
      ...sanitizeRequestLogEntry(entry, this.config),
      id: generateId()
    };
    if (!this.config.enabled) {
      return logEntry;
    }
    this.requestLogs.push(logEntry);
    this.requestLogs = trimRequestLogsToMaxEntries(this.requestLogs, this.config);
    this.schedulePersist();
    return logEntry;
  }
  updateRequestLog(id, updates) {
    this.ensureInitialized();
    if (!this.config.enabled || this.config.maxEntries <= 0) {
      return false;
    }
    const index = this.requestLogs.findIndex((entry) => entry.id === id);
    if (index === -1) {
      return false;
    }
    this.requestLogs[index] = {
      ...this.requestLogs[index],
      ...sanitizeRequestLogUpdates(updates, this.config)
    };
    this.schedulePersist();
    return true;
  }
  getRequestLogs(limit, filter) {
    this.ensureInitialized();
    let result = [...this.requestLogs];
    if (filter?.status) {
      result = result.filter((entry) => entry.status === filter.status);
    }
    if (filter?.providerId) {
      result = result.filter((entry) => entry.providerId === filter.providerId);
    }
    result.sort((a, b) => b.timestamp - a.timestamp);
    if (limit && result.length > limit) {
      return result.slice(0, limit);
    }
    return result;
  }
  getRequestLogById(id) {
    this.ensureInitialized();
    return this.requestLogs.find((entry) => entry.id === id);
  }
  clearRequestLogs() {
    this.ensureInitialized();
    this.requestLogs = [];
    this.schedulePersist();
  }
  getRequestLogStats() {
    this.ensureInitialized();
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const todayStart = new Date(today).getTime();
    const todayEnd = todayStart + 24 * 60 * 60 * 1e3;
    const todayLogs = this.requestLogs.filter((entry) => entry.timestamp >= todayStart && entry.timestamp < todayEnd);
    return {
      total: this.requestLogs.length,
      success: this.requestLogs.filter((entry) => entry.status === "success").length,
      error: this.requestLogs.filter((entry) => entry.status === "error").length,
      todayTotal: todayLogs.length,
      todaySuccess: todayLogs.filter((entry) => entry.status === "success").length,
      todayError: todayLogs.filter((entry) => entry.status === "error").length
    };
  }
  getRequestLogTrend(days = 7) {
    this.ensureInitialized();
    const dayMs = 24 * 60 * 60 * 1e3;
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const todayStart = new Date(today).getTime();
    const trends = [];
    for (let i = days - 1; i >= 0; i--) {
      const dayStart = todayStart - i * dayMs;
      const dayEnd = dayStart + dayMs;
      const date = new Date(dayStart).toISOString().split("T")[0];
      const dayLogs = this.requestLogs.filter((entry) => entry.timestamp >= dayStart && entry.timestamp < dayEnd);
      const successLogs = dayLogs.filter((entry) => entry.status === "success");
      const errorLogs = dayLogs.filter((entry) => entry.status === "error");
      const totalLatency = successLogs.reduce((sum, entry) => sum + entry.latency, 0);
      trends.push({
        date,
        total: dayLogs.length,
        success: successLogs.length,
        error: errorLogs.length,
        avgLatency: successLogs.length > 0 ? Math.round(totalLatency / successLogs.length) : 0
      });
    }
    return trends;
  }
  exportRequestLogs() {
    this.ensureInitialized();
    return [...this.requestLogs];
  }
  flushSync() {
    if (!this.initialized) {
      return;
    }
    if (this.persistTimer) {
      clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }
    this.persistNow();
  }
  ensureInitialized() {
    if (!this.initialized) {
      throw new Error("RequestLogManager is not initialized");
    }
  }
  loadRequestLogs() {
    if (!node_fs.existsSync(this.logFile)) {
      return [];
    }
    const content = node_fs.readFileSync(this.logFile, "utf-8").trim();
    if (!content) {
      return [];
    }
    return content.split("\n").filter(Boolean).map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    }).filter((entry) => entry !== null);
  }
  schedulePersist() {
    this.dirty = true;
    if (this.persistTimer) {
      clearTimeout(this.persistTimer);
    }
    this.persistTimer = setTimeout(() => {
      this.persistTimer = null;
      this.persistNow();
    }, this.persistDelayMs);
  }
  persistNow() {
    if (!this.dirty) {
      return;
    }
    const content = this.requestLogs.map((entry) => JSON.stringify(entry)).join("\n");
    node_fs.writeFileSync(this.logFile, content, "utf-8");
    this.dirty = false;
  }
}
function generateId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
}
function stripId(entry) {
  const { id: _id, ...rest } = entry;
  return rest;
}
class AppLogManager {
  constructor(options) {
    this.logs = [];
    this.initialized = false;
    this.persistTimer = null;
    this.dirty = false;
    this.persistDelayMs = 2e3;
    this.storageDir = options.storageDir;
    this.logFile = node_path.join(options.storageDir, "app-logs.ndjson");
    this.maxEntries = Math.max(0, options.maxEntries ?? 7e3);
  }
  async initialize() {
    if (this.initialized) return;
    node_fs.mkdirSync(this.storageDir, { recursive: true });
    this.logs = this.trimLogs(this.loadLogs());
    this.initialized = true;
  }
  setMaxEntries(maxEntries) {
    this.ensureInitialized();
    this.maxEntries = Math.max(0, maxEntries);
    this.logs = this.trimLogs(this.logs);
    this.schedulePersist();
  }
  async migrateLegacyLogs(legacyLogs) {
    this.ensureInitialized();
    if (legacyLogs.length === 0) {
      return false;
    }
    const byId = /* @__PURE__ */ new Map();
    for (const entry of [...this.logs, ...legacyLogs]) {
      byId.set(entry.id, entry);
    }
    this.logs = this.trimLogs(
      [...byId.values()].sort((a, b) => a.timestamp - b.timestamp)
    );
    this.schedulePersist();
    return true;
  }
  addLog(entry) {
    this.ensureInitialized();
    this.logs.push(entry);
    this.logs = this.trimLogs(this.logs);
    this.schedulePersist();
    return entry;
  }
  replaceLogs(logs) {
    this.ensureInitialized();
    this.logs = this.trimLogs([...logs].sort((a, b) => a.timestamp - b.timestamp));
    this.schedulePersist();
  }
  getLogs(filter) {
    this.ensureInitialized();
    let result = [...this.logs];
    if (filter?.level && filter.level !== "all") {
      result = result.filter((entry) => entry.level === filter.level);
    }
    if (filter?.keyword) {
      const keyword = filter.keyword.toLowerCase();
      result = result.filter((entry) => entry.message.toLowerCase().includes(keyword));
    }
    if (filter?.startTime) {
      result = result.filter((entry) => entry.timestamp >= filter.startTime);
    }
    if (filter?.endTime) {
      result = result.filter((entry) => entry.timestamp <= filter.endTime);
    }
    result.sort((a, b) => b.timestamp - a.timestamp);
    if (filter?.offset !== void 0) {
      result = result.slice(filter.offset);
    }
    if (filter?.limit !== void 0) {
      result = result.slice(0, filter.limit);
    }
    return result;
  }
  getLogById(id) {
    this.ensureInitialized();
    return this.logs.find((entry) => entry.id === id);
  }
  clearLogs() {
    this.ensureInitialized();
    this.logs = [];
    this.schedulePersist();
  }
  getStats() {
    this.ensureInitialized();
    return this.logs.reduce(
      (stats, entry) => ({
        ...stats,
        total: stats.total + 1,
        [entry.level]: stats[entry.level] + 1
      }),
      { total: 0, info: 0, warn: 0, error: 0, debug: 0 }
    );
  }
  getTrend(days = 7) {
    this.ensureInitialized();
    return this.getTrendFromLogs(this.logs, days);
  }
  getAccountTrend(accountId, days = 7) {
    this.ensureInitialized();
    const accountLogs = this.logs.filter((entry) => entry.accountId === accountId && entry.requestId);
    return this.getTrendFromLogs(accountLogs, days, true);
  }
  exportLogs() {
    this.ensureInitialized();
    return [...this.logs];
  }
  flushSync() {
    if (!this.initialized) {
      return;
    }
    if (this.persistTimer) {
      clearTimeout(this.persistTimer);
      this.persistTimer = null;
    }
    this.persistNow();
  }
  getTrendFromLogs(logs, days, totalUsesInfo = false) {
    const dayMs = 24 * 60 * 60 * 1e3;
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const todayStart = new Date(today).getTime();
    const trends = [];
    for (let i = days - 1; i >= 0; i--) {
      const dayStart = todayStart - i * dayMs;
      const dayEnd = dayStart + dayMs;
      const date = new Date(dayStart).toISOString().split("T")[0];
      const dayLogs = logs.filter((entry) => entry.timestamp >= dayStart && entry.timestamp < dayEnd);
      const info = dayLogs.filter((entry) => entry.level === "info").length;
      const warn = dayLogs.filter((entry) => entry.level === "warn").length;
      const error = dayLogs.filter((entry) => entry.level === "error").length;
      trends.push({
        date,
        total: totalUsesInfo ? info : dayLogs.length,
        info,
        warn,
        error
      });
    }
    return trends;
  }
  ensureInitialized() {
    if (!this.initialized) {
      throw new Error("AppLogManager is not initialized");
    }
  }
  loadLogs() {
    if (!node_fs.existsSync(this.logFile)) {
      return [];
    }
    const content = node_fs.readFileSync(this.logFile, "utf-8").trim();
    if (!content) {
      return [];
    }
    return content.split("\n").filter(Boolean).map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    }).filter((entry) => entry !== null);
  }
  trimLogs(logs) {
    if (this.maxEntries <= 0) {
      return [];
    }
    return logs.length > this.maxEntries ? logs.slice(-this.maxEntries) : logs;
  }
  schedulePersist() {
    this.dirty = true;
    if (this.persistTimer) {
      clearTimeout(this.persistTimer);
    }
    this.persistTimer = setTimeout(() => {
      this.persistTimer = null;
      this.persistNow();
    }, this.persistDelayMs);
  }
  persistNow() {
    if (!this.dirty) {
      return;
    }
    const content = this.logs.map((entry) => JSON.stringify(entry)).join("\n");
    node_fs.writeFileSync(this.logFile, content, "utf-8");
    this.dirty = false;
  }
}
async function createElectronJsonStore(options) {
  const module2 = await import("electron-store");
  const Store = module2.default;
  return new Store(options);
}
class StoreManager {
  constructor() {
    this.store = null;
    this.isInitialized = false;
    this.mainWindow = null;
    this.initializationError = null;
    this.requestLogManager = null;
    this.appLogManager = null;
  }
  setMainWindow(window) {
    this.mainWindow = window;
  }
  /**
   * Check if storage has initialization error
   */
  hasInitializationError() {
    return this.initializationError !== null;
  }
  /**
   * Get initialization error
   */
  getInitializationError() {
    return this.initializationError;
  }
  /**
   * Initialize Storage
   * Create storage instance and initialize default data
   */
  async initialize() {
    if (this.isInitialized) {
      return;
    }
    const storagePath = this.getStoragePath();
    try {
      this.store = await this.createStore(storagePath);
      await this.initializeAppLogManager(storagePath);
      await this.initializeRequestLogManager(storagePath);
      this.initializeDefaultModelMappings();
      await this.initializeDefaultProviders();
      this.isInitialized = true;
      this.initializationError = null;
    } catch (error) {
      console.error("[Store] Failed to initialize storage:", error);
      this.initializationError = error instanceof Error ? error : new Error(String(error));
      try {
        await this.recoverFromCorruptedData(storagePath);
        this.store = await this.createStore(storagePath);
        await this.initializeAppLogManager(storagePath);
        await this.initializeRequestLogManager(storagePath);
        this.initializeDefaultModelMappings();
        await this.initializeDefaultProviders();
        this.isInitialized = true;
        this.initializationError = null;
        console.log("[Store] Successfully recovered from corrupted data");
      } catch (recoveryError) {
        console.error("[Store] Failed to recover from corrupted data:", recoveryError);
        throw this.initializationError;
      }
    }
  }
  async createStore(storagePath) {
    const runtime2 = getRuntime();
    const options = {
      name: "data",
      cwd: storagePath,
      defaults: this.getDefaultData(),
      encryptionKey: this.getEncryptionKey()
    };
    if (runtime2.kind === "electron") {
      return createElectronJsonStore(options);
    }
    return new main_store_storage_nodeJsonStore.NodeJsonStore(options);
  }
  /**
   * Recover from corrupted data file
   * Backup the corrupted file and create a new one
   */
  async recoverFromCorruptedData(storagePath) {
    const { renameSync, existsSync } = await import("fs");
    const { join: join2 } = await import("path");
    const dataPath = join2(storagePath, "data.json");
    const backupPath = join2(storagePath, `data.corrupted.${Date.now()}.json`);
    if (existsSync(dataPath)) {
      console.log("[Store] Backing up corrupted data file to:", backupPath);
      try {
        renameSync(dataPath, backupPath);
        console.log("[Store] Corrupted data file backed up successfully");
      } catch (backupError) {
        console.error("[Store] Failed to backup corrupted data:", backupError);
        throw backupError;
      }
    }
  }
  /**
   * Get Storage Path
   * Storage path: ~/.chat2api/
   */
  getStoragePath() {
    return getRuntime().getDataDir();
  }
  /**
   * Get Encryption Key
   * Returns a fixed encryption key for electron-store
   * Note: electron-store uses this key to encrypt/decrypt the data file,
   * so it must be stable across app restarts
   */
  getEncryptionKey() {
    return getRuntime().isEncryptionAvailable() ? "chat2api-fixed-encryption-key-v1" : void 0;
  }
  /**
   * Get Default Data Structure
   */
  getDefaultData() {
    return {
      providers: [],
      accounts: [],
      config: DEFAULT_CONFIG,
      logs: [],
      requestLogs: [],
      systemPrompts: [],
      sessions: [],
      statistics: DEFAULT_STATISTICS,
      userModelOverrides: DEFAULT_USER_MODEL_OVERRIDES
    };
  }
  async initializeRequestLogManager(storagePath) {
    const config = this.normalizeConfig(this.store?.get("config") || DEFAULT_CONFIG);
    this.requestLogManager = new RequestLogManager({
      storageDir: path.join(storagePath, "request-logs"),
      config: config.requestLogConfig
    });
    await this.requestLogManager.initialize();
    const legacyRequestLogs = this.store?.get("requestLogs") || [];
    if (legacyRequestLogs.length > 0) {
      await this.requestLogManager.migrateLegacyLogs(legacyRequestLogs);
      this.store?.set("requestLogs", []);
    }
  }
  async initializeAppLogManager(storagePath) {
    const config = this.normalizeConfig(this.store?.get("config") || DEFAULT_CONFIG);
    this.appLogManager = new AppLogManager({
      storageDir: path.join(storagePath, "logs"),
      maxEntries: this.getMaxLogEntries(config)
    });
    await this.appLogManager.initialize();
    const legacyLogs = this.store?.get("logs") || [];
    if (legacyLogs.length > 0) {
      await this.appLogManager.migrateLegacyLogs(legacyLogs);
      this.appLogManager.flushSync();
      this.store?.set("logs", []);
    }
  }
  getMaxLogEntries(config) {
    return config.logRetentionDays * 1e3;
  }
  normalizeConfig(config) {
    const rawConfig = {
      ...DEFAULT_CONFIG,
      ...config
    };
    const rawToolCallingConfig = rawConfig.toolCallingConfig ?? rawConfig.toolPromptConfig;
    return {
      ...rawConfig,
      modelMappings: normalizeModelMappingsWithDefaults(rawConfig.modelMappings),
      defaultModelMappingsSeeded: config.defaultModelMappingsSeeded,
      requestLogConfig: normalizeRequestLogConfig(
        rawConfig.requestLogConfig || DEFAULT_REQUEST_LOG_CONFIG
      ),
      toolCallingConfig: normalizeToolCallingConfig(rawToolCallingConfig),
      toolPromptConfig: void 0
    };
  }
  initializeDefaultModelMappings() {
    const rawConfig = this.store?.get("config") || DEFAULT_CONFIG;
    const config = this.normalizeConfig(rawConfig);
    if (config.defaultModelMappingsSeeded) {
      this.store?.set("config", config);
      return;
    }
    this.store?.set("config", this.normalizeConfig({
      ...config,
      modelMappings: {
        ...createDefaultModelMappings(),
        ...config.modelMappings || {}
      },
      defaultModelMappingsSeeded: true
    }));
  }
  /**
   * Initialize Default Providers
   * Clear provider list, users create providers by adding accounts
   */
  async initializeDefaultProviders() {
    const providers = this.store?.get("providers") || [];
    const accounts = this.store?.get("accounts") || [];
    const builtinIds = builtinProviders.map((p) => p.id);
    const qwenAiAliasIds = providers.filter((provider) => this.isQwenAiProviderAlias(provider)).map((provider) => provider.id);
    const hasQwenAiAliasAccounts = accounts.some((account) => {
      const providerExists = providers.some((provider) => account.providerId === provider.id);
      return qwenAiAliasIds.includes(account.providerId) || !providerExists && this.isLikelyQwenAiAccount(account);
    });
    const validProviders = providers.filter((p) => {
      if (p.type === "builtin") {
        return builtinIds.includes(p.id);
      }
      return true;
    });
    const userModelOverrides = {
      ...this.store?.get("userModelOverrides") || {}
    };
    let userModelOverridesChanged = false;
    let updatedProviders = validProviders.map((p) => {
      if (p.type === "builtin") {
        const builtinConfig = builtinProviders.find((bp) => bp.id === p.id);
        if (builtinConfig) {
          if (p.id === "deepseek") {
            const sanitizedOverrides = sanitizeDeepSeekModelOverrides(userModelOverrides[p.id]);
            if (JSON.stringify(sanitizedOverrides) !== JSON.stringify(userModelOverrides[p.id])) {
              userModelOverrides[p.id] = sanitizedOverrides;
              userModelOverridesChanged = true;
            }
          }
          return {
            ...p,
            apiEndpoint: builtinConfig.apiEndpoint,
            chatPath: builtinConfig.chatPath,
            supportedModels: builtinConfig.supportedModels,
            modelMappings: builtinConfig.modelMappings,
            headers: builtinConfig.headers,
            credentialFields: builtinConfig.credentialFields,
            description: builtinConfig.description,
            modelsApiEndpoint: builtinConfig.modelsApiEndpoint,
            modelsApiHeaders: builtinConfig.modelsApiHeaders
          };
        }
      }
      return p;
    });
    if (hasQwenAiAliasAccounts && !updatedProviders.some((provider) => provider.id === "qwen-ai")) {
      const qwenAiBuiltin = builtinProviders.find((provider) => provider.id === "qwen-ai");
      if (qwenAiBuiltin) {
        const now = Date.now();
        updatedProviders = [
          ...updatedProviders,
          {
            ...qwenAiBuiltin,
            createdAt: now,
            updatedAt: now
          }
        ];
      }
    }
    if (userModelOverridesChanged) {
      this.store?.set("userModelOverrides", userModelOverrides);
    }
    this.store?.set("providers", updatedProviders);
    this.migrateQwenAiProviderAliases(providers, updatedProviders);
  }
  isQwenAiProviderAlias(provider) {
    if (provider.type !== "builtin" || provider.id === "qwen-ai") {
      return false;
    }
    const endpoint = provider.apiEndpoint || "";
    const description = provider.description || "";
    return provider.name === "Qwen AI (International)" || endpoint.includes("chat.qwen.ai") || description.includes("chat.qwen.ai");
  }
  isLikelyQwenAiAccount(account) {
    const name = (account.name || "").toLowerCase();
    const credentials = account.credentials || {};
    const hasBrowserImportCredentials = Boolean(
      credentials.token && Object.prototype.hasOwnProperty.call(credentials, "cookies")
    );
    return name.includes("qwen ai") || name.includes("qwen-ai") || name.includes("chat.qwen.ai") || name.includes("qwen") && hasBrowserImportCredentials;
  }
  migrateQwenAiProviderAliases(originalProviders, currentProviders) {
    const accounts = this.store?.get("accounts") || [];
    if (accounts.length === 0) {
      return;
    }
    const qwenAiAliasIds = new Set(
      originalProviders.filter((provider) => this.isQwenAiProviderAlias(provider)).map((provider) => provider.id)
    );
    const now = Date.now();
    let changed = false;
    const migratedAccounts = accounts.map((account) => {
      const providerExists = currentProviders.some((provider) => account.providerId === provider.id);
      const shouldMigrate = account.providerId !== "qwen-ai" && (qwenAiAliasIds.has(account.providerId) || !providerExists && this.isLikelyQwenAiAccount(account));
      if (!shouldMigrate) {
        return account;
      }
      changed = true;
      return {
        ...account,
        providerId: "qwen-ai",
        updatedAt: now
      };
    });
    if (changed) {
      this.store?.set("accounts", migratedAccounts);
    }
  }
  /**
   * Ensure provider exists, create if not
   */
  ensureProviderExists(providerId) {
    this.ensureInitialized();
    const providers = this.store.get("providers") || [];
    const exists = providers.some((p) => p.id === providerId);
    if (!exists) {
      const builtinConfig = builtinProviders.find((bp) => bp.id === providerId);
      if (builtinConfig) {
        const now = Date.now();
        const newProvider = {
          id: builtinConfig.id,
          name: builtinConfig.name,
          type: "builtin",
          authType: builtinConfig.authType,
          apiEndpoint: builtinConfig.apiEndpoint,
          chatPath: builtinConfig.chatPath,
          headers: builtinConfig.headers,
          enabled: true,
          createdAt: now,
          updatedAt: now,
          description: builtinConfig.description,
          supportedModels: builtinConfig.supportedModels,
          modelMappings: builtinConfig.modelMappings,
          modelsApiEndpoint: builtinConfig.modelsApiEndpoint,
          modelsApiHeaders: builtinConfig.modelsApiHeaders
        };
        this.store.set("providers", [...providers, newProvider]);
        console.log("[Store] Created missing provider:", providerId);
      }
    }
  }
  /**
   * Ensure Storage is Initialized
   */
  ensureInitialized() {
    if (!this.isInitialized || !this.store) {
      const errorMsg = this.initializationError ? `Storage initialization failed: ${this.initializationError.message}` : "Storage not initialized, please call initialize() first";
      throw new Error(errorMsg);
    }
  }
  getLogPriority(level) {
    switch (level) {
      case "debug":
        return 10;
      case "info":
        return 20;
      case "warn":
        return 30;
      case "error":
        return 40;
      default:
        return 20;
    }
  }
  shouldRecordLog(level) {
    const config = this.normalizeConfig(this.store.get("config") || DEFAULT_CONFIG);
    return this.getLogPriority(level) >= this.getLogPriority(config.logLevel);
  }
  getCombinedLogs() {
    return this.getAppLogManager().exportLogs();
  }
  flushPendingWrites() {
    this.appLogManager?.flushSync();
    this.requestLogManager?.flushSync();
  }
  /**
   * Encrypt Sensitive Data
   * @param data Data to encrypt
   * @returns Encrypted string
   */
  encryptData(data) {
    try {
      const runtime2 = getRuntime();
      if (runtime2.isEncryptionAvailable()) {
        return runtime2.encryptString(data);
      }
    } catch (error) {
      console.error("Failed to encrypt data:", error);
    }
    return data;
  }
  /**
   * Decrypt Sensitive Data
   * @param encryptedData Encrypted data
   * @returns Decrypted string
   */
  decryptData(encryptedData) {
    try {
      const runtime2 = getRuntime();
      if (runtime2.isEncryptionAvailable()) {
        return runtime2.decryptString(encryptedData);
      }
    } catch (error) {
      console.error("Failed to decrypt data:", error);
    }
    return encryptedData;
  }
  /**
   * Encrypt Credentials Object
   * @param credentials Credentials object
   * @returns Encrypted credentials object
   */
  encryptCredentials(credentials) {
    const encrypted = {};
    for (const [key, value] of Object.entries(credentials)) {
      encrypted[key] = this.encryptData(value);
    }
    return encrypted;
  }
  /**
   * Decrypt Credentials Object
   * @param encryptedCredentials Encrypted credentials object
   * @returns Decrypted credentials object
   */
  decryptCredentials(encryptedCredentials) {
    const decrypted = {};
    for (const [key, value] of Object.entries(encryptedCredentials)) {
      decrypted[key] = this.decryptData(value);
    }
    return decrypted;
  }
  // ==================== Provider Operations ====================
  /**
   * Get All Providers
   */
  getProviders() {
    this.ensureInitialized();
    return this.store.get("providers") || [];
  }
  /**
   * Get Provider By ID
   */
  getProviderById(id) {
    this.ensureInitialized();
    const providers = this.store.get("providers") || [];
    return providers.find((p) => p.id === id);
  }
  /**
   * Add Provider
   */
  addProvider(provider) {
    this.ensureInitialized();
    const providers = this.store.get("providers") || [];
    this.store.set("providers", [...providers, provider]);
  }
  /**
   * Update Provider
   */
  updateProvider(id, updates) {
    this.ensureInitialized();
    const providers = this.store.get("providers") || [];
    const index = providers.findIndex((p) => p.id === id);
    if (index === -1) {
      return null;
    }
    providers[index] = {
      ...providers[index],
      ...updates,
      updatedAt: Date.now()
    };
    this.store.set("providers", providers);
    return providers[index];
  }
  /**
   * Delete Provider
   */
  deleteProvider(id) {
    this.ensureInitialized();
    const providers = this.store.get("providers") || [];
    const index = providers.findIndex((p) => p.id === id);
    if (index === -1) {
      return false;
    }
    providers.splice(index, 1);
    this.store.set("providers", providers);
    const accounts = this.store.get("accounts") || [];
    const filteredAccounts = accounts.filter((a) => a.providerId !== id);
    this.store.set("accounts", filteredAccounts);
    return true;
  }
  // ==================== Model Overrides Operations ====================
  /**
   * Get Model Overrides for a Provider
   * Returns user customizations to built-in provider models
   */
  getModelOverrides(providerId) {
    this.ensureInitialized();
    const userModelOverrides = this.store.get("userModelOverrides") || DEFAULT_USER_MODEL_OVERRIDES;
    return userModelOverrides[providerId];
  }
  /**
   * Check if Provider has Model Overrides
   * Returns true if provider has user-added models or excluded models
   */
  hasModelOverrides(providerId) {
    const overrides = this.getModelOverrides(providerId);
    if (!overrides) return false;
    return overrides.addedModels && overrides.addedModels.length > 0 || overrides.excludedModels && overrides.excludedModels.length > 0;
  }
  // ==================== Account Operations ====================
  /**
   * Get All Accounts
   * @param includeCredentials Whether to include decrypted credentials
   */
  getAccounts(includeCredentials = false) {
    this.ensureInitialized();
    const accounts = this.store.get("accounts") || [];
    if (includeCredentials) {
      return accounts.map((account) => ({
        ...account,
        credentials: this.decryptCredentials(account.credentials)
      }));
    }
    return accounts;
  }
  /**
   * Get Account By ID
   * @param includeCredentials Whether to include decrypted credentials
   */
  getAccountById(id, includeCredentials = false) {
    this.ensureInitialized();
    const accounts = this.store.get("accounts") || [];
    const account = accounts.find((a) => a.id === id);
    if (account && includeCredentials) {
      return {
        ...account,
        credentials: this.decryptCredentials(account.credentials)
      };
    }
    return account;
  }
  /**
   * Get Accounts By Provider ID
   */
  getAccountsByProviderId(providerId, includeCredentials = false) {
    this.ensureInitialized();
    const accounts = this.store.get("accounts") || [];
    const filtered = accounts.filter((a) => a.providerId === providerId);
    if (includeCredentials) {
      return filtered.map((account) => ({
        ...account,
        credentials: this.decryptCredentials(account.credentials)
      }));
    }
    return filtered;
  }
  /**
   * Add Account
   * Credentials are automatically encrypted before storage
   */
  addAccount(account) {
    this.ensureInitialized();
    const accounts = this.store.get("accounts") || [];
    const encryptedAccount = {
      ...account,
      credentials: this.encryptCredentials(account.credentials)
    };
    accounts.push(encryptedAccount);
    this.store.set("accounts", accounts);
  }
  /**
   * Update Account
   */
  updateAccount(id, updates) {
    this.ensureInitialized();
    const accounts = this.store.get("accounts") || [];
    const index = accounts.findIndex((a) => a.id === id);
    if (index === -1) {
      return null;
    }
    const updatedAccount = {
      ...accounts[index],
      ...updates,
      updatedAt: Date.now()
    };
    if (updates.credentials) {
      updatedAccount.credentials = this.encryptCredentials(updates.credentials);
    }
    accounts[index] = updatedAccount;
    this.store.set("accounts", accounts);
    return {
      ...updatedAccount,
      credentials: updates.credentials || this.decryptCredentials(accounts[index].credentials)
    };
  }
  /**
   * Delete Account
   */
  deleteAccount(id) {
    this.ensureInitialized();
    const accounts = this.store.get("accounts") || [];
    const index = accounts.findIndex((a) => a.id === id);
    if (index === -1) {
      return false;
    }
    accounts.splice(index, 1);
    this.store.set("accounts", accounts);
    return true;
  }
  /**
   * Get Active Accounts
   */
  getActiveAccounts(includeCredentials = false) {
    this.ensureInitialized();
    const accounts = this.store.get("accounts") || [];
    const active = accounts.filter((a) => a.status === "active");
    if (includeCredentials) {
      return active.map((account) => ({
        ...account,
        credentials: this.decryptCredentials(account.credentials)
      }));
    }
    return active;
  }
  // ==================== Configuration Operations ====================
  /**
   * Get Application Configuration
   */
  getConfig() {
    this.ensureInitialized();
    return this.normalizeConfig(this.store.get("config") || DEFAULT_CONFIG);
  }
  /**
   * Set Application Configuration
   */
  setConfig(config) {
    this.ensureInitialized();
    const normalized = this.normalizeConfig(config);
    this.store.set("config", normalized);
    this.requestLogManager?.setConfig(normalized.requestLogConfig);
  }
  /**
   * Update Application Configuration
   */
  updateConfig(updates) {
    this.ensureInitialized();
    const currentConfig = this.getConfig();
    const newConfig = {
      ...currentConfig,
      ...updates
    };
    if (updates.toolCallingConfig || updates.toolPromptConfig) {
      const incoming = updates.toolCallingConfig ?? updates.toolPromptConfig;
      const incomingRecord = incoming && typeof incoming === "object" ? incoming : {};
      const incomingAdvanced = incomingRecord.advanced && typeof incomingRecord.advanced === "object" ? incomingRecord.advanced : {};
      newConfig.toolCallingConfig = normalizeToolCallingConfig({
        ...currentConfig.toolCallingConfig,
        ...incomingRecord,
        advanced: {
          ...currentConfig.toolCallingConfig.advanced,
          ...incomingAdvanced
        }
      });
      newConfig.toolPromptConfig = void 0;
    }
    if (updates.sessionConfig && currentConfig.sessionConfig) {
      newConfig.sessionConfig = {
        ...currentConfig.sessionConfig,
        ...updates.sessionConfig
      };
    }
    if (updates.requestLogConfig) {
      newConfig.requestLogConfig = normalizeRequestLogConfig({
        ...currentConfig.requestLogConfig,
        ...updates.requestLogConfig
      });
    }
    const normalized = this.normalizeConfig(newConfig);
    this.store.set("config", normalized);
    this.appLogManager?.setMaxEntries(this.getMaxLogEntries(normalized));
    this.requestLogManager?.setConfig(normalized.requestLogConfig);
    return normalized;
  }
  /**
   * Reset Configuration to Default Values
   */
  resetConfig() {
    this.ensureInitialized();
    this.store.set("config", DEFAULT_CONFIG);
    this.appLogManager?.setMaxEntries(this.getMaxLogEntries(DEFAULT_CONFIG));
    this.requestLogManager?.setConfig(DEFAULT_CONFIG.requestLogConfig);
    return DEFAULT_CONFIG;
  }
  // ==================== Log Operations ====================
  /**
   * Add Log Entry
   */
  addLog(level, message, data) {
    this.ensureInitialized();
    const entry = {
      id: this.generateId(),
      timestamp: Date.now(),
      level,
      message,
      ...data
    };
    if (!this.shouldRecordLog(level)) {
      return entry;
    }
    this.getAppLogManager().addLog(entry);
    return entry;
  }
  /**
   * Get Logs
   * @param limit Limit count
   * @param level Log level filter
   */
  getLogs(filter) {
    this.ensureInitialized();
    return this.getAppLogManager().getLogs(filter);
  }
  /**
   * Clear Logs
   */
  clearLogs() {
    this.ensureInitialized();
    this.getAppLogManager().clearLogs();
    this.store.set("logs", []);
  }
  replaceLogs(logs) {
    this.ensureInitialized();
    this.getAppLogManager().replaceLogs(logs);
    this.store.set("logs", []);
  }
  /**
   * Get Log Statistics
   */
  getLogStats() {
    this.ensureInitialized();
    return this.getAppLogManager().getStats();
  }
  /**
   * Get Log Trend
   */
  getLogTrend(days = 7) {
    this.ensureInitialized();
    return this.getAppLogManager().getTrend(days);
  }
  /**
   * Get Log Trend for specific account
   * Only counts successful API requests (logs with requestId) to match requestCount
   */
  getAccountLogTrend(accountId, days = 7) {
    this.ensureInitialized();
    return this.getAppLogManager().getAccountTrend(accountId, days);
  }
  /**
   * Export Logs
   */
  exportLogs(format = "json") {
    this.ensureInitialized();
    const logs = this.getCombinedLogs();
    if (format === "json") {
      return JSON.stringify(logs, null, 2);
    }
    return logs.map((log) => {
      const time = new Date(log.timestamp).toISOString();
      const level = log.level.toUpperCase().padEnd(5);
      let line = `[${time}] [${level}] ${log.message}`;
      if (log.providerId) {
        line += ` | Provider: ${log.providerId}`;
      }
      if (log.accountId) {
        line += ` | Account: ${log.accountId}`;
      }
      if (log.requestId) {
        line += ` | Request: ${log.requestId}`;
      }
      if (log.data) {
        line += ` | Data: ${JSON.stringify(log.data)}`;
      }
      return line;
    }).join("\n");
  }
  /**
   * Get Log By ID
   */
  getLogById(id) {
    this.ensureInitialized();
    const logs = this.getCombinedLogs();
    return logs.find((l) => l.id === id);
  }
  /**
   * Clear Expired Logs
   */
  cleanExpiredLogs() {
    this.ensureInitialized();
    const config = this.getConfig();
    const logs = this.getCombinedLogs();
    const cutoff = Date.now() - config.logRetentionDays * 24 * 60 * 60 * 1e3;
    const filtered = logs.filter((l) => l.timestamp >= cutoff);
    this.getAppLogManager().replaceLogs(filtered);
    this.store.set("logs", []);
  }
  // ==================== Request Log Operations ====================
  /**
   * Add Request Log Entry
   */
  addRequestLog(entry) {
    this.ensureInitialized();
    const newEntry = this.getRequestLogManager().addRequestLog(entry);
    return newEntry;
  }
  /**
   * Update Request Log Entry
   */
  updateRequestLog(id, updates) {
    this.ensureInitialized();
    return this.getRequestLogManager().updateRequestLog(id, updates);
  }
  /**
   * Get Request Logs
   */
  getRequestLogs(limit, filter) {
    this.ensureInitialized();
    return this.getRequestLogManager().getRequestLogs(limit, filter);
  }
  /**
   * Get Request Log By ID
   */
  getRequestLogById(id) {
    this.ensureInitialized();
    return this.getRequestLogManager().getRequestLogById(id);
  }
  /**
   * Clear Request Logs
   */
  clearRequestLogs() {
    this.ensureInitialized();
    this.getRequestLogManager().clearRequestLogs();
    this.store.set("statistics", DEFAULT_STATISTICS);
  }
  /**
   * Get Request Log Statistics
   */
  getRequestLogStats() {
    this.ensureInitialized();
    return this.getRequestLogManager().getRequestLogStats();
  }
  /**
   * Get Request Log Trend
   */
  getRequestLogTrend(days = 7) {
    this.ensureInitialized();
    return this.getRequestLogManager().getRequestLogTrend(days);
  }
  // ==================== Statistics Operations ====================
  /**
   * Get Persistent Statistics
   */
  getStatistics() {
    this.ensureInitialized();
    return this.store.get("statistics") || DEFAULT_STATISTICS;
  }
  /**
   * Update Statistics
   */
  updateStatistics(updates) {
    this.ensureInitialized();
    const currentStats = this.store.get("statistics") || DEFAULT_STATISTICS;
    const newStats = {
      ...currentStats,
      ...updates,
      lastUpdated: Date.now()
    };
    this.store.set("statistics", newStats);
    return newStats;
  }
  /**
   * Record Request in Statistics
   */
  recordRequestInStats(success, latency, model, providerId, accountId) {
    this.ensureInitialized();
    const stats = this.store.get("statistics") || DEFAULT_STATISTICS;
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    const newStats = {
      ...stats,
      totalRequests: stats.totalRequests + 1,
      successRequests: success ? stats.successRequests + 1 : stats.successRequests,
      failedRequests: success ? stats.failedRequests : stats.failedRequests + 1,
      totalLatency: success ? stats.totalLatency + latency : stats.totalLatency,
      lastUpdated: Date.now(),
      modelUsage: { ...stats.modelUsage },
      providerUsage: { ...stats.providerUsage },
      accountUsage: { ...stats.accountUsage },
      dailyStats: { ...stats.dailyStats }
    };
    if (model) {
      newStats.modelUsage[model] = (newStats.modelUsage[model] || 0) + 1;
    }
    if (providerId) {
      newStats.providerUsage[providerId] = (newStats.providerUsage[providerId] || 0) + 1;
    }
    if (accountId) {
      newStats.accountUsage[accountId] = (newStats.accountUsage[accountId] || 0) + 1;
    }
    if (!newStats.dailyStats[today]) {
      newStats.dailyStats[today] = {
        date: today,
        totalRequests: 0,
        successRequests: 0,
        failedRequests: 0,
        totalLatency: 0,
        modelUsage: {},
        providerUsage: {}
      };
    }
    newStats.dailyStats[today].totalRequests++;
    if (success) {
      newStats.dailyStats[today].successRequests++;
      newStats.dailyStats[today].totalLatency += latency;
    } else {
      newStats.dailyStats[today].failedRequests++;
    }
    if (model) {
      newStats.dailyStats[today].modelUsage[model] = (newStats.dailyStats[today].modelUsage[model] || 0) + 1;
    }
    if (providerId) {
      newStats.dailyStats[today].providerUsage[providerId] = (newStats.dailyStats[today].providerUsage[providerId] || 0) + 1;
    }
    this.store.set("statistics", newStats);
    return newStats;
  }
  /**
   * Get Today Statistics
   */
  getTodayStatistics() {
    this.ensureInitialized();
    const stats = this.store.get("statistics") || DEFAULT_STATISTICS;
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    return stats.dailyStats[today] || {
      date: today,
      totalRequests: 0,
      successRequests: 0,
      failedRequests: 0,
      totalLatency: 0,
      modelUsage: {},
      providerUsage: {}
    };
  }
  /**
   * Clean Old Daily Statistics (older than 30 days)
   */
  cleanOldDailyStats() {
    this.ensureInitialized();
    const stats = this.store.get("statistics") || DEFAULT_STATISTICS;
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1e3;
    const cutoffDate = new Date(cutoff).toISOString().split("T")[0];
    const filteredDailyStats = {};
    for (const [date, dayStats] of Object.entries(stats.dailyStats)) {
      if (date >= cutoffDate) {
        filteredDailyStats[date] = dayStats;
      }
    }
    if (Object.keys(filteredDailyStats).length !== Object.keys(stats.dailyStats).length) {
      stats.dailyStats = filteredDailyStats;
      this.store.set("statistics", stats);
    }
  }
  // ==================== System Prompts Operations ====================
  /**
   * Get All System Prompts
   * Merges built-in prompts with custom prompts
   */
  getSystemPrompts() {
    this.ensureInitialized();
    const customPrompts = this.store.get("systemPrompts") || [];
    return [...BUILTIN_PROMPTS, ...customPrompts];
  }
  /**
   * Get Built-in System Prompts
   */
  getBuiltinPrompts() {
    return BUILTIN_PROMPTS;
  }
  /**
   * Get Custom System Prompts
   */
  getCustomPrompts() {
    this.ensureInitialized();
    return this.store.get("systemPrompts") || [];
  }
  /**
   * Get System Prompt By ID
   */
  getSystemPromptById(id) {
    return this.getSystemPrompts().find((p) => p.id === id);
  }
  /**
   * Add Custom System Prompt
   */
  addSystemPrompt(prompt) {
    this.ensureInitialized();
    const prompts = this.store.get("systemPrompts") || [];
    const newPrompt = {
      ...prompt,
      id: this.generateId(),
      isBuiltin: false,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    prompts.push(newPrompt);
    this.store.set("systemPrompts", prompts);
    return newPrompt;
  }
  /**
   * Update Custom System Prompt
   * Cannot update built-in prompts
   */
  updateSystemPrompt(id, updates) {
    this.ensureInitialized();
    if (BUILTIN_PROMPTS.some((p) => p.id === id)) {
      console.warn("Cannot update built-in prompt:", id);
      return null;
    }
    const prompts = this.store.get("systemPrompts") || [];
    const index = prompts.findIndex((p) => p.id === id);
    if (index === -1) {
      return null;
    }
    prompts[index] = {
      ...prompts[index],
      ...updates,
      updatedAt: Date.now()
    };
    this.store.set("systemPrompts", prompts);
    return prompts[index];
  }
  /**
   * Delete Custom System Prompt
   * Cannot delete built-in prompts
   */
  deleteSystemPrompt(id) {
    this.ensureInitialized();
    if (BUILTIN_PROMPTS.some((p) => p.id === id)) {
      console.warn("Cannot delete built-in prompt:", id);
      return false;
    }
    const prompts = this.store.get("systemPrompts") || [];
    const index = prompts.findIndex((p) => p.id === id);
    if (index === -1) {
      return false;
    }
    prompts.splice(index, 1);
    this.store.set("systemPrompts", prompts);
    return true;
  }
  /**
   * Get System Prompts By Type
   */
  getSystemPromptsByType(type) {
    return this.getSystemPrompts().filter((p) => p.type === type);
  }
  // ==================== Session Operations ====================
  /**
   * Get Session Configuration
   */
  getSessionConfig() {
    this.ensureInitialized();
    const config = this.store.get("config") || DEFAULT_CONFIG;
    return config.sessionConfig || DEFAULT_SESSION_CONFIG;
  }
  /**
   * Update Session Configuration
   */
  updateSessionConfig(updates) {
    this.ensureInitialized();
    const currentConfig = this.store.get("config") || DEFAULT_CONFIG;
    const newSessionConfig = {
      ...currentConfig.sessionConfig || DEFAULT_SESSION_CONFIG,
      ...updates
    };
    const newConfig = {
      ...currentConfig,
      sessionConfig: newSessionConfig
    };
    this.store.set("config", newConfig);
    return newSessionConfig;
  }
  /**
   * Get All Sessions
   */
  getSessions() {
    this.ensureInitialized();
    return this.store.get("sessions") || [];
  }
  /**
   * Get Session By ID
   */
  getSessionById(id) {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    return sessions.find((s) => s.id === id);
  }
  /**
   * Get Active Sessions
   */
  getActiveSessions() {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    const config = this.getSessionConfig();
    const timeoutMs = config.sessionTimeout * 60 * 1e3;
    const now = Date.now();
    return sessions.filter(
      (s) => s.status === "active" && now - s.lastActiveAt < timeoutMs
    );
  }
  /**
   * Add Session
   */
  addSession(session) {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    sessions.push(session);
    this.store.set("sessions", sessions);
  }
  /**
   * Update Session
   */
  updateSession(id, updates) {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    const index = sessions.findIndex((s) => s.id === id);
    if (index === -1) {
      return null;
    }
    sessions[index] = {
      ...sessions[index],
      ...updates
    };
    this.store.set("sessions", sessions);
    return sessions[index];
  }
  /**
   * Add Message to Session
   */
  addMessageToSession(sessionId, message) {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    const index = sessions.findIndex((s) => s.id === sessionId);
    if (index === -1) {
      return null;
    }
    const config = this.getSessionConfig();
    const session = sessions[index];
    if (session.messages.length >= config.maxMessagesPerSession) {
      session.messages = session.messages.slice(-config.maxMessagesPerSession + 1);
    }
    session.messages.push(message);
    session.lastActiveAt = Date.now();
    sessions[index] = session;
    this.store.set("sessions", sessions);
    return session;
  }
  /**
   * Delete Session
   */
  deleteSession(id) {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    const index = sessions.findIndex((s) => s.id === id);
    if (index === -1) {
      return false;
    }
    sessions.splice(index, 1);
    this.store.set("sessions", sessions);
    return true;
  }
  /**
   * Mark Session as Expired
   */
  expireSession(id) {
    return this.updateSession(id, { status: "expired" });
  }
  /**
   * Clean Expired Sessions
   * Always delete sessions with 'expired' status
   * For timed-out active sessions, behavior depends on deleteAfterTimeout config:
   * - If true: Delete them from storage
   * - If false: Mark them as 'expired' (will be deleted on next clean)
   */
  cleanExpiredSessions() {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    const config = this.getSessionConfig();
    const timeoutMs = config.sessionTimeout * 60 * 1e3;
    const now = Date.now();
    let removedCount = 0;
    let remainingSessions = sessions.filter((s) => {
      if (s.status === "expired") {
        removedCount++;
        return false;
      }
      return true;
    });
    if (config.deleteAfterTimeout) {
      remainingSessions = remainingSessions.filter((s) => {
        if (s.status === "active" && now - s.lastActiveAt >= timeoutMs) {
          removedCount++;
          return false;
        }
        return true;
      });
    } else {
      remainingSessions = remainingSessions.map((s) => {
        if (s.status === "active" && now - s.lastActiveAt >= timeoutMs) {
          removedCount++;
          return { ...s, status: "expired" };
        }
        return s;
      });
    }
    this.store.set("sessions", remainingSessions);
    return removedCount;
  }
  /**
   * Get Sessions By Account ID
   */
  getSessionsByAccountId(accountId) {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    return sessions.filter((s) => s.accountId === accountId);
  }
  /**
   * Get Sessions By Provider ID
   */
  getSessionsByProviderId(providerId) {
    this.ensureInitialized();
    const sessions = this.store.get("sessions") || [];
    return sessions.filter((s) => s.providerId === providerId);
  }
  /**
   * Clear All Sessions
   */
  clearAllSessions() {
    this.ensureInitialized();
    this.store.set("sessions", []);
  }
  // ==================== Model Management Operations ====================
  /**
   * Get User Model Overrides
   */
  getUserModelOverrides() {
    this.ensureInitialized();
    return this.store.get("userModelOverrides") || DEFAULT_USER_MODEL_OVERRIDES;
  }
  /**
   * Set User Model Overrides
   */
  setUserModelOverrides(overrides) {
    this.ensureInitialized();
    this.store.set("userModelOverrides", overrides);
  }
  /**
   * Get Provider Model Overrides
   */
  getProviderModelOverrides(providerId) {
    const overrides = this.getUserModelOverrides();
    return overrides[providerId] || {
      addedModels: [],
      excludedModels: []
    };
  }
  /**
   * Get Effective Models for a Provider
   * Merges default models with user overrides
   */
  getEffectiveModels(providerId) {
    this.ensureInitialized();
    const provider = this.getProviderById(providerId);
    if (!provider) {
      return [];
    }
    const defaultModels = provider.supportedModels || [];
    const modelMappings = provider.modelMappings || {};
    const overrides = this.getProviderModelOverrides(providerId);
    const effectiveModels = [];
    defaultModels.forEach((displayName) => {
      if (!overrides.excludedModels.includes(displayName)) {
        const actualModelId = modelMappings[displayName] || displayName;
        effectiveModels.push({
          displayName,
          actualModelId,
          isCustom: false
        });
      }
    });
    overrides.addedModels.forEach((customModel) => {
      effectiveModels.push({
        displayName: customModel.displayName,
        actualModelId: customModel.actualModelId,
        isCustom: true
      });
    });
    return effectiveModels;
  }
  /**
   * Add Custom Model to Provider
   */
  addCustomModel(providerId, model) {
    this.ensureInitialized();
    const overrides = this.getUserModelOverrides();
    if (!overrides[providerId]) {
      overrides[providerId] = {
        addedModels: [],
        excludedModels: []
      };
    }
    const existingModel = overrides[providerId].addedModels.find(
      (m) => m.displayName === model.displayName || m.actualModelId === model.actualModelId
    );
    if (existingModel) {
      throw new Error(`Model with display name "${model.displayName}" or actual ID "${model.actualModelId}" already exists`);
    }
    overrides[providerId].addedModels.push(model);
    this.setUserModelOverrides(overrides);
    return this.getEffectiveModels(providerId);
  }
  /**
   * Remove Model from Provider
   * For default models: add to excludedModels
   * For custom models: remove from addedModels
   */
  removeModel(providerId, modelName) {
    this.ensureInitialized();
    const provider = this.getProviderById(providerId);
    if (!provider) {
      throw new Error("Provider not found");
    }
    const overrides = this.getUserModelOverrides();
    if (!overrides[providerId]) {
      overrides[providerId] = {
        addedModels: [],
        excludedModels: []
      };
    }
    const defaultModels = provider.supportedModels || [];
    const isDefaultModel = defaultModels.includes(modelName);
    if (isDefaultModel) {
      if (!overrides[providerId].excludedModels.includes(modelName)) {
        overrides[providerId].excludedModels.push(modelName);
      }
    } else {
      overrides[providerId].addedModels = overrides[providerId].addedModels.filter(
        (m) => m.displayName !== modelName
      );
    }
    this.setUserModelOverrides(overrides);
    return this.getEffectiveModels(providerId);
  }
  /**
   * Reset Provider Models to Default
   * Removes all user overrides for the provider
   */
  resetModels(providerId) {
    this.ensureInitialized();
    const overrides = this.getUserModelOverrides();
    if (overrides[providerId]) {
      delete overrides[providerId];
      this.setUserModelOverrides(overrides);
    }
    const builtinConfig = builtinProviders.find((provider) => provider.id === providerId);
    if (builtinConfig) {
      const providers = (this.store.get("providers") || []).map((provider) => {
        if (provider.id !== providerId || provider.type !== "builtin") {
          return provider;
        }
        return {
          ...provider,
          apiEndpoint: builtinConfig.apiEndpoint,
          chatPath: builtinConfig.chatPath,
          supportedModels: builtinConfig.supportedModels,
          modelMappings: builtinConfig.modelMappings,
          headers: builtinConfig.headers,
          credentialFields: builtinConfig.credentialFields,
          description: builtinConfig.description,
          modelsApiEndpoint: builtinConfig.modelsApiEndpoint,
          modelsApiHeaders: builtinConfig.modelsApiHeaders,
          updatedAt: Date.now()
        };
      });
      this.store.set("providers", providers);
    }
    return this.getEffectiveModels(providerId);
  }
  // ==================== Utility Methods ====================
  /**
   * Generate Unique ID
   */
  generateId() {
    return `${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
  }
  /**
   * Get Storage Instance (for internal use only)
   */
  getStore() {
    return this.store;
  }
  /**
   * Clear All Data
   */
  clearAll() {
    this.ensureInitialized();
    this.appLogManager?.clearLogs();
    this.appLogManager?.flushSync();
    this.store.clear();
    this.requestLogManager?.clearRequestLogs();
    this.requestLogManager?.flushSync();
  }
  /**
   * Export Data (for backup)
   * Does not include encrypted credential data
   */
  exportData() {
    this.ensureInitialized();
    const providers = this.store.get("providers") || [];
    const accounts = (this.store.get("accounts") || []).map((a) => {
      const { credentials, ...rest } = a;
      return rest;
    });
    const config = this.store.get("config") || DEFAULT_CONFIG;
    const logs = this.getAppLogManager().exportLogs();
    const requestLogs = this.getRequestLogManager().exportRequestLogs();
    const systemPrompts = this.store.get("systemPrompts") || [];
    const sessions = this.store.get("sessions") || [];
    const statistics = this.store.get("statistics") || DEFAULT_STATISTICS;
    const userModelOverrides = this.store.get("userModelOverrides") || DEFAULT_USER_MODEL_OVERRIDES;
    return {
      providers,
      accounts,
      config,
      logs,
      requestLogs,
      systemPrompts,
      sessions,
      statistics,
      userModelOverrides
    };
  }
  /**
   * Get Storage Path
   */
  getStorePath() {
    return this.getStoragePath();
  }
  getRequestLogManager() {
    if (!this.requestLogManager) {
      throw new Error("Request log manager is not initialized");
    }
    return this.requestLogManager;
  }
  getAppLogManager() {
    if (!this.appLogManager) {
      throw new Error("App log manager is not initialized");
    }
    return this.appLogManager;
  }
}
const storeManager = new StoreManager();
const VALID_STRATEGIES = /* @__PURE__ */ new Set([
  "round-robin",
  "fill-first",
  "failover"
]);
function parsePort(value) {
  if (!value) {
    return void 0;
  }
  const parsed = Number.parseInt(value, 10);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > 65535) {
    throw new Error(`Invalid CHAT2API_PORT: ${value}`);
  }
  return parsed;
}
function parseBoolean(value) {
  if (value === void 0) {
    return void 0;
  }
  return ["1", "true", "yes", "on"].includes(value.toLowerCase());
}
function createServerConfigOverrides() {
  const overrides = {};
  const port = parsePort(process.env.CHAT2API_PORT);
  const host = process.env.CHAT2API_HOST;
  const strategy = process.env.CHAT2API_LOAD_BALANCE_STRATEGY;
  const enableManagementApi = parseBoolean(process.env.CHAT2API_ENABLE_MANAGEMENT_API);
  const managementSecret = process.env.CHAT2API_MANAGEMENT_SECRET;
  const enableApiKey = parseBoolean(process.env.CHAT2API_ENABLE_API_KEY);
  const logLevel = process.env.CHAT2API_LOG_LEVEL;
  if (port !== void 0) {
    overrides.proxyPort = port;
  }
  if (host) {
    overrides.proxyHost = host;
  }
  if (strategy) {
    if (!VALID_STRATEGIES.has(strategy)) {
      throw new Error(`Invalid CHAT2API_LOAD_BALANCE_STRATEGY: ${strategy}`);
    }
    overrides.loadBalanceStrategy = strategy;
  }
  if (logLevel) {
    if (!["debug", "info", "warn", "error"].includes(logLevel)) {
      throw new Error(`Invalid CHAT2API_LOG_LEVEL: ${logLevel}`);
    }
    overrides.logLevel = logLevel;
  }
  if (enableApiKey !== void 0) {
    overrides.enableApiKey = enableApiKey;
  }
  if (enableManagementApi !== void 0 || managementSecret) {
    overrides.managementApi = {
      enableManagementApi: enableManagementApi ?? Boolean(managementSecret),
      managementApiSecret: managementSecret || ""
    };
  }
  return overrides;
}
function applyServerConfigOverrides() {
  const overrides = createServerConfigOverrides();
  if (Object.keys(overrides).length === 0) {
    return storeManager.getConfig();
  }
  return storeManager.updateConfig(overrides);
}
exports.DEFAULT_CONFIG = DEFAULT_CONFIG;
exports.DEFAULT_TOOL_CALLING_CONFIG = DEFAULT_TOOL_CALLING_CONFIG;
exports.applyServerConfigOverrides = applyServerConfigOverrides;
exports.builtinProviders = builtinProviders;
exports.createServerConfigOverrides = createServerConfigOverrides;
exports.getBuiltinProvider = getBuiltinProvider;
exports.getRuntime = getRuntime;
exports.normalizeToolCallingConfig = normalizeToolCallingConfig;
exports.setRuntime = setRuntime;
exports.storeManager = storeManager;
