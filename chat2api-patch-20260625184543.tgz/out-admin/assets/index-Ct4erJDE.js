import{r as o}from"./admin-oeBYF4aB.js";var n=o.createContext(void 0);function i(t){const r=o.useContext(n);return t||r||"ltr"}function c(t,[r,e]){return Math.min(e,Math.max(r,t))}export{c,i as u};
