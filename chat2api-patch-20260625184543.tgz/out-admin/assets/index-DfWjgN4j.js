import{c as h,r as c,U as d}from"./admin-oeBYF4aB.js";/**
 * @license lucide-react v0.454.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const b=h("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);function v(r){const e=c.useRef({value:r,previous:r});return c.useMemo(()=>(e.current.value!==r&&(e.current.previous=e.current.value,e.current.value=r),e.current.previous),[r])}function x(r){const[e,t]=c.useState(void 0);return d(()=>{if(r){t({width:r.offsetWidth,height:r.offsetHeight});const n=new ResizeObserver(s=>{if(!Array.isArray(s)||!s.length)return;const f=s[0];let i,o;if("borderBoxSize"in f){const u=f.borderBoxSize,a=Array.isArray(u)?u[0]:u;i=a.inlineSize,o=a.blockSize}else i=r.offsetWidth,o=r.offsetHeight;t({width:i,height:o})});return n.observe(r,{box:"border-box"}),()=>n.unobserve(r)}else t(void 0)},[r]),e}export{b as T,v as a,x as u};
